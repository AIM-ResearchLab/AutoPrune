# AutoPrune

This repository contains the code for **AutoPrune**, an LLM-driven visual-token pruning policy design framework based on TPDSL.

## Overview

AutoPrune represents visual-token pruning policies as TPDSL-structured residual search states over a base pruning policy. It supports:

- TPDSL-based pruning-policy search
- safety-validated policy materialization
- residual token refinement
- cross-budget and cross-backbone policy re-instantiation
- ablation studies for TPDSL components and residual exchange quota

## Repository Structure

- `tools/`: core scripts for TPDSL search, policy materialization, and ablation experiments.
- `openevolve/`: evaluator-guided search utilities and TPDSL policy search components.
- `cdpruner_policy/`: TPDSL policy loading, execution, verification, and atom definitions.
- `yaml_policy/`: TPDSL policy definitions and atom registries.
- `configs/`: selected policy and ablation configurations.
- `policies/`: materialized pruning policies and selected TPDSL states.
- `scripts/`: benchmark evaluation and data/result conversion scripts.

## Data and Model Checkpoints

Model checkpoints, benchmark datasets, and generated outputs are not included. Please download the corresponding MLLM checkpoints and benchmark datasets separately.

Before running experiments, update local paths to model checkpoints and datasets according to your environment.

## API Keys

No API key is included in this repository. If LLM-driven search is used, set the API key through environment variables, for example:

```bash
export OPENAI_API_KEY=your_api_key
```

or

```bash
export DASHSCOPE_API_KEY=your_api_key
```

## Citation

If you use this code, please cite our paper.

## License

This repository is released for academic and non-commercial research use only. Commercial use is prohibited without prior permission.

## Environment Variables

The evaluation scripts use local paths for model checkpoints and datasets. Before running evaluation, set:

```bash
export CKPT_DIR=/path/to/hf_models
export DATA_DIR=/path/to/eval_data
```

For LLM-driven policy search, set the corresponding API key through environment variables, for example:

```bash
export OPENAI_API_KEY=your_api_key
```

or

```bash
export DASHSCOPE_API_KEY=your_api_key
```
