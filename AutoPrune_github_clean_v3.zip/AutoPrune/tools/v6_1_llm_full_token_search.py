#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, re, subprocess, sys
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional
import yaml

ATOM_ALIAS={
 'cdpruner_prior':'cdpruner_prior','relevance':'relevance','norm':'norm','spatial':'spatial','redundancy':'redundancy','attn':'attn','attention':'attn','similarity':'similarity',
 'cdpruner_default_soft_score':'cdpruner_prior','instruction_guided_visual_relevance':'relevance','visual_token_norm_saliency':'norm','spatial_centrality_prior':'spatial','redundancy_density_penalty':'redundancy','attention_proxy_saliency':'attn','pairwise_token_similarity':'similarity','conditional_similarity_score':'similarity'
}
SCORER_SPECS={
 'cdpruner_prior':{'atom':'cdpruner_default_soft_score','params':{'quality_weight':0.75,'diversity_weight':0.25,'transform':'minmax'}},
 'relevance':{'atom':'instruction_guided_visual_relevance','params':{'sign':'negative_mean','transform':'minmax','power':1.0}},
 'norm':{'atom':'visual_token_norm_saliency','params':{'transform':'minmax'}},
 'spatial':{'atom':'spatial_centrality_prior','params':{'center_bias':1.0,'transform':'minmax'}},
 'redundancy':{'atom':'redundancy_density_penalty','params':{'transform':'minmax'}},
 'attn':{'atom':'attention_proxy_saliency','params':{'norm_weight':0.7,'center_weight':0.3,'transform':'minmax'}},
 'similarity':{'atom':'pairwise_token_similarity','params':{'similarity_metric':'cosine','similarity_transform':'identity'}},
}
ATOM_CARDS="""Available full-token atoms.
Scalar scorers [B,N] that may appear in fusion weights:
- cdpruner_prior / cdpruner_default_soft_score
- relevance / instruction_guided_visual_relevance
- norm / visual_token_norm_saliency
- spatial / spatial_centrality_prior
- redundancy / redundancy_density_penalty
- attn / attention_proxy_saliency
Similarity atom [B,N,N]: similarity / pairwise_token_similarity is for MMR/DPP only and must NOT appear in fusion weights.
Selectors: topk_selector, full_token_pool_dpp_selector, full_token_pool_mmr_selector, stratified_full_token_selector.
Budget: keep_tokens=host_argument.
"""
KNOWN_FAILURE_MEMORY="""Known failed pattern: low-overlap full_token_pool_mmr_selector policies with overlap about 0.15 and changed about 27/32 can look good on smoke chunks but failed full MME badly: perception about 1288, far below Default-32 about 1369. Avoid repeatedly proposing low-overlap MMR-only policies. Prefer diverse selector families and designs that preserve more soft-prior structure, reduce excessive diversity, or use topK/DPP/stratified alternatives. This is failure feedback, not a hard constraint."""
FALLBACK_FAMILIES=[
 {'family_name':'fallback_prior_topk_strong_teacher','scorers':['cdpruner_prior','relevance'],'weights':{'cdpruner_prior':0.90,'relevance':0.10},'selector':{'atom':'topk_selector','params':{}},'rationale':'strong soft prior'},
 {'family_name':'fallback_prior_dpp_conservative','scorers':['cdpruner_prior','relevance','similarity'],'weights':{'cdpruner_prior':0.85,'relevance':0.15},'selector':{'atom':'full_token_pool_dpp_selector','params':{'pool_multiplier':2.0,'postprocess':'sort_by_position'}},'rationale':'conservative DPP'},
 {'family_name':'fallback_stratified_soft_prior','scorers':['cdpruner_prior','relevance','spatial'],'weights':{'cdpruner_prior':0.80,'relevance':0.15,'spatial':0.05},'selector':{'atom':'stratified_full_token_selector','params':{'core_ratio':0.875,'grid_size':4}},'rationale':'stratified coverage'},
 {'family_name':'fallback_mmr_high_lambda','scorers':['cdpruner_prior','relevance','similarity'],'weights':{'cdpruner_prior':0.85,'relevance':0.15},'selector':{'atom':'full_token_pool_mmr_selector','params':{'pool_multiplier':2.0,'mmr_lambda':0.97,'postprocess':'sort_by_position'}},'rationale':'safe MMR'},
]

def cjson(o): return json.dumps(o,ensure_ascii=False,sort_keys=True)
def fp(o): return hashlib.sha1(cjson(o).encode()).hexdigest()[:16]
def extract_json(text):
    m=re.search(r"```(?:json)?\s*([\s\S]*?)```",text)
    if m: text=m.group(1)
    st=text.find('{')
    if st<0: return None
    d=0
    for i in range(st,len(text)):
        if text[i]=='{': d+=1
        elif text[i]=='}':
            d-=1
            if d==0:
                try: return json.loads(text[st:i+1])
                except Exception: return None
    return None

def canon_scorer(x):
    if not isinstance(x,str): return None
    return ATOM_ALIAS.get(x.strip(),ATOM_ALIAS.get(x.strip().lower()))
def norm_sel(atom):
    atom=str(atom or 'full_token_pool_mmr_selector')
    alias={'mmr':'full_token_pool_mmr_selector','pool_mmr':'full_token_pool_mmr_selector','dpp':'full_token_pool_dpp_selector','pool_dpp':'full_token_pool_dpp_selector','topk':'topk_selector','top_k':'topk_selector','stratified':'stratified_full_token_selector'}
    atom=alias.get(atom,atom)
    return atom if atom in {'topk_selector','full_token_pool_dpp_selector','full_token_pool_mmr_selector','stratified_full_token_selector'} else 'full_token_pool_mmr_selector'

def sanitize_family(plan, idx):
    name=str(plan.get('family_name',f'llm_family_{idx}')).replace(' ','_')
    raw=plan.get('scorers',['cdpruner_prior','relevance','similarity'])
    if not isinstance(raw,list): raw=['cdpruner_prior','relevance','similarity']
    scorers=[]
    for s in raw:
        c=canon_scorer(s)
        if c and c not in scorers: scorers.append(c)
    if 'cdpruner_prior' not in scorers: scorers.insert(0,'cdpruner_prior')
    if 'relevance' not in scorers: scorers.append('relevance')
    sel=plan.get('selector',{}) if isinstance(plan.get('selector',{}),Mapping) else {}
    atom=norm_sel(sel.get('atom','full_token_pool_mmr_selector')); params=sel.get('params',{}) if isinstance(sel.get('params',{}),Mapping) else {}
    if atom in {'full_token_pool_dpp_selector','full_token_pool_mmr_selector'} and 'similarity' not in scorers: scorers.append('similarity')
    raww=plan.get('weights',{}) if isinstance(plan.get('weights',{}),Mapping) else {}
    weights={}
    for k,v in raww.items():
        ck=canon_scorer(k)
        if ck and ck!='similarity':
            try: weights[ck]=max(0.0,float(v))
            except Exception: pass
    scalar=[s for s in scorers if s!='similarity']
    if not weights or sum(weights.values())<=1e-9: weights={'cdpruner_prior':0.75,'relevance':0.25}
    weights={k:v for k,v in weights.items() if k in scalar}
    for s in scalar: weights.setdefault(s,0.0)
    if sum(weights.values())<=1e-9: weights={'cdpruner_prior':0.75,'relevance':0.25}
    return {'family_name':name,'scorers':scorers,'weights':weights,'selector':{'atom':atom,'params':dict(params)},'rationale':str(plan.get('rationale',''))}

def policy_from_family(fam,suffix=''):
    scorers={s:SCORER_SPECS[s] for s in fam['scorers'] if s in SCORER_SPECS}
    sel=fam['selector']['atom']
    if sel in {'full_token_pool_dpp_selector','full_token_pool_mmr_selector'}: scorers.setdefault('similarity',SCORER_SPECS['similarity'])
    weights=dict(fam['weights']); weights.pop('similarity',None); total=sum(abs(float(v)) for v in weights.values()) or 1.0
    weights={k:round(float(v)/total,4) for k,v in weights.items()}
    return {'version':'0.5-light','policy_name':(fam['family_name']+suffix).replace(' ','_'),'target_host':'cdpruner_encode_images','target_domain':'mllm_visual_token_pruning','search_stage':'v6_1_failure_aware_full_token_search','pipeline':[{'id':'visual_token_selection','trigger':{'atom':'pre_llm_visual_reduction_trigger'},'target':{'atom':'image_patch_tokens'},'scorer':scorers,'fusion':{'atom':'full_token_score_fusion','params':{'weights':weights,'score_normalization':'minmax','output_transform':'minmax'}},'budget':{'atom':'fixed_keep_tokens','params':{'keep_tokens':'host_argument'}},'selector':fam['selector'],'action':{'atom':'hard_prune'},'protection':[]}]}

def selector_balanced_variants(fam,max_variants):
    scalar=[s for s in fam['scorers'] if s!='similarity']
    if 'cdpruner_prior' not in scalar: scalar.insert(0,'cdpruner_prior')
    if 'relevance' not in scalar: scalar.append('relevance')
    aux=[s for s in scalar if s not in {'cdpruner_prior','relevance'}]
    weight_variants=[dict(fam['weights'])]
    for wp,wr,wa in [(0.90,0.10,0.00),(0.85,0.15,0.00),(0.80,0.15,0.05),(0.75,0.20,0.05),(0.70,0.25,0.05),(0.65,0.30,0.05)]:
        w={'cdpruner_prior':wp,'relevance':wr}
        if aux and wa>0:
            for a in aux: w[a]=wa/len(aux)
        weight_variants.append(w)
    selectors=[
      ('topk_selector',{}),
      ('full_token_pool_dpp_selector',{'pool_multiplier':1.5,'postprocess':'sort_by_position'}),
      ('full_token_pool_dpp_selector',{'pool_multiplier':2.0,'postprocess':'sort_by_position'}),
      ('full_token_pool_dpp_selector',{'pool_multiplier':3.0,'postprocess':'sort_by_position'}),
      ('full_token_pool_mmr_selector',{'pool_multiplier':1.5,'mmr_lambda':0.95,'postprocess':'sort_by_position'}),
      ('full_token_pool_mmr_selector',{'pool_multiplier':2.0,'mmr_lambda':0.95,'postprocess':'sort_by_position'}),
      ('full_token_pool_mmr_selector',{'pool_multiplier':2.0,'mmr_lambda':0.98,'postprocess':'sort_by_position'}),
      ('stratified_full_token_selector',{'core_ratio':0.875,'grid_size':4}),
      ('stratified_full_token_selector',{'core_ratio':0.95,'grid_size':4}),
    ]
    llm_sel=fam['selector']['atom']; llm_params=dict(fam['selector'].get('params',{}))
    selectors.insert(0,(llm_sel,llm_params))
    out=[]; seen=set()
    for sel,params in selectors:
        for weights in weight_variants:
            vf={'family_name':fam['family_name'],'scorers':list(dict.fromkeys(scalar+(['similarity'] if sel in {'full_token_pool_dpp_selector','full_token_pool_mmr_selector'} else []))),'weights':dict(weights),'selector':{'atom':sel,'params':dict(params)},'rationale':fam.get('rationale','')}
            f=fp(vf)
            if f in seen: continue
            seen.add(f); out.append(vf)
            if len(out)>=max_variants: return out
    return out

def build_prompt(history,iteration,k):
    top=sorted(history,key=lambda r:float(r.get('adjusted_score',r.get('combined_score',0.0))),reverse=True)[:10]
    hist=[{'policy':r.get('policy_name'),'adjusted_score':r.get('adjusted_score'),'robust':r.get('combined_score'),'perception_mean':r.get('perception_mean'),'perception_std':r.get('perception_std'),'overlap':r.get('overlap_with_reference_avg'),'changed':r.get('changed_tokens_avg'),'selector':r.get('selector'),'weights':r.get('weights')} for r in top]
    return f'''You design a full-token visual token pruning policy family for LLaVA/CDPruner.
Goal: select exactly K={k} visual tokens from all image tokens. Do NOT choose fixed token IDs. Do NOT use hard CDPruner mask anchor or residual swap. CDPruner may be used only as soft prior scorer.
Failure memory:\n{KNOWN_FAILURE_MEMORY}\n\nAtom cards and aliases:\n{ATOM_CARDS}\n\nHistorical evaluated candidates, best first:\n{json.dumps(hist,indent=2,ensure_ascii=False)}\n\nReturn JSON only. You may use aliases or real atom names. Similarity must not appear in fusion weights. Schema:\n{{"family_name":"short_unique_name","scorers":["cdpruner_prior","relevance","norm|spatial|redundancy|attn","similarity"],"weights":{{"cdpruner_prior":0.8,"relevance":0.15,"norm":0.05}},"selector":{{"atom":"topk_selector|full_token_pool_dpp_selector|full_token_pool_mmr_selector|stratified_full_token_selector","params":{{}}}},"rationale":"why this should generalize beyond one smoke chunk"}}'''

def call_llm(prompt,args):
    if not os.environ.get('OPENAI_API_KEY'): return None
    try:
        from openai import OpenAI
        kw={'api_key':os.environ['OPENAI_API_KEY']}
        if os.environ.get('OPENAI_BASE_URL'): kw['base_url']=os.environ['OPENAI_BASE_URL']
        client=OpenAI(**kw)
        resp=client.chat.completions.create(model=args.model,messages=[{'role':'system','content':'You are an expert at search-space design. Return strict JSON only.'},{'role':'user','content':prompt}],temperature=args.temperature,max_tokens=args.max_tokens)
        return extract_json(resp.choices[0].message.content or '')
    except Exception as e:
        print('[LLM_ERROR]',e,flush=True); return None

def first_json(text):
    st=text.find('{')
    if st<0: return {}
    d=0
    for i in range(st,len(text)):
        if text[i]=='{': d+=1
        elif text[i]=='}':
            d-=1
            if d==0:
                try: return json.loads(text[st:i+1])
                except Exception: return {}
    return {}

def eval_multismoke(policy_path,args,log_dir):
    cmd=[sys.executable,'yaml_policy/openevolve_yaml_search/evaluator_multismoke.py',str(policy_path),'--gpu',str(args.gpu),'--token',str(args.token),'--base-script',str(args.base_script),'--num-chunks',str(args.num_chunks),'--chunks',args.chunks,'--std-penalty',str(args.std_penalty),'--log-dir',str(log_dir)]
    env=os.environ.copy(); env['EVO_TOKEN']=str(args.token); env['EVO_FORCE_FIXED_TOKENS']=str(args.token)
    proc=subprocess.run(cmd,cwd=Path.cwd(),env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    log_dir.mkdir(parents=True,exist_ok=True); (log_dir/'multismoke_stdout.txt').write_text(proc.stdout)
    row=first_json(proc.stdout)
    return row if row else {'valid':0.0,'combined_score':0.0,'error':'parse_failed','stdout_tail':proc.stdout[-2000:]}

def apply_penalty(row,args):
    r=dict(row); robust=float(r.get('combined_score',0.0)); overlap=float(r.get('overlap_with_reference_avg',0.0)); changed=float(r.get('changed_tokens_avg',0.0))
    op=args.low_overlap_penalty*max(0.0,args.low_overlap_floor-overlap)
    cp=args.changed_penalty*max(0.0,changed-args.changed_soft_ceiling)
    r['raw_robust_score']=robust; r['overlap_penalty']=op; r['changed_penalty']=cp; r['adjusted_score']=robust-op-cp
    return r

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--gpu',default=os.environ.get('EVO_GPU','3')); ap.add_argument('--token',type=int,default=int(os.environ.get('EVO_TOKEN',os.environ.get('EVO_FORCE_FIXED_TOKENS','32'))))
    ap.add_argument('--base-script',default='scripts/v1_5/eval/mme_yaml_smoke21.sh'); ap.add_argument('--chunks',default='0,1,2'); ap.add_argument('--num-chunks',type=int,default=21)
    ap.add_argument('--families',type=int,default=8); ap.add_argument('--variants-per-family',type=int,default=12); ap.add_argument('--std-penalty',type=float,default=0.5); ap.add_argument('--out-dir',default=None)
    ap.add_argument('--model',default=os.environ.get('V6_LLM_MODEL','qwen-plus')); ap.add_argument('--temperature',type=float,default=float(os.environ.get('V6_LLM_TEMPERATURE','0.85'))); ap.add_argument('--max-tokens',type=int,default=int(os.environ.get('V6_LLM_MAX_TOKENS','1600')))
    ap.add_argument('--low-overlap-floor',type=float,default=0.25); ap.add_argument('--low-overlap-penalty',type=float,default=100.0); ap.add_argument('--changed-soft-ceiling',type=float,default=24.0); ap.add_argument('--changed-penalty',type=float,default=1.0)
    args=ap.parse_args()
    out_dir=Path(args.out_dir or f'openevolve/runs/v6_1_llm_full_token_K{args.token}_multismoke'); policy_dir=out_dir/'policies'; log_dir=out_dir/'logs'; prompt_dir=out_dir/'prompts'
    for d in [policy_dir,log_dir,prompt_dir]: d.mkdir(parents=True,exist_ok=True)
    results_path=out_dir/'results.jsonl'; history=[]; evaluated=set(); best=None; fallback_i=0
    for fam_i in range(args.families):
        prompt=build_prompt(history,fam_i,args.token); (prompt_dir/f'family_{fam_i:03d}_prompt.txt').write_text(prompt)
        plan=call_llm(prompt,args)
        if plan is None:
            plan=FALLBACK_FAMILIES[fallback_i%len(FALLBACK_FAMILIES)]; fallback_i+=1
        (prompt_dir/f'family_{fam_i:03d}_raw_plan.json').write_text(json.dumps(plan,indent=2,ensure_ascii=False))
        fam=sanitize_family(plan,fam_i); (prompt_dir/f'family_{fam_i:03d}_sanitized_plan.json').write_text(json.dumps(fam,indent=2,ensure_ascii=False))
        for var_i,vfam in enumerate(selector_balanced_variants(fam,args.variants_per_family)):
            f=fp(vfam)
            if f in evaluated: continue
            evaluated.add(f)
            policy=policy_from_family(vfam,f'_f{fam_i:02d}_v{var_i:02d}'); pname=policy['policy_name']; ppath=policy_dir/f'{len(evaluated):04d}_{pname}.yaml'; ppath.write_text(yaml.safe_dump(policy,sort_keys=False,allow_unicode=True))
            print(f'[EVAL] family={fam_i} variant={var_i} {pname}',flush=True)
            row=apply_penalty(eval_multismoke(ppath,args,log_dir/f'{len(evaluated):04d}_{pname}'),args)
            row.update({'policy_name':pname,'policy_path':str(ppath),'family_plan':fam,'weights':policy['pipeline'][0]['fusion']['params']['weights'],'selector':policy['pipeline'][0]['selector']['atom'],'selector_params':policy['pipeline'][0]['selector'].get('params',{})})
            with results_path.open('a',encoding='utf-8') as fobj: fobj.write(json.dumps(row,ensure_ascii=False)+'\n')
            history.append(row); score=float(row.get('adjusted_score',0.0))
            if best is None or score>float(best.get('adjusted_score',-1e18)):
                best=row; (out_dir/'best_policy.yaml').write_text(ppath.read_text()); (out_dir/'best_metrics.json').write_text(json.dumps(row,indent=2,ensure_ascii=False))
                print(f"[BEST] {pname} adjusted={score:.4f} robust={row.get('combined_score')} overlap={row.get('overlap_with_reference_avg')} selector={row.get('selector')}",flush=True)
    rows=[]
    if results_path.exists():
        for line in results_path.read_text().splitlines():
            try: rows.append(json.loads(line))
            except Exception: pass
    fields=['policy_name','valid','adjusted_score','raw_robust_score','combined_score','perception_mean','perception_std','perception_min','cognition_mean','overlap_with_reference_avg','changed_tokens_avg','overlap_penalty','changed_penalty','selector','policy_path']
    with (out_dir/'results.csv').open('w',newline='',encoding='utf-8') as fobj:
        w=csv.DictWriter(fobj,fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k:r.get(k) for k in fields})
    print('done'); print('results:',results_path); print('best:',out_dir/'best_policy.yaml')
if __name__=='__main__': main()
