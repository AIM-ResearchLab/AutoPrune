#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    if not path.exists():
        raise SystemExit(f"missing file: {path}")
    return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]


def safe_float(x, default=0.0):
    try:
        return float(x)
    except Exception:
        return default


def scorer_set(row: Dict[str, Any]) -> set:
    return set(row.get("scorer_atoms") or [])


def family_key(row: Dict[str, Any]) -> str:
    fusion = row.get("fusion")
    selector = row.get("selector")
    scorers = scorer_set(row)

    has_attn = "attention_proxy_saliency" in scorers
    has_sem = "instruction_guided_visual_relevance" in scorers
    has_sim = "pairwise_token_similarity" in scorers or "conditional_similarity_score" in scorers
    has_red = "redundancy_density_penalty" in scorers
    has_cov = "spatial_centrality_prior" in scorers
    has_norm = "visual_token_norm_saliency" in scorers

    if selector == "topk_pool_dpp_selector" and has_red:
        return "pool_dpp_redundancy"
    if selector == "topk_pool_dpp_selector" and has_sem:
        return "pool_dpp_semantic"
    if selector == "topk_pool_dpp_selector" and has_cov:
        return "pool_dpp_coverage"
    if selector == "dpp_selector" and fusion == "quality_diversity_kernel" and has_attn and has_sim and len(scorers) <= 2:
        return "pure_global_attention_dpp"
    if selector == "dpp_selector" and has_cov:
        return "coverage_global_dpp"
    if selector == "mmr_selector":
        return "mmr_family"
    if selector == "stratified_full_token_selector":
        return "stratified_coverage"
    if has_norm:
        return "norm_uncertainty"
    return f"{fusion}:{selector}:{','.join(sorted(scorers))}"


def full_stable_prior(row: Dict[str, Any]) -> float:
    scorers = scorer_set(row)
    fusion = row.get("fusion")
    selector = row.get("selector")

    score = 0.0

    # Structure priors from observed full-MME behavior.
    if selector == "topk_pool_dpp_selector":
        score += 10.0
    if "redundancy_density_penalty" in scorers:
        score += 8.0
    if "pairwise_token_similarity" in scorers or "conditional_similarity_score" in scorers:
        score += 4.0
    if "instruction_guided_visual_relevance" in scorers:
        score += 4.0
    if "spatial_centrality_prior" in scorers:
        score += 2.0

    # Pure global DPP can overfit smoke.
    if selector == "dpp_selector" and fusion == "quality_diversity_kernel":
        if scorers == {"attention_proxy_saliency", "pairwise_token_similarity"}:
            score -= 8.0
        else:
            score -= 2.0

    changed = safe_float(row.get("changed_tokens_avg"), -1)
    overlap = safe_float(row.get("overlap_with_reference_avg"), -1)
    std = safe_float(row.get("perception_std"), 0)
    prs = safe_float(row.get("plan_realization_score"), 0)

    # Moderate deviation tends to be safer than extreme replacement.
    if 0.18 <= overlap <= 0.30:
        score += 6.0
    elif 0.12 <= overlap < 0.18:
        score += 2.0
    elif 0 <= overlap < 0.10:
        score -= 8.0

    if 23.0 <= changed <= 27.0:
        score += 3.0
    elif changed > 28.5:
        score -= 6.0

    # Prefer full-stable smoke signals.
    if std <= 12:
        score += 4.0
    elif std >= 25:
        score -= 5.0

    if prs >= 0.88:
        score += 4.0
    elif prs < 0.80:
        score -= 5.0

    if safe_float(row.get("fallback_count"), 0) > 0:
        score -= 100.0
    if safe_float(row.get("unsupported_count"), 0) > 0:
        score -= 100.0
    if safe_float(row.get("ignored_count"), 0) > 0:
        score -= 30.0

    return score


def adjusted_score(row: Dict[str, Any]) -> float:
    return safe_float(row.get("combined_score"), 0) + full_stable_prior(row)


def sanitize(name: str) -> str:
    name = re.sub(r"[^A-Za-z0-9_.-]+", "_", name)
    return name[:120]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True)
    ap.add_argument("--out-dir", required=True)
    ap.add_argument("--top-k", type=int, default=8)
    ap.add_argument("--gpu", default="3")
    ap.add_argument("--token", default="32")
    ap.add_argument("--script", default="scripts/v1_5/eval/mme.sh")
    args = ap.parse_args()

    run_dir = Path(args.run_dir)
    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    rows = load_jsonl(run_dir / "results.jsonl")
    rows = sorted(rows, key=lambda r: safe_float(r.get("combined_score"), 0), reverse=True)

    for i, r in enumerate(rows, 1):
        r["_smoke_rank"] = i
        r["_family_key"] = family_key(r)
        r["_full_stable_prior"] = full_stable_prior(r)
        r["_v84_adjusted_score"] = adjusted_score(r)

    selected: List[Dict[str, Any]] = []
    selected_names = set()
    selected_families = set()

    def add(row):
        name = row.get("policy_name")
        if not name or name in selected_names:
            return False
        selected.append(row)
        selected_names.add(name)
        selected_families.add(row["_family_key"])
        return True

    # Always keep the best smoke candidate and the best known full-stable pool-DPP style candidates.
    if rows:
        add(rows[0])

    # First pass: select one per family by adjusted score.
    by_adjusted = sorted(rows, key=lambda r: r["_v84_adjusted_score"], reverse=True)
    for r in by_adjusted:
        if len(selected) >= args.top_k:
            break
        if r["_family_key"] in selected_families:
            continue
        add(r)

    # Second pass: fill remaining slots by adjusted score.
    for r in by_adjusted:
        if len(selected) >= args.top_k:
            break
        add(r)

    selected = selected[: args.top_k]

    (out_dir / "selected_candidates.json").write_text(
        json.dumps(selected, indent=2, ensure_ascii=False)
    )

    # Markdown table.
    lines = []
    lines.append("| selected | smoke_rank | adjusted | smoke_score | prior | prs | family | fusion | selector | scorers | policy |")
    lines.append("|---:|---:|---:|---:|---:|---:|---|---|---|---|---|")
    for i, r in enumerate(selected, 1):
        lines.append(
            f"| {i} "
            f"| {r['_smoke_rank']} "
            f"| {r['_v84_adjusted_score']:.4f} "
            f"| {safe_float(r.get('combined_score')):.4f} "
            f"| {r['_full_stable_prior']:.2f} "
            f"| {safe_float(r.get('plan_realization_score')):.3f} "
            f"| {r['_family_key']} "
            f"| {r.get('fusion')} "
            f"| {r.get('selector')} "
            f"| {r.get('scorer_atoms')} "
            f"| {r.get('policy_name')} |"
        )
    (out_dir / "selected_table.md").write_text("\n".join(lines) + "\n")

    # Full MME run script.
    sh = []
    sh.append("set -e")
    sh.append("cd /data/lz/openevolve_pruner/CDPruner")
    sh.append(f"export EVO_GPU={args.gpu}")
    sh.append(f"export EVO_TOKEN={args.token}")
    sh.append(f"export EVO_FORCE_FIXED_TOKENS={args.token}")
    sh.append(f"mkdir -p {out_dir}")
    for i, r in enumerate(selected, 1):
        smoke_rank = r["_smoke_rank"]
        name = sanitize(r["policy_name"])
        policy_path = r["policy_path"]
        log_path = out_dir / f"selected{i:02d}_smoke{smoke_rank:02d}_{name}.full_mme.log"
        json_path = out_dir / f"selected{i:02d}_smoke{smoke_rank:02d}_{name}.metrics.json"
        sh.append("")
        sh.append(f'echo "===== FULL MME SELECTED {i} / SMOKE {smoke_rank}: {name} ====="')
        sh.append(
            f'python yaml_policy/openevolve_yaml_search/evaluator.py '
            f'"{policy_path}" '
            f'--gpu {args.gpu} '
            f'--token {args.token} '
            f'--script {args.script} '
            f'--log "{log_path}" '
            f'| tee "{json_path}"'
        )
    (out_dir / "run_full_selected.sh").write_text("\n".join(sh) + "\n")

    print("selected:", len(selected))
    print("table:", out_dir / "selected_table.md")
    print("run:", out_dir / "run_full_selected.sh")


if __name__ == "__main__":
    main()
