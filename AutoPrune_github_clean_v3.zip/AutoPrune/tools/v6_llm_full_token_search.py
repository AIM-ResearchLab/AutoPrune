#!/usr/bin/env python3
from __future__ import annotations
import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional
import yaml

ATOM_CARDS = """
Available full-token atoms.

Scorers:
- cdpruner_default_soft_score(params: quality_weight, diversity_weight, transform)
  Soft CDPruner teacher prior. Does NOT hard-anchor selected tokens.
- instruction_guided_visual_relevance(params: sign in {negative_mean,max,norm}, transform, power)
- visual_token_norm_saliency(params: transform)
- spatial_centrality_prior(params: center_bias, transform)
- redundancy_density_penalty(params: transform)
- attention_proxy_saliency(params: norm_weight, center_weight, transform)
- pairwise_token_similarity(params: similarity_metric=cosine, similarity_transform=identity)

Fusion:
- full_token_score_fusion(params: weights mapping, score_normalization, output_transform)

Selectors:
- topk_selector
- full_token_pool_dpp_selector(params: pool_multiplier, postprocess)
- full_token_pool_mmr_selector(params: pool_multiplier, mmr_lambda, postprocess)
- stratified_full_token_selector(params: core_ratio, grid_size)

Budget:
- fixed_keep_tokens(params: keep_tokens=host_argument). K is controlled externally. Do not hard-code K.
"""

SCORER_SPECS = {
    "cdpruner_prior": {"atom": "cdpruner_default_soft_score", "params": {"quality_weight": 0.75, "diversity_weight": 0.25, "transform": "minmax"}},
    "relevance": {"atom": "instruction_guided_visual_relevance", "params": {"sign": "negative_mean", "transform": "minmax", "power": 1.0}},
    "norm": {"atom": "visual_token_norm_saliency", "params": {"transform": "minmax"}},
    "spatial": {"atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}},
    "redundancy": {"atom": "redundancy_density_penalty", "params": {"transform": "minmax"}},
    "attn": {"atom": "attention_proxy_saliency", "params": {"norm_weight": 0.7, "center_weight": 0.3, "transform": "minmax"}},
    "similarity": {"atom": "pairwise_token_similarity", "params": {"similarity_metric": "cosine", "similarity_transform": "identity"}},
}

FALLBACK_FAMILIES = [
    {"family_name": "fallback_soft_prior_mmr_relevance", "scorers": ["cdpruner_prior", "relevance", "similarity"], "weights": {"cdpruner_prior": 0.55, "relevance": 0.45}, "selector": {"atom": "full_token_pool_mmr_selector", "params": {"pool_multiplier": 4.0, "mmr_lambda": 0.85, "postprocess": "sort_by_position"}}, "rationale": "Soft prior plus relevance with MMR."},
    {"family_name": "fallback_prior_norm_mmr", "scorers": ["cdpruner_prior", "relevance", "norm", "similarity"], "weights": {"cdpruner_prior": 0.60, "relevance": 0.30, "norm": 0.10}, "selector": {"atom": "full_token_pool_mmr_selector", "params": {"pool_multiplier": 3.0, "mmr_lambda": 0.90, "postprocess": "sort_by_position"}}, "rationale": "Add norm saliency."},
    {"family_name": "fallback_prior_redundancy_dpp", "scorers": ["cdpruner_prior", "relevance", "redundancy", "similarity"], "weights": {"cdpruner_prior": 0.65, "relevance": 0.25, "redundancy": 0.10}, "selector": {"atom": "full_token_pool_dpp_selector", "params": {"pool_multiplier": 2.0, "postprocess": "sort_by_position"}}, "rationale": "DPP with non-redundancy."},
    {"family_name": "fallback_stratified_prior", "scorers": ["cdpruner_prior", "relevance", "spatial"], "weights": {"cdpruner_prior": 0.70, "relevance": 0.20, "spatial": 0.10}, "selector": {"atom": "stratified_full_token_selector", "params": {"core_ratio": 0.875, "grid_size": 4}}, "rationale": "Mild spatial coverage."},
]


def canonical_json(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, sort_keys=True)


def fingerprint(obj: Any) -> str:
    return hashlib.sha1(canonical_json(obj).encode()).hexdigest()[:16]


def extract_json(text: str) -> Optional[Dict[str, Any]]:
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if m:
        text = m.group(1)
    start = text.find("{")
    if start < 0:
        return None
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i+1])
                except Exception:
                    return None
    return None


def first_json(text: str) -> Dict[str, Any]:
    start = text.find("{")
    if start < 0:
        return {}
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i+1])
                except Exception:
                    return {}
    return {}


def sanitize_family(plan: Mapping[str, Any], idx: int) -> Dict[str, Any]:
    name = str(plan.get("family_name", f"llm_family_{idx}"))
    scorers = plan.get("scorers", ["cdpruner_prior", "relevance", "similarity"])
    if not isinstance(scorers, list):
        scorers = ["cdpruner_prior", "relevance", "similarity"]
    scorers = [s for s in scorers if s in SCORER_SPECS]
    if "cdpruner_prior" not in scorers:
        scorers.insert(0, "cdpruner_prior")
    if "relevance" not in scorers:
        scorers.append("relevance")
    selector = plan.get("selector", {})
    if not isinstance(selector, Mapping):
        selector = {}
    atom = selector.get("atom", "full_token_pool_mmr_selector")
    if atom not in {"topk_selector", "full_token_pool_dpp_selector", "full_token_pool_mmr_selector", "stratified_full_token_selector"}:
        atom = "full_token_pool_mmr_selector"
    params = selector.get("params", {})
    if not isinstance(params, Mapping):
        params = {}
    weights = plan.get("weights", {})
    if not isinstance(weights, Mapping):
        weights = {}
    weights = {k: float(weights.get(k, 0.0)) for k in scorers if k != "similarity"}
    if sum(abs(x) for x in weights.values()) <= 1e-9:
        weights = {"cdpruner_prior": 0.65, "relevance": 0.35}
    return {"family_name": name, "scorers": scorers, "weights": weights, "selector": {"atom": atom, "params": dict(params)}, "rationale": str(plan.get("rationale", ""))}


def policy_from_family(fam: Mapping[str, Any], name_suffix: str = "") -> Dict[str, Any]:
    scorers = {s: SCORER_SPECS[s] for s in fam["scorers"] if s in SCORER_SPECS}
    if fam["selector"]["atom"] in {"full_token_pool_dpp_selector", "full_token_pool_mmr_selector"}:
        scorers.setdefault("similarity", SCORER_SPECS["similarity"])
    weights = dict(fam["weights"])
    total = sum(abs(float(v)) for v in weights.values()) or 1.0
    weights = {k: round(float(v) / total, 4) for k, v in weights.items()}
    return {
        "version": "0.5-light",
        "policy_name": (fam["family_name"] + name_suffix).replace(" ", "_"),
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "v6_llm_full_token_atom_search",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": scorers,
            "fusion": {"atom": "full_token_score_fusion", "params": {"weights": weights, "score_normalization": "minmax", "output_transform": "minmax"}},
            "budget": {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}},
            "selector": fam["selector"],
            "action": {"atom": "hard_prune"},
            "protection": [],
        }],
    }


def expand_family(fam: Dict[str, Any], max_variants: int) -> List[Dict[str, Any]]:
    base_weights = dict(fam["weights"])
    selector = fam["selector"]["atom"]
    base_params = dict(fam["selector"].get("params", {}))
    weight_variants = [base_weights]
    if "cdpruner_prior" in base_weights and "relevance" in base_weights:
        for wp, wr in [(0.85, 0.15), (0.75, 0.25), (0.65, 0.35), (0.55, 0.45)]:
            w = dict(base_weights)
            w["cdpruner_prior"] = wp
            w["relevance"] = wr
            others = [k for k in w if k not in {"cdpruner_prior", "relevance"}]
            if others:
                rem = max(0.0, 1.0 - wp - wr)
                for o in others:
                    w[o] = rem / len(others)
            weight_variants.append(w)
    if selector == "full_token_pool_mmr_selector":
        param_variants = []
        for lam in [base_params.get("mmr_lambda", 0.85), 0.75, 0.85, 0.90, 0.95]:
            for pm in [base_params.get("pool_multiplier", 4.0), 2.0, 3.0, 4.0]:
                param_variants.append({"pool_multiplier": float(pm), "mmr_lambda": float(lam), "postprocess": "sort_by_position"})
    elif selector == "full_token_pool_dpp_selector":
        param_variants = [{"pool_multiplier": float(pm), "postprocess": "sort_by_position"} for pm in [base_params.get("pool_multiplier", 4.0), 2.0, 3.0, 4.0]]
    elif selector == "stratified_full_token_selector":
        param_variants = [{"core_ratio": float(cr), "grid_size": int(base_params.get("grid_size", 4))} for cr in [base_params.get("core_ratio", 0.875), 0.75, 0.875, 0.95]]
    else:
        param_variants = [{}]
    variants, seen = [], set()
    for w in weight_variants:
        for pp in param_variants:
            nf = dict(fam)
            nf["weights"] = w
            nf["selector"] = {"atom": selector, "params": pp}
            fp = fingerprint(nf)
            if fp in seen:
                continue
            seen.add(fp)
            variants.append(nf)
            if len(variants) >= max_variants:
                return variants
    return variants


def build_prompt(history: List[Mapping[str, Any]], iteration: int, k: int) -> str:
    top = sorted(history, key=lambda r: float(r.get("combined_score", 0.0)), reverse=True)[:8]
    hist = []
    for r in top:
        hist.append({
            "policy": r.get("policy_name"),
            "robust": r.get("combined_score"),
            "perception_mean": r.get("perception_mean"),
            "perception_std": r.get("perception_std"),
            "overlap": r.get("overlap_with_reference_avg"),
            "changed": r.get("changed_tokens_avg"),
            "selector": r.get("selector"),
            "weights": r.get("weights"),
        })
    return f"""
You design a full-token visual token pruning policy family for LLaVA/CDPruner.

Goal:
- Select exactly K={k} visual tokens from all image tokens.
- Do NOT choose fixed token IDs.
- Do NOT use hard CDPruner mask anchor or residual swap.
- CDPruner may be used only as soft prior scorer.
- Optimize robust MME perception over multiple smoke chunks.
- Low overlap with CDPruner is allowed, but extremely low overlap previously overfit smoke and failed full MME. Use your judgment.

{ATOM_CARDS}

Historical evaluated candidates, best first:
{json.dumps(hist, indent=2, ensure_ascii=False)}

Return JSON only:
{{
  "family_name": "short_unique_name",
  "scorers": ["cdpruner_prior", "relevance", "norm|spatial|redundancy|attn", "similarity"],
  "weights": {{"cdpruner_prior": 0.6, "relevance": 0.3, "norm": 0.1}},
  "selector": {{"atom": "full_token_pool_mmr_selector", "params": {{"pool_multiplier": 4.0, "mmr_lambda": 0.85, "postprocess": "sort_by_position"}}}},
  "rationale": "why this may generalize across chunks"
}}
"""


def call_llm(prompt: str, args) -> Optional[Dict[str, Any]]:
    if not os.environ.get("OPENAI_API_KEY"):
        return None
    try:
        from openai import OpenAI
        kwargs = {"api_key": os.environ.get("OPENAI_API_KEY")}
        if os.environ.get("OPENAI_BASE_URL"):
            kwargs["base_url"] = os.environ["OPENAI_BASE_URL"]
        client = OpenAI(**kwargs)
        resp = client.chat.completions.create(
            model=args.model,
            messages=[
                {"role": "system", "content": "You are an expert at token pruning search-space design. Return strict JSON only."},
                {"role": "user", "content": prompt},
            ],
            temperature=args.temperature,
            max_tokens=args.max_tokens,
        )
        text = resp.choices[0].message.content or ""
        return extract_json(text)
    except Exception as e:
        print(f"[LLM_ERROR] {e}", flush=True)
        return None


def eval_multismoke(policy_path: Path, args, log_dir: Path) -> Dict[str, Any]:
    cmd = [
        sys.executable,
        "yaml_policy/openevolve_yaml_search/evaluator_multismoke.py",
        str(policy_path),
        "--gpu", str(args.gpu),
        "--token", str(args.token),
        "--base-script", str(args.base_script),
        "--num-chunks", str(args.num_chunks),
        "--chunks", args.chunks,
        "--std-penalty", str(args.std_penalty),
        "--log-dir", str(log_dir),
    ]
    env = os.environ.copy()
    env["EVO_TOKEN"] = str(args.token)
    env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
    proc = subprocess.run(cmd, cwd=Path.cwd(), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (log_dir / "multismoke_stdout.txt").write_text(proc.stdout)
    row = first_json(proc.stdout)
    if not row:
        row = {"valid": 0.0, "combined_score": 0.0, "error": "parse_failed", "stdout_tail": proc.stdout[-2000:]}
    return row


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU", "3"))
    ap.add_argument("--token", type=int, default=int(os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32"))))
    ap.add_argument("--base-script", default="scripts/v1_5/eval/mme_yaml_smoke21.sh")
    ap.add_argument("--chunks", default="0,1,2")
    ap.add_argument("--num-chunks", type=int, default=21)
    ap.add_argument("--families", type=int, default=8)
    ap.add_argument("--variants-per-family", type=int, default=8)
    ap.add_argument("--std-penalty", type=float, default=0.5)
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--model", default=os.environ.get("V6_LLM_MODEL", "gpt-4o-mini"))
    ap.add_argument("--temperature", type=float, default=float(os.environ.get("V6_LLM_TEMPERATURE", "0.85")))
    ap.add_argument("--max-tokens", type=int, default=int(os.environ.get("V6_LLM_MAX_TOKENS", "1600")))
    args = ap.parse_args()

    out_dir = Path(args.out_dir or f"openevolve/runs/v6_llm_full_token_K{args.token}_multismoke")
    policy_dir, log_dir, prompt_dir = out_dir / "policies", out_dir / "logs", out_dir / "prompts"
    for d in [policy_dir, log_dir, prompt_dir]:
        d.mkdir(parents=True, exist_ok=True)
    results_path = out_dir / "results.jsonl"

    history: List[Dict[str, Any]] = []
    evaluated_fp = set()
    best = None
    fallback_i = 0

    for fam_i in range(args.families):
        prompt = build_prompt(history, fam_i, args.token)
        (prompt_dir / f"family_{fam_i:03d}_prompt.txt").write_text(prompt)
        plan = call_llm(prompt, args)
        if plan is None:
            plan = FALLBACK_FAMILIES[fallback_i % len(FALLBACK_FAMILIES)]
            fallback_i += 1
        (prompt_dir / f"family_{fam_i:03d}_plan.json").write_text(json.dumps(plan, indent=2, ensure_ascii=False))

        fam = sanitize_family(plan, fam_i)
        variants = expand_family(fam, args.variants_per_family)
        for var_i, vfam in enumerate(variants):
            fp = fingerprint(vfam)
            if fp in evaluated_fp:
                continue
            evaluated_fp.add(fp)
            policy = policy_from_family(vfam, f"_f{fam_i:02d}_v{var_i:02d}")
            policy_name = policy["policy_name"]
            policy_path = policy_dir / f"{len(evaluated_fp):04d}_{policy_name}.yaml"
            policy_path.write_text(yaml.safe_dump(policy, sort_keys=False, allow_unicode=True))
            print(f"[EVAL] family={fam_i} variant={var_i} {policy_name}", flush=True)
            row = eval_multismoke(policy_path, args, log_dir / f"{len(evaluated_fp):04d}_{policy_name}")
            row.update({
                "policy_name": policy_name,
                "policy_path": str(policy_path),
                "family_plan": fam,
                "weights": policy["pipeline"][0]["fusion"]["params"]["weights"],
                "selector": policy["pipeline"][0]["selector"]["atom"],
                "selector_params": policy["pipeline"][0]["selector"].get("params", {}),
            })
            with results_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
            history.append(row)
            score = float(row.get("combined_score", 0.0))
            if best is None or score > float(best.get("combined_score", 0.0)):
                best = row
                (out_dir / "best_policy.yaml").write_text(policy_path.read_text())
                (out_dir / "best_metrics.json").write_text(json.dumps(row, indent=2, ensure_ascii=False))
                print(f"[BEST] {policy_name} robust={score} perception_mean={row.get('perception_mean')}", flush=True)

    rows = []
    if results_path.exists():
        for line in results_path.read_text().splitlines():
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    fields = ["policy_name", "valid", "combined_score", "perception_mean", "perception_std", "perception_min", "cognition_mean", "overlap_with_reference_avg", "changed_tokens_avg", "selector", "policy_path"]
    with (out_dir / "results.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})
    print("done")
    print("results:", results_path)
    print("best:", out_dir / "best_policy.yaml")


if __name__ == "__main__":
    main()
