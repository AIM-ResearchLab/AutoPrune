#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, os, subprocess, sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Mapping
import yaml

@dataclass
class Candidate:
    name: str
    scorers: Dict[str, Dict[str, Any]]
    weights: Dict[str, float]
    selector_atom: str
    selector_params: Dict[str, Any]

def _policy_from_candidate(c: Candidate) -> Dict[str, Any]:
    scorers = dict(c.scorers)
    if c.selector_atom in {"full_token_pool_dpp_selector", "full_token_pool_mmr_selector"}:
        scorers.setdefault("similarity", {"atom": "pairwise_token_similarity", "params": {"similarity_metric": "cosine", "similarity_transform": "identity"}})
    return {
        "version": "0.5-light",
        "policy_name": c.name,
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "v5_full_token_direct_search",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": scorers,
            "fusion": {"atom": "full_token_score_fusion", "params": {"weights": c.weights, "score_normalization": "minmax", "output_transform": "minmax"}},
            "budget": {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}},
            "selector": {"atom": c.selector_atom, "params": c.selector_params},
            "action": {"atom": "hard_prune"},
            "protection": [],
        }],
    }

def build_candidates(max_candidates=None):
    base = {
        "cdpruner_prior": {"atom": "cdpruner_default_soft_score", "params": {"quality_weight": 0.75, "diversity_weight": 0.25, "transform": "minmax"}},
        "relevance": {"atom": "instruction_guided_visual_relevance", "params": {"sign": "negative_mean", "transform": "minmax", "power": 1.0}},
    }
    aux = {
        "norm": {"atom": "visual_token_norm_saliency", "params": {"transform": "minmax"}},
        "spatial": {"atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}},
        "redundancy": {"atom": "redundancy_density_penalty", "params": {"transform": "minmax"}},
        "attn": {"atom": "attention_proxy_saliency", "params": {"norm_weight": 0.7, "center_weight": 0.3, "transform": "minmax"}},
    }
    aux_sets = [[], ["norm"], ["redundancy"], ["attn"], ["spatial"], ["norm","redundancy"], ["norm","spatial"], ["attn","redundancy"]]
    selectors = [
        ("topk_selector", {}),
        ("full_token_pool_dpp_selector", {"pool_multiplier": 2.0, "postprocess": "sort_by_position"}),
        ("full_token_pool_dpp_selector", {"pool_multiplier": 4.0, "postprocess": "sort_by_position"}),
        ("full_token_pool_mmr_selector", {"pool_multiplier": 4.0, "mmr_lambda": 0.75, "postprocess": "sort_by_position"}),
        ("full_token_pool_mmr_selector", {"pool_multiplier": 4.0, "mmr_lambda": 0.90, "postprocess": "sort_by_position"}),
        ("stratified_full_token_selector", {"core_ratio": 0.875, "grid_size": 4}),
    ]
    candidates = []
    for aux_names in aux_sets:
        for sel, sel_params in selectors:
            for wp in [0.85, 0.70, 0.55, 0.40]:
                for wr in [0.10, 0.20, 0.30]:
                    for wa in [0.05, 0.10, 0.20]:
                        if not aux_names and wa > 0.05: continue
                        if wp + wr >= 1.0: continue
                        scorers = dict(base)
                        for a in aux_names: scorers[a] = aux[a]
                        weights = {"cdpruner_prior": wp, "relevance": wr}
                        if aux_names:
                            for a in aux_names: weights[a] = wa / len(aux_names)
                        total = sum(weights.values())
                        weights = {k: round(v/total, 4) for k, v in weights.items()}
                        name = ("v5_" + sel.replace("full_token_", "").replace("_selector","") + "_" + ("aux_"+"_".join(aux_names) if aux_names else "noaux") + f"_wp{wp:.2f}_wr{wr:.2f}_wa{wa:.2f}").replace(".", "p")
                        candidates.append(Candidate(name, scorers, weights, sel, dict(sel_params)))
    uniq = {}
    for c in candidates: uniq.setdefault(c.name, c)
    out = list(uniq.values())
    return out[:max_candidates] if max_candidates else out

def parse_first_json(text):
    start = text.find("{")
    if start < 0: return {}
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{": depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try: return json.loads(text[start:i+1])
                except Exception: return {}
    return {}

def run_eval(policy_path, args, log_path):
    cmd = [sys.executable, "yaml_policy/openevolve_yaml_search/evaluator.py", str(policy_path), "--gpu", str(args.gpu), "--token", str(args.token), "--script", str(args.script), "--log", str(log_path)]
    env = os.environ.copy()
    env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
    env["EVO_TOKEN"] = str(args.token)
    env["EVO_OBJECTIVE"] = str(args.objective)
    proc = subprocess.run(cmd, cwd=Path.cwd(), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (log_path.with_suffix(".stdout.txt")).write_text(proc.stdout)
    m = parse_first_json(proc.stdout)
    if not m:
        m = {"valid": 0.0, "combined_score": 0.0, "error": "parse_failed", "stdout_tail": proc.stdout[-2000:]}
    return m

def metric(m, objective):
    try: return float(m.get(objective, m.get("combined_score", 0.0)))
    except Exception: return 0.0

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU", "3"))
    ap.add_argument("--token", type=int, default=int(os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32"))))
    ap.add_argument("--script", default=os.environ.get("EVO_EVAL_SCRIPT", "scripts/v1_5/eval/mme_yaml_smoke21.sh"))
    ap.add_argument("--objective", default=os.environ.get("EVO_OBJECTIVE", "perception"))
    ap.add_argument("--max-candidates", type=int, default=24)
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--resume", action="store_true")
    args = ap.parse_args()
    out_dir = Path(args.out_dir or f"openevolve/runs/v5_full_token_direct_K{args.token}_{Path(args.script).stem}")
    policy_dir = out_dir / "policies"; log_dir = out_dir / "logs"
    policy_dir.mkdir(parents=True, exist_ok=True); log_dir.mkdir(parents=True, exist_ok=True)
    results_path = out_dir / "results.jsonl"; csv_path = out_dir / "results.csv"
    seen = set()
    if args.resume and results_path.exists():
        for line in results_path.read_text().splitlines():
            try: seen.add(json.loads(line)["policy_name"])
            except Exception: pass
    best = None
    for idx, c in enumerate(build_candidates(args.max_candidates)):
        if c.name in seen: continue
        policy_path = policy_dir / f"{idx:04d}_{c.name}.yaml"
        policy_path.write_text(yaml.safe_dump(_policy_from_candidate(c), sort_keys=False, allow_unicode=True))
        print(f"[{idx+1}] evaluating {c.name}", flush=True)
        m = run_eval(policy_path, args, log_dir / f"{idx:04d}_{c.name}.log")
        m.update({"policy_name": c.name, "policy_path": str(policy_path), "selector": c.selector_atom, "weights": c.weights, "selector_params": c.selector_params})
        with results_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(m, ensure_ascii=False) + "\n")
        if best is None or metric(m, args.objective) > metric(best, args.objective):
            best = m
            (out_dir / "best_policy.yaml").write_text(policy_path.read_text())
            (out_dir / "best_metrics.json").write_text(json.dumps(m, indent=2, ensure_ascii=False))
            print("[BEST]", c.name, args.objective, metric(m, args.objective), flush=True)
    rows = []
    if results_path.exists():
        for line in results_path.read_text().splitlines():
            try: rows.append(json.loads(line))
            except Exception: pass
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        fields = ["policy_name", "valid", "perception", "cognition", "raw_combined_score", "combined_score", "balanced_score", "selector", "policy_path"]
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k: r.get(k) for k in fields})
    print("done")
    print("results:", results_path)
    print("csv:", csv_path)
    print("best:", out_dir / "best_policy.yaml")

if __name__ == "__main__":
    main()
