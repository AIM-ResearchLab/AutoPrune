#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, re, subprocess, sys
from pathlib import Path
from typing import Any, Dict, List, Mapping
import yaml

SCORER_SPECS = {
    "native_teacher": {"atom": "native_teacher_mask_prior", "params": {"selected_score": 1.0, "unselected_score": 0.0, "blend_soft_prior": 0.0, "transform": "identity"}},
    "relevance": {"atom": "instruction_guided_visual_relevance", "params": {"sign": "negative_mean", "transform": "minmax", "power": 1.0}},
    "norm": {"atom": "visual_token_norm_saliency", "params": {"transform": "minmax"}},
    "spatial": {"atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}},
    "redundancy": {"atom": "redundancy_density_penalty", "params": {"transform": "minmax"}},
    "attn": {"atom": "attention_proxy_saliency", "params": {"norm_weight": 0.7, "center_weight": 0.3, "transform": "minmax"}},
    "similarity": {"atom": "pairwise_token_similarity", "params": {"similarity_metric": "cosine", "similarity_transform": "identity"}},
}
FUSIONS = {"full_token_score_fusion", "v7_rank_fusion", "v7_score_product_fusion", "v7_teacher_residual_fusion"}
SELECTORS = {"topk_selector", "full_token_pool_dpp_selector", "full_token_pool_mmr_selector", "stratified_full_token_selector", "v7_conditional_dpp_selector", "v7_two_stage_pool_selector"}

SEED_FAMILIES = [
    {"family_name": "cdpruner_like_conditional_dpp", "scorers": ["relevance", "similarity"], "fusion": {"atom": "full_token_score_fusion", "params": {"weights": {"relevance": 1.0}}}, "selector": {"atom": "v7_conditional_dpp_selector", "params": {"quality_power": 1.0, "shift_similarity": False, "symmetrize": True}}, "rationale": "Native-like relevance and conditional DPP."},
    {"family_name": "teacher_residual_dpp", "scorers": ["native_teacher", "relevance", "norm", "similarity"], "fusion": {"atom": "v7_teacher_residual_fusion", "params": {"teacher_key": "native_teacher", "residual_keys": ["relevance", "norm"], "teacher_weight": 0.25, "residual_weight": 0.75}}, "selector": {"atom": "v7_conditional_dpp_selector", "params": {"quality_power": 1.0, "shift_similarity": False, "symmetrize": True}}, "rationale": "Soft native teacher residual."},
    {"family_name": "quality_diversity_product", "scorers": ["relevance", "redundancy", "norm", "similarity"], "fusion": {"atom": "v7_score_product_fusion", "params": {"product_keys": ["relevance", "redundancy"], "powers": {"relevance": 1.0, "redundancy": 0.5}, "add_weights": {"norm": 0.15}, "add_mix": 0.15}}, "selector": {"atom": "v7_two_stage_pool_selector", "params": {"pool_multiplier": 3.0, "stage2": "dpp", "quality_power": 1.0, "shift_similarity": False}}, "rationale": "Teacher-free quality diversity."},
    {"family_name": "rank_fusion_mmr", "scorers": ["relevance", "norm", "spatial", "similarity"], "fusion": {"atom": "v7_rank_fusion", "params": {"weights": {"relevance": 0.6, "norm": 0.25, "spatial": 0.15}}}, "selector": {"atom": "full_token_pool_mmr_selector", "params": {"pool_multiplier": 3.0, "mmr_lambda": 0.85, "postprocess": "sort_by_position"}}, "rationale": "Rank fusion and MMR."},
]

def sha(x: Any) -> str:
    return hashlib.sha1(json.dumps(x, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]

def functional_key(fam: Mapping[str, Any]) -> str:
    # Deduplicate by executable YAML semantics, not by family name/rationale.
    obj = {
        "scorers": sorted([str(x) for x in fam.get("scorers", [])]),
        "fusion": fam.get("fusion", {}),
        "selector": fam.get("selector", {}),
    }
    return sha(obj)


def first_json(text: str):
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if m:
        text = m.group(1)
    start = text.find("{")
    if start < 0:
        return None
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i+1])
                except Exception:
                    return None
    return None

def call_llm(prompt: str, args):
    if not os.environ.get("OPENAI_API_KEY"):
        return None
    try:
        from openai import OpenAI
        kw = {"api_key": os.environ["OPENAI_API_KEY"]}
        if os.environ.get("OPENAI_BASE_URL"):
            kw["base_url"] = os.environ["OPENAI_BASE_URL"]
        client = OpenAI(**kw)
        resp = client.chat.completions.create(
            model=args.model,
            messages=[{"role": "system", "content": "Return strict JSON only."}, {"role": "user", "content": prompt}],
            temperature=args.temperature,
            max_tokens=args.max_tokens,
        )
        return first_json(resp.choices[0].message.content or "")
    except Exception as e:
        print("[LLM_ERROR]", e, flush=True)
        return None

def normalize_plan(plan: Mapping[str, Any], idx: int):
    if not isinstance(plan, Mapping):
        plan = {}
    name = str(plan.get("family_name", f"v7_family_{idx}")).replace(" ", "_")
    raw_scorers = plan.get("scorers", ["relevance", "similarity"])
    if not isinstance(raw_scorers, list):
        raw_scorers = ["relevance", "similarity"]
    scorers = []
    for s in raw_scorers:
        s = str(s)
        if s in SCORER_SPECS and s not in scorers:
            scorers.append(s)
    if not any(s in scorers for s in ["relevance", "native_teacher"]):
        scorers.insert(0, "relevance")
    fusion = plan.get("fusion", {"atom": "full_token_score_fusion", "params": {"weights": {"relevance": 1.0}}})
    if not isinstance(fusion, Mapping):
        fusion = {"atom": "full_token_score_fusion", "params": {"weights": {"relevance": 1.0}}}
    f_atom = str(fusion.get("atom", "full_token_score_fusion"))
    if f_atom not in FUSIONS:
        f_atom = "full_token_score_fusion"
    f_params = fusion.get("params", {})
    if not isinstance(f_params, Mapping):
        f_params = {}
    selector = plan.get("selector", {"atom": "v7_conditional_dpp_selector", "params": {}})
    if not isinstance(selector, Mapping):
        selector = {"atom": "v7_conditional_dpp_selector", "params": {}}
    s_atom = str(selector.get("atom", "v7_conditional_dpp_selector"))
    if s_atom not in SELECTORS:
        s_atom = "v7_conditional_dpp_selector"
    s_params = selector.get("params", {})
    if not isinstance(s_params, Mapping):
        s_params = {}
    if s_atom in {"full_token_pool_dpp_selector", "full_token_pool_mmr_selector", "v7_conditional_dpp_selector", "v7_two_stage_pool_selector"} and "similarity" not in scorers:
        scorers.append("similarity")
    return {"family_name": name, "scorers": scorers, "fusion": {"atom": f_atom, "params": dict(f_params)}, "selector": {"atom": s_atom, "params": dict(s_params)}, "rationale": str(plan.get("rationale", ""))}

def mutate_variants(fam: Dict[str, Any], n: int):
    variants, seen = [], set()
    selector_atoms = [fam["selector"]["atom"], "v7_conditional_dpp_selector", "v7_two_stage_pool_selector", "full_token_pool_dpp_selector", "full_token_pool_mmr_selector", "topk_selector"]
    selector_variants = []
    for atom in selector_atoms:
        if atom == "full_token_pool_mmr_selector":
            selector_variants += [(atom, {"pool_multiplier": pm, "mmr_lambda": lam, "postprocess": "sort_by_position"}) for pm in [2.0, 3.0, 4.0] for lam in [0.75, 0.85, 0.95]]
        elif atom == "full_token_pool_dpp_selector":
            selector_variants += [(atom, {"pool_multiplier": pm, "postprocess": "sort_by_position"}) for pm in [2.0, 3.0, 4.0]]
        elif atom == "v7_two_stage_pool_selector":
            selector_variants += [(atom, {"pool_multiplier": pm, "stage2": st, "quality_power": qp, "shift_similarity": False}) for pm in [2.0, 3.0, 4.0] for st in ["dpp", "mmr", "topk"] for qp in [0.8, 1.0, 1.2]]
        elif atom == "v7_conditional_dpp_selector":
            selector_variants += [(atom, {"quality_power": qp, "shift_similarity": sh, "symmetrize": True}) for qp in [0.8, 1.0, 1.2, 1.5] for sh in [False, True]]
        else:
            selector_variants += [(atom, {})]
    fusion_variants = [fam["fusion"]]
    scorers = [s for s in fam["scorers"] if s != "similarity"]
    if "native_teacher" in scorers:
        for tw in [0.10, 0.20, 0.30, 0.40]:
            fusion_variants.append({"atom": "v7_teacher_residual_fusion", "params": {"teacher_key": "native_teacher", "residual_keys": [s for s in scorers if s != "native_teacher"], "teacher_weight": tw, "residual_weight": 1.0 - tw}})
    if "relevance" in scorers:
        for atom in ["full_token_score_fusion", "v7_rank_fusion"]:
            weights = {}
            for s in scorers:
                if s == "native_teacher":
                    weights[s] = 0.2
                elif s == "relevance":
                    weights[s] = 0.55
                else:
                    weights[s] = 0.25 / max(1, len([x for x in scorers if x not in {"native_teacher", "relevance"}]))
            fusion_variants.append({"atom": atom, "params": {"weights": weights, "score_normalization": "minmax", "output_transform": "minmax"}})
        if "redundancy" in scorers:
            fusion_variants.append({"atom": "v7_score_product_fusion", "params": {"product_keys": ["relevance", "redundancy"], "powers": {"relevance": 1.0, "redundancy": 0.5}, "score_normalization": "minmax"}})
    for f in fusion_variants:
        if f.get("atom") not in FUSIONS:
            continue
        for sel_atom, sel_params in selector_variants:
            v = json.loads(json.dumps(fam))
            v["fusion"] = f
            v["selector"] = {"atom": sel_atom, "params": sel_params}
            key = sha(v)
            if key in seen:
                continue
            seen.add(key)
            variants.append(v)
            if len(variants) >= n:
                return variants
    return variants

def policy_from_family(fam: Mapping[str, Any], suffix: str):
    scorers = {s: SCORER_SPECS[s] for s in fam["scorers"] if s in SCORER_SPECS}
    return {
        "version": "0.5-light",
        "policy_name": (fam["family_name"] + suffix).replace(" ", "_"),
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "v7_yaml_atom_evolution",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": scorers,
            "fusion": fam["fusion"],
            "budget": {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}},
            "selector": fam["selector"],
            "action": {"atom": "hard_prune"},
            "protection": [],
        }]
    }

def build_prompt(history: List[Mapping[str, Any]], k: int):
    top = sorted(history, key=lambda r: float(r.get("adjusted_score", r.get("combined_score",0))), reverse=True)[:10]
    hist = [{"policy": r.get("policy_name"), "adjusted": r.get("adjusted_score"), "valid": r.get("valid"), "robust": r.get("combined_score"), "mean": r.get("perception_mean"), "std": r.get("perception_std"), "overlap": r.get("overlap_with_reference_avg"), "changed": r.get("changed_tokens_avg"), "fusion": r.get("fusion"), "selector": r.get("selector")} for r in top]
    return f"""
Design a YAML atom program for visual token pruning.

Task:
- Select exactly K={k} tokens from all visual tokens.
- Do NOT propose fixed token IDs.
- Do NOT focus on replace_tokens; this is full-token pipeline evolution.
- native_teacher is optional and soft, not a hard boundary.
- Avoid exact native copy (changed≈0), but also avoid extreme drift (changed>24).

Allowed scorers: native_teacher, relevance, norm, spatial, redundancy, attn, similarity.
Allowed fusion atoms: full_token_score_fusion, v7_rank_fusion, v7_score_product_fusion, v7_teacher_residual_fusion.
Allowed selector atoms: topk_selector, full_token_pool_dpp_selector, full_token_pool_mmr_selector, stratified_full_token_selector, v7_conditional_dpp_selector, v7_two_stage_pool_selector.

History:
{json.dumps(hist, indent=2, ensure_ascii=False)}

Return strict JSON:
{{
  "family_name": "short_name",
  "scorers": ["relevance", "redundancy", "similarity"],
  "fusion": {{"atom": "v7_score_product_fusion", "params": {{...}}}},
  "selector": {{"atom": "v7_conditional_dpp_selector", "params": {{...}}}},
  "rationale": "why this pipeline should work"
}}
"""

def run_eval(policy_path: Path, args, log_dir: Path):
    cmd = [sys.executable, "yaml_policy/openevolve_yaml_search/evaluator_multismoke.py", str(policy_path), "--gpu", str(args.gpu), "--token", str(args.token), "--base-script", args.base_script, "--chunks", args.chunks, "--num-chunks", str(args.num_chunks), "--std-penalty", str(args.std_penalty), "--log-dir", str(log_dir)]
    env = os.environ.copy()
    env["EVO_TOKEN"] = str(args.token)
    env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
    p = subprocess.run(cmd, cwd=Path.cwd(), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / "multismoke_stdout.txt").write_text(p.stdout)
    row = first_json(p.stdout)
    if not row:
        row = {"valid": 0.0, "combined_score": 0.0, "error": "parse_failed", "stdout_tail": p.stdout[-2000:]}
    return row

def adjusted(row: Mapping[str, Any], args):
    r = dict(row)
    robust = float(r.get("combined_score", 0.0))
    valid = float(r.get("valid", 0.0))
    changed = float(r.get("changed_tokens_avg", 0.0))
    exact_pen = args.exact_copy_penalty if valid > 0 and changed < args.exact_copy_changed else 0.0
    far_pen = args.far_penalty * max(0.0, changed - args.far_changed) if valid > 0 else 0.0
    invalid_pen = args.invalid_penalty if valid <= 0 else 0.0
    r["exact_copy_penalty"] = exact_pen
    r["far_penalty"] = far_pen
    r["invalid_penalty"] = invalid_pen
    r["adjusted_score"] = robust - exact_pen - far_pen - invalid_pen
    return r

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU", "3"))
    ap.add_argument("--token", type=int, default=int(os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32"))))
    ap.add_argument("--base-script", default="scripts/v1_5/eval/mme_yaml_smoke21.sh")
    ap.add_argument("--chunks", default="0,1,2")
    ap.add_argument("--num-chunks", type=int, default=21)
    ap.add_argument("--families", type=int, default=10)
    ap.add_argument("--variants-per-family", type=int, default=10)
    ap.add_argument("--std-penalty", type=float, default=0.5)
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--model", default=os.environ.get("V6_LLM_MODEL", "qwen-plus"))
    ap.add_argument("--temperature", type=float, default=float(os.environ.get("V6_LLM_TEMPERATURE", "0.85")))
    ap.add_argument("--max-tokens", type=int, default=int(os.environ.get("V6_LLM_MAX_TOKENS", "1400")))
    ap.add_argument("--invalid-penalty", type=float, default=10000.0)
    ap.add_argument("--exact-copy-changed", type=float, default=0.5)
    ap.add_argument("--exact-copy-penalty", type=float, default=15.0)
    ap.add_argument("--far-changed", type=float, default=24.0)
    ap.add_argument("--far-penalty", type=float, default=1.0)
    args = ap.parse_args()
    out = Path(args.out_dir or f"openevolve/runs/v7_yaml_atom_evolution_K{args.token}_multismoke")
    pol_dir, log_dir, prompt_dir = out/"policies", out/"logs", out/"prompts"
    for d in [pol_dir, log_dir, prompt_dir]:
        d.mkdir(parents=True, exist_ok=True)
    res_path = out / "results.jsonl"
    history, seen, best, seed_idx = [], set(), None, 0
    for fi in range(args.families):
        prompt = build_prompt(history, args.token)
        (prompt_dir / f"family_{fi:03d}_prompt.txt").write_text(prompt)
        plan = call_llm(prompt, args)
        if plan is None:
            plan = SEED_FAMILIES[seed_idx % len(SEED_FAMILIES)]
            seed_idx += 1
        (prompt_dir / f"family_{fi:03d}_raw_plan.json").write_text(json.dumps(plan, indent=2, ensure_ascii=False))
        fam = normalize_plan(plan, fi)
        (prompt_dir / f"family_{fi:03d}_sanitized_plan.json").write_text(json.dumps(fam, indent=2, ensure_ascii=False))
        for vi, vfam in enumerate(mutate_variants(fam, args.variants_per_family)):
            key = functional_key(vfam)
            if key in seen:
                continue
            seen.add(key)
            policy = policy_from_family(vfam, f"_f{fi:02d}_v{vi:02d}")
            name = policy["policy_name"]
            pp = pol_dir / f"{len(seen):04d}_{name}.yaml"
            pp.write_text(yaml.safe_dump(policy, sort_keys=False, allow_unicode=True))
            print(f"[EVAL] family={fi} variant={vi} {name}", flush=True)
            row = adjusted(run_eval(pp, args, log_dir / f"{len(seen):04d}_{name}"), args)
            row.update({"policy_name": name, "policy_path": str(pp), "family_plan": fam, "fusion": policy["pipeline"][0]["fusion"]["atom"], "selector": policy["pipeline"][0]["selector"]["atom"], "fusion_params": policy["pipeline"][0]["fusion"].get("params", {}), "selector_params": policy["pipeline"][0]["selector"].get("params", {})})
            with res_path.open("a", encoding="utf-8") as f:
                f.write(json.dumps(row, ensure_ascii=False) + "\n")
            history.append(row)
            if best is None or float(row.get("adjusted_score", -1e18)) > float(best.get("adjusted_score", -1e18)):
                best = row
                (out / "best_policy.yaml").write_text(pp.read_text())
                (out / "best_metrics.json").write_text(json.dumps(row, indent=2, ensure_ascii=False))
                print(f"[BEST] {name} adjusted={row.get('adjusted_score')} robust={row.get('combined_score')} valid={row.get('valid')} changed={row.get('changed_tokens_avg')} overlap={row.get('overlap_with_reference_avg')}", flush=True)
    rows = []
    if res_path.exists():
        for line in res_path.read_text().splitlines():
            try:
                rows.append(json.loads(line))
            except Exception:
                pass
    fields = ["policy_name", "valid", "adjusted_score", "combined_score", "perception_mean", "perception_std", "perception_min", "overlap_with_reference_avg", "changed_tokens_avg", "fusion", "selector", "policy_path"]
    with (out / "results.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})
    print("done")
    print("results:", res_path)
    print("best:", out / "best_policy.yaml")

if __name__ == "__main__":
    main()
