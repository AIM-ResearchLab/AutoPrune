#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v8_universal_yaml_program_search.py

LLM-driven fully-free YAML program synthesis for CDPruner visual token pruning.

Core idea:
1. Read typed atom cards from:
   yaml_policy/universal_pruning_yaml_v0_5_light/universal_pruning_typed_atom_registry_v0_5_light.yaml
2. Let LLM design a high-level policy_graph using universal typed atoms.
3. Lower the typed policy_graph into currently executable CDPruner YAML.
4. Verify by selftest, then evaluate with evaluator_multismoke.
5. Feed results/errors back to the next LLM generation.

This script keeps the search fully free:
- overlap/change are diagnostics only;
- no native-anchor penalty/reward;
- by default, native/reference atoms are not used unless explicitly requested by the LLM and the lowerer supports them.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import yaml


# ---------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------

def sha(obj: Any) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def first_json_or_yaml(text: str) -> Any:
    """
    Extract the first JSON/YAML object/list from an LLM response.
    It supports fenced ```json blocks and raw JSON.
    """
    m = re.search(r"```(?:json|yaml|yml)?\s*([\s\S]*?)```", text)
    if m:
        text = m.group(1).strip()

    # Try strict JSON whole text first.
    try:
        return json.loads(text)
    except Exception:
        pass

    # Try YAML whole text.
    try:
        obj = yaml.safe_load(text)
        if isinstance(obj, (dict, list)):
            return obj
    except Exception:
        pass

    # Extract first balanced JSON object/list.
    starts = [i for i in [text.find("{"), text.find("[")] if i >= 0]
    if not starts:
        return None
    start = min(starts)
    open_ch = text[start]
    close_ch = "}" if open_ch == "{" else "]"
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == open_ch:
                depth += 1
            elif ch == close_ch:
                depth -= 1
                if depth == 0:
                    raw = text[start:i + 1]
                    try:
                        return json.loads(raw)
                    except Exception:
                        try:
                            return yaml.safe_load(raw)
                        except Exception:
                            return None
    return None


def append_jsonl(path: Path, row: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            continue
    return rows


def sanitize_name(name: str, max_len: int = 160) -> str:
    name = re.sub(r"[^A-Za-z0-9_]+", "_", str(name)).strip("_")
    return (name or "candidate")[:max_len]


# ---------------------------------------------------------------------
# Registry loading
# ---------------------------------------------------------------------

def load_typed_atom_cards(reg_path: Path) -> Dict[str, Dict[str, Any]]:
    data = yaml.safe_load(reg_path.read_text(encoding="utf-8"))
    cards: Dict[str, Dict[str, Any]] = {}

    for category, atoms in (data.get("typed_atoms", {}) or {}).items():
        if not isinstance(atoms, dict):
            continue
        for name, card in atoms.items():
            if not isinstance(card, dict):
                continue
            atom_id = card.get("atom_id", name)
            cards[atom_id] = {
                "atom_id": atom_id,
                "category": category,
                "description": card.get("description", ""),
                "maturity": card.get("maturity", {}),
                "io_contract": card.get("io_contract", {}),
                "shape_constraints": card.get("shape_constraints", {}),
                "score_semantics": card.get("score_semantics", {}),
                "capability_requirements": card.get("capability_requirements", {}),
                "params_schema": card.get("params_schema", {}),
                "compatibility": card.get("compatibility", {}),
                "implementation_binding": card.get("implementation_binding", {}),
                "verifier_rules": card.get("verifier_rules", {}),
                "eval_hints": card.get("eval_hints", {}),
                "atom_granularity": card.get("atom_granularity"),
                "decomposable": card.get("decomposable"),
                "search_level": card.get("search_level"),
                "expose_to_llm": card.get("expose_to_llm"),
                "micro_decomposition": card.get("micro_decomposition"),
                "micro_search_policy": card.get("micro_search_policy"),
            }

    for name, card in (data.get("bridge_atoms", {}) or {}).items():
        if not isinstance(card, dict):
            continue
        atom_id = card.get("atom_id", name)
        cards[atom_id] = {
            "atom_id": atom_id,
            "category": "bridge",
            "description": card.get("description", ""),
            "io_contract": card.get("io_contract", {}),
            "score_semantics": card.get("score_semantics", {}),
            "params_schema": card.get("params_schema", {}),
            "implementation_binding": card.get("implementation_binding", {}),
            "atom_granularity": card.get("atom_granularity"),
            "decomposable": card.get("decomposable"),
            "search_level": card.get("search_level"),
            "expose_to_llm": card.get("expose_to_llm"),
            "micro_decomposition": card.get("micro_decomposition"),
        }

    return cards


def group_cards(cards: Mapping[str, Mapping[str, Any]]) -> Dict[str, List[str]]:
    by_cat: Dict[str, List[str]] = {}
    for atom, card in cards.items():
        by_cat.setdefault(str(card.get("category", "unknown")), []).append(atom)
    return {k: sorted(v) for k, v in by_cat.items()}


def _short_text(x: Any, max_chars: int = 160) -> str:
    if x is None:
        return ""
    s = str(x).replace("\n", " ").strip()
    s = re.sub(r"\s+", " ", s)
    return s[:max_chars]

def _schema_keys(x: Any, max_items: int = 8) -> List[str]:
    if isinstance(x, dict):
        return [str(k) for k in list(x.keys())[:max_items]]
    if isinstance(x, list):
        return [str(v)[:40] for v in x[:max_items]]
    return []

def compact_card(card: Mapping[str, Any]) -> Dict[str, Any]:
    """
    Very compact card for LLM prompt.
    Do NOT dump full params_schema / io_contract / compatibility / micro_decomposition.
    Full registry is saved to disk; prompt only needs enough for design.
    """
    params_schema = card.get("params_schema", {}) or {}
    io_contract = card.get("io_contract", {}) or {}
    micro = card.get("micro_decomposition", {}) or {}
    compat = card.get("compatibility", {}) or {}

    if isinstance(io_contract, dict):
        inputs = io_contract.get("inputs", {})
        outputs = io_contract.get("outputs", {})
    else:
        inputs, outputs = {}, {}

    return {
        "atom": card.get("atom_id"),
        "cat": card.get("category"),
        "desc": _short_text(card.get("description", ""), 140),
        "params": _schema_keys(params_schema, 6),
        "in": _schema_keys(inputs, 5),
        "out": _schema_keys(outputs, 5),
        "compat": _schema_keys(compat, 5),
        "micro": _schema_keys(micro, 5),
    }


def select_prompt_cards(cards: Mapping[str, Mapping[str, Any]], max_per_category: int = 22) -> Dict[str, List[Dict[str, Any]]]:
    """
    Prefer MLLM-relevant atoms, but still expose a broad set.
    """
    priority_keywords = [
        "visual", "image", "patch", "instruction", "text", "similarity", "dpp", "mmr",
        "coverage", "spatial", "entropy", "cluster", "object", "attention", "sink",
        "relevance", "diversity", "topk", "threshold", "adaptive", "uncertainty",
    ]
    by_cat = group_cards(cards)
    out: Dict[str, List[Dict[str, Any]]] = {}

    wanted_cats = ["triggers", "targets", "scorers", "fusions", "budgets", "selectors", "actions", "protections", "bridge"]
    for cat in wanted_cats:
        names = by_cat.get(cat, [])
        def score_name(n: str) -> Tuple[int, str]:
            s = sum(1 for k in priority_keywords if k in n.lower())
            return (-s, n)
        names = sorted(names, key=score_name)[:max_per_category]
        out[cat] = [compact_card(cards[n]) for n in names]
    return out


# ---------------------------------------------------------------------
# Lowering: typed universal plan -> executable CDPruner YAML
# ---------------------------------------------------------------------

EXEC_SCORER_ALIASES = {
    # Current native/default executable atoms.
    "instruction_guided_visual_relevance": "instruction_guided_visual_relevance",
    "conditional_similarity_score": "conditional_similarity_score",
    "pairwise_token_similarity": "pairwise_token_similarity",

    # v7 executable extensions previously added.
    "visual_token_norm_saliency": "visual_token_norm_saliency",
    "redundancy_density_penalty": "redundancy_density_penalty",
    "spatial_centrality_prior": "spatial_centrality_prior",
    "attention_proxy_saliency": "attention_proxy_saliency",
    "native_teacher_mask_prior": "native_teacher_mask_prior",
    "cdpruner_reference_mask_prior": "cdpruner_reference_mask_prior",
    "cdpruner_default_soft_score": "cdpruner_default_soft_score",

    # Universal registry atoms lowered to available approximations.
    "visual_encoder_cls_attention_score": "attention_proxy_saliency",
    "decoder_attention_to_visual_score": "attention_proxy_saliency",
    "class_token_attention_score": "attention_proxy_saliency",
    "observation_window_attention_score": "attention_proxy_saliency",
    "objectness_region_score": "visual_token_norm_saliency",
    "spatial_entropy_complexity_score": "spatial_centrality_prior",
    "tile_text_alignment_score": "instruction_guided_visual_relevance",
    "chart_structure_score": "spatial_centrality_prior",
    "ocr_density_score": "spatial_centrality_prior",
    "cluster_centroid_representativeness": "redundancy_density_penalty",
    "max_min_diversity_gain": "redundancy_density_penalty",
    "multi_objective_coverage_score": "spatial_centrality_prior",
    "query_agnostic_reconstruction_score": "visual_token_norm_saliency",
    "token_recovery_potential_score": "visual_token_norm_saliency",
    "pca_energy_importance": "visual_token_norm_saliency",
    "value_norm_score": "visual_token_norm_saliency",
    "key_l2_norm_score": "visual_token_norm_saliency",
    "visual_sink_score": "spatial_centrality_prior",
    "visual_register_relevance_score": "instruction_guided_visual_relevance",
    "modality_balance_score": "spatial_centrality_prior",
    "answer_uncertainty_score": "visual_token_norm_saliency",
    "adaptive_sampling_score": "visual_token_norm_saliency",
    "adaptive_halting_probability": "visual_token_norm_saliency",
}

EXEC_FUSION_ALIASES = {
    "quality_diversity_kernel": "quality_diversity_kernel",
    "weighted_sum_score_fusion": "full_token_score_fusion",
    "full_token_score_fusion": "full_token_score_fusion",
    "v7_score_product_fusion": "v7_score_product_fusion",
    "v7_rank_fusion": "v7_rank_fusion",
    "v7_teacher_residual_fusion": "v7_teacher_residual_fusion",

    "mmr_relevance_diversity_fusion": "v7_score_product_fusion",
    "two_stage_relevance_then_diversity": "v7_score_product_fusion",
    "multi_objective_balanced_covering_fusion": "full_token_score_fusion",
    "cluster_quality_diversity_fusion": "v7_score_product_fusion",
    "cost_aware_score_fusion": "full_token_score_fusion",
    "uncertainty_cost_fusion": "full_token_score_fusion",
    "recoverability_aware_fusion": "full_token_score_fusion",
    "hierarchical_anchor_context_fusion": "v7_rank_fusion",
    "frequency_time_domain_fusion": "full_token_score_fusion",
    "modality_aware_budget_fusion": "full_token_score_fusion",
}

EXEC_SELECTOR_ALIASES = {
    "dpp_selector": "dpp_selector",
    "topk_selector": "topk_selector",
    "mmr_selector": "mmr_selector",
    "v7_conditional_dpp_selector": "v7_conditional_dpp_selector",
    "v7_two_stage_pool_selector": "v7_two_stage_pool_selector",
    "full_token_pool_dpp_selector": "full_token_pool_dpp_selector",
    "topk_pool_dpp_selector": "topk_pool_dpp_selector",
    "full_token_pool_mmr_selector": "full_token_pool_mmr_selector",
    "topk_pool_mmr_selector": "topk_pool_mmr_selector",
    "stratified_full_token_selector": "stratified_full_token_selector",

    "hierarchical_topk_dpp_selector": "v7_two_stage_pool_selector",
    "balanced_covering_selector": "stratified_full_token_selector",
    "greedy_max_min_selector": "mmr_selector",
    "cluster_centroid_selector": "topk_pool_dpp_selector",
    "threshold_selector": "topk_selector",
    "stochastic_sampling_selector": "topk_selector",
    "leverage_score_selector": "topk_selector",
    "bipartite_matching_selector": "topk_pool_mmr_selector",
    "framefusion_selector": "v7_two_stage_pool_selector",
}

EXEC_BUDGET_ALIASES = {
    "fixed_keep_tokens": "fixed_keep_tokens",
    "fixed_keep_ratio": "fixed_keep_tokens",
    "input_adaptive_token_count": "fixed_keep_tokens",
    "dynamic_visual_complexity_budget": "fixed_keep_tokens",
    "high_resolution_tile_budget": "fixed_keep_tokens",
    "modality_aware_budget": "fixed_keep_tokens",
    "structured_sparsity_ratio": "fixed_keep_tokens",
}

EXEC_ACTION_ALIASES = {
    "dpp_subset_prune": "dpp_subset_prune",
    "hard_prune": "hard_prune",
    "soft_mask_prune": "hard_prune",
    "tiled_visual_prune": "hard_prune",
    "token_reorganization": "hard_prune",
    "token_halting": "hard_prune",
    "token_squeeze_summary": "hard_prune",
}

EXEC_PROTECTION_ALIASES = {
    "special_token_preservation": "special_token_preservation",
    "spatial_coverage_preservation": "spatial_coverage_preservation",
    "semantic_cluster_coverage_preservation": "spatial_coverage_preservation",
    "top_relevance_anchor_preservation": "special_token_preservation",
    "visual_sink_preservation": "special_token_preservation",
    "attention_sink_preservation": "special_token_preservation",
    "modality_balance_preservation": "spatial_coverage_preservation",
}

DEFAULT_SCORER_PARAMS = {
    "instruction_guided_visual_relevance": {"sign": "negative_mean", "transform": "minmax", "power": 1.0},
    "conditional_similarity_score": {"similarity_metric": "cosine", "similarity_transform": "identity"},
    "pairwise_token_similarity": {"similarity_metric": "cosine", "similarity_transform": "identity"},
    "visual_token_norm_saliency": {"transform": "minmax"},
    "redundancy_density_penalty": {"transform": "minmax"},
    "spatial_centrality_prior": {"center_bias": 1.0, "transform": "minmax"},
    "attention_proxy_saliency": {"transform": "minmax"},
    "native_teacher_mask_prior": {"selected_score": 1.0, "unselected_score": 0.0, "blend_soft_prior": 0.0},
    "cdpruner_reference_mask_prior": {"selected_score": 1.0, "unselected_score": 0.0},
    "cdpruner_default_soft_score": {"transform": "minmax"},
}

FORBIDDEN_FREE_ATOMS = {
    "native_teacher_mask_prior",
    "cdpruner_reference_mask_prior",
    "cdpruner_default_soft_score",
}


def normalize_node_list(obj: Any) -> List[Dict[str, Any]]:
    if isinstance(obj, dict):
        if isinstance(obj.get("nodes"), list):
            return [x for x in obj["nodes"] if isinstance(x, dict)]
        if isinstance(obj.get("policy_graph"), dict):
            return normalize_node_list(obj["policy_graph"])
        if isinstance(obj.get("candidate"), dict):
            return normalize_node_list(obj["candidate"])
    return []


def plan_from_llm_obj(obj: Any) -> List[Dict[str, Any]]:
    """
    Accept several LLM formats:
    - {"policy_graph": {"nodes": [...]}}
    - {"nodes": [...]}
    - {"candidates": [{"policy_graph": ...}, ...]}
    """
    if isinstance(obj, dict) and isinstance(obj.get("candidates"), list):
        plans = []
        for c in obj["candidates"]:
            nodes = normalize_node_list(c)
            if nodes:
                plans.append({"meta": {k: c.get(k) for k in ["policy_name", "rationale"] if isinstance(c, dict)}, "nodes": nodes})
        return plans
    nodes = normalize_node_list(obj)
    if nodes:
        return [{"meta": {}, "nodes": nodes}]
    return []


def lower_atom(atom: str, slot: str) -> Tuple[str, str]:
    """
    Return executable_atom, lowering_note.
    """
    maps = {
        "scorer": EXEC_SCORER_ALIASES,
        "fusion": EXEC_FUSION_ALIASES,
        "selector": EXEC_SELECTOR_ALIASES,
        "budget": EXEC_BUDGET_ALIASES,
        "action": EXEC_ACTION_ALIASES,
        "protection": EXEC_PROTECTION_ALIASES,
    }
    table = maps.get(slot, {})
    if atom in table:
        out = table[atom]
        return out, "" if out == atom else f"{atom}->{out}"
    # Default fallbacks by slot.
    fallbacks = {
        "scorer": "visual_token_norm_saliency",
        "fusion": "full_token_score_fusion",
        "selector": "v7_conditional_dpp_selector",
        "budget": "fixed_keep_tokens",
        "action": "hard_prune",
        "protection": "special_token_preservation",
    }
    out = fallbacks.get(slot, atom)
    return out, f"{atom}->{out}(fallback)"


def merge_params(defaults: Mapping[str, Any], user: Any) -> Dict[str, Any]:
    out = dict(defaults or {})
    if isinstance(user, dict):
        for k, v in user.items():
            # Keep only simple JSON-like params. Avoid nested unknown weird structures unless safe.
            if isinstance(v, (str, int, float, bool)) or v is None or isinstance(v, (list, dict)):
                out[k] = v
    return out


def lower_plan_to_policy(plan: Mapping[str, Any], idx: int, token: int, ban_native_teacher: bool = True) -> Tuple[Dict[str, Any], List[str]]:
    nodes = plan.get("nodes", [])
    meta = plan.get("meta", {}) or {}
    notes: List[str] = []

    scorer_specs: Dict[str, Dict[str, Any]] = {}
    fusion_spec: Optional[Dict[str, Any]] = None
    selector_spec: Optional[Dict[str, Any]] = None
    budget_spec: Optional[Dict[str, Any]] = None
    action_spec: Optional[Dict[str, Any]] = None
    protections: List[Dict[str, Any]] = []
    bridge_atoms_seen: List[str] = []

    for n_i, node in enumerate(nodes):
        if not isinstance(node, dict):
            continue
        slot = str(node.get("slot", node.get("category", ""))).strip().lower()
        atom = str(node.get("atom", node.get("atom_id", ""))).strip()
        params = node.get("params", {})
        if not atom:
            continue

        # Normalize plural categories.
        if slot.endswith("s"):
            slot = slot[:-1]
        if slot in {"score", "scorers"}:
            slot = "scorer"
        if slot in {"fuse", "fusions"}:
            slot = "fusion"
        if slot in {"select", "selectors"}:
            slot = "selector"
        if slot in {"protect", "protections"}:
            slot = "protection"
        if slot in {"budgeter", "budgets"}:
            slot = "budget"
        if slot in {"actions"}:
            slot = "action"

        if slot not in {"scorer", "fusion", "selector", "budget", "action", "protection", "target", "trigger", "bridge"}:
            # Infer from atom name.
            if atom in EXEC_SCORER_ALIASES:
                slot = "scorer"
            elif atom in EXEC_FUSION_ALIASES:
                slot = "fusion"
            elif atom in EXEC_SELECTOR_ALIASES:
                slot = "selector"
            elif atom in EXEC_BUDGET_ALIASES:
                slot = "budget"
            elif atom in EXEC_ACTION_ALIASES:
                slot = "action"
            elif atom in EXEC_PROTECTION_ALIASES:
                slot = "protection"
            else:
                notes.append(f"ignored unsupported slot node: {atom}/{slot}")
                continue

        if slot == "bridge":
            bridge_atoms_seen.append(atom)
            notes.append(f"bridge_preference_seen: {atom}")
            continue

        if slot in {"target", "trigger"}:
            # Current host target/trigger are fixed for CDPruner encode_images.
            notes.append(f"ignored planning-only {slot}: {atom}")
            continue

        exec_atom, note = lower_atom(atom, slot)
        if note:
            notes.append(note)
        if ban_native_teacher and exec_atom in FORBIDDEN_FREE_ATOMS:
            notes.append(f"banned native/reference scorer removed: {exec_atom}")
            continue

        if slot == "scorer":
            key_base = re.sub(r"_(score|saliency|prior)$", "", exec_atom)
            key = sanitize_name(node.get("id", key_base), max_len=40)
            if key in scorer_specs:
                key = f"{key}_{n_i}"
            scorer_specs[key] = {
                "atom": exec_atom,
                "params": merge_params(DEFAULT_SCORER_PARAMS.get(exec_atom, {}), params),
            }
        elif slot == "fusion":
            fusion_spec = {
                "atom": exec_atom,
                "params": dict(params) if isinstance(params, dict) else {},
            }
        elif slot == "selector":
            selector_spec = {
                "atom": exec_atom,
                "params": dict(params) if isinstance(params, dict) else {},
            }
        elif slot == "budget":
            budget_spec = {
                "atom": exec_atom,
                "params": {"keep_tokens": "host_argument"},
            }
        elif slot == "action":
            action_spec = {
                "atom": exec_atom,
            }
        elif slot == "protection":
            protections.append({"atom": exec_atom, "params": dict(params) if isinstance(params, dict) else {}})

    # Ensure a general quality signal for task-agnostic pruning.
    # This is NOT an MME-specific semantic constraint and does NOT use native/reference masks.
    # It only prevents policies from relying solely on coverage/spatial/cluster proxies.
    quality_atoms = {
        "visual_token_norm_saliency",
        "attention_proxy_saliency",
        "instruction_guided_visual_relevance",
        "cdpruner_default_soft_score",
    }
    has_general_quality = any(
        v.get("atom") in quality_atoms
        for v in scorer_specs.values()
        if isinstance(v, dict)
    )
    if not has_general_quality:
        scorer_specs["generic_quality"] = {
            "atom": "visual_token_norm_saliency",
            "params": DEFAULT_SCORER_PARAMS["visual_token_norm_saliency"],
        }
        notes.append("compiler_injected_generic_quality: visual_token_norm_saliency")

    # Bridge preferences from universal registry.
    # These bridges are planning-level atoms, but they imply executable fusion/selector choices.
    bridge_prefers_dpp_kernel = any(
        b in {
            "quality_similarity_to_dpp_kernel_bridge",
            "query_relevance_to_dpp_quality_bridge",
        }
        for b in bridge_atoms_seen
    )

    # Ensure similarity if DPP/MMR-like selector/fusion, or if a DPP bridge is requested.
    selector_atom = (selector_spec or {}).get("atom", "v7_conditional_dpp_selector")
    fusion_atom = (fusion_spec or {}).get("atom", "quality_diversity_kernel")
    need_sim = (
        any(k in str(selector_atom) for k in ["dpp", "mmr"])
        or "diversity" in str(fusion_atom)
        or fusion_atom == "quality_diversity_kernel"
        or bridge_prefers_dpp_kernel
    )
    if need_sim and not any(v["atom"] in {"conditional_similarity_score", "pairwise_token_similarity"} for v in scorer_specs.values()):
        scorer_specs["similarity"] = {
            "atom": "pairwise_token_similarity",
            "params": DEFAULT_SCORER_PARAMS["pairwise_token_similarity"],
        }

    # Lower bridge-level intent into executable CDPruner operators.
    # This keeps the policy general and free, but prevents useful bridge atoms from being ignored.
    if bridge_prefers_dpp_kernel:
        if fusion_spec is None or fusion_spec.get("atom") in {"full_token_score_fusion", "v7_rank_fusion"}:
            fusion_spec = {
                "atom": "quality_diversity_kernel",
                "params": {
                    "quality_power": 1.0,
                    "similarity_power": 1.0,
                    "stabilization": ["symmetrize", "eps_diagonal"],
                },
            }
            notes.append("bridge_lowered_to_quality_diversity_kernel")

        if selector_spec is None or selector_spec.get("atom") in {"topk_selector", "stratified_full_token_selector"}:
            selector_spec = {
                "atom": "dpp_selector",
                "params": {
                    "algorithm": "fast_map",
                    "postprocess": "sort_by_position",
                },
            }
            notes.append("bridge_lowered_to_dpp_selector")

    # Normalize fusion params to executable expectations.
    if fusion_spec is None:
        fusion_spec = {"atom": "quality_diversity_kernel", "params": {"quality_power": 1.0, "similarity_power": 1.0, "stabilization": ["symmetrize", "eps_diagonal"]}}
    else:
        fa = fusion_spec["atom"]
        p = fusion_spec.setdefault("params", {})
        if fa == "quality_diversity_kernel":
            p.setdefault("quality_power", 1.0)
            p.setdefault("similarity_power", 1.0)
            p.setdefault("stabilization", ["symmetrize", "eps_diagonal"])
        elif fa == "full_token_score_fusion":
            # weight every non-similarity scorer equally by default
            keys = [k for k, v in scorer_specs.items() if "similarity" not in k and v["atom"] not in {"conditional_similarity_score", "pairwise_token_similarity"}]
            if "weights" not in p:
                p["weights"] = {k: 1.0 for k in keys}
            p.setdefault("score_normalization", "minmax")
            p.setdefault("output_transform", "minmax")
        elif fa == "v7_score_product_fusion":
            keys = [k for k, v in scorer_specs.items() if v["atom"] not in {"conditional_similarity_score", "pairwise_token_similarity"}]
            if "product_keys" not in p:
                p["product_keys"] = keys[:2] if len(keys) >= 2 else keys
            p.setdefault("powers", {k: 1.0 for k in p.get("product_keys", keys)})
            p.setdefault("add_weights", {})
            p.setdefault("add_mix", 0.15)
            p.setdefault("score_normalization", "minmax")
            p.setdefault("output_transform", "minmax")
        elif fa == "v7_rank_fusion":
            keys = [k for k, v in scorer_specs.items() if v["atom"] not in {"conditional_similarity_score", "pairwise_token_similarity"}]
            p.setdefault("weights", {k: 1.0 for k in keys})
            p.setdefault("output_transform", "minmax")
        elif fa == "v7_teacher_residual_fusion":
            p.setdefault("teacher_weight", 0.0 if ban_native_teacher else 0.05)
            p.setdefault("residual_weight", 1.0)

    # Normalize selector params.
    if selector_spec is None:
        selector_spec = {"atom": "v7_conditional_dpp_selector", "params": {"quality_power": 1.2, "shift_similarity": False, "symmetrize": True}}
    else:
        sa = selector_spec["atom"]
        p = selector_spec.setdefault("params", {})
        if sa == "dpp_selector":
            p.setdefault("algorithm", "fast_map")
            p.setdefault("postprocess", "sort_by_position")
        elif sa == "v7_conditional_dpp_selector":
            p.setdefault("quality_power", 1.2)
            p.setdefault("shift_similarity", False)
            p.setdefault("symmetrize", True)
        elif sa == "v7_two_stage_pool_selector":
            p.setdefault("pool_multiplier", 3.0)
            p.setdefault("quality_power", 1.2)
            p.setdefault("shift_similarity", False)
            p.setdefault("symmetrize", True)
        elif sa in {"full_token_pool_dpp_selector", "topk_pool_dpp_selector"}:
            p.setdefault("pool_multiplier", 3.0)
            p.setdefault("quality_power", 1.2)
        elif sa in {"full_token_pool_mmr_selector", "topk_pool_mmr_selector", "mmr_selector"}:
            p.setdefault("lambda_relevance", 0.7)

    budget_spec = budget_spec or {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}}
    action_spec = action_spec or {"atom": "hard_prune"}
    # Protection is optional. Avoid unsupported protection causing failures; keep only if likely executable.
    protections = [p for p in protections if p.get("atom") in {"special_token_preservation", "spatial_coverage_preservation"}][:2]

    raw_name = meta.get("policy_name") or f"v8_universal_free_{idx:05d}"
    policy_name = sanitize_name(f"{raw_name}_{sha({'nodes': nodes})}", max_len=180)

    policy = {
        "version": "0.5-light",
        "policy_name": policy_name,
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "v8_universal_llm_plan_lowered_free_search",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": scorer_specs,
            "fusion": fusion_spec,
            "budget": budget_spec,
            "selector": selector_spec,
            "action": action_spec,
            "protection": protections,
        }],
    }
    return policy, notes


def canonical_policy_key(policy: Mapping[str, Any]) -> str:
    obj = json.loads(json.dumps(policy, sort_keys=True, ensure_ascii=False))
    obj.pop("policy_name", None)
    obj.pop("search_stage", None)
    return sha(obj)


def policy_summary(policy: Mapping[str, Any]) -> Dict[str, Any]:
    step = policy["pipeline"][0]
    return {
        "fusion": step.get("fusion", {}).get("atom"),
        "fusion_params": step.get("fusion", {}).get("params", {}),
        "selector": step.get("selector", {}).get("atom"),
        "selector_params": step.get("selector", {}).get("params", {}),
        "scorer_atoms": [v.get("atom") for v in step.get("scorer", {}).values() if isinstance(v, Mapping)],
        "scorer_keys": list(step.get("scorer", {}).keys()),
        "action": step.get("action", {}).get("atom"),
        "protections": [x.get("atom") for x in step.get("protection", []) if isinstance(x, Mapping)],
    }


# ---------------------------------------------------------------------
# Prompt and LLM
# ---------------------------------------------------------------------

def build_prompt(cards: Mapping[str, Mapping[str, Any]], history: Sequence[Mapping[str, Any]],
                 args: argparse.Namespace, generation: int) -> str:
    prompt_cards = select_prompt_cards(cards, max_per_category=args.max_cards_per_category)

    top = sorted(history, key=lambda r: safe_float(r.get("combined_score")), reverse=True)[:6]
    top_compact = []
    for r in top:
        top_compact.append({
            "score": r.get("combined_score"),
            "mean": r.get("perception_mean"),
            "std": r.get("perception_std"),
            "fusion": r.get("fusion"),
            "selector": r.get("selector"),
            "scorer_atoms": r.get("scorer_atoms"),
            "lowering": (r.get("lowering_notes") or [])[:4],
        })

    return f"""
You are an expert program-synthesis agent for visual token pruning in an MLLM.
Your job is to design fully-free YAML pruning programs using a typed universal atom registry.

Important task setting:
- Host: CDPruner/LLaVA encode_images visual token pruning.
- Target: select exactly K={args.token} visual tokens from all image patch tokens before the LLM.
- Fully free search: do NOT optimize for overlap with any native/reference mask.
- overlap_with_reference and changed_tokens are diagnostics only.
- Do NOT use native/reference/copy atoms. Avoid native_teacher_mask_prior, cdpruner_reference_mask_prior, cdpruner_default_soft_score.
- The final policy will be lowered into currently executable YAML, so you may use universal typed atoms as design language.
- Prefer creative but plausible combinations, not only relevance × redundancy + DPP.
- This is a GENERAL pruning search across multiple downstream tasks, not an MME-only or VQA-only search.
- Do not rely only on spatial/coverage/cluster signals; combine them with a general quality/saliency/importance signal.
- Text-conditioned or instruction-conditioned relevance is optional, not mandatory.
- Good general policies may combine visual saliency, attention proxy, redundancy/diversity, spatial coverage, uncertainty, recoverability, and optional task relevance.
- If you use DPP/MMR/diversity selectors, include a similarity-like signal such as pairwise_token_similarity or conditional_similarity_score.
- Explore scorers/fusions/selectors/protections/bridges from the registry.
- Programs should generalize across dispersed MME chunks, not just one chunk.

Available typed atom cards, grouped by role:
{json.dumps(prompt_cards, ensure_ascii=False, indent=2)}

Prior evaluated candidates:
{json.dumps(top_compact, ensure_ascii=False, indent=2)}

Design hints:
- Good visual-token pruning usually needs both task relevance and diversity/coverage.
- Similarity/DPP/MMR-style selectors need a similarity or diversity signal.
- You may combine semantic relevance with spatial, attention, objectness, coverage, uncertainty, or reconstruction-inspired scorers.
- You may propose high-level typed atoms; the compiler will lower them to executable approximations.
- Avoid generating candidates that are identical to prior fusion+selector+scorer sets.

Return strict JSON only, no markdown.
Return {args.batch_size} diverse candidates in this schema:
{{
  "candidates": [
    {{
      "policy_name": "short_unique_name",
      "rationale": "why this program may work",
      "policy_graph": {{
        "nodes": [
          {{"id": "quality", "slot": "scorer", "atom": "instruction_guided_visual_relevance", "params": {{"transform": "minmax", "power": 1.0}}}},
          {{"id": "structure", "slot": "scorer", "atom": "spatial_entropy_complexity_score", "params": {{"transform": "minmax"}}}},
          {{"id": "fusion", "slot": "fusion", "atom": "multi_objective_balanced_covering_fusion", "params": {{"quality_weight": 0.7, "coverage_weight": 0.3}}}},
          {{"id": "selector", "slot": "selector", "atom": "hierarchical_topk_dpp_selector", "params": {{"pool_multiplier": 3.0, "quality_power": 1.2}}}},
          {{"id": "budget", "slot": "budget", "atom": "fixed_keep_tokens", "params": {{"keep_tokens": "host_argument"}}}},
          {{"id": "action", "slot": "action", "atom": "hard_prune", "params": {{}}}}
        ]
      }}
    }}
  ]
}}

Generation: {generation}
"""


def call_llm(prompt: str, args: argparse.Namespace) -> List[Mapping[str, Any]]:
    from openai import OpenAI
    import time

    kwargs = {"api_key": os.environ["OPENAI_API_KEY"]}
    if os.environ.get("OPENAI_BASE_URL"):
        kwargs["base_url"] = os.environ["OPENAI_BASE_URL"]

    client = OpenAI(**kwargs)
    resp = client.chat.completions.create(
        model=args.model,
        messages=[
            {"role": "system", "content": "Return strict JSON only. You are designing policy_graph programs using typed pruning atoms."},
            {"role": "user", "content": prompt},
        ],
        temperature=args.temperature,
        max_tokens=args.max_tokens,
    )

    content = resp.choices[0].message.content or ""

    usage_obj = getattr(resp, "usage", None)
    if usage_obj is None:
        usage = {}
    elif hasattr(usage_obj, "model_dump"):
        usage = usage_obj.model_dump()
    elif isinstance(usage_obj, dict):
        usage = usage_obj
    else:
        usage = {
            "prompt_tokens": getattr(usage_obj, "prompt_tokens", None),
            "completion_tokens": getattr(usage_obj, "completion_tokens", None),
            "total_tokens": getattr(usage_obj, "total_tokens", None),
        }

    usage_row = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "model": args.model,
        "prompt_chars": len(prompt),
        "completion_chars": len(content),
        "usage": usage,
    }

    usage_path = os.environ.get("V8_LLM_USAGE_JSONL")
    if usage_path:
        with open(usage_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(usage_row, ensure_ascii=False) + "\n")

    print(
        "[LLM_USAGE]",
        "prompt_tokens=", usage.get("prompt_tokens"),
        "completion_tokens=", usage.get("completion_tokens"),
        "total_tokens=", usage.get("total_tokens"),
        "prompt_chars=", len(prompt),
        "completion_chars=", len(content),
        flush=True,
    )

    obj = first_json_or_yaml(content)
    if not isinstance(obj, Mapping) or not isinstance(obj.get("candidates"), list):
        raise ValueError("LLM did not return {'candidates': [...]} JSON.")
    return obj["candidates"]


# ---------------------------------------------------------------------
# Runtime verification/evaluation
# ---------------------------------------------------------------------

def run_selftest(repo: Path, policy_path: Path, token: int, timeout: int = 180) -> Tuple[bool, str]:
    cmd = [
        sys.executable, "tools/evo_cdpruner/selftest_cdpruner_policy.py",
        "--policy", str(policy_path),
        "--tokens", "576",
        "--keep", str(token),
    ]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(repo)
    proc = subprocess.run(cmd, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    return proc.returncode == 0, proc.stdout


def run_multismoke(repo: Path, policy_path: Path, args: argparse.Namespace, log_dir: Path) -> Dict[str, Any]:
    cmd = [
        sys.executable, "yaml_policy/openevolve_yaml_search/evaluator_multismoke.py",
        str(policy_path),
        "--gpu", str(args.gpu),
        "--token", str(args.token),
        "--base-script", args.base_script,
        "--chunks", args.chunks,
        "--num-chunks", str(args.num_chunks),
        "--std-penalty", str(args.std_penalty),
        "--log-dir", str(log_dir),
    ]
    env = os.environ.copy()
    env["EVO_TOKEN"] = str(args.token)
    env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
    proc = subprocess.run(cmd, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / "eval_stdout.txt").write_text(proc.stdout, encoding="utf-8")
    obj = first_json_or_yaml(proc.stdout)
    if not isinstance(obj, Mapping):
        obj = {"valid": 0.0, "combined_score": 0.0, "error": "parse_failed", "stdout_tail": proc.stdout[-3000:]}
    return dict(obj)


def write_csv_summary(results_path: Path, csv_path: Path) -> None:
    rows = load_jsonl(results_path)
    rows = sorted(rows, key=lambda r: safe_float(r.get("combined_score")), reverse=True)
    fields = [
        "policy_name", "valid", "combined_score", "perception_mean", "perception_std", "perception_min",
        "cognition_mean", "changed_tokens_avg", "overlap_with_reference_avg", "fusion", "selector",
        "scorer_atoms", "lowering_notes", "policy_path", "rationale",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--registry", default="yaml_policy/universal_pruning_yaml_v0_5_light/universal_pruning_typed_atom_registry_v0_5_light.yaml")
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU", "3"))
    ap.add_argument("--token", type=int, default=int(os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32"))))
    ap.add_argument("--base-script", default="scripts/v1_5/eval/mme_yaml_smoke21.sh")
    ap.add_argument("--chunks", default="0,5,10,15,20")
    ap.add_argument("--num-chunks", type=int, default=21)
    ap.add_argument("--std-penalty", type=float, default=0.5)
    ap.add_argument("--generations", type=int, default=8)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--out-dir", default="openevolve/runs/v8_universal_free_K32_chunks_0_5_10_15_20")
    ap.add_argument("--model", default=os.environ.get("V8_LLM_MODEL", os.environ.get("V6_LLM_MODEL", "qwen-plus")))
    ap.add_argument("--temperature", type=float, default=float(os.environ.get("V8_LLM_TEMPERATURE", "0.9")))
    ap.add_argument("--max-tokens", type=int, default=int(os.environ.get("V8_LLM_MAX_TOKENS", "5000")))
    ap.add_argument("--max-cards-per-category", type=int, default=8)
    ap.add_argument("--no-selftest", action="store_true")
    ap.add_argument("--allow-native-teacher", action="store_true")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    out = repo / args.out_dir
    pol_dir = out / "policies"
    plan_dir = out / "plans"
    log_dir = out / "logs"
    prompt_dir = out / "prompts"
    rej_dir = out / "rejected"
    for d in [pol_dir, plan_dir, log_dir, prompt_dir, rej_dir]:
        d.mkdir(parents=True, exist_ok=True)

    if not os.environ.get("OPENAI_API_KEY"):
        raise SystemExit("OPENAI_API_KEY is required.")

    reg_path = repo / args.registry
    cards = load_typed_atom_cards(reg_path)
    (out / "typed_atom_cards_clean.json").write_text(json.dumps(cards, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "typed_atom_categories.json").write_text(json.dumps(group_cards(cards), indent=2, ensure_ascii=False), encoding="utf-8")

    results_path = out / "results.jsonl"
    os.environ["V8_LLM_USAGE_JSONL"] = str(out / "llm_usage.jsonl")
    history = load_jsonl(results_path)
    seen_keys = {r.get("canonical_key") for r in history if r.get("canonical_key")}
    best = max(history, key=lambda r: safe_float(r.get("combined_score")), default=None)

    for gen in range(args.generations):
        prompt = build_prompt(cards, history, args, gen)
        (prompt_dir / f"gen_{gen:03d}_prompt.txt").write_text(prompt, encoding="utf-8")
        try:
            candidates = call_llm(prompt, args)
            (prompt_dir / f"gen_{gen:03d}_raw_candidates.json").write_text(json.dumps(candidates, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            (prompt_dir / f"gen_{gen:03d}_llm_error.txt").write_text(str(e), encoding="utf-8")
            print("[LLM_ERROR]", e, flush=True)
            time.sleep(2)
            continue

        for j, cand in enumerate(candidates):
            if not isinstance(cand, Mapping):
                continue
            obj = {"candidates": [cand]}
            plans = plan_from_llm_obj(obj)
            if not plans:
                append_jsonl(out / "rejected_parse.jsonl", {"generation": gen, "candidate_index": j, "candidate": cand, "error": "no policy_graph nodes"})
                print("[REJECT_PARSE] no policy_graph", flush=True)
                continue

            plan = plans[0]
            # Preserve metadata.
            plan["meta"] = {
                "policy_name": cand.get("policy_name", f"g{gen}_c{j}"),
                "rationale": cand.get("rationale", ""),
            }

            idx = len(history) + 1
            try:
                policy, lowering_notes = lower_plan_to_policy(
                    plan, idx=idx, token=args.token, ban_native_teacher=not args.allow_native_teacher
                )
            except Exception as e:
                append_jsonl(out / "rejected_lowering.jsonl", {"generation": gen, "candidate_index": j, "candidate": cand, "error": str(e)})
                print("[REJECT_LOWER]", e, flush=True)
                continue

            key = canonical_policy_key(policy)
            if key in seen_keys:
                print("[SKIP_DUP]", policy["policy_name"], flush=True)
                continue
            seen_keys.add(key)

            stem = f"{idx:05d}_{policy['policy_name']}"
            pp = pol_dir / f"{stem}.yaml"
            plan_path = plan_dir / f"{stem}.json"
            pp.write_text(yaml.safe_dump(policy, sort_keys=False, allow_unicode=True), encoding="utf-8")
            plan_path.write_text(json.dumps({"candidate": cand, "plan": plan, "lowering_notes": lowering_notes, "policy": policy}, indent=2, ensure_ascii=False), encoding="utf-8")

            if not args.no_selftest:
                ok, st_out = run_selftest(repo, pp, args.token)
                (log_dir / f"{stem}_selftest.txt").write_text(st_out, encoding="utf-8")
                if not ok:
                    append_jsonl(out / "rejected_selftest.jsonl", {
                        "generation": gen,
                        "candidate_index": j,
                        "policy_path": str(pp),
                        "lowering_notes": lowering_notes,
                        "error": st_out[-3000:],
                    })
                    print("[REJECT_SELFTEST]", pp.name, flush=True)
                    continue

            print(f"[EVAL] gen={gen} cand={j} {pp.name}", flush=True)
            row = run_multismoke(repo, pp, args, log_dir / stem)
            row.update(policy_summary(policy))
            row.update({
                "policy_name": policy["policy_name"],
                "policy_path": str(pp),
                "plan_path": str(plan_path),
                "canonical_key": key,
                "generation": gen,
                "candidate_index": j,
                "rationale": cand.get("rationale", ""),
                "lowering_notes": lowering_notes,
            })
            append_jsonl(results_path, row)
            history.append(row)

            score = safe_float(row.get("combined_score"))
            if best is None or score > safe_float(best.get("combined_score")):
                best = row
                (out / "best_policy.yaml").write_text(pp.read_text(encoding="utf-8"), encoding="utf-8")
                (out / "best_plan.json").write_text(plan_path.read_text(encoding="utf-8"), encoding="utf-8")
                (out / "best_metrics.json").write_text(json.dumps(row, indent=2, ensure_ascii=False), encoding="utf-8")
                print(
                    "[BEST]",
                    policy["policy_name"],
                    "score=", row.get("combined_score"),
                    "mean=", row.get("perception_mean"),
                    "std=", row.get("perception_std"),
                    "min=", row.get("perception_min"),
                    "valid=", row.get("valid"),
                    "changed=", row.get("changed_tokens_avg"),
                    "overlap=", row.get("overlap_with_reference_avg"),
                    "fusion=", row.get("fusion"),
                    "selector=", row.get("selector"),
                    flush=True,
                )

        write_csv_summary(results_path, out / "results.csv")

    write_csv_summary(results_path, out / "results.csv")
    print("done")
    print("results:", results_path)
    print("best:", out / "best_policy.yaml")


if __name__ == "__main__":
    main()
