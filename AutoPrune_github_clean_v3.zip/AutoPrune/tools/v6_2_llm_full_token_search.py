#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, hashlib, json, os, re, subprocess, sys
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional
import yaml

ATOM_ALIAS = {
    "reference_prior": "reference_prior", "cdpruner_reference_mask_prior": "reference_prior",
    "reference_mask_prior": "reference_prior", "true_reference_prior": "reference_prior",
    "cdpruner_prior": "cdpruner_prior", "cdpruner_default_soft_score": "cdpruner_prior",
    "relevance": "relevance", "instruction_guided_visual_relevance": "relevance",
    "norm": "norm", "visual_token_norm_saliency": "norm",
    "spatial": "spatial", "spatial_centrality_prior": "spatial",
    "redundancy": "redundancy", "redundancy_density_penalty": "redundancy",
    "attn": "attn", "attention": "attn", "attention_proxy_saliency": "attn",
    "similarity": "similarity", "pairwise_token_similarity": "similarity",
}
SCORER_SPECS = {
    "reference_prior": {"atom": "cdpruner_reference_mask_prior", "params": {"selected_score": 1.0, "unselected_score": 0.0, "blend_soft_prior": 0.05, "transform": "identity"}},
    "cdpruner_prior": {"atom": "cdpruner_default_soft_score", "params": {"quality_weight": 0.75, "diversity_weight": 0.25, "transform": "minmax"}},
    "relevance": {"atom": "instruction_guided_visual_relevance", "params": {"sign": "negative_mean", "transform": "minmax", "power": 1.0}},
    "norm": {"atom": "visual_token_norm_saliency", "params": {"transform": "minmax"}},
    "spatial": {"atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}},
    "redundancy": {"atom": "redundancy_density_penalty", "params": {"transform": "minmax"}},
    "attn": {"atom": "attention_proxy_saliency", "params": {"norm_weight": 0.7, "center_weight": 0.3, "transform": "minmax"}},
    "similarity": {"atom": "pairwise_token_similarity", "params": {"similarity_metric": "cosine", "similarity_transform": "identity"}},
}
MEMORY = """
v6.1 full MME improved to about 1316 perception but still had overlap≈0.16 and changed≈27.
The old cdpruner_prior was only a proxy. v6.2 adds reference_prior from a true reference mask.
Use reference_prior to keep full-token search connected to the teacher signal.
Avoid pure low-overlap MMR/DPP. Do not use residual swap or fixed token IDs.
"""
ATOM_CARDS = """
Scalar scorers allowed in fusion weights:
- reference_prior / cdpruner_reference_mask_prior: true reference-mask teacher score [B,N].
- cdpruner_prior, relevance, norm, spatial, redundancy, attn.
Similarity:
- similarity / pairwise_token_similarity is [B,N,N], only for MMR/DPP, not fusion weights.
Selectors:
- topk_selector
- full_token_pool_dpp_selector(pool_multiplier, postprocess)
- full_token_pool_mmr_selector(pool_multiplier, mmr_lambda, postprocess)
- stratified_full_token_selector(core_ratio, grid_size)
"""
FALLBACK_FAMILIES = [
    {"family_name": "v62_reference_topk_strong", "scorers": ["reference_prior", "relevance"], "weights": {"reference_prior": 0.9, "relevance": 0.1}, "selector": {"atom": "topk_selector", "params": {}}, "rationale": "Strong reference prior."},
    {"family_name": "v62_reference_dpp", "scorers": ["reference_prior", "relevance", "similarity"], "weights": {"reference_prior": 0.85, "relevance": 0.15}, "selector": {"atom": "full_token_pool_dpp_selector", "params": {"pool_multiplier": 2.0, "postprocess": "sort_by_position"}}, "rationale": "Reference-aware DPP."},
    {"family_name": "v62_reference_mmr_highlambda", "scorers": ["reference_prior", "relevance", "similarity"], "weights": {"reference_prior": 0.85, "relevance": 0.15}, "selector": {"atom": "full_token_pool_mmr_selector", "params": {"pool_multiplier": 2.0, "mmr_lambda": 0.98, "postprocess": "sort_by_position"}}, "rationale": "Conservative MMR."},
    {"family_name": "v62_reference_stratified", "scorers": ["reference_prior", "relevance", "spatial"], "weights": {"reference_prior": 0.8, "relevance": 0.15, "spatial": 0.05}, "selector": {"atom": "stratified_full_token_selector", "params": {"core_ratio": 0.875, "grid_size": 4}}, "rationale": "Reference + mild spatial."},
]
def canonical_json(x): return json.dumps(x, ensure_ascii=False, sort_keys=True)
def fingerprint(x): return hashlib.sha1(canonical_json(x).encode()).hexdigest()[:16]
def extract_json(text):
    m = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if m: text = m.group(1)
    start = text.find("{")
    if start < 0: return None
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{": depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try: return json.loads(text[start:i+1])
                except Exception: return None
    return None
def canon_scorer(x):
    if not isinstance(x, str): return None
    return ATOM_ALIAS.get(x.strip(), ATOM_ALIAS.get(x.strip().lower()))
def norm_selector(atom):
    atom = str(atom or "full_token_pool_dpp_selector")
    mp = {"topk": "topk_selector", "top_k": "topk_selector", "dpp": "full_token_pool_dpp_selector", "pool_dpp": "full_token_pool_dpp_selector", "mmr": "full_token_pool_mmr_selector", "pool_mmr": "full_token_pool_mmr_selector", "stratified": "stratified_full_token_selector"}
    atom = mp.get(atom, atom)
    return atom if atom in {"topk_selector","full_token_pool_dpp_selector","full_token_pool_mmr_selector","stratified_full_token_selector"} else "full_token_pool_dpp_selector"
def sanitize_family(plan, idx):
    name = str(plan.get("family_name", f"llm_family_{idx}")).replace(" ", "_")
    raw = plan.get("scorers", ["reference_prior", "relevance", "similarity"])
    if not isinstance(raw, list): raw = ["reference_prior", "relevance", "similarity"]
    scorers = []
    for s in raw:
        c = canon_scorer(s)
        if c and c not in scorers: scorers.append(c)
    if "reference_prior" not in scorers: scorers.insert(0, "reference_prior")
    if "relevance" not in scorers: scorers.append("relevance")
    sel = plan.get("selector", {})
    if not isinstance(sel, Mapping): sel = {}
    atom = norm_selector(sel.get("atom"))
    params = sel.get("params", {})
    if not isinstance(params, Mapping): params = {}
    if atom in {"full_token_pool_dpp_selector","full_token_pool_mmr_selector"} and "similarity" not in scorers:
        scorers.append("similarity")
    raw_w = plan.get("weights", {})
    weights = {}
    if isinstance(raw_w, Mapping):
        for k,v in raw_w.items():
            ck = canon_scorer(k)
            if ck and ck != "similarity":
                try: weights[ck] = max(0.0, float(v))
                except Exception: pass
    weights.pop("similarity", None)
    if not weights: weights = {"reference_prior": 0.85, "relevance": 0.15}
    for s in [x for x in scorers if x != "similarity"]:
        weights.setdefault(s, 0.0)
    if sum(weights.values()) <= 1e-9: weights = {"reference_prior": 0.85, "relevance": 0.15}
    return {"family_name": name, "scorers": scorers, "weights": weights, "selector": {"atom": atom, "params": dict(params)}, "rationale": str(plan.get("rationale",""))}
def policy_from_family(fam, suffix=""):
    scorers = {s: SCORER_SPECS[s] for s in fam["scorers"] if s in SCORER_SPECS}
    sel_atom = fam["selector"]["atom"]
    if sel_atom in {"full_token_pool_dpp_selector","full_token_pool_mmr_selector"}:
        scorers.setdefault("similarity", SCORER_SPECS["similarity"])
    weights = dict(fam["weights"]); weights.pop("similarity", None)
    total = sum(abs(float(v)) for v in weights.values()) or 1.0
    weights = {k: round(float(v)/total, 4) for k,v in weights.items() if k in scorers and k != "similarity"}
    return {"version":"0.5-light","policy_name":(fam["family_name"]+suffix).replace(" ","_"),"target_host":"cdpruner_encode_images","target_domain":"mllm_visual_token_pruning","search_stage":"v6_2_reference_prior_full_token_search","pipeline":[{"id":"visual_token_selection","trigger":{"atom":"pre_llm_visual_reduction_trigger"},"target":{"atom":"image_patch_tokens"},"scorer":scorers,"fusion":{"atom":"full_token_score_fusion","params":{"weights":weights,"score_normalization":"minmax","output_transform":"minmax"}},"budget":{"atom":"fixed_keep_tokens","params":{"keep_tokens":"host_argument"}},"selector":fam["selector"],"action":{"atom":"hard_prune"},"protection":[]}]}
def expand_family(fam, max_variants):
    scalar = [s for s in fam["scorers"] if s != "similarity"]
    if "reference_prior" not in scalar: scalar.insert(0, "reference_prior")
    if "relevance" not in scalar: scalar.append("relevance")
    aux = [s for s in scalar if s not in {"reference_prior", "cdpruner_prior", "relevance"}]
    weight_variants = [dict(fam["weights"])]
    for wrp,wcp,wrel,waux in [(0.95,0,0.05,0),(0.90,0,0.10,0),(0.85,0,0.15,0),(0.80,0,0.15,0.05),(0.70,0.10,0.15,0.05),(0.60,0.20,0.15,0.05),(0.50,0.25,0.20,0.05)]:
        w = {"reference_prior": wrp, "relevance": wrel}
        if "cdpruner_prior" in scalar and wcp > 0: w["cdpruner_prior"] = wcp
        if aux and waux > 0:
            for a in aux: w[a] = waux/len(aux)
        weight_variants.append(w)
    selector_variants = [("topk_selector", {}),("full_token_pool_dpp_selector", {"pool_multiplier":1.5,"postprocess":"sort_by_position"}),("full_token_pool_dpp_selector", {"pool_multiplier":2.0,"postprocess":"sort_by_position"}),("full_token_pool_dpp_selector", {"pool_multiplier":3.0,"postprocess":"sort_by_position"}),("full_token_pool_mmr_selector", {"pool_multiplier":1.5,"mmr_lambda":0.97,"postprocess":"sort_by_position"}),("full_token_pool_mmr_selector", {"pool_multiplier":2.0,"mmr_lambda":0.98,"postprocess":"sort_by_position"}),("stratified_full_token_selector", {"core_ratio":0.875,"grid_size":4}),("stratified_full_token_selector", {"core_ratio":0.95,"grid_size":4})]
    selector_variants.insert(0, (fam["selector"]["atom"], dict(fam["selector"].get("params", {}))))
    out, seen = [], set()
    for sel_atom, sel_params in selector_variants:
        for w in weight_variants:
            vf = {"family_name": fam["family_name"], "scorers": list(dict.fromkeys(scalar + (["similarity"] if sel_atom in {"full_token_pool_dpp_selector","full_token_pool_mmr_selector"} else []))), "weights": dict(w), "selector": {"atom": sel_atom, "params": dict(sel_params)}, "rationale": fam.get("rationale","")}
            fp = fingerprint(vf)
            if fp in seen: continue
            seen.add(fp); out.append(vf)
            if len(out) >= max_variants: return out
    return out
def build_prompt(history, k):
    top = sorted(history, key=lambda r: float(r.get("adjusted_score", r.get("combined_score",0))), reverse=True)[:10]
    hist = [{"policy":r.get("policy_name"),"adjusted":r.get("adjusted_score"),"robust":r.get("combined_score"),"mean":r.get("perception_mean"),"std":r.get("perception_std"),"overlap":r.get("overlap_with_reference_avg"),"changed":r.get("changed_tokens_avg"),"selector":r.get("selector"),"weights":r.get("weights")} for r in top]
    return f"""Design one full-token visual token pruning policy family for K={k}.

{MEMORY}

{ATOM_CARDS}

History:
{json.dumps(hist, indent=2, ensure_ascii=False)}

Return strict JSON only:
{{
  "family_name": "name",
  "scorers": ["reference_prior", "relevance", "norm|spatial|redundancy|attn", "similarity"],
  "weights": {{"reference_prior": 0.8, "relevance": 0.15, "norm": 0.05}},
  "selector": {{"atom": "topk_selector|full_token_pool_dpp_selector|full_token_pool_mmr_selector|stratified_full_token_selector", "params": {{}}}},
  "rationale": "why it generalizes"
}}
Similarity must not appear in weights.
Do not use fixed token IDs or residual swap.
"""
def call_llm(prompt, args):
    if not os.environ.get("OPENAI_API_KEY"): return None
    try:
        from openai import OpenAI
        kwargs = {"api_key": os.environ["OPENAI_API_KEY"]}
        if os.environ.get("OPENAI_BASE_URL"): kwargs["base_url"] = os.environ["OPENAI_BASE_URL"]
        client = OpenAI(**kwargs)
        resp = client.chat.completions.create(model=args.model, messages=[{"role":"system","content":"Return strict JSON only."},{"role":"user","content":prompt}], temperature=args.temperature, max_tokens=args.max_tokens)
        return extract_json(resp.choices[0].message.content or "")
    except Exception as e:
        print("[LLM_ERROR]", e, flush=True); return None
def first_json(text):
    start = text.find("{")
    if start < 0: return {}
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{": depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try: return json.loads(text[start:i+1])
                except Exception: return {}
    return {}
def eval_multismoke(policy_path, args, log_dir):
    cmd = [sys.executable, "yaml_policy/openevolve_yaml_search/evaluator_multismoke.py", str(policy_path), "--gpu", str(args.gpu), "--token", str(args.token), "--base-script", str(args.base_script), "--num-chunks", str(args.num_chunks), "--chunks", args.chunks, "--std-penalty", str(args.std_penalty), "--log-dir", str(log_dir)]
    env = os.environ.copy(); env["EVO_TOKEN"] = str(args.token); env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
    proc = subprocess.run(cmd, cwd=Path.cwd(), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log_dir.mkdir(parents=True, exist_ok=True); (log_dir/"multismoke_stdout.txt").write_text(proc.stdout)
    row = first_json(proc.stdout)
    return row if row else {"valid":0.0,"combined_score":0.0,"error":"parse_failed","stdout_tail":proc.stdout[-2000:]}
def apply_penalty(row, args):
    r = dict(row)
    robust = float(r.get("combined_score",0)); overlap = float(r.get("overlap_with_reference_avg",0)); changed = float(r.get("changed_tokens_avg",0))
    op = args.low_overlap_penalty * max(0.0, args.low_overlap_floor - overlap)
    cp = args.changed_penalty * max(0.0, changed - args.changed_soft_ceiling)
    r["raw_robust_score"] = robust; r["overlap_penalty"] = op; r["changed_penalty"] = cp; r["adjusted_score"] = robust - op - cp
    return r
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU","3"))
    ap.add_argument("--token", type=int, default=int(os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS","32"))))
    ap.add_argument("--base-script", default="scripts/v1_5/eval/mme_yaml_smoke21.sh")
    ap.add_argument("--chunks", default="0,1,2")
    ap.add_argument("--num-chunks", type=int, default=21)
    ap.add_argument("--families", type=int, default=8)
    ap.add_argument("--variants-per-family", type=int, default=12)
    ap.add_argument("--std-penalty", type=float, default=0.5)
    ap.add_argument("--out-dir", default=None)
    ap.add_argument("--model", default=os.environ.get("V6_LLM_MODEL","qwen-plus"))
    ap.add_argument("--temperature", type=float, default=float(os.environ.get("V6_LLM_TEMPERATURE","0.85")))
    ap.add_argument("--max-tokens", type=int, default=int(os.environ.get("V6_LLM_MAX_TOKENS","1600")))
    ap.add_argument("--low-overlap-floor", type=float, default=0.35)
    ap.add_argument("--low-overlap-penalty", type=float, default=80.0)
    ap.add_argument("--changed-soft-ceiling", type=float, default=20.0)
    ap.add_argument("--changed-penalty", type=float, default=0.75)
    args = ap.parse_args()
    out_dir = Path(args.out_dir or f"openevolve/runs/v6_2_reference_prior_K{args.token}_multismoke")
    policy_dir = out_dir/"policies"; log_dir = out_dir/"logs"; prompt_dir = out_dir/"prompts"
    for d in [policy_dir, log_dir, prompt_dir]: d.mkdir(parents=True, exist_ok=True)
    results_path = out_dir/"results.jsonl"; history=[]; seen=set(); best=None; fallback_i=0
    for fam_i in range(args.families):
        prompt = build_prompt(history, args.token); (prompt_dir/f"family_{fam_i:03d}_prompt.txt").write_text(prompt)
        plan = call_llm(prompt, args)
        if plan is None: plan = FALLBACK_FAMILIES[fallback_i % len(FALLBACK_FAMILIES)]; fallback_i += 1
        (prompt_dir/f"family_{fam_i:03d}_raw_plan.json").write_text(json.dumps(plan, indent=2, ensure_ascii=False))
        fam = sanitize_family(plan, fam_i); (prompt_dir/f"family_{fam_i:03d}_sanitized_plan.json").write_text(json.dumps(fam, indent=2, ensure_ascii=False))
        for var_i, vfam in enumerate(expand_family(fam, args.variants_per_family)):
            fp = fingerprint(vfam)
            if fp in seen: continue
            seen.add(fp)
            policy = policy_from_family(vfam, f"_f{fam_i:02d}_v{var_i:02d}")
            name = policy["policy_name"]; p = policy_dir/f"{len(seen):04d}_{name}.yaml"
            p.write_text(yaml.safe_dump(policy, sort_keys=False, allow_unicode=True))
            print(f"[EVAL] family={fam_i} variant={var_i} {name}", flush=True)
            row = apply_penalty(eval_multismoke(p, args, log_dir/f"{len(seen):04d}_{name}"), args)
            row.update({"policy_name":name,"policy_path":str(p),"family_plan":fam,"weights":policy["pipeline"][0]["fusion"]["params"]["weights"],"selector":policy["pipeline"][0]["selector"]["atom"],"selector_params":policy["pipeline"][0]["selector"].get("params",{})})
            with results_path.open("a", encoding="utf-8") as f: f.write(json.dumps(row, ensure_ascii=False)+"\n")
            history.append(row)
            if best is None or float(row.get("adjusted_score",0)) > float(best.get("adjusted_score",-1e18)):
                best = row; (out_dir/"best_policy.yaml").write_text(p.read_text()); (out_dir/"best_metrics.json").write_text(json.dumps(row, indent=2, ensure_ascii=False))
                print(f"[BEST] {name} adjusted={row.get('adjusted_score')} robust={row.get('combined_score')} overlap={row.get('overlap_with_reference_avg')} changed={row.get('changed_tokens_avg')} selector={row.get('selector')}", flush=True)
    rows=[]
    if results_path.exists():
        for line in results_path.read_text().splitlines():
            try: rows.append(json.loads(line))
            except Exception: pass
    with (out_dir/"results.csv").open("w", newline="", encoding="utf-8") as f:
        fields=["policy_name","valid","adjusted_score","raw_robust_score","combined_score","perception_mean","perception_std","perception_min","cognition_mean","overlap_with_reference_avg","changed_tokens_avg","overlap_penalty","changed_penalty","selector","policy_path"]
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader()
        for r in rows: w.writerow({k:r.get(k) for k in fields})
    print("done"); print("results:", results_path); print("best:", out_dir/"best_policy.yaml")
if __name__ == "__main__":
    main()
