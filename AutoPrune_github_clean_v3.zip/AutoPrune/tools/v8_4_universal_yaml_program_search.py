#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
v8_universal_yaml_program_search.py

LLM-driven fully-free YAML program synthesis for CDPruner visual token pruning.

Core idea:
1. Read typed atom cards from:
   yaml_policy/universal_pruning_yaml_v0_5_light/universal_pruning_typed_atom_registry_v0_5_light.yaml
2. Let LLM design a high-level policy_graph using universal typed atoms.
3. Lower the typed policy_graph into currently executable CDPruner YAML.
4. Verify by selftest, then evaluate with evaluator_multismoke.
5. Feed results/errors back to the next LLM generation.

This script keeps the search fully free:
- overlap/change are diagnostics only;
- no native-anchor penalty/reward;
- by default, native/reference atoms are not used unless explicitly requested by the LLM and the lowerer supports them.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import yaml


# ---------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------

def sha(obj: Any) -> str:
    return hashlib.sha1(json.dumps(obj, sort_keys=True, ensure_ascii=False).encode()).hexdigest()[:16]


def safe_float(x: Any, default: float = 0.0) -> float:
    try:
        return float(x)
    except Exception:
        return default


def first_json_or_yaml(text: str) -> Any:
    """
    Extract the first JSON/YAML object/list from an LLM response.
    It supports fenced ```json blocks and raw JSON.
    """
    m = re.search(r"```(?:json|yaml|yml)?\s*([\s\S]*?)```", text)
    if m:
        text = m.group(1).strip()

    # Try strict JSON whole text first.
    try:
        return json.loads(text)
    except Exception:
        pass

    # Try YAML whole text.
    try:
        obj = yaml.safe_load(text)
        if isinstance(obj, (dict, list)):
            return obj
    except Exception:
        pass

    # Extract first balanced JSON object/list.
    starts = [i for i in [text.find("{"), text.find("[")] if i >= 0]
    if not starts:
        return None
    start = min(starts)
    open_ch = text[start]
    close_ch = "}" if open_ch == "{" else "]"
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == open_ch:
                depth += 1
            elif ch == close_ch:
                depth -= 1
                if depth == 0:
                    raw = text[start:i + 1]
                    try:
                        return json.loads(raw)
                    except Exception:
                        try:
                            return yaml.safe_load(raw)
                        except Exception:
                            return None
    return None


def append_jsonl(path: Path, row: Mapping[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def load_jsonl(path: Path) -> List[Dict[str, Any]]:
    rows = []
    if not path.exists():
        return rows
    for line in path.read_text(encoding="utf-8").splitlines():
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except Exception:
            continue
    return rows


def sanitize_name(name: str, max_len: int = 160) -> str:
    name = re.sub(r"[^A-Za-z0-9_]+", "_", str(name)).strip("_")
    return (name or "candidate")[:max_len]


# ---------------------------------------------------------------------
# Registry loading
# ---------------------------------------------------------------------

def load_typed_atom_cards(reg_path: Path) -> Dict[str, Dict[str, Any]]:
    data = yaml.safe_load(reg_path.read_text(encoding="utf-8"))
    cards: Dict[str, Dict[str, Any]] = {}

    for category, atoms in (data.get("typed_atoms", {}) or {}).items():
        if not isinstance(atoms, dict):
            continue
        for name, card in atoms.items():
            if not isinstance(card, dict):
                continue
            atom_id = card.get("atom_id", name)
            cards[atom_id] = {
                "atom_id": atom_id,
                "category": category,
                "description": card.get("description", ""),
                "maturity": card.get("maturity", {}),
                "io_contract": card.get("io_contract", {}),
                "shape_constraints": card.get("shape_constraints", {}),
                "score_semantics": card.get("score_semantics", {}),
                "capability_requirements": card.get("capability_requirements", {}),
                "params_schema": card.get("params_schema", {}),
                "compatibility": card.get("compatibility", {}),
                "implementation_binding": card.get("implementation_binding", {}),
                "verifier_rules": card.get("verifier_rules", {}),
                "eval_hints": card.get("eval_hints", {}),
                "atom_granularity": card.get("atom_granularity"),
                "decomposable": card.get("decomposable"),
                "search_level": card.get("search_level"),
                "expose_to_llm": card.get("expose_to_llm"),
                "micro_decomposition": card.get("micro_decomposition"),
                "micro_search_policy": card.get("micro_search_policy"),
            }

    for name, card in (data.get("bridge_atoms", {}) or {}).items():
        if not isinstance(card, dict):
            continue
        atom_id = card.get("atom_id", name)
        cards[atom_id] = {
            "atom_id": atom_id,
            "category": "bridge",
            "description": card.get("description", ""),
            "io_contract": card.get("io_contract", {}),
            "score_semantics": card.get("score_semantics", {}),
            "params_schema": card.get("params_schema", {}),
            "implementation_binding": card.get("implementation_binding", {}),
            "atom_granularity": card.get("atom_granularity"),
            "decomposable": card.get("decomposable"),
            "search_level": card.get("search_level"),
            "expose_to_llm": card.get("expose_to_llm"),
            "micro_decomposition": card.get("micro_decomposition"),
        }

    return cards


def group_cards(cards: Mapping[str, Mapping[str, Any]]) -> Dict[str, List[str]]:
    by_cat: Dict[str, List[str]] = {}
    for atom, card in cards.items():
        by_cat.setdefault(str(card.get("category", "unknown")), []).append(atom)
    return {k: sorted(v) for k, v in by_cat.items()}


def _short_text(x: Any, max_chars: int = 160) -> str:
    if x is None:
        return ""
    s = str(x).replace("\n", " ").strip()
    s = re.sub(r"\s+", " ", s)
    return s[:max_chars]

def _schema_keys(x: Any, max_items: int = 8) -> List[str]:
    if isinstance(x, dict):
        return [str(k) for k in list(x.keys())[:max_items]]
    if isinstance(x, list):
        return [str(v)[:40] for v in x[:max_items]]
    return []

def compact_card(card: Mapping[str, Any]) -> Dict[str, Any]:
    """
    Very compact card for LLM prompt.
    Do NOT dump full params_schema / io_contract / compatibility / micro_decomposition.
    Full registry is saved to disk; prompt only needs enough for design.
    """
    params_schema = card.get("params_schema", {}) or {}
    io_contract = card.get("io_contract", {}) or {}
    micro = card.get("micro_decomposition", {}) or {}
    compat = card.get("compatibility", {}) or {}

    if isinstance(io_contract, dict):
        inputs = io_contract.get("inputs", {})
        outputs = io_contract.get("outputs", {})
    else:
        inputs, outputs = {}, {}

    return {
        "atom": card.get("atom_id"),
        "cat": card.get("category"),
        "desc": _short_text(card.get("description", ""), 140),
        "params": _schema_keys(params_schema, 6),
        "in": _schema_keys(inputs, 5),
        "out": _schema_keys(outputs, 5),
        "compat": _schema_keys(compat, 5),
        "micro": _schema_keys(micro, 5),
    }


def select_prompt_cards(cards: Mapping[str, Mapping[str, Any]], max_per_category: int = 22) -> Dict[str, List[Dict[str, Any]]]:
    """
    Prefer MLLM-relevant atoms, but still expose a broad set.
    """
    priority_keywords = [
        "visual", "image", "patch", "instruction", "text", "similarity", "dpp", "mmr",
        "coverage", "spatial", "entropy", "cluster", "object", "attention", "sink",
        "relevance", "diversity", "topk", "threshold", "adaptive", "uncertainty",
    ]
    by_cat = group_cards(cards)
    out: Dict[str, List[Dict[str, Any]]] = {}

    wanted_cats = ["triggers", "targets", "scorers", "fusions", "budgets", "selectors", "actions", "protections", "bridge"]
    for cat in wanted_cats:
        names = by_cat.get(cat, [])
        def score_name(n: str) -> Tuple[int, str]:
            s = sum(1 for k in priority_keywords if k in n.lower())
            return (-s, n)
        names = sorted(names, key=score_name)[:max_per_category]
        out[cat] = [compact_card(cards[n]) for n in names]
    return out


# ---------------------------------------------------------------------
# Lowering: typed universal plan -> executable CDPruner YAML
# ---------------------------------------------------------------------

EXEC_SCORER_ALIASES = {
    # Current native/default executable atoms.
    "instruction_guided_visual_relevance": "instruction_guided_visual_relevance",
    "conditional_similarity_score": "conditional_similarity_score",
    "pairwise_token_similarity": "pairwise_token_similarity",

    # v7 executable extensions previously added.
    "visual_token_norm_saliency": "visual_token_norm_saliency",
    "redundancy_density_penalty": "redundancy_density_penalty",
    "spatial_centrality_prior": "spatial_centrality_prior",
    "attention_proxy_saliency": "attention_proxy_saliency",
    "native_teacher_mask_prior": "native_teacher_mask_prior",
    "cdpruner_reference_mask_prior": "cdpruner_reference_mask_prior",
    "cdpruner_default_soft_score": "cdpruner_default_soft_score",

    # Universal registry atoms lowered to available approximations.
    "visual_encoder_cls_attention_score": "attention_proxy_saliency",
    "decoder_attention_to_visual_score": "attention_proxy_saliency",
    "class_token_attention_score": "attention_proxy_saliency",
    "observation_window_attention_score": "attention_proxy_saliency",
    "objectness_region_score": "visual_token_norm_saliency",
    "spatial_entropy_complexity_score": "spatial_centrality_prior",
    "tile_text_alignment_score": "instruction_guided_visual_relevance",
    "chart_structure_score": "spatial_centrality_prior",
    "ocr_density_score": "spatial_centrality_prior",
    "cluster_centroid_representativeness": "redundancy_density_penalty",
    "max_min_diversity_gain": "redundancy_density_penalty",
    "multi_objective_coverage_score": "spatial_centrality_prior",
    "query_agnostic_reconstruction_score": "visual_token_norm_saliency",
    "token_recovery_potential_score": "visual_token_norm_saliency",
    "pca_energy_importance": "visual_token_norm_saliency",
    "value_norm_score": "visual_token_norm_saliency",
    "key_l2_norm_score": "visual_token_norm_saliency",
    "visual_sink_score": "spatial_centrality_prior",
    "visual_register_relevance_score": "instruction_guided_visual_relevance",
    "modality_balance_score": "spatial_centrality_prior",
    "answer_uncertainty_score": "visual_token_norm_saliency",
    "adaptive_sampling_score": "visual_token_norm_saliency",
    "adaptive_halting_probability": "visual_token_norm_saliency",
}

EXEC_FUSION_ALIASES = {
    "quality_diversity_kernel": "quality_diversity_kernel",
    "weighted_sum_score_fusion": "full_token_score_fusion",
    "full_token_score_fusion": "full_token_score_fusion",
    "v7_score_product_fusion": "v7_score_product_fusion",
    "v7_rank_fusion": "v7_rank_fusion",
    "v7_teacher_residual_fusion": "v7_teacher_residual_fusion",

    "mmr_relevance_diversity_fusion": "v7_score_product_fusion",
    "two_stage_relevance_then_diversity": "v7_score_product_fusion",
    "multi_objective_balanced_covering_fusion": "full_token_score_fusion",
    "cluster_quality_diversity_fusion": "v7_score_product_fusion",
    "cost_aware_score_fusion": "full_token_score_fusion",
    "uncertainty_cost_fusion": "full_token_score_fusion",
    "recoverability_aware_fusion": "full_token_score_fusion",
    "hierarchical_anchor_context_fusion": "v7_rank_fusion",
    "frequency_time_domain_fusion": "full_token_score_fusion",
    "modality_aware_budget_fusion": "full_token_score_fusion",
}

EXEC_SELECTOR_ALIASES = {
    "dpp_selector": "dpp_selector",
    "topk_selector": "topk_selector",
    "mmr_selector": "mmr_selector",
    "v7_conditional_dpp_selector": "v7_conditional_dpp_selector",
    "v7_two_stage_pool_selector": "v7_two_stage_pool_selector",
    "full_token_pool_dpp_selector": "full_token_pool_dpp_selector",
    "topk_pool_dpp_selector": "topk_pool_dpp_selector",
    "full_token_pool_mmr_selector": "full_token_pool_mmr_selector",
    "topk_pool_mmr_selector": "topk_pool_mmr_selector",
    "stratified_full_token_selector": "stratified_full_token_selector",

    "hierarchical_topk_dpp_selector": "v7_two_stage_pool_selector",
    "balanced_covering_selector": "stratified_full_token_selector",
    "greedy_max_min_selector": "mmr_selector",
    "cluster_centroid_selector": "topk_pool_dpp_selector",
    "threshold_selector": "topk_selector",
    "stochastic_sampling_selector": "topk_selector",
    "leverage_score_selector": "topk_selector",
    "bipartite_matching_selector": "topk_pool_mmr_selector",
    "framefusion_selector": "v7_two_stage_pool_selector",
}

EXEC_BUDGET_ALIASES = {
    "fixed_keep_tokens": "fixed_keep_tokens",
    "fixed_keep_ratio": "fixed_keep_tokens",
    "input_adaptive_token_count": "fixed_keep_tokens",
    "dynamic_visual_complexity_budget": "fixed_keep_tokens",
    "high_resolution_tile_budget": "fixed_keep_tokens",
    "modality_aware_budget": "fixed_keep_tokens",
    "structured_sparsity_ratio": "fixed_keep_tokens",
}

EXEC_ACTION_ALIASES = {
    "dpp_subset_prune": "dpp_subset_prune",
    "hard_prune": "hard_prune",
    "soft_mask_prune": "hard_prune",
    "tiled_visual_prune": "hard_prune",
    "token_reorganization": "hard_prune",
    "token_halting": "hard_prune",
    "token_squeeze_summary": "hard_prune",
}

EXEC_PROTECTION_ALIASES = {
    "special_token_preservation": "special_token_preservation",
    "spatial_coverage_preservation": "spatial_coverage_preservation",
    "semantic_cluster_coverage_preservation": "spatial_coverage_preservation",
    "top_relevance_anchor_preservation": "special_token_preservation",
    "visual_sink_preservation": "special_token_preservation",
    "attention_sink_preservation": "special_token_preservation",
    "modality_balance_preservation": "spatial_coverage_preservation",
}

DEFAULT_SCORER_PARAMS = {
    "instruction_guided_visual_relevance": {"sign": "negative_mean", "transform": "minmax", "power": 1.0},
    "conditional_similarity_score": {"similarity_metric": "cosine", "similarity_transform": "identity"},
    "pairwise_token_similarity": {"similarity_metric": "cosine", "similarity_transform": "identity"},
    "visual_token_norm_saliency": {"transform": "minmax"},
    "redundancy_density_penalty": {"transform": "minmax"},
    "spatial_centrality_prior": {"center_bias": 1.0, "transform": "minmax"},
    "attention_proxy_saliency": {"transform": "minmax"},
    "native_teacher_mask_prior": {"selected_score": 1.0, "unselected_score": 0.0, "blend_soft_prior": 0.0},
    "cdpruner_reference_mask_prior": {"selected_score": 1.0, "unselected_score": 0.0},
    "cdpruner_default_soft_score": {"transform": "minmax"},
}

FORBIDDEN_FREE_ATOMS = {
    "native_teacher_mask_prior",
    "cdpruner_reference_mask_prior",
    "cdpruner_default_soft_score",
}


def normalize_node_list(obj: Any) -> List[Dict[str, Any]]:
    if isinstance(obj, dict):
        if isinstance(obj.get("nodes"), list):
            return [x for x in obj["nodes"] if isinstance(x, dict)]
        if isinstance(obj.get("policy_graph"), dict):
            return normalize_node_list(obj["policy_graph"])
        if isinstance(obj.get("candidate"), dict):
            return normalize_node_list(obj["candidate"])
    return []


def plan_from_llm_obj(obj: Any) -> List[Dict[str, Any]]:
    """
    Accept several LLM formats:
    - {"policy_graph": {"nodes": [...]}}
    - {"nodes": [...]}
    - {"candidates": [{"policy_graph": ...}, ...]}
    """
    if isinstance(obj, dict) and isinstance(obj.get("candidates"), list):
        plans = []
        for c in obj["candidates"]:
            nodes = normalize_node_list(c)
            if nodes:
                plans.append({"meta": {k: c.get(k) for k in ["policy_name", "rationale"] if isinstance(c, dict)}, "nodes": nodes})
        return plans
    nodes = normalize_node_list(obj)
    if nodes:
        return [{"meta": {}, "nodes": nodes}]
    return []


def lower_atom(atom: str, slot: str) -> Tuple[str, str]:
    """
    Return executable_atom, lowering_note.
    """
    maps = {
        "scorer": EXEC_SCORER_ALIASES,
        "fusion": EXEC_FUSION_ALIASES,
        "selector": EXEC_SELECTOR_ALIASES,
        "budget": EXEC_BUDGET_ALIASES,
        "action": EXEC_ACTION_ALIASES,
        "protection": EXEC_PROTECTION_ALIASES,
    }
    table = maps.get(slot, {})
    if atom in table:
        out = table[atom]
        return out, "" if out == atom else f"{atom}->{out}"
    # Default fallbacks by slot.
    fallbacks = {
        "scorer": "visual_token_norm_saliency",
        "fusion": "full_token_score_fusion",
        "selector": "v7_conditional_dpp_selector",
        "budget": "fixed_keep_tokens",
        "action": "hard_prune",
        "protection": "special_token_preservation",
    }
    out = fallbacks.get(slot, atom)
    return out, f"{atom}->{out}(fallback)"


def merge_params(defaults: Mapping[str, Any], user: Any) -> Dict[str, Any]:
    out = dict(defaults or {})
    if isinstance(user, dict):
        for k, v in user.items():
            # Keep only simple JSON-like params. Avoid nested unknown weird structures unless safe.
            if isinstance(v, (str, int, float, bool)) or v is None or isinstance(v, (list, dict)):
                out[k] = v
    return out




def lower_plan_to_policy(plan: Mapping[str, Any], idx: int, token: int, ban_native_teacher: bool = True, cards: Optional[Mapping[str, Mapping[str, Any]]] = None) -> Tuple[Dict[str, Any], List[str], Dict[str, Any]]:
    """
    v8.3 plan-aware lowerer.

    Key difference from v8/v8.2:
    - Do not simply replace atom names through alias tables.
    - First interpret LLM nodes as planning intents.
    - Then compile those intents into compositional executable primitives.
    - Track compile fidelity through compile_report.
    """
    nodes = plan.get("nodes", [])
    meta = plan.get("meta", {}) or {}
    notes: List[str] = []

    scorer_specs: Dict[str, Dict[str, Any]] = {}
    protections: List[Dict[str, Any]] = []

    fusion_pref: Optional[Dict[str, Any]] = None
    selector_pref: Optional[Dict[str, Any]] = None
    action_spec: Optional[Dict[str, Any]] = None

    bridge_atoms_seen: List[str] = []
    budget_atoms_seen: List[str] = []
    selector_atoms_seen: List[str] = []
    fusion_atoms_seen: List[str] = []
    protection_atoms_seen: List[str] = []

    intent_flags = {
        "attention": False,
        "semantic": False,
        "norm": False,
        "coverage": False,
        "cluster": False,
        "similarity": False,
        "uncertainty": False,
        "recoverability": False,
        "dpp": False,
        "mmr": False,
        "dynamic_budget": False,
        "protection": False,
    }

    compile_report: Dict[str, Any] = {
        "direct_count": 0,
        "composed_count": 0,
        "approx_count": 0,
        "ignored_count": 0,
        "fallback_count": 0,
        "unsupported_count": 0,
        "mappings": [],
        "fatal": False,
        "fatal_reasons": [],
    }

    def add_report(status: str, atom: str, lowered_to: Any, reason: str = "", node: Optional[Mapping[str, Any]] = None) -> None:
        key = f"{status}_count"
        if key in compile_report:
            compile_report[key] += 1
        compile_report["mappings"].append({
            "status": status,
            "atom": atom,
            "lowered_to": lowered_to,
            "reason": reason,
            "expected_role": (node or {}).get("expected_role"),
            "intent": (node or {}).get("intent"),
            "must_preserve": (node or {}).get("must_preserve"),
            "fallback_allowed": (node or {}).get("fallback_allowed"),
        })

    def unique_key(base: str) -> str:
        k = sanitize_name(base, max_len=48)
        if not k:
            k = "score"
        if k not in scorer_specs:
            return k
        i = 2
        while f"{k}_{i}" in scorer_specs:
            i += 1
        return f"{k}_{i}"

    def add_scorer(role: str, backend_atom: str, source_atom: str, params: Any, status: str, reason: str, node: Mapping[str, Any]) -> None:
        key = unique_key(str(node.get("id") or role or backend_atom))
        merged = merge_params(DEFAULT_SCORER_PARAMS.get(backend_atom, {}), params if isinstance(params, dict) else {})
        merged.setdefault("source_atom", source_atom)
        merged.setdefault("expected_role", role)
        if source_atom != backend_atom:
            merged.setdefault("lowered_from", source_atom)
        scorer_specs[key] = {
            "atom": backend_atom,
            "params": merged,
        }
        add_report(status, source_atom, f"scorer:{key}:{backend_atom}", reason, node)
        notes.append(f"{source_atom}->{backend_atom}({role},{status})")

    def norm_slot(slot: str) -> str:
        slot = str(slot or "").strip().lower()
        if slot.endswith("s"):
            slot = slot[:-1]
        aliases = {
            "score": "scorer",
            "fuse": "fusion",
            "select": "selector",
            "protect": "protection",
            "budgeter": "budget",
        }
        return aliases.get(slot, slot)

    def infer_slot(atom: str, slot: str) -> str:
        """
        Prefer canonical atom role over LLM-provided slot.

        Reason:
        LLM sometimes writes slot=scorer for a fusion atom such as
        cluster_quality_diversity_fusion. If we trust the slot blindly,
        the lowerer may compile a fusion intention as a scorer proxy.
        """
        slot = norm_slot(slot)

        known_bridges = {
            "quality_similarity_to_dpp_kernel_bridge",
            "query_relevance_to_dpp_quality_bridge",
            "uncertainty_to_budget_bridge",
            "structure_score_to_budget_bridge",
            "coverage_constraint_to_protection_bridge",
            "token_score_to_protection_mask_bridge",
            "cache_score_to_token_score_bridge",
            "cluster_assignment_to_merge_plan_bridge",
            "redundancy_to_importance_bridge",
            "token_score_to_frame_budget_bridge",
        }

        known_triggers = {
            "pre_llm_visual_reduction_trigger",
            "dynamic_scene_complexity_trigger",
            "high_resolution_tile_trigger",
            "video_frame_sampling_trigger",
            "two_stage_pre_and_inside_llm_trigger",
            "selected_llm_layer_trigger",
            "layer_range_progressive_trigger",
            "per_layer_halting_trigger",
            "decode_step_trigger",
            "prefill_end_observation_trigger",
        }

        known_targets = {
            "image_patch_tokens",
            "visual_tokens_inside_llm",
            "visual_register_tokens",
            "high_resolution_tile_tokens",
            "video_spatiotemporal_tokens",
            "text_context_tokens",
            "kv_cache_entries",
        }

        # Canonical non-scorer roles must override LLM slot.
        if atom in known_bridges or atom.endswith("_bridge"):
            return "bridge"
        if atom in known_triggers:
            return "trigger"
        if atom in known_targets:
            return "target"
        if atom in EXEC_FUSION_ALIASES:
            return "fusion"
        if atom in EXEC_SELECTOR_ALIASES:
            return "selector"
        if atom in EXEC_BUDGET_ALIASES:
            return "budget"
        if atom in EXEC_ACTION_ALIASES:
            return "action"
        if atom in EXEC_PROTECTION_ALIASES:
            return "protection"
        if atom in EXEC_SCORER_ALIASES:
            return "scorer"

        # Unknown atoms may still use LLM-provided slot.
        if slot:
            return slot
        return "unknown"

    canonical_atom_rewrites = {
        # Common near-miss names generated by LLM.
        "visual_reconstruction_uncertainty_score": "query_agnostic_reconstruction_score",
        "visual_reconstruction_score": "query_agnostic_reconstruction_score",
        "reconstruction_uncertainty_score": "query_agnostic_reconstruction_score",
        "token_recoverability_score": "token_recovery_potential_score",
        "token_recoverability": "token_recovery_potential_score",
        "recoverability_score": "token_recovery_potential_score",
        "semantic_cluster_assignment": "cluster_centroid_representativeness",
        "semantic_cluster_score": "cluster_centroid_representativeness",
        "cluster_representativeness_score": "cluster_centroid_representativeness",
        "cls_attention_score": "visual_encoder_cls_attention_score",
        "visual_cls_attention_score": "visual_encoder_cls_attention_score",
        "decoder_visual_attention_score": "decoder_attention_to_visual_score",
        "decoder_attention_visual_score": "decoder_attention_to_visual_score",
        "visual_attention_score": "visual_encoder_cls_attention_score",
        "coverage_score": "multi_objective_coverage_score",
        "spatial_coverage_score": "multi_objective_coverage_score",
        "spatial_complexity_score": "spatial_entropy_complexity_score",
        "objectness_score": "objectness_region_score",
        "uncertainty_score": "answer_uncertainty_score",
    }

    known_registry_atoms = set(cards.keys()) if isinstance(cards, Mapping) else set()
    known_executable_or_extra_atoms = set()
    for _d in [
        EXEC_SCORER_ALIASES,
        EXEC_FUSION_ALIASES,
        EXEC_SELECTOR_ALIASES,
        EXEC_BUDGET_ALIASES,
        EXEC_ACTION_ALIASES,
        EXEC_PROTECTION_ALIASES,
    ]:
        known_executable_or_extra_atoms.update(_d.keys())
        known_executable_or_extra_atoms.update(_d.values())

    attention_atoms = {
        "attention_proxy_saliency",
        "visual_encoder_cls_attention_score",
        "decoder_attention_to_visual_score",
        "class_token_attention_score",
        "observation_window_attention_score",
        "attention_sink_preservation",
    }

    semantic_atoms = {
        "instruction_guided_visual_relevance",
        "tile_text_alignment_score",
        "visual_register_relevance_score",
        "decoder_attention_to_visual_score",
    }

    norm_atoms = {
        "visual_token_norm_saliency",
        "objectness_region_score",
        "value_norm_score",
        "key_l2_norm_score",
        "pca_energy_importance",
        "adaptive_sampling_score",
        "adaptive_halting_probability",
        "token_recovery_potential_score",
        "query_agnostic_reconstruction_score",
    }

    coverage_atoms = {
        "spatial_entropy_complexity_score",
        "multi_objective_coverage_score",
        "spatial_centrality_prior",
        "visual_sink_score",
        "position_based_sink_score",
        "ocr_density_score",
        "modality_balance_score",
        "chart_structure_score",
    }

    cluster_atoms = {
        "cluster_centroid_representativeness",
        "max_min_diversity_gain",
        "redundancy_density_penalty",
        "semantic_cluster_coverage_preservation",
    }

    similarity_atoms = {
        "pairwise_token_similarity",
        "conditional_similarity_score",
        "spatiotemporal_similarity_score",
    }

    uncertainty_atoms = {
        "answer_uncertainty_score",
        "adaptive_sampling_score",
        "adaptive_halting_probability",
        "token_recovery_potential_score",
    }

    recoverability_atoms = {
        "recoverability_aware_fusion",
        "token_recovery_potential_score",
        "query_agnostic_reconstruction_score",
    }

    for n_i, node in enumerate(nodes):
        if not isinstance(node, dict):
            continue

        atom = str(node.get("atom", node.get("atom_id", ""))).strip()
        if not atom:
            continue

        raw_atom_name = atom
        if atom in canonical_atom_rewrites:
            atom = canonical_atom_rewrites[atom]
            notes.append(f"atom_canonicalized:{raw_atom_name}->{atom}")

        raw_slot = norm_slot(node.get("slot", node.get("category", "")))
        slot = infer_slot(atom, raw_slot)
        if raw_slot and slot != raw_slot:
            notes.append(f"slot_corrected:{atom}:{raw_slot}->{slot}")
        params = node.get("params", {})
        expected_role = str(node.get("expected_role", "") or "").strip().lower()
        must_preserve = bool(node.get("must_preserve", False))
        fallback_allowed = bool(node.get("fallback_allowed", True))

        if known_registry_atoms and atom not in known_registry_atoms and atom not in known_executable_or_extra_atoms:
            reason = f"atom_not_in_registry_after_canonicalization: raw={raw_atom_name}, atom={atom}"
            if must_preserve and not fallback_allowed:
                add_report("unsupported", atom, None, reason, node)
                compile_report["fatal"] = True
                compile_report["fatal_reasons"].append(reason)
                continue
            else:
                # Allow compilation by declared role, but count as approx rather than high-fidelity composed.
                add_report("approx", atom, f"compile_by_expected_role:{expected_role or slot}", reason, node)
                notes.append(f"unknown_atom_compiled_by_role:{raw_atom_name}->{atom}:{expected_role or slot}")

        if atom in FORBIDDEN_FREE_ATOMS and ban_native_teacher:
            add_report("unsupported", atom, None, "native/reference atom is banned in fully-free search", node)
            compile_report["fatal"] = True
            compile_report["fatal_reasons"].append(f"banned native/reference atom: {atom}")
            continue

        if slot == "trigger":
            # Trigger is fixed by CDPruner host, but dynamic triggers can still imply dynamic selection intent.
            if atom in {"dynamic_scene_complexity_trigger", "high_resolution_tile_trigger"}:
                intent_flags["dynamic_budget"] = True
                add_report("composed", atom, "selector_params:dynamic_pool", "trigger intent converted into dynamic pool/search parameters", node)
                notes.append(f"{atom}->dynamic_pool_intent(composed)")
            else:
                add_report("approx", atom, "fixed_host_trigger:pre_llm_visual_reduction_trigger", "host trigger is fixed", node)
                notes.append(f"host_fixed_trigger_approximates:{atom}")
            continue

        if slot == "target":
            if atom != "image_patch_tokens":
                add_report("approx", atom, "target:image_patch_tokens", "current host only prunes image patch tokens", node)
                notes.append(f"{atom}->image_patch_tokens(host_target)")
            else:
                add_report("direct", atom, "target:image_patch_tokens", "direct target", node)
            continue

        if slot == "bridge":
            bridge_atoms_seen.append(atom)
            add_report("composed", atom, "bridge_intent", "bridge retained for later compositional lowering", node)
            notes.append(f"bridge_preference_seen:{atom}")
            if atom in {"quality_similarity_to_dpp_kernel_bridge", "query_relevance_to_dpp_quality_bridge"}:
                intent_flags["dpp"] = True
                intent_flags["similarity"] = True
            if atom in {"uncertainty_to_budget_bridge", "structure_score_to_budget_bridge"}:
                intent_flags["dynamic_budget"] = True
            if atom in {"coverage_constraint_to_protection_bridge", "token_score_to_protection_mask_bridge"}:
                intent_flags["protection"] = True
            continue

        if slot == "budget":
            budget_atoms_seen.append(atom)
            if atom == "fixed_keep_tokens":
                add_report("direct", atom, "fixed_keep_tokens", "fixed K is directly supported by host_argument", node)
                notes.append(f"{atom}->fixed_keep_tokens(direct)")
            elif atom in {
                "dynamic_visual_complexity_budget",
                "input_adaptive_token_count",
                "framewise_adaptive_budget",
                "high_resolution_tile_budget",
                "modality_aware_budget",
                "layerwise_keep_ratio",
                "progressive_drop_ratio",
            }:
                intent_flags["dynamic_budget"] = True
                add_report("composed", atom, "selector_params:pool_multiplier/quality_power", "fixed final K, budget intent changes internal pool/search aggressiveness", node)
                notes.append(f"{atom}->dynamic_selection_params(composed)")
            else:
                add_report("approx", atom, "fixed_keep_tokens", "budget is approximated by fixed visual token budget", node)
                notes.append(f"{atom}->fixed_keep_tokens(approx)")
            continue

        if slot == "fusion":
            fusion_atoms_seen.append(atom)
            fusion_pref = {
                "atom": atom,
                "params": params if isinstance(params, dict) else {},
                "node": node,
            }
            if "dpp" in atom or "diversity" in atom or atom in {"quality_diversity_kernel", "cluster_quality_diversity_fusion"}:
                intent_flags["dpp"] = True
                intent_flags["similarity"] = True
            if "coverage" in atom or "balanced" in atom:
                intent_flags["coverage"] = True
            if "cluster" in atom:
                intent_flags["cluster"] = True
            if "uncertainty" in atom:
                intent_flags["uncertainty"] = True
            add_report("composed" if atom in EXEC_FUSION_ALIASES else "approx", atom, "fusion_intent", "fusion intent retained for IR-level compilation", node)
            continue

        if slot == "selector":
            selector_atoms_seen.append(atom)
            selector_pref = {
                "atom": atom,
                "params": params if isinstance(params, dict) else {},
                "node": node,
            }
            if "dpp" in atom or atom in {"cluster_centroid_selector", "balanced_covering_selector"}:
                intent_flags["dpp"] = True
                intent_flags["similarity"] = True
            if "mmr" in atom or "max_min" in atom:
                intent_flags["mmr"] = True
                intent_flags["similarity"] = True
            if "coverage" in atom or "balanced" in atom:
                intent_flags["coverage"] = True
            if "cluster" in atom:
                intent_flags["cluster"] = True
            add_report("composed" if atom in EXEC_SELECTOR_ALIASES else "approx", atom, "selector_intent", "selector intent retained for IR-level compilation", node)
            continue

        if slot == "action":
            exec_atom, note = lower_atom(atom, "action")
            action_spec = {"atom": exec_atom}
            add_report("direct" if exec_atom == atom else "approx", atom, f"action:{exec_atom}", note or "action lowered", node)
            if note:
                notes.append(note)
            continue

        if slot == "protection":
            protection_atoms_seen.append(atom)
            exec_atom, note = lower_atom(atom, "protection")
            if exec_atom in {"special_token_preservation", "spatial_coverage_preservation"}:
                protections.append({"atom": exec_atom, "params": params if isinstance(params, dict) else {}})
                intent_flags["protection"] = True
                add_report("direct" if exec_atom == atom else "composed", atom, f"protection:{exec_atom}", note or "protection lowered", node)
                if note:
                    notes.append(note)
            else:
                add_report("approx", atom, None, "unsupported protection approximated by no-op", node)
            continue

        if slot != "scorer":
            if must_preserve and not fallback_allowed:
                add_report("unsupported", atom, None, f"unsupported slot {slot} and fallback not allowed", node)
                compile_report["fatal"] = True
                compile_report["fatal_reasons"].append(f"unsupported non-scorer atom without fallback: {atom}/{slot}")
            else:
                add_report("ignored", atom, None, f"ignored unsupported slot {slot}", node)
                notes.append(f"ignored_unsupported_slot:{atom}/{slot}")
            continue

        # Scorer intent compilation.
        role_hint = expected_role
        if atom in similarity_atoms or role_hint == "similarity":
            backend = "conditional_similarity_score" if atom == "conditional_similarity_score" else "pairwise_token_similarity"
            intent_flags["similarity"] = True
            add_scorer("similarity", backend, atom, params, "direct" if backend == atom else "composed", "similarity signal", node)
        elif atom in attention_atoms or role_hint == "attention_quality":
            intent_flags["attention"] = True
            add_scorer("attention_quality", "attention_proxy_saliency", atom, params, "direct" if atom == "attention_proxy_saliency" else "composed", "attention-like quality signal", node)
        elif atom in semantic_atoms or role_hint == "semantic_quality":
            intent_flags["semantic"] = True
            add_scorer("semantic_quality", "instruction_guided_visual_relevance", atom, params, "direct" if atom == "instruction_guided_visual_relevance" else "composed", "semantic/task-conditioned quality signal", node)
        elif atom in norm_atoms or role_hint == "norm_quality":
            intent_flags["norm"] = True
            add_scorer("norm_quality", "visual_token_norm_saliency", atom, params, "direct" if atom == "visual_token_norm_saliency" else "composed", "generic norm/objectness/recoverability quality", node)
        elif atom in coverage_atoms or role_hint == "coverage":
            intent_flags["coverage"] = True
            add_scorer("coverage", "spatial_centrality_prior", atom, params, "direct" if atom == "spatial_centrality_prior" else "composed", "coverage/spatial structure signal", node)
        elif atom in cluster_atoms or role_hint == "cluster":
            intent_flags["cluster"] = True
            add_scorer("cluster", "redundancy_density_penalty", atom, params, "direct" if atom == "redundancy_density_penalty" else "composed", "cluster/redundancy/diversity signal", node)
        elif atom in uncertainty_atoms or role_hint == "uncertainty":
            intent_flags["uncertainty"] = True
            add_scorer("uncertainty_quality", "visual_token_norm_saliency", atom, params, "composed", "uncertainty approximated as generic quality/recoverability", node)
        elif atom in recoverability_atoms or role_hint == "recoverability":
            intent_flags["recoverability"] = True
            add_scorer("recoverability_quality", "visual_token_norm_saliency", atom, params, "composed", "recoverability approximated as generic saliency", node)
        else:
            if must_preserve and not fallback_allowed:
                add_report("unsupported", atom, None, "unknown scorer and fallback not allowed", node)
                compile_report["fatal"] = True
                compile_report["fatal_reasons"].append(f"unknown scorer without fallback: {atom}")
            else:
                intent_flags["norm"] = True
                add_scorer("generic_quality", "visual_token_norm_saliency", atom, params, "approx", "unknown scorer approximated by generic quality", node)

    # ------------------------------------------------------------------
    # IR-level completion rules.
    # ------------------------------------------------------------------

    has_quality = any(
        v.get("atom") in {
            "attention_proxy_saliency",
            "visual_token_norm_saliency",
            "instruction_guided_visual_relevance",
        }
        for v in scorer_specs.values()
        if isinstance(v, dict)
    )
    if not has_quality:
        fake_node = {"id": "generic_quality", "expected_role": "norm_quality", "intent": "compiler inserted general quality", "must_preserve": False, "fallback_allowed": True}
        add_scorer("generic_quality", "visual_token_norm_saliency", "compiler_inserted_generic_quality", {}, "composed", "ensure at least one general quality signal", fake_node)
        notes.append("compiler_injected_generic_quality:visual_token_norm_saliency")

    need_similarity = intent_flags["dpp"] or intent_flags["mmr"] or any(
        "dpp" in a or "mmr" in a or "diversity" in a for a in selector_atoms_seen + fusion_atoms_seen + bridge_atoms_seen
    )
    has_similarity = any(
        v.get("atom") in {"pairwise_token_similarity", "conditional_similarity_score"}
        for v in scorer_specs.values()
        if isinstance(v, dict)
    )
    if need_similarity and not has_similarity:
        fake_node = {"id": "pairwise_similarity", "expected_role": "similarity", "intent": "compiler inserted similarity for DPP/MMR/diversity", "must_preserve": False, "fallback_allowed": True}
        add_scorer("similarity", "pairwise_token_similarity", "compiler_inserted_pairwise_similarity", {}, "composed", "DPP/MMR/diversity requires similarity", fake_node)
        notes.append("compiler_injected_similarity:pairwise_token_similarity")

    if intent_flags["coverage"] and not any(v.get("atom") == "spatial_centrality_prior" for v in scorer_specs.values()):
        fake_node = {"id": "coverage", "expected_role": "coverage", "intent": "compiler inserted coverage channel", "must_preserve": False, "fallback_allowed": True}
        add_scorer("coverage", "spatial_centrality_prior", "compiler_inserted_coverage", {}, "composed", "coverage intent requires spatial prior", fake_node)
        notes.append("compiler_injected_coverage:spatial_centrality_prior")

    if intent_flags["cluster"] and not any(v.get("atom") == "redundancy_density_penalty" for v in scorer_specs.values()):
        fake_node = {"id": "cluster_density", "expected_role": "cluster", "intent": "compiler inserted cluster/redundancy channel", "must_preserve": False, "fallback_allowed": True}
        add_scorer("cluster", "redundancy_density_penalty", "compiler_inserted_cluster_density", {}, "composed", "cluster intent requires redundancy/density proxy", fake_node)
        notes.append("compiler_injected_cluster:redundancy_density_penalty")

    # ------------------------------------------------------------------
    # Fusion compilation from IR.
    # ------------------------------------------------------------------

    bridge_prefers_dpp_kernel = any(
        b in {"quality_similarity_to_dpp_kernel_bridge", "query_relevance_to_dpp_quality_bridge"}
        for b in bridge_atoms_seen
    )

    fusion_atom_from_plan = (fusion_pref or {}).get("atom")
    fusion_params_from_plan = (fusion_pref or {}).get("params", {}) if fusion_pref else {}

    if bridge_prefers_dpp_kernel or fusion_atom_from_plan == "quality_diversity_kernel":
        fusion_spec = {
            "atom": "quality_diversity_kernel",
            "params": {
                "quality_power": fusion_params_from_plan.get("quality_power", fusion_params_from_plan.get("quality_exponent", 1.0)),
                "similarity_power": fusion_params_from_plan.get("similarity_power", fusion_params_from_plan.get("diversity_power", 1.0)),
                "stabilization": fusion_params_from_plan.get("stabilization", ["symmetrize", "eps_diagonal"]),
            },
        }
        add_report("direct" if fusion_atom_from_plan == "quality_diversity_kernel" else "composed", str(fusion_atom_from_plan or "bridge_dpp_kernel"), "fusion:quality_diversity_kernel", "IR selects quality-similarity DPP kernel", (fusion_pref or {}).get("node", {}))
        notes.append("ir_lowered_fusion:quality_diversity_kernel")
    elif fusion_atom_from_plan in {"cluster_quality_diversity_fusion", "mmr_relevance_diversity_fusion", "two_stage_relevance_then_diversity"} or intent_flags["cluster"]:
        score_keys = [k for k, v in scorer_specs.items() if v.get("atom") not in {"pairwise_token_similarity", "conditional_similarity_score"}]
        fusion_spec = {
            "atom": "v7_score_product_fusion",
            "params": {
                "product_keys": score_keys[:3],
                "powers": {k: 1.0 for k in score_keys[:3]},
                "add_weights": {},
                "add_mix": 0.15,
                "score_normalization": "minmax",
                "output_transform": "minmax",
            },
        }
        add_report("composed", str(fusion_atom_from_plan or "cluster_intent"), "fusion:v7_score_product_fusion", "cluster/diversity intent compiled to product fusion", (fusion_pref or {}).get("node", {}))
        notes.append("ir_lowered_fusion:v7_score_product_fusion")
    elif fusion_atom_from_plan in {"hierarchical_anchor_context_fusion"}:
        fusion_spec = {
            "atom": "v7_rank_fusion",
            "params": {
                "weights": {k: 1.0 for k, v in scorer_specs.items() if v.get("atom") not in {"pairwise_token_similarity", "conditional_similarity_score"}},
                "output_transform": "minmax",
            },
        }
        add_report("composed", str(fusion_atom_from_plan), "fusion:v7_rank_fusion", "hierarchical context intent compiled to rank fusion", (fusion_pref or {}).get("node", {}))
        notes.append("ir_lowered_fusion:v7_rank_fusion")
    else:
        score_keys = [k for k, v in scorer_specs.items() if v.get("atom") not in {"pairwise_token_similarity", "conditional_similarity_score"}]
        fusion_spec = {
            "atom": "full_token_score_fusion",
            "params": {
                "weights": {k: 1.0 for k in score_keys},
                "score_normalization": "minmax",
                "output_transform": "minmax",
            },
        }
        add_report("composed", str(fusion_atom_from_plan or "default_multi_signal_fusion"), "fusion:full_token_score_fusion", "default multi-channel score fusion", (fusion_pref or {}).get("node", {}))
        notes.append("ir_lowered_fusion:full_token_score_fusion")

    # ------------------------------------------------------------------
    # Selector compilation from IR.
    # ------------------------------------------------------------------

    selector_atom_from_plan = (selector_pref or {}).get("atom")
    selector_params_from_plan = (selector_pref or {}).get("params", {}) if selector_pref else {}

    if selector_atom_from_plan == "balanced_covering_selector" or (intent_flags["coverage"] and not intent_flags["dpp"] and not intent_flags["cluster"]):
        selector_spec = {
            "atom": "stratified_full_token_selector",
            "params": {
                "strata": selector_params_from_plan.get("strata", 4),
                "score_key": "fused",
            },
        }
        add_report("composed", str(selector_atom_from_plan or "coverage_selector"), "selector:stratified_full_token_selector", "coverage/balanced covering intent", (selector_pref or {}).get("node", {}))
        notes.append("ir_lowered_selector:stratified_full_token_selector")
    elif selector_atom_from_plan in {"cluster_centroid_selector", "hierarchical_topk_dpp_selector"} or intent_flags["cluster"]:
        selector_spec = {
            "atom": "topk_pool_dpp_selector",
            "params": {
                "pool_multiplier": selector_params_from_plan.get("pool_multiplier", 3.0),
                "quality_power": selector_params_from_plan.get("quality_power", 1.2),
                "postprocess": selector_params_from_plan.get("postprocess", "sort_by_position"),
            },
        }
        add_report("composed", str(selector_atom_from_plan or "cluster_selector"), "selector:topk_pool_dpp_selector", "cluster/hierarchical selection compiled to pool-DPP", (selector_pref or {}).get("node", {}))
        notes.append("ir_lowered_selector:topk_pool_dpp_selector")
    elif selector_atom_from_plan == "mmr_selector" or intent_flags["mmr"]:
        selector_spec = {
            "atom": "mmr_selector",
            "params": {
                "lambda_relevance": selector_params_from_plan.get("lambda_relevance", 0.7),
                "postprocess": selector_params_from_plan.get("postprocess", "sort_by_position"),
            },
        }
        add_report("direct" if selector_atom_from_plan == "mmr_selector" else "composed", str(selector_atom_from_plan or "mmr_intent"), "selector:mmr_selector", "MMR intent", (selector_pref or {}).get("node", {}))
        notes.append("ir_lowered_selector:mmr_selector")
    elif bridge_prefers_dpp_kernel or intent_flags["dpp"] or fusion_spec.get("atom") == "quality_diversity_kernel":
        selector_spec = {
            "atom": "dpp_selector",
            "params": {
                "algorithm": selector_params_from_plan.get("algorithm", "fast_map"),
                "postprocess": selector_params_from_plan.get("postprocess", "sort_by_position"),
            },
        }
        add_report("direct" if selector_atom_from_plan == "dpp_selector" else "composed", str(selector_atom_from_plan or "dpp_intent"), "selector:dpp_selector", "DPP kernel intent", (selector_pref or {}).get("node", {}))
        notes.append("ir_lowered_selector:dpp_selector")
    else:
        selector_spec = {
            "atom": "topk_selector",
            "params": {
                "postprocess": selector_params_from_plan.get("postprocess", "sort_by_position"),
            },
        }
        add_report("direct" if selector_atom_from_plan == "topk_selector" else "approx", str(selector_atom_from_plan or "default_topk"), "selector:topk_selector", "default top-k selector", (selector_pref or {}).get("node", {}))
        notes.append("ir_lowered_selector:topk_selector")

    # Dynamic budget cannot change final K, but it can change internal selection aggressiveness.
    if intent_flags["dynamic_budget"]:
        sp = selector_spec.setdefault("params", {})
        if selector_spec["atom"] in {"topk_pool_dpp_selector", "v7_two_stage_pool_selector"}:
            sp["pool_multiplier"] = max(float(sp.get("pool_multiplier", 3.0)), 4.0)
        elif selector_spec["atom"] == "dpp_selector":
            # dpp_selector has no pool stage; increase quality sharpness through fusion if possible.
            fp = fusion_spec.setdefault("params", {})
            if "quality_power" in fp:
                fp["quality_power"] = max(float(fp.get("quality_power", 1.0)), 1.25)
        notes.append("dynamic_budget_intent_lowered_to_internal_search_aggressiveness")
        add_report("composed", ",".join(budget_atoms_seen) or "dynamic_budget_intent", f"selector/fusion params:{selector_spec['atom']}", "fixed final K, dynamic budget affects internal search", {})

    budget_spec = {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}}
    action_spec = action_spec or {"atom": "hard_prune"}

    if intent_flags["coverage"] or intent_flags["protection"]:
        if not any(p.get("atom") == "spatial_coverage_preservation" for p in protections):
            protections.append({"atom": "spatial_coverage_preservation", "params": {"source": "compiler_inserted_for_coverage_intent"}})
            notes.append("compiler_inserted_protection:spatial_coverage_preservation")
            add_report("composed", "coverage_intent", "protection:spatial_coverage_preservation", "coverage/protection intent", {})

    protections = [p for p in protections if p.get("atom") in {"special_token_preservation", "spatial_coverage_preservation"}][:2]

    # ------------------------------------------------------------------
    # Compile fidelity.
    # ------------------------------------------------------------------
    total = max(
        1,
        compile_report["direct_count"]
        + compile_report["composed_count"]
        + compile_report["approx_count"]
        + compile_report["ignored_count"]
        + compile_report["fallback_count"]
        + compile_report["unsupported_count"],
    )
    raw_score = (
        1.0 * compile_report["direct_count"]
        + 0.8 * compile_report["composed_count"]
        + 0.4 * compile_report["approx_count"]
        - 0.8 * compile_report["ignored_count"]
        - 1.0 * compile_report["fallback_count"]
        - 1.0 * compile_report["unsupported_count"]
    ) / total
    compile_report["plan_realization_score"] = max(0.0, min(1.0, raw_score))
    compile_report["total_plan_nodes_accounted"] = total

    if compile_report["fallback_count"] > 0:
        compile_report["fatal"] = True
        compile_report["fatal_reasons"].append("fallback_count > 0")
    if compile_report["unsupported_count"] > 0:
        compile_report["fatal"] = True
        compile_report["fatal_reasons"].append("unsupported_count > 0")
    if compile_report["plan_realization_score"] < 0.45:
        compile_report["fatal"] = True
        compile_report["fatal_reasons"].append("plan_realization_score < 0.45")

    raw_name = meta.get("policy_name") or f"v83_plan_aware_{idx:05d}"
    policy_name = sanitize_name(f"{raw_name}_{sha({'nodes': nodes, 'compiler': 'v83_plan_aware'})}", max_len=180)

    policy = {
        "version": "0.5-light",
        "policy_name": policy_name,
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "v8_3_plan_aware_universal_yaml_compiler",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": scorer_specs,
            "fusion": fusion_spec,
            "budget": budget_spec,
            "selector": selector_spec,
            "action": action_spec,
            "protection": protections,
        }],
    }

    return policy, notes, compile_report


def canonical_policy_key(policy: Mapping[str, Any]) -> str:
    obj = json.loads(json.dumps(policy, sort_keys=True, ensure_ascii=False))
    obj.pop("policy_name", None)
    obj.pop("search_stage", None)
    return sha(obj)


def policy_summary(policy: Mapping[str, Any]) -> Dict[str, Any]:
    step = policy["pipeline"][0]
    return {
        "fusion": step.get("fusion", {}).get("atom"),
        "fusion_params": step.get("fusion", {}).get("params", {}),
        "selector": step.get("selector", {}).get("atom"),
        "selector_params": step.get("selector", {}).get("params", {}),
        "scorer_atoms": [v.get("atom") for v in step.get("scorer", {}).values() if isinstance(v, Mapping)],
        "scorer_keys": list(step.get("scorer", {}).keys()),
        "action": step.get("action", {}).get("atom"),
        "protections": [x.get("atom") for x in step.get("protection", []) if isinstance(x, Mapping)],
    }


# ---------------------------------------------------------------------
# Prompt and LLM
# ---------------------------------------------------------------------

def build_prompt(cards: Mapping[str, Mapping[str, Any]], history: Sequence[Mapping[str, Any]],
                 args: argparse.Namespace, generation: int) -> str:
    prompt_cards = select_prompt_cards(cards, max_per_category=args.max_cards_per_category)

    top = sorted(history, key=lambda r: safe_float(r.get("combined_score")), reverse=True)[:6]
    top_compact = []
    for r in top:
        top_compact.append({
            "score": r.get("combined_score"),
            "mean": r.get("perception_mean"),
            "std": r.get("perception_std"),
            "fusion": r.get("fusion"),
            "selector": r.get("selector"),
            "scorer_atoms": r.get("scorer_atoms"),
            "lowering": (r.get("lowering_notes") or [])[:4],
        })

    return f"""
You are an expert program-synthesis agent for visual token pruning in an MLLM.
Your job is to design fully-free YAML pruning programs using a typed universal atom registry.

Important task setting:
- Host: CDPruner/LLaVA encode_images visual token pruning.
- Target: select exactly K={args.token} visual tokens from all image patch tokens before the LLM.
- Fully free search: do NOT optimize for overlap with any native/reference mask.
- overlap_with_reference and changed_tokens are diagnostics only.
- Do NOT use native/reference/copy atoms. Avoid native_teacher_mask_prior, cdpruner_reference_mask_prior, cdpruner_default_soft_score.
- The final policy will be lowered into currently executable YAML, so you may use universal typed atoms as design language.
- Prefer creative but plausible combinations, not only relevance × redundancy + DPP.
- This is a GENERAL pruning search across multiple downstream tasks, not an MME-only or VQA-only search.
- Do not rely only on spatial/coverage/cluster signals; combine them with a general quality/saliency/importance signal.
- Text-conditioned or instruction-conditioned relevance is optional, not mandatory; do not make it the default unless the policy explicitly needs task-conditioned pruning.
- Good general policies may combine visual saliency, attention proxy, redundancy/diversity, spatial coverage, uncertainty, recoverability, and optional task relevance.
- If you use DPP/MMR/diversity selectors, include a similarity-like signal such as pairwise_token_similarity or conditional_similarity_score.
- Explore scorers/fusions/selectors/protections/bridges from the registry.
- Programs should generalize across dispersed MME chunks, not just one chunk.

Available typed atom cards, grouped by role:
{json.dumps(prompt_cards, ensure_ascii=False, indent=2)}

Prior evaluated candidates:
{json.dumps(top_compact, ensure_ascii=False, indent=2)}

Design hints:
- Good visual-token pruning usually needs both task relevance and diversity/coverage.
- Similarity/DPP/MMR-style selectors need a similarity or diversity signal.
- You may combine semantic relevance with spatial, attention, objectness, coverage, uncertainty, or reconstruction-inspired scorers.
- You may propose high-level typed atoms; the compiler will lower them to executable approximations.
- Avoid generating candidates that are identical to prior fusion+selector+scorer sets.

For every policy_graph node, include these extra fields:
- intent: a short natural-language explanation of what this atom is meant to achieve.
- expected_role: one of ["attention_quality", "semantic_quality", "norm_quality", "coverage", "cluster", "similarity", "fusion", "selector", "budget", "protection", "bridge"].
- must_preserve: true if this planning intention must be faithfully implemented by the compiler.
- fallback_allowed: false if replacing it with an unrelated proxy would invalidate the design.

The compiler is plan-aware. It can compose several executable primitives to realize one high-level atom.
Avoid relying on atom names alone. State the intended role clearly.

CRITICAL:
- Use exact atom_id strings from the provided atom cards.
- Do NOT invent new atom names.
- If the exact concept is not available, choose the closest listed atom_id and explain the intended behavior in the intent field.
- The compiler validates atom names against the registry. Invented atom names may be rejected or counted as approximate realization.


V8.4 FULL-STABLE SEARCH MEMORY:
- Previous smoke ranking did not perfectly match full-MME ranking.
- The best full-MME candidate was NOT the highest smoke candidate.
- Best full-MME observed family:
  scorers = instruction_guided_visual_relevance + pairwise_token_similarity + redundancy_density_penalty
  fusion = v7_score_product_fusion
  selector = topk_pool_dpp_selector
  behavior = pool-based selection with relevance/similarity/redundancy balance
- This family was more full-stable than pure global DPP.
- Pure global DPP with only attention_proxy_saliency + pairwise_token_similarity can obtain high smoke scores but may generalize poorly to full MME.
- Explore variants around:
  1. topk_pool_dpp_selector
  2. redundancy/cluster-aware scoring
  3. semantic or attention quality
  4. pairwise or conditional similarity
  5. moderate coverage protection
- Avoid producing functionally duplicate policies with different names.
- Prefer structurally diverse candidates across DPP, pool-DPP, MMR, coverage-aware, cluster-aware, and recoverability-aware families.
- Do not over-optimize for a single pure attention+similarity+DPP template.

Return strict JSON only, no markdown.
Return {args.batch_size} diverse candidates in this schema:
{{
  "candidates": [
    {{
      "policy_name": "short_unique_name",
      "rationale": "why this program may work",
      "policy_graph": {{
        "nodes": [
          {{"id": "quality", "slot": "scorer", "atom": "visual_encoder_cls_attention_score", "intent": "estimate general visual token saliency from vision-side attention without assuming a VQA-only objective", "expected_role": "attention_quality", "must_preserve": true, "fallback_allowed": true, "params": {{"transform": "minmax", "power": 1.0}}}},
          {{"id": "structure", "slot": "scorer", "atom": "spatial_entropy_complexity_score", "intent": "encourage spatially informative and well-covered visual tokens", "expected_role": "coverage", "must_preserve": true, "fallback_allowed": true, "params": {{"transform": "minmax"}}}},
          {{"id": "fusion", "slot": "fusion", "atom": "multi_objective_balanced_covering_fusion", "intent": "combine quality and coverage objectives without collapsing to a single proxy", "expected_role": "fusion", "must_preserve": true, "fallback_allowed": true, "params": {{"quality_weight": 0.7, "coverage_weight": 0.3}}}},
          {{"id": "selector", "slot": "selector", "atom": "hierarchical_topk_dpp_selector", "intent": "first form a high-quality pool and then select a diverse subset", "expected_role": "selector", "must_preserve": true, "fallback_allowed": true, "params": {{"pool_multiplier": 3.0, "quality_power": 1.2}}}},
          {{"id": "budget", "slot": "budget", "atom": "fixed_keep_tokens", "params": {{"keep_tokens": "host_argument"}}}},
          {{"id": "action", "slot": "action", "atom": "hard_prune", "params": {{}}}}
        ]
      }}
    }}
  ]
}}

Generation: {generation}
"""


def call_llm(prompt: str, args: argparse.Namespace) -> List[Mapping[str, Any]]:
    from openai import OpenAI
    import time

    kwargs = {"api_key": os.environ["OPENAI_API_KEY"]}
    if os.environ.get("OPENAI_BASE_URL"):
        kwargs["base_url"] = os.environ["OPENAI_BASE_URL"]

    client = OpenAI(**kwargs)
    resp = client.chat.completions.create(
        model=args.model,
        messages=[
            {"role": "system", "content": "Return strict JSON only. You are designing policy_graph programs using typed pruning atoms."},
            {"role": "user", "content": prompt},
        ],
        temperature=args.temperature,
        max_tokens=args.max_tokens,
    )

    content = resp.choices[0].message.content or ""

    usage_obj = getattr(resp, "usage", None)
    if usage_obj is None:
        usage = {}
    elif hasattr(usage_obj, "model_dump"):
        usage = usage_obj.model_dump()
    elif isinstance(usage_obj, dict):
        usage = usage_obj
    else:
        usage = {
            "prompt_tokens": getattr(usage_obj, "prompt_tokens", None),
            "completion_tokens": getattr(usage_obj, "completion_tokens", None),
            "total_tokens": getattr(usage_obj, "total_tokens", None),
        }

    usage_row = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "model": args.model,
        "prompt_chars": len(prompt),
        "completion_chars": len(content),
        "usage": usage,
    }

    usage_path = os.environ.get("V8_LLM_USAGE_JSONL")
    if usage_path:
        with open(usage_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(usage_row, ensure_ascii=False) + "\n")

    print(
        "[LLM_USAGE]",
        "prompt_tokens=", usage.get("prompt_tokens"),
        "completion_tokens=", usage.get("completion_tokens"),
        "total_tokens=", usage.get("total_tokens"),
        "prompt_chars=", len(prompt),
        "completion_chars=", len(content),
        flush=True,
    )

    obj = first_json_or_yaml(content)
    if not isinstance(obj, Mapping) or not isinstance(obj.get("candidates"), list):
        raise ValueError("LLM did not return {'candidates': [...]} JSON.")
    return obj["candidates"]


# ---------------------------------------------------------------------
# Runtime verification/evaluation
# ---------------------------------------------------------------------

def run_selftest(repo: Path, policy_path: Path, token: int, timeout: int = 180) -> Tuple[bool, str]:
    cmd = [
        sys.executable, "tools/evo_cdpruner/selftest_cdpruner_policy.py",
        "--policy", str(policy_path),
        "--tokens", "576",
        "--keep", str(token),
    ]
    env = os.environ.copy()
    env["PYTHONPATH"] = str(repo)
    proc = subprocess.run(cmd, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    return proc.returncode == 0, proc.stdout


def run_multismoke(repo: Path, policy_path: Path, args: argparse.Namespace, log_dir: Path) -> Dict[str, Any]:
    cmd = [
        sys.executable, "yaml_policy/openevolve_yaml_search/evaluator_multismoke.py",
        str(policy_path),
        "--gpu", str(args.gpu),
        "--token", str(args.token),
        "--base-script", args.base_script,
        "--chunks", args.chunks,
        "--num-chunks", str(args.num_chunks),
        "--std-penalty", str(args.std_penalty),
        "--log-dir", str(log_dir),
    ]
    env = os.environ.copy()
    env["EVO_TOKEN"] = str(args.token)
    env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
    proc = subprocess.run(cmd, cwd=repo, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / "eval_stdout.txt").write_text(proc.stdout, encoding="utf-8")
    obj = first_json_or_yaml(proc.stdout)
    if not isinstance(obj, Mapping):
        obj = {"valid": 0.0, "combined_score": 0.0, "error": "parse_failed", "stdout_tail": proc.stdout[-3000:]}
    return dict(obj)


def write_csv_summary(results_path: Path, csv_path: Path) -> None:
    rows = load_jsonl(results_path)
    rows = sorted(rows, key=lambda r: safe_float(r.get("combined_score")), reverse=True)
    fields = [
        "policy_name", "valid", "combined_score", "perception_mean", "perception_std", "perception_min",
        "cognition_mean", "changed_tokens_avg", "overlap_with_reference_avg",
        "plan_realization_score", "direct_count", "composed_count", "approx_count", "ignored_count", "fallback_count", "unsupported_count",
        "fusion", "selector", "scorer_atoms", "lowering_notes", "policy_path", "rationale",
    ]
    with csv_path.open("w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k) for k in fields})


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------

def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--registry", default="yaml_policy/universal_pruning_yaml_v0_5_light/universal_pruning_typed_atom_registry_v0_5_light.yaml")
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU", "3"))
    ap.add_argument("--token", type=int, default=int(os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32"))))
    ap.add_argument("--base-script", default="scripts/v1_5/eval/mme_yaml_smoke21.sh")
    ap.add_argument("--chunks", default="0,5,10,15,20")
    ap.add_argument("--num-chunks", type=int, default=21)
    ap.add_argument("--std-penalty", type=float, default=0.5)
    ap.add_argument("--generations", type=int, default=8)
    ap.add_argument("--batch-size", type=int, default=8)
    ap.add_argument("--out-dir", default="openevolve/runs/v8_universal_free_K32_chunks_0_5_10_15_20")
    ap.add_argument("--model", default=os.environ.get("V8_LLM_MODEL", os.environ.get("V6_LLM_MODEL", "qwen-plus")))
    ap.add_argument("--temperature", type=float, default=float(os.environ.get("V8_LLM_TEMPERATURE", "0.9")))
    ap.add_argument("--max-tokens", type=int, default=int(os.environ.get("V8_LLM_MAX_TOKENS", "5000")))
    ap.add_argument("--max-cards-per-category", type=int, default=8)
    ap.add_argument("--no-selftest", action="store_true")
    ap.add_argument("--allow-native-teacher", action="store_true")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    out = repo / args.out_dir
    pol_dir = out / "policies"
    plan_dir = out / "plans"
    log_dir = out / "logs"
    prompt_dir = out / "prompts"
    rej_dir = out / "rejected"
    for d in [pol_dir, plan_dir, log_dir, prompt_dir, rej_dir]:
        d.mkdir(parents=True, exist_ok=True)

    if not os.environ.get("OPENAI_API_KEY"):
        raise SystemExit("OPENAI_API_KEY is required.")

    reg_path = repo / args.registry
    cards = load_typed_atom_cards(reg_path)
    (out / "typed_atom_cards_clean.json").write_text(json.dumps(cards, indent=2, ensure_ascii=False), encoding="utf-8")
    (out / "typed_atom_categories.json").write_text(json.dumps(group_cards(cards), indent=2, ensure_ascii=False), encoding="utf-8")

    results_path = out / "results.jsonl"
    os.environ["V8_LLM_USAGE_JSONL"] = str(out / "llm_usage.jsonl")
    history = load_jsonl(results_path)
    seen_keys = {r.get("canonical_key") for r in history if r.get("canonical_key")}
    best = max(history, key=lambda r: safe_float(r.get("combined_score")), default=None)

    for gen in range(args.generations):
        prompt = build_prompt(cards, history, args, gen)
        (prompt_dir / f"gen_{gen:03d}_prompt.txt").write_text(prompt, encoding="utf-8")
        try:
            candidates = call_llm(prompt, args)
            (prompt_dir / f"gen_{gen:03d}_raw_candidates.json").write_text(json.dumps(candidates, indent=2, ensure_ascii=False), encoding="utf-8")
        except Exception as e:
            (prompt_dir / f"gen_{gen:03d}_llm_error.txt").write_text(str(e), encoding="utf-8")
            print("[LLM_ERROR]", e, flush=True)
            time.sleep(2)
            continue

        for j, cand in enumerate(candidates):
            if not isinstance(cand, Mapping):
                continue
            obj = {"candidates": [cand]}
            plans = plan_from_llm_obj(obj)
            if not plans:
                append_jsonl(out / "rejected_parse.jsonl", {"generation": gen, "candidate_index": j, "candidate": cand, "error": "no policy_graph nodes"})
                print("[REJECT_PARSE] no policy_graph", flush=True)
                continue

            plan = plans[0]
            # Preserve metadata.
            plan["meta"] = {
                "policy_name": cand.get("policy_name", f"g{gen}_c{j}"),
                "rationale": cand.get("rationale", ""),
            }

            idx = len(history) + 1
            try:
                policy, lowering_notes, compile_report = lower_plan_to_policy(
                    plan, idx=idx, token=args.token, ban_native_teacher=not args.allow_native_teacher, cards=cards
                )
                if compile_report.get("fatal"):
                    append_jsonl(out / "rejected_compile_report.jsonl", {
                        "generation": gen,
                        "candidate_index": j,
                        "candidate": cand,
                        "lowering_notes": lowering_notes,
                        "compile_report": compile_report,
                    })
                    print("[REJECT_COMPILE_REPORT]", cand.get("policy_name", f"gen{gen}_cand{j}"), compile_report.get("fatal_reasons"), flush=True)
                    continue
            except Exception as e:
                append_jsonl(out / "rejected_lowering.jsonl", {"generation": gen, "candidate_index": j, "candidate": cand, "error": str(e)})
                print("[REJECT_LOWER]", e, flush=True)
                continue

            key = canonical_policy_key(policy)
            if key in seen_keys:
                print("[SKIP_DUP]", policy["policy_name"], flush=True)
                continue
            seen_keys.add(key)

            stem = f"{idx:05d}_{policy['policy_name']}"
            pp = pol_dir / f"{stem}.yaml"
            plan_path = plan_dir / f"{stem}.json"
            pp.write_text(yaml.safe_dump(policy, sort_keys=False, allow_unicode=True), encoding="utf-8")
            plan_path.write_text(json.dumps({"candidate": cand, "plan": plan, "lowering_notes": lowering_notes, "policy": policy}, indent=2, ensure_ascii=False), encoding="utf-8")

            if not args.no_selftest:
                ok, st_out = run_selftest(repo, pp, args.token)
                (log_dir / f"{stem}_selftest.txt").write_text(st_out, encoding="utf-8")
                if not ok:
                    append_jsonl(out / "rejected_selftest.jsonl", {
                        "generation": gen,
                        "candidate_index": j,
                        "policy_path": str(pp),
                        "lowering_notes": lowering_notes,
                        "compile_report": compile_report,
                        "error": st_out[-3000:],
                    })
                    print("[REJECT_SELFTEST]", pp.name, flush=True)
                    continue

            print(f"[EVAL] gen={gen} cand={j} {pp.name}", flush=True)
            row = run_multismoke(repo, pp, args, log_dir / stem)
            row.update(policy_summary(policy))
            row.update({
                "policy_name": policy["policy_name"],
                "policy_path": str(pp),
                "plan_path": str(plan_path),
                "canonical_key": key,
                "generation": gen,
                "candidate_index": j,
                "rationale": cand.get("rationale", ""),
                "lowering_notes": lowering_notes,
                "compile_report": compile_report,
                "plan_realization_score": compile_report.get("plan_realization_score"),
                "direct_count": compile_report.get("direct_count"),
                "composed_count": compile_report.get("composed_count"),
                "approx_count": compile_report.get("approx_count"),
                "ignored_count": compile_report.get("ignored_count"),
                "fallback_count": compile_report.get("fallback_count"),
                "unsupported_count": compile_report.get("unsupported_count"),
            })
            append_jsonl(results_path, row)
            history.append(row)

            score = safe_float(row.get("combined_score"))
            if best is None or score > safe_float(best.get("combined_score")):
                best = row
                (out / "best_policy.yaml").write_text(pp.read_text(encoding="utf-8"), encoding="utf-8")
                (out / "best_plan.json").write_text(plan_path.read_text(encoding="utf-8"), encoding="utf-8")
                (out / "best_metrics.json").write_text(json.dumps(row, indent=2, ensure_ascii=False), encoding="utf-8")
                print(
                    "[BEST]",
                    policy["policy_name"],
                    "score=", row.get("combined_score"),
                    "mean=", row.get("perception_mean"),
                    "std=", row.get("perception_std"),
                    "min=", row.get("perception_min"),
                    "valid=", row.get("valid"),
                    "changed=", row.get("changed_tokens_avg"),
                    "overlap=", row.get("overlap_with_reference_avg"),
                    "fusion=", row.get("fusion"),
                    "selector=", row.get("selector"),
                    flush=True,
                )

        write_csv_summary(results_path, out / "results.csv")

    write_csv_summary(results_path, out / "results.csv")
    print("done")
    print("results:", results_path)
    print("best:", out / "best_policy.yaml")


if __name__ == "__main__":
    main()
