# Universal Pruning YAML v0.5-light

This version is a controllability/executability upgrade over v0.4 controlled.

It does **not** expand the paper bank. Instead, it adds:

1. `atom_granularity`
2. `decomposable`
3. `search_level`
4. `expose_to_llm`
5. `micro_decomposition`
6. CDPruner stage-1 compact search space
7. CDPruner default reconstructed policy
8. LLM-visible search context template

## Statistics

- Paper/method entries inherited from v0.4: 155
- Controlled canonical atoms: 180
- Bridge atoms: 10
- Total typed entries including bridges: 190
- Decomposable atoms: 100
- Non-decomposable atoms: 80

## Recommended usage

Use `cdpruner_stage1_search_space_v0_5.yaml` for the first OpenEvolve run.

Do not expose the full typed registry to the LLM. The planner should generate a compact context from:
- current policy
- last evaluation result
- CDPruner host profile
- CDPruner stage-1 search space
- allowed mutations

## Next implementation step

Implement:

- `CDPrunerPolicyVerifier`
- `CDPrunerPolicyCompiler`
- `CDPrunerPolicyExecutor`

Then reproduce `cdpruner_default_policy_v0_5.yaml` before running OpenEvolve mutations.
