# v0.5-light summary

| Item | Count |
|---|---:|
| Paper/method entries inherited from v0.4 | 155 |
| Controlled canonical atoms | 180 |
| Bridge atoms | 10 |
| Total typed entries | 190 |
| Decomposable atoms | 100 |
| Non-decomposable atoms | 80 |

## Granularity counts

- execution: 21
- functional: 118
- interface: 34
- procedure: 7

## CDPruner Stage-1

The first executable search should use:

- `cdpruner_stage1_search_space_v0_5.yaml`
- `cdpruner_default_policy_v0_5.yaml`
- `llm_visible_search_context_template_cdpruner_stage1_v0_5.yaml`

The full registry is for planner retrieval only.
