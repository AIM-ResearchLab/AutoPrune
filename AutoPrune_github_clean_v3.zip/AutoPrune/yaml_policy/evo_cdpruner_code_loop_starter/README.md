# Evo-CDPruner code-loop starter

This starter package implements:

```text
YAML policy
  -> PolicyVerifier
  -> CDPrunerPolicyExecutor
  -> index_masks [B,N]
  -> CDPruner encode_images
  -> original CDPruner evaluation scripts
```

It intentionally supports only the CDPruner stage-1 compact search space.

## Minimal test

```bash
python tools/selftest_cdpruner_policy.py --policy configs/cdpruner_default_policy_v0_5.yaml --tokens 576 --keep 128
python tools/selftest_cdpruner_policy.py --policy configs/cdpruner_mmr_policy_example.yaml --tokens 576 --keep 128
```

## Key principle

Do not ask OpenEvolve to edit model code first. Ask it to mutate YAML policies.
Only after the YAML executor reproduces original CDPruner should you connect OpenEvolve.


Note: the default reconstructed policy uses `global_minmax` for relevance normalization to match the original CDPruner code path.
