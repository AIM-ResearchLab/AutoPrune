from __future__ import annotations

from typing import Dict, Any
import torch

from .types import CDPrunerContext
from .verifier import PolicyVerifier
from .atoms import (
    instruction_guided_visual_relevance,
    pairwise_token_similarity,
    conditional_similarity_score,
    quality_diversity_kernel,
    weighted_sum_score_fusion,
    fast_map_dpp,
    topk_select,
    mmr_select,
    apply_top_relevance_anchor,
    apply_spatial_coverage,
)


class CDPrunerPolicyExecutor:
    """Executes a CDPruner-compatible YAML policy and returns index_masks [B,N]."""

    def __init__(self, policy: Dict[str, Any], strict: bool = True) -> None:
        self.policy = policy
        if strict:
            PolicyVerifier().verify(policy)
        self.step = policy["pipeline"][0]

    def select(self, ctx: CDPrunerContext) -> torch.Tensor:
        ctx.validate()
        k = self._get_budget(ctx)
        scores: Dict[str, torch.Tensor] = {}

        scorer_spec = self.step.get("scorer", {})
        if "atom" in scorer_spec:
            scores["main"] = self._run_scorer(scorer_spec, ctx, scores)
        else:
            for name, spec in scorer_spec.items():
                scores[name] = self._run_scorer(spec, ctx, scores)

        fusion_spec = self.step.get("fusion", {"atom": "quality_diversity_kernel"})
        fusion_atom = fusion_spec.get("atom")
        fusion_params = fusion_spec.get("params", {})
        selector_spec = self.step.get("selector", {"atom": "dpp_selector"})
        selector_atom = selector_spec.get("atom")
        selector_params = selector_spec.get("params", {})

        if fusion_atom == "quality_diversity_kernel":
            quality = scores.get("quality", scores.get("main"))
            similarity = scores.get("similarity")
            if similarity is None:
                similarity = pairwise_token_similarity(ctx, {})
            kernel = quality_diversity_kernel(quality, similarity, fusion_params)
            if selector_atom == "dpp_selector":
                selected = fast_map_dpp(kernel, k)
            elif selector_atom == "topk_selector":
                selected = topk_select(torch.diagonal(kernel, dim1=1, dim2=2), k=k)
            else:
                raise ValueError(f"Unsupported selector {selector_atom!r} for quality_diversity_kernel")

        elif fusion_atom == "weighted_sum_score_fusion":
            fused = weighted_sum_score_fusion(scores, fusion_params)
            selected = topk_select(fused, k=k, largest=selector_params.get("largest", True))

        elif fusion_atom == "mmr_relevance_diversity_fusion":
            quality = scores.get("quality", scores.get("main"))
            similarity = scores.get("similarity")
            if similarity is None:
                similarity = pairwise_token_similarity(ctx, {})
            selected = mmr_select(
                quality=quality,
                similarity=similarity,
                k=k,
                lambda_relevance=float(fusion_params.get("lambda_relevance", 0.5)),
            )
        else:
            raise ValueError(f"Unsupported fusion atom in starter: {fusion_atom!r}")

        selected = self._apply_protections(selected, scores, ctx)
        return self._indices_to_mask(selected, ctx.image_features.shape[1], ctx.image_features.device)

    def _run_scorer(self, spec: Dict[str, Any], ctx: CDPrunerContext, scores: Dict[str, torch.Tensor]) -> torch.Tensor:
        atom = spec.get("atom")
        params = spec.get("params", {})

        if atom == "instruction_guided_visual_relevance":
            return instruction_guided_visual_relevance(ctx, params)
        if atom == "pairwise_token_similarity":
            return pairwise_token_similarity(ctx, params)
        if atom == "conditional_similarity_score":
            relevance = scores.get("quality")
            if relevance is None:
                relevance = instruction_guided_visual_relevance(ctx, {})
            return conditional_similarity_score(ctx, relevance, params)

        # Safe placeholder fallbacks for stage-1 atoms not yet implemented.
        if atom in {
            "visual_encoder_cls_attention_score",
            "spatial_entropy_complexity_score",
            "objectness_region_score",
            "ocr_density_score",
            "multi_objective_coverage_score",
        }:
            return instruction_guided_visual_relevance(ctx, params)

        raise ValueError(f"Unsupported scorer atom in starter: {atom!r}")

    def _get_budget(self, ctx: CDPrunerContext) -> int:
        budget_spec = self.step.get("budget", {"atom": "fixed_keep_tokens"})
        atom = budget_spec.get("atom")
        params = budget_spec.get("params", {})
        n = ctx.image_features.size(1)

        if atom == "fixed_keep_tokens":
            k = params.get("keep_tokens", "host_argument")
            if k == "host_argument":
                k = ctx.visual_token_budget
            return max(1, min(int(k), n))
        if atom == "fixed_keep_ratio":
            ratio = float(params.get("keep_ratio", 0.5))
            min_keep = int(params.get("min_keep_tokens", 1))
            return max(min_keep, min(int(round(ratio * n)), n))
        return max(1, min(int(ctx.visual_token_budget), n))

    def _apply_protections(self, selected: torch.Tensor, scores: Dict[str, torch.Tensor], ctx: CDPrunerContext) -> torch.Tensor:
        protections = self.step.get("protection", []) or []
        relevance = scores.get("quality", scores.get("main"))
        if relevance is None:
            relevance = instruction_guided_visual_relevance(ctx, {})

        out = selected
        for p in protections:
            atom = p.get("atom")
            params = p.get("params", {})
            if atom == "top_relevance_anchor_preservation":
                out = apply_top_relevance_anchor(out, relevance, int(params.get("anchor_count", params.get("topk", 8))))
            elif atom == "spatial_coverage_preservation":
                out = apply_spatial_coverage(
                    out, relevance, ctx.token_positions,
                    grid_size=int(params.get("grid_size", 4)),
                    min_keep_per_cell=int(params.get("min_keep_per_cell", 1)),
                )
            elif atom in {"special_token_preservation", "ocr_text_region_preservation", "semantic_cluster_coverage_preservation"}:
                continue
            else:
                raise ValueError(f"Unsupported protection atom in starter: {atom!r}")
        return out

    @staticmethod
    def _indices_to_mask(indices: torch.Tensor, n: int, device: torch.device) -> torch.Tensor:
        B, _ = indices.shape
        mask = torch.zeros(B, n, dtype=torch.bool, device=device)
        mask.scatter_(1, indices.long(), True)
        return mask
