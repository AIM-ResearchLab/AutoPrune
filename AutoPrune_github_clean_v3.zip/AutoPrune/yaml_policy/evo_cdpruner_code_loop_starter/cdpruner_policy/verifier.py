from __future__ import annotations

from typing import Dict, Any


CDPRUNER_ALLOWED = {
    "trigger": {"pre_llm_visual_reduction_trigger"},
    "target": {"image_patch_tokens", "high_resolution_tile_tokens", "ocr_region_tokens"},
    "scorer": {
        "instruction_guided_visual_relevance",
        "conditional_similarity_score",
        "pairwise_token_similarity",
        "visual_encoder_cls_attention_score",
        "spatial_entropy_complexity_score",
        "objectness_region_score",
        "ocr_density_score",
        "multi_objective_coverage_score",
    },
    "fusion": {
        "quality_diversity_kernel",
        "mmr_relevance_diversity_fusion",
        "multi_objective_balanced_covering_fusion",
        "hierarchical_anchor_context_fusion",
        "weighted_sum_score_fusion",
    },
    "budget": {"fixed_keep_tokens", "fixed_keep_ratio", "dynamic_visual_complexity_budget", "high_resolution_tile_budget"},
    "selector": {"dpp_selector", "topk_selector", "mmr_selector", "balanced_covering_selector", "greedy_max_min_selector", "hierarchical_topk_dpp_selector"},
    "action": {"dpp_subset_prune", "hard_prune"},
    "protection": {"special_token_preservation", "spatial_coverage_preservation", "top_relevance_anchor_preservation", "ocr_text_region_preservation", "semantic_cluster_coverage_preservation"},
}


class PolicyVerifier:
    """Minimal verifier for CDPruner stage-1 policy."""

    def __init__(self, allowed: Dict[str, set[str]] | None = None) -> None:
        self.allowed = allowed or CDPRUNER_ALLOWED

    def verify(self, policy: Dict[str, Any]) -> None:
        if not isinstance(policy, dict):
            raise ValueError("policy must be a dict.")
        host = policy.get("target_host") or policy.get("target", {}).get("host_profile")
        if host not in (None, "cdpruner_encode_images"):
            raise ValueError(f"Only cdpruner_encode_images host is supported, got {host!r}")

        pipeline = policy.get("pipeline")
        if not isinstance(pipeline, list) or not pipeline:
            raise ValueError("policy.pipeline must be a non-empty list.")
        if len(pipeline) != 1:
            raise ValueError("Starter supports exactly one CDPruner visual-token-selection step.")

        step = pipeline[0]
        self._check_atom(step.get("trigger", {}), "trigger")
        self._check_atom(step.get("target", {}), "target")
        self._check_scorer(step.get("scorer"))
        self._check_atom(step.get("fusion", {}), "fusion")
        self._check_atom(step.get("budget", {}), "budget")
        self._check_atom(step.get("selector", {}), "selector")
        self._check_atom(step.get("action", {}), "action")

        protections = step.get("protection", []) or []
        if not isinstance(protections, list):
            raise ValueError("step.protection must be a list.")
        if len(protections) > 2:
            raise ValueError("Starter allows at most 2 active protection atoms.")
        for p in protections:
            self._check_atom(p, "protection")

        selector = step.get("selector", {}).get("atom")
        fusion = step.get("fusion", {}).get("atom")
        if selector == "dpp_selector" and fusion != "quality_diversity_kernel":
            raise ValueError("dpp_selector currently requires quality_diversity_kernel.")
        if selector == "mmr_selector" and fusion != "mmr_relevance_diversity_fusion":
            raise ValueError("mmr_selector currently requires mmr_relevance_diversity_fusion.")
        if selector == "topk_selector" and fusion not in {"weighted_sum_score_fusion", "quality_diversity_kernel"}:
            raise ValueError("topk_selector currently expects weighted_sum_score_fusion or quality_diversity_kernel.")

    def _check_atom(self, obj: Dict[str, Any], slot: str) -> None:
        if not isinstance(obj, dict):
            raise ValueError(f"{slot} must be a mapping with an atom field.")
        atom = obj.get("atom")
        if atom not in self.allowed.get(slot, set()):
            raise ValueError(f"Unsupported {slot} atom: {atom!r}")

    def _check_scorer(self, scorer: Any) -> None:
        if not isinstance(scorer, dict):
            raise ValueError("scorer must be a mapping.")
        if "atom" in scorer:
            self._check_atom(scorer, "scorer")
            return
        for key, value in scorer.items():
            if not isinstance(value, dict):
                raise ValueError(f"scorer.{key} must be a mapping.")
            self._check_atom(value, "scorer")
