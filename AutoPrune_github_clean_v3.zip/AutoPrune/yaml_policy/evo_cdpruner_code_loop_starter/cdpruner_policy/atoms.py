from __future__ import annotations

from typing import Dict, Any, Optional
import math
import torch

from .types import CDPrunerContext


def _safe_l2_normalize(x: torch.Tensor, dim: int = -1, eps: float = 1e-6) -> torch.Tensor:
    return x / x.norm(dim=dim, keepdim=True).clamp_min(eps)


def _minmax_per_sample(x: torch.Tensor, eps: float = 1e-6) -> torch.Tensor:
    xmin = x.min(dim=-1, keepdim=True).values
    xmax = x.max(dim=-1, keepdim=True).values
    return (x - xmin + eps) / (xmax - xmin + eps)


def _rank_norm(x: torch.Tensor) -> torch.Tensor:
    # x: [B, N], returns [0,1] rank score per sample.
    # Larger original value receives larger normalized rank.
    order = torch.argsort(x, dim=-1)  # [B, N]
    ranks = torch.zeros_like(x, dtype=torch.float32)
    base = torch.arange(x.size(-1), device=x.device, dtype=torch.float32).view(1, -1)
    base = base.expand_as(order).contiguous()
    ranks.scatter_(dim=1, index=order, src=base)
    denom = max(x.size(-1) - 1, 1)
    return ranks / denom
def normalize_score(score: torch.Tensor, mode: str = "minmax", temperature: float = 1.0) -> torch.Tensor:
    if mode == "global_minmax":
        return (score - score.min() + 1e-6) / (score.max() - score.min() + 1e-6)
    if mode == "minmax":
        return _minmax_per_sample(score)
    if mode == "rank_norm":
        return _rank_norm(score)
    if mode == "softmax":
        return torch.softmax(score / max(float(temperature), 1e-6), dim=-1)
    if mode == "sigmoid":
        return torch.sigmoid(score / max(float(temperature), 1e-6))
    if mode in ("none", None):
        return score
    raise ValueError(f"Unsupported score normalization: {mode}")


def instruction_guided_visual_relevance(ctx: CDPrunerContext, params: Dict[str, Any]) -> torch.Tensor:
    image_embeds = _safe_l2_normalize(ctx.image_embeds.float(), dim=-1)
    text_embeds = ctx.text_embeds.float()

    if text_embeds.ndim == 2:
        text_embeds = _safe_l2_normalize(text_embeds, dim=-1)
        rel = torch.matmul(image_embeds, text_embeds.t())
    else:
        text_embeds = _safe_l2_normalize(text_embeds, dim=-1)
        rel = torch.einsum("bnc,bmc->bnm", image_embeds, text_embeds)

    sign = params.get("sign", "negative_mean")
    if sign == "negative_mean":
        score = -rel.mean(dim=-1)
    elif sign == "positive_mean":
        score = rel.mean(dim=-1)
    elif sign == "max":
        score = rel.max(dim=-1).values
    else:
        raise ValueError(f"Unsupported relevance sign: {sign}")

    score = normalize_score(score, params.get("score_normalization", params.get("transform", "minmax")),
                            params.get("temperature", 1.0))
    power = float(params.get("power", 1.0))
    if power != 1.0:
        score = score.clamp_min(1e-6).pow(power)
    return score.float()


def pairwise_token_similarity(ctx: CDPrunerContext, params: Dict[str, Any]) -> torch.Tensor:
    feats = ctx.image_features.float()
    metric = params.get("similarity_metric", "cosine")
    if metric in ("cosine", "centered_cosine"):
        if metric == "centered_cosine":
            feats = feats - feats.mean(dim=1, keepdim=True)
        feats = _safe_l2_normalize(feats, dim=-1)
        sim = torch.matmul(feats, feats.transpose(1, 2))
    elif metric == "dot":
        sim = torch.matmul(feats, feats.transpose(1, 2))
    elif metric in ("rbf", "l2_rbf"):
        tau = float(params.get("tau", 1.0))
        dist = torch.cdist(feats, feats, p=2).pow(2)
        sim = torch.exp(-dist / max(tau, 1e-6))
    else:
        raise ValueError(f"Unsupported similarity metric: {metric}")

    if params.get("similarity_transform") == "clamp_positive":
        sim = sim.clamp_min(0.0)
    return sim.float()


def conditional_similarity_score(ctx: CDPrunerContext, relevance: torch.Tensor, params: Dict[str, Any]) -> torch.Tensor:
    sim = pairwise_token_similarity(ctx, params)
    mode = params.get("conditioning_mode", "none")
    if mode in ("none", None):
        return sim
    q = relevance.float().clamp_min(1e-6)
    if mode == "multiplicative":
        return (sim * q.unsqueeze(2) * q.unsqueeze(1)).float()
    if mode == "gated":
        gate = torch.sigmoid((q - q.mean(dim=-1, keepdim=True))).unsqueeze(2)
        return (sim * gate * gate.transpose(1, 2)).float()
    raise ValueError(f"Unsupported conditioning_mode: {mode}")


def quality_diversity_kernel(quality: torch.Tensor, similarity: torch.Tensor, params: Dict[str, Any]) -> torch.Tensor:
    q = quality.float().clamp_min(1e-6)
    s = similarity.float()
    q = q.pow(float(params.get("quality_power", 1.0)))
    if params.get("similarity_transform", "identity") == "clamp_positive":
        s = s.clamp_min(0.0)
    sp = float(params.get("similarity_power", 1.0))
    if sp != 1.0:
        s = s.clamp_min(1e-6).pow(sp)
    kernel = q.unsqueeze(2) * s * q.unsqueeze(1)
    if params.get("symmetrize", True):
        kernel = 0.5 * (kernel + kernel.transpose(1, 2))
    eps = float(params.get("eps", 1e-6))
    eye = torch.eye(kernel.size(-1), device=kernel.device, dtype=kernel.dtype).unsqueeze(0)
    return kernel + eps * eye


def weighted_sum_score_fusion(scores: Dict[str, torch.Tensor], params: Dict[str, Any]) -> torch.Tensor:
    names = list(scores.keys())
    weights = params.get("weights")
    if weights is None:
        weights = [1.0 / max(len(names), 1)] * len(names)
    if len(weights) != len(names):
        raise ValueError("weights length must match number of score tensors")
    out = 0.0
    for name, weight in zip(names, weights):
        out = out + float(weight) * normalize_score(scores[name], params.get("score_normalization", "minmax"))
    return out.float()


def mmr_select(quality: torch.Tensor, similarity: torch.Tensor, k: int, lambda_relevance: float = 0.5) -> torch.Tensor:
    B, N = quality.shape
    k = min(int(k), N)
    selected = torch.empty(B, k, dtype=torch.long, device=quality.device)
    candidate_mask = torch.ones(B, N, dtype=torch.bool, device=quality.device)

    for t in range(k):
        if t == 0:
            score = quality.clone()
        else:
            prev = selected[:, :t]
            sim_to_selected = torch.gather(similarity, 2, prev[:, None, :].expand(B, N, t)).max(dim=-1).values
            score = lambda_relevance * quality - (1.0 - lambda_relevance) * sim_to_selected
        score = score.masked_fill(~candidate_mask, -float("inf"))
        idx = score.argmax(dim=-1)
        selected[:, t] = idx
        candidate_mask.scatter_(1, idx[:, None], False)

    return torch.sort(selected, dim=-1).values


def topk_select(score: torch.Tensor, k: int, largest: bool = True) -> torch.Tensor:
    k = min(int(k), score.size(-1))
    idx = torch.topk(score, k=k, dim=-1, largest=largest).indices
    return torch.sort(idx, dim=-1).values


def fast_map_dpp(kernel: torch.Tensor, k: int) -> torch.Tensor:
    B, N, _ = kernel.shape
    K = min(int(k), N)
    device = kernel.device
    cis = torch.zeros((K, B, N), device=device, dtype=kernel.dtype)
    di2s = torch.diagonal(kernel, dim1=1, dim2=2).clone()
    select_idx = torch.empty((K, B), dtype=torch.long, device=device)

    for i in range(K):
        j = torch.argmax(di2s, dim=-1)
        select_idx[i] = j
        denom = torch.sqrt(di2s[torch.arange(B, device=device), j].clamp_min(1e-6)).unsqueeze(-1)
        eis = (kernel[torch.arange(B, device=device), j] -
               torch.einsum("tb,tbn->bn", cis[:i, torch.arange(B, device=device), j], cis[:i])) / denom
        cis[i] = eis
        di2s = di2s - torch.square(eis)
        di2s[torch.arange(B, device=device), j] = -float("inf")

    return torch.sort(select_idx.t(), dim=-1).values


def infer_grid_positions(n: int, device: torch.device) -> Optional[torch.Tensor]:
    side = int(math.sqrt(n))
    if side * side != n:
        return None
    y, x = torch.meshgrid(torch.arange(side, device=device), torch.arange(side, device=device), indexing="ij")
    return torch.stack([y.flatten(), x.flatten()], dim=-1)


def apply_top_relevance_anchor(selected: torch.Tensor, relevance: torch.Tensor, topk: int) -> torch.Tensor:
    B, K = selected.shape
    topk = min(int(topk), K, relevance.size(-1))
    anchors = torch.topk(relevance, k=topk, dim=-1).indices
    out = selected.clone()
    for b in range(B):
        keep = torch.unique(torch.cat([anchors[b], selected[b]], dim=0), sorted=False)
        if keep.numel() < K:
            keep = torch.unique(torch.cat([keep, selected[b]], dim=0), sorted=False)
        cand_score = relevance[b, keep]
        trim = torch.topk(cand_score, k=K).indices
        out[b] = torch.sort(keep[trim]).values
    return out


def apply_spatial_coverage(selected: torch.Tensor, score: torch.Tensor, token_positions: Optional[torch.Tensor],
                           grid_size: int = 4, min_keep_per_cell: int = 1) -> torch.Tensor:
    B, K = selected.shape
    N = score.size(-1)
    device = score.device
    if token_positions is None:
        token_positions = infer_grid_positions(N, device)
    if token_positions is None:
        return selected

    pos = token_positions[None].expand(B, -1, -1) if token_positions.ndim == 2 else token_positions
    out = selected.clone()
    for b in range(B):
        y = pos[b, :, 0].float()
        x = pos[b, :, 1].float()
        ybin = torch.clamp((grid_size * (y - y.min()) / (y.max() - y.min()).clamp_min(1e-6)).long(), 0, grid_size - 1)
        xbin = torch.clamp((grid_size * (x - x.min()) / (x.max() - x.min()).clamp_min(1e-6)).long(), 0, grid_size - 1)
        required = []
        for gy in range(grid_size):
            for gx in range(grid_size):
                mask = (ybin == gy) & (xbin == gx)
                if mask.any():
                    idxs = torch.where(mask)[0]
                    best = idxs[score[b, idxs].argmax()]
                    required.append(best)
        if not required:
            continue
        required = torch.stack(required)[:K]
        keep = torch.unique(torch.cat([out[b], required], dim=0), sorted=False)
        cand_score = score[b, keep]
        trim = torch.topk(cand_score, k=min(K, keep.numel())).indices
        new = keep[trim]
        if new.numel() < K:
            new = torch.cat([new, out[b]])[:K]
        out[b] = torch.sort(new[:K]).values
    return out
