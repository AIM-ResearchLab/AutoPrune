# Integration patch for CDPruner `llava/model/llava_arch.py`

## Goal

Replace the hard-coded CDPruner token-selection logic in `encode_images` with a YAML policy executor.

The executor preserves the original return contract:

```python
return image_features, index_masks
```

## 1. Copy files

```bash
cp -r cdpruner_policy /path/to/CDPruner/
cp -r configs /path/to/CDPruner/
cp -r tools /path/to/CDPruner/
```

## 2. Add imports near the top of `llava/model/llava_arch.py`

```python
import os
from cdpruner_policy import load_policy, CDPrunerPolicyExecutor
from cdpruner_policy.types import CDPrunerContext
```

## 3. Replace only the selection block inside `encode_images`

Keep this part:

```python
image_features, image_embeds, text_embeds = self.get_model().get_vision_tower()(images, texts=texts)
B, N, C = image_features.shape
device = image_features.device
index_masks = torch.ones(B, N, dtype=torch.bool, device=device)
image_features = self.get_model().mm_projector(image_features)
```

Then replace the original cosine similarity / relevance / kernel / DPP block with:

```python
policy_path = os.environ.get("CDPRUNER_POLICY", "configs/cdpruner_default_policy_v0_5.yaml")
if not hasattr(self, "_evo_cdpruner_policy_path") or self._evo_cdpruner_policy_path != policy_path:
    self._evo_cdpruner_policy_path = policy_path
    self._evo_cdpruner_executor = CDPrunerPolicyExecutor(load_policy(policy_path))

ctx = CDPrunerContext(
    image_features=image_features,
    image_embeds=image_embeds,
    text_embeds=text_embeds,
    visual_token_budget=int(self.visual_token_num),
    token_positions=None,
    metadata={"texts": texts, "stage": "encode_images"},
)
index_masks = self._evo_cdpruner_executor.select(ctx)
return image_features, index_masks
```

## 4. Self-test

```bash
python tools/selftest_cdpruner_policy.py --policy configs/cdpruner_default_policy_v0_5.yaml --tokens 576 --keep 128
python tools/selftest_cdpruner_policy.py --policy configs/cdpruner_mmr_policy_example.yaml --tokens 576 --keep 128
```

## 5. Evaluation

```bash
export CDPRUNER_POLICY=configs/cdpruner_default_policy_v0_5.yaml
CUDA_VISIBLE_DEVICES=0 bash scripts/v1_5/eval/gqa.sh 128
```

Then compare with original CDPruner using the same `VISUAL_TOKEN_NUMBER`.

## 6. OpenEvolve integration

OpenEvolve should mutate only the YAML policy file. The evaluator should:

1. Copy candidate policy to a run directory.
2. Set `CDPRUNER_POLICY=/path/to/candidate_policy.yaml`.
3. Run a small benchmark subset.
4. Parse score, latency, memory, and validity.
5. Return scalar objective.
