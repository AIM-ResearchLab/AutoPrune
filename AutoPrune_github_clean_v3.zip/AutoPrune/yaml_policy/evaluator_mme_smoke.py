#!/usr/bin/env python3
from __future__ import annotations
import argparse, os, re, subprocess, sys
from pathlib import Path

def parse_mme_score(text: str) -> dict:
    totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
    if len(totals) < 2:
        raise RuntimeError("Could not parse both Perception and Cognition total scores.")
    p, c = totals[0], totals[1]
    return {"perception": p, "cognition": c, "combined_score": p + c}

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", required=True)
    ap.add_argument("--gpu", default="3")
    ap.add_argument("--token", default="32")
    ap.add_argument("--script", default="scripts/v1_5/eval/mme_yaml_smoke21.sh")
    ap.add_argument("--log", default=None)
    args = ap.parse_args()
    policy = Path(args.policy).resolve()
    log_path = Path(args.log or f"/tmp/evo_cdpruner_mme_{policy.stem}.log")
    env = os.environ.copy()
    env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
    env["EVO_CDPRUNER_ENABLE"] = "1"
    env["EVO_CDPRUNER_DEBUG"] = "0"
    env["EVO_CDPRUNER_DEBUG_MASK"] = "0"
    env["CDPRUNER_POLICY"] = str(policy)
    env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
    env["EVO_TOKEN"] = str(args.token)
    proc = subprocess.run(["bash", args.script, str(args.token)], cwd=Path.cwd(), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    log_path.write_text(proc.stdout)
    if proc.returncode != 0:
        print(proc.stdout[-4000:])
        print("combined_score: 0.0")
        print("valid: 0")
        return
    try:
        scores = parse_mme_score(proc.stdout)
    except Exception as e:
        print(proc.stdout[-4000:])
        print("[PARSE_ERROR]", e, file=sys.stderr)
        print("combined_score: 0.0")
        print("valid: 0")
        return
    print(f"perception: {scores['perception']}")
    print(f"cognition: {scores['cognition']}")
    print(f"combined_score: {scores['combined_score']}")
    print("valid: 1")

if __name__ == "__main__":
    main()
