from __future__ import annotations

import importlib.util
import json
import os
import re
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path
from typing import Any, Dict, Optional

import yaml


ROOT = Path("/data/lz/openevolve_pruner/CDPruner")
CLI_EVALUATOR = ROOT / "yaml_policy/openevolve_yaml_search/evaluator.py"


def _extract_first_json_object(text: str) -> Optional[Dict[str, Any]]:
    start = text.find("{")
    if start < 0:
        return None

    depth = 0
    in_str = False
    esc = False

    for i in range(start, len(text)):
        ch = text[i]

        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
        else:
            if ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        obj = json.loads(text[start:i + 1])
                        return obj if isinstance(obj, dict) else None
                    except Exception:
                        return None

    return None


def _load_candidate_module(program_path: str):
    path = Path(program_path)
    spec = importlib.util.spec_from_file_location("candidate_program", str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load candidate module from {program_path}")

    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _candidate_to_policy_yaml(program_path: str) -> str:
    path = Path(program_path)
    mod = _load_candidate_module(program_path)

    # Preferred format from openevolve/initial_program.py
    if hasattr(mod, "get_policy_yaml"):
        obj = mod.get_policy_yaml()
        if isinstance(obj, str):
            return obj
        if isinstance(obj, dict):
            return yaml.safe_dump(obj, sort_keys=False, allow_unicode=True)

    if hasattr(mod, "POLICY_YAML"):
        obj = getattr(mod, "POLICY_YAML")
        if isinstance(obj, str):
            return obj
        if isinstance(obj, dict):
            return yaml.safe_dump(obj, sort_keys=False, allow_unicode=True)

    # Some generators may emit POLICY / policy as a dict.
    for name in ["POLICY", "policy"]:
        if hasattr(mod, name):
            obj = getattr(mod, name)
            if isinstance(obj, dict):
                return yaml.safe_dump(obj, sort_keys=False, allow_unicode=True)
            if isinstance(obj, str):
                return obj

    # Last-resort regex extraction.
    text = path.read_text(errors="ignore")
    m = re.search(r'POLICY_YAML\s*=\s*r?"""(.*?)"""', text, flags=re.S)
    if m:
        return m.group(1)

    raise RuntimeError(
        "candidate program does not expose get_policy_yaml(), POLICY_YAML, POLICY, or policy"
    )


def _bad_metrics(error: str, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    out: Dict[str, Any] = {
        "combined_score": -1e18,
        "ood_acc": -1e18,
        "valid": 0.0,
        "error": error,
    }
    if extra:
        out.update(extra)
    return out


def evaluate(program_path: str) -> Dict[str, Any]:
    """OpenEvolve-compatible evaluator entrypoint.

    OpenEvolve calls evaluate(candidate_program_path). This wrapper extracts
    POLICY_YAML from the candidate Python program, writes it to a temporary YAML
    file, and delegates real scoring to yaml_policy/openevolve_yaml_search/evaluator.py.
    """
    try:
        policy_yaml = _candidate_to_policy_yaml(program_path)
    except Exception as e:
        return _bad_metrics(
            f"extract_policy_failed:{e}",
            {"traceback": traceback.format_exc()[-4000:]},
        )

    gpu = str(os.environ.get("EVO_GPU", "5"))
    token = str(os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32")))
    script = str(os.environ.get("EVO_EVAL_SCRIPT", "scripts/v1_5/eval/mme_yaml_smoke21.sh"))
    timeout = int(float(os.environ.get("EVO_EVAL_TIMEOUT", "1800")))

    with tempfile.TemporaryDirectory(prefix="evo_v10_eval_") as td:
        td_path = Path(td)
        policy_path = td_path / "candidate_policy.yaml"
        log_path = td_path / "candidate_eval.log"

        policy_path.write_text(policy_yaml, encoding="utf-8")

        cmd = [
            sys.executable,
            str(CLI_EVALUATOR),
            str(policy_path),
            "--gpu",
            gpu,
            "--token",
            token,
            "--script",
            script,
            "--log",
            str(log_path),
        ]

        env = os.environ.copy()
        env["PYTHONPATH"] = f"{ROOT}:{env.get('PYTHONPATH', '')}"

        try:
            proc = subprocess.run(
                cmd,
                cwd=str(ROOT),
                env=env,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=timeout,
            )
        except subprocess.TimeoutExpired:
            return _bad_metrics(
                "eval_timeout",
                {
                    "candidate_program_path": program_path,
                    "candidate_policy_path": str(policy_path),
                    "eval_script": script,
                    "gpu": gpu,
                    "token": token,
                },
            )

        stdout = proc.stdout or ""
        obj = _extract_first_json_object(stdout)

        if obj is None:
            return _bad_metrics(
                "eval_json_parse_failed",
                {
                    "returncode": proc.returncode,
                    "stdout_tail": stdout[-4000:],
                    "candidate_program_path": program_path,
                    "eval_script": script,
                },
            )

        if proc.returncode != 0:
            obj["valid"] = 0.0
            obj["error"] = obj.get("error") or f"eval_returncode_{proc.returncode}"
            obj["stdout_tail"] = stdout[-4000:]

        # OpenEvolve often expects combined_score / ood_acc.
        # v10: allow OpenEvolve selection metric to differ from CLI evaluator objective.
        # Example:
        #   EVO_OE_SELECTION_METRIC=raw_combined_score
        #   EVO_OE_SELECTION_METRIC=balanced_score
        selection_metric = str(os.environ.get("EVO_OE_SELECTION_METRIC", "")).strip()

        if selection_metric and selection_metric in obj:
            try:
                obj["combined_score"] = float(obj[selection_metric])
            except Exception:
                obj["combined_score"] = obj[selection_metric]
            obj["objective_score"] = obj["combined_score"]
            obj["oe_selection_metric"] = selection_metric
        elif "combined_score" not in obj:
            obj["combined_score"] = obj.get(
                "objective_score",
                obj.get("perception", obj.get("raw_combined_score", -1e18)),
            )
            obj["oe_selection_metric"] = obj.get("objective", "combined_score")
        else:
            obj["oe_selection_metric"] = obj.get("objective", "combined_score")

        obj["ood_acc"] = obj.get("combined_score", -1e18)
        obj.setdefault("valid", 1.0 if float(obj.get("combined_score", -1e18)) > -1e17 else 0.0)
        obj.setdefault("candidate_program_path", program_path)
        obj.setdefault("eval_script", script)
        obj.setdefault("gpu", gpu)
        obj.setdefault("token", token)

        return obj
