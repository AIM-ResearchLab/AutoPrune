"""
OpenEvolve candidate program for Evo-CDPruner YAML policy search.
This seed reconstructs the CDPruner-style DPP policy.
"""

POLICY_YAML = r"""
version: "0.5-light"
policy_name: "evolved_cdpruner_policy"
target_host: "cdpruner_encode_images"
target_domain: "mllm_visual_token_pruning"
search_stage: "stage1_functional_search"
pipeline:
  - id: "visual_token_selection"
    trigger:
      atom: "pre_llm_visual_reduction_trigger"
    target:
      atom: "image_patch_tokens"
    scorer:
      quality:
        atom: "instruction_guided_visual_relevance"
        params:
          sign: "negative_mean"
          transform: "minmax"
          power: 1.0
      similarity:
        atom: "conditional_similarity_score"
        params:
          similarity_metric: "cosine"
          conditioning_mode: "none"
          similarity_transform: "identity"
    fusion:
      atom: "quality_diversity_kernel"
      params:
        quality_power: 1.0
        similarity_power: 1.0
        eps: 1.0e-6
        symmetrize: true
    budget:
      atom: "fixed_keep_tokens"
      params:
        keep_tokens: "host_argument"
    selector:
      atom: "dpp_selector"
      params:
        algorithm: "fast_map"
        postprocess: "sort_by_position"
    action:
      atom: "dpp_subset_prune"
    protection: []
"""

def get_policy_yaml() -> str:
    return POLICY_YAML
