You are evolving a YAML policy for Evo-CDPruner visual token selection.

The candidate program contains a single string variable named POLICY_YAML.
Only modify the YAML policy inside POLICY_YAML. Do not modify Python imports, function names, or evaluator logic.

Goal:
Maximize combined_score on the MME smoke evaluator while keeping the policy valid and CDPruner-compatible.

Hard constraints:
- target_host must remain "cdpruner_encode_images".
- target_domain must remain "mllm_visual_token_pruning".
- Keep exactly one pipeline step.
- trigger.atom must remain "pre_llm_visual_reduction_trigger".
- target.atom must remain "image_patch_tokens".
- Do not use LLM attention, gradients, KV cache, trainable modules, or model path changes.
- Do not add more than two protection atoms.
- Make one small, valid mutation at a time.

Implemented safe templates:

1. DPP template:
   scorer:
     quality: instruction_guided_visual_relevance
     similarity: conditional_similarity_score or pairwise_token_similarity
   fusion.atom: quality_diversity_kernel
   selector.atom: dpp_selector
   action.atom: dpp_subset_prune

2. TopK template:
   scorer:
     main: instruction_guided_visual_relevance
   fusion.atom: weighted_sum_score_fusion
   selector.atom: topk_selector
   action.atom: hard_prune

3. MMR template:
   scorer:
     quality: instruction_guided_visual_relevance
     similarity: pairwise_token_similarity or conditional_similarity_score
   fusion.atom: mmr_relevance_diversity_fusion
   selector.atom: mmr_selector
   action.atom: hard_prune

Safe parameters:
- relevance sign: negative_mean, positive_mean, max
- score normalization: minmax, rank_norm, softmax, sigmoid
- power: 0.5, 0.75, 1.0, 1.25, 1.5, 2.0
- similarity metric: cosine, centered_cosine, dot, rbf
- conditioning_mode: none, multiplicative, gated
- MMR lambda_relevance: 0.3, 0.4, 0.5, 0.6, 0.7

Protections:
- spatial_coverage_preservation with grid_size: 2, 4, 7, 8
- top_relevance_anchor_preservation with topk or anchor_count: 4, 8, 16, 32
- special_token_preservation

Avoid YAML syntax errors and atoms not listed above.
