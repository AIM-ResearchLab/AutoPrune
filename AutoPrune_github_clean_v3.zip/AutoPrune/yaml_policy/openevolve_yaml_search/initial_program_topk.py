"""
OpenEvolve candidate program for Evo-CDPruner YAML policy search.
OpenEvolve should mutate only POLICY_YAML.
"""

POLICY_YAML = r"""
version: "0.5-light"
policy_name: "evolved_cdpruner_policy"
target_host: "cdpruner_encode_images"
target_domain: "mllm_visual_token_pruning"
search_stage: "stage1_functional_search"
pipeline:
  - id: "visual_token_selection"
    trigger:
      atom: "pre_llm_visual_reduction_trigger"
    target:
      atom: "image_patch_tokens"
    scorer:
      main:
        atom: "instruction_guided_visual_relevance"
        params:
          sign: "negative_mean"
          transform: "rank_norm"
          power: 1.0
    fusion:
      atom: "weighted_sum_score_fusion"
      params:
        score_normalization: "rank_norm"
        weights: [1.0]
    budget:
      atom: "fixed_keep_tokens"
      params:
        keep_tokens: "host_argument"
    selector:
      atom: "topk_selector"
      params:
        largest: true
    action:
      atom: "hard_prune"
    protection: []
"""

def get_policy_yaml() -> str:
    return POLICY_YAML
