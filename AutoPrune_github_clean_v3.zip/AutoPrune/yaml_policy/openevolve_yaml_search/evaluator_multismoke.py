#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, math, os, re, subprocess, sys, tempfile
from pathlib import Path
from typing import Dict, List, Any

def first_json(text: str) -> Dict[str, Any]:
    start = text.find("{")
    if start < 0:
        return {}
    depth = 0
    for i in range(start, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                try:
                    return json.loads(text[start:i+1])
                except Exception:
                    return {}
    return {}

def make_chunk_script(base_script: Path, out_path: Path, num_chunks: int, chunk_idx: int) -> None:
    s = base_script.read_text()
    if "--num-chunks" in s:
        s = re.sub(r"--num-chunks\s+\d+", f"--num-chunks {num_chunks}", s)
    else:
        s = s.replace("--visual_token_num ${TOKEN} \\", f"--visual_token_num ${{TOKEN}} \\\n    --num-chunks {num_chunks} \\")
    if "--chunk-idx" in s:
        s = re.sub(r"--chunk-idx\s+\d+", f"--chunk-idx {chunk_idx}", s)
    else:
        s = s.replace(f"--num-chunks {num_chunks} \\", f"--num-chunks {num_chunks} \\\n    --chunk-idx {chunk_idx} \\")
    out_path.write_text(s)
    out_path.chmod(0o755)

def mean(xs: List[float]) -> float:
    return sum(xs) / len(xs) if xs else 0.0

def std(xs: List[float]) -> float:
    if len(xs) <= 1:
        return 0.0
    m = mean(xs)
    return math.sqrt(sum((x-m)**2 for x in xs) / len(xs))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate")
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU", "3"))
    ap.add_argument("--token", default=os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32")))
    ap.add_argument("--base-script", default="scripts/v1_5/eval/mme_yaml_smoke21.sh")
    ap.add_argument("--num-chunks", type=int, default=21)
    ap.add_argument("--chunks", default="0,1,2")
    ap.add_argument("--std-penalty", type=float, default=0.5)
    ap.add_argument("--log-dir", default=None)
    ap.add_argument("--allow-partial-score", action="store_true")
    args = ap.parse_args()

    chunks = [int(x) for x in args.chunks.split(",") if x.strip()]
    tmpdir = Path(tempfile.mkdtemp(prefix="evo_v7_multismoke_"))
    log_dir = Path(args.log_dir or tmpdir / "logs")
    log_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    for c in chunks:
        script_path = tmpdir / f"smoke_chunk_{c}.sh"
        make_chunk_script(Path(args.base_script), script_path, args.num_chunks, c)
        cmd = [
            sys.executable, "yaml_policy/openevolve_yaml_search/evaluator.py", args.candidate,
            "--gpu", str(args.gpu), "--token", str(args.token),
            "--script", str(script_path), "--log", str(log_dir / f"chunk_{c}.log"),
        ]
        env = os.environ.copy()
        env["EVO_TOKEN"] = str(args.token)
        env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
        env["EVO_OBJECTIVE"] = "perception"
        proc = subprocess.run(cmd, cwd=Path.cwd(), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        (log_dir / f"chunk_{c}.stdout.txt").write_text(proc.stdout)
        row = first_json(proc.stdout)
        if not row:
            row = {"valid": 0.0, "perception": 0.0, "cognition": 0.0, "combined_score": 0.0, "error": "parse_failed", "stdout_tail": proc.stdout[-2000:]}
        row["chunk_idx"] = c
        row["returncode"] = proc.returncode
        rows.append(row)

    valid_rows = [r for r in rows if float(r.get("valid", 0.0)) > 0]
    pers = [float(r.get("perception", 0.0)) for r in valid_rows]
    cogs = [float(r.get("cognition", 0.0)) for r in valid_rows]
    all_valid = len(valid_rows) == len(chunks)
    robust = mean(pers) - args.std_penalty * std(pers) if pers else 0.0

    out: Dict[str, Any] = {
        "valid": 1.0 if all_valid else 0.0,
        "num_chunks_eval": len(chunks),
        "num_chunks_valid": len(valid_rows),
        "perception_mean": mean(pers),
        "perception_std": std(pers),
        "perception_min": min(pers) if pers else 0.0,
        "cognition_mean": mean(cogs),
        "robust_perception": robust,
        "chunks": rows,
    }
    for k in ["overlap_with_reference_avg", "changed_tokens_avg", "selected_score_avg", "selected_tokens_avg"]:
        vals = [float(r[k]) for r in valid_rows if isinstance(r.get(k), (int, float))]
        if vals:
            out[k] = mean(vals)
    if all_valid or args.allow_partial_score:
        out["combined_score"] = robust
    else:
        out["combined_score"] = 0.0
        out["invalid_combined_score_before_zero"] = robust
    out["objective"] = "robust_perception"
    out["artifact"] = {"log_dir": str(log_dir), "chunks": chunks, "base_script": args.base_script, "num_chunks": args.num_chunks}
    print(json.dumps(out, indent=2, ensure_ascii=False))
    print(f"combined_score: {out['combined_score']}")
    print(f"valid: {out['valid']}")

if __name__ == "__main__":
    main()
