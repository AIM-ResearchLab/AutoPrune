# OpenEvolve YAML Policy Search for Evo-CDPruner

This folder converts YAML policy search into an OpenEvolve-compatible code evolution task.

OpenEvolve evolves `initial_program_*.py`.
Each candidate program contains:

```python
POLICY_YAML = r""" ... """
```

The evaluator extracts the YAML string, writes it to a candidate YAML file, and calls:

```bash
python yaml_policy/evaluator_mme_smoke.py --policy candidate.yaml
```

## Test

```bash
bash yaml_policy/openevolve_yaml_search/run_test_evaluator.sh
```

Expected on your current smoke50 setting:
- TopK seed around 1659.047
- Default seed around 1654.047

## First OpenEvolve run

Use:
- initial program: `initial_program_topk.py`
- evaluator: `evaluator.py`
- prompt: `prompt.md`
- iterations: 20
- workers: 1
- script: `scripts/v1_5/eval/mme_yaml_smoke.sh`

After this works, switch to `mme_yaml_smoke20.sh` for more stable scoring.
