#!/usr/bin/env bash
set -euo pipefail

# Template only. Adjust the OpenEvolve CLI flags to match your local installation.
# Keep workers=1 for the first run because MME answer files may be overwritten in parallel.

cd /data/lz/openevolve_pruner/CDPruner

export EVO_GPU="${EVO_GPU:-6}"
export EVO_TOKEN="${EVO_TOKEN:-64}"
export EVO_EVAL_SCRIPT="${EVO_EVAL_SCRIPT:-scripts/v1_5/eval/mme_yaml_smoke.sh}"
export EVO_EVAL_TIMEOUT="${EVO_EVAL_TIMEOUT:-900}"

mkdir -p yaml_policy/evo_runs/topk_seed_smoke50

cat <<'NOTE'
Use these files in your OpenEvolve command:

initial_program:
  yaml_policy/openevolve_yaml_search/initial_program_topk.py

evaluator:
  yaml_policy/openevolve_yaml_search/evaluator.py

prompt/context:
  yaml_policy/openevolve_yaml_search/prompt.md

output_dir:
  yaml_policy/evo_runs/topk_seed_smoke50

recommended:
  iterations = 20
  workers = 1
NOTE
