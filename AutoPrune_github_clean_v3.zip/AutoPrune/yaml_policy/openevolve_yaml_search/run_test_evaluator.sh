#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

export EVO_GPU="${EVO_GPU:-6}"
export EVO_TOKEN="${EVO_TOKEN:-64}"
export EVO_EVAL_SCRIPT="${EVO_EVAL_SCRIPT:-scripts/v1_5/eval/mme_yaml_smoke.sh}"

python yaml_policy/openevolve_yaml_search/evaluator.py \
  yaml_policy/openevolve_yaml_search/initial_program_topk.py \
  --gpu "${EVO_GPU}" \
  --token "${EVO_TOKEN}" \
  --script "${EVO_EVAL_SCRIPT}"

python yaml_policy/openevolve_yaml_search/evaluator.py \
  yaml_policy/openevolve_yaml_search/initial_program_default.py \
  --gpu "${EVO_GPU}" \
  --token "${EVO_TOKEN}" \
  --script "${EVO_EVAL_SCRIPT}"
