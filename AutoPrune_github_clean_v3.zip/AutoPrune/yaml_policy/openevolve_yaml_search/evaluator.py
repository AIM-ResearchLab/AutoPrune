#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib.util, json, os, re, subprocess, tempfile
from pathlib import Path
from typing import Dict, Any
import yaml

def _load_policy_yaml(path: Path) -> str:
    if path.suffix in {".yaml", ".yml"}:
        return path.read_text()
    spec = importlib.util.spec_from_file_location("candidate_program", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    if hasattr(mod, "get_policy_yaml"):
        return str(mod.get_policy_yaml())
    if hasattr(mod, "POLICY_YAML"):
        return str(mod.POLICY_YAML)
    raise RuntimeError("candidate must define get_policy_yaml or POLICY_YAML")

def _force_fixed_tokens(policy_yaml: str, k: int) -> str:
    data = yaml.safe_load(policy_yaml)
    for pipe in data.get("pipeline", []):
        pipe["budget"] = {"atom": "fixed_keep_tokens", "params": {"keep_tokens": int(k)}}
    return yaml.safe_dump(data, sort_keys=False, allow_unicode=True)

def _parse_mme_output(text: str) -> Dict[str, float]:
    totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
    if len(totals) >= 2:
        p, c = totals[:2]
        return {"perception": p, "cognition": c, "raw_combined_score": p+c, "mme_combined_score": p+c}
    return {"perception": 0.0, "cognition": 0.0, "raw_combined_score": 0.0, "mme_combined_score": 0.0}

def _load_mask_diag(path: Path) -> Dict[str, float]:
    if not path.exists():
        return {}
    rows = []
    for line in path.read_text(errors="ignore").splitlines():
        try: rows.append(json.loads(line))
        except Exception: pass
    if not rows: return {}
    keys = set()
    for r in rows:
        for k, v in r.items():
            if isinstance(v, (int, float)): keys.add(k)
    out = {"mask_diag_num_rows": float(len(rows))}
    for k in keys:
        vals = [float(r[k]) for r in rows if isinstance(r.get(k), (int, float))]
        if vals: out[k] = sum(vals)/len(vals)
    return out


def _apply_v14b_strict_filter(metrics):
    if os.environ.get("EVO_V14B_STRICT", "0").strip() != "1":
        return metrics

    try:
        overlap = float(metrics.get("overlap_with_reference_avg", -1.0))
        changed = float(metrics.get("changed_tokens_avg", -999.0))
        delta = float(metrics.get("v14_feature_delta_norm_avg", 0.0))
    except Exception:
        overlap, changed, delta = -1.0, -999.0, 0.0

    ok = (
        float(metrics.get("valid", 0.0)) == 1.0
        and abs(overlap - 0.9375) <= 1e-4
        and abs(changed - 2.0) <= 1e-4
        and delta > 0.0
    )

    if not ok:
        metrics["v14b_reject_reason"] = (
            f"strict_v14b_failed: overlap={overlap}, changed={changed}, delta={delta}"
        )
        metrics["valid"] = 0.0
        for k in [
            "combined_score",
            "objective_score",
            "raw_combined_score",
            "mme_combined_score",
            "balanced_score",
            "perception",
            "cognition",
            "ood_acc",
        ]:
            if k in metrics:
                metrics[k] = 0.0
    return metrics


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("candidate")
    ap.add_argument("--gpu", default=os.environ.get("EVO_GPU", "3"))
    ap.add_argument("--token", default=os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32")))
    ap.add_argument("--script", default=os.environ.get("EVO_EVAL_SCRIPT", "scripts/v1_5/eval/mme_yaml_smoke21.sh"))
    ap.add_argument("--log", default=None)
    args = ap.parse_args()
    tmpdir = Path(tempfile.mkdtemp(prefix="evo_v5_eval_"))
    policy_path = tmpdir / "candidate_policy.yaml"
    stdout_path = Path(args.log or (tmpdir / "stdout.log"))
    mask_diag_path = tmpdir / "mask_diagnostics.jsonl"
    try:
        policy_yaml = _load_policy_yaml(Path(args.candidate).resolve())
        policy_yaml = _force_fixed_tokens(policy_yaml, int(os.environ.get("EVO_FORCE_FIXED_TOKENS") or args.token))
        policy_path.write_text(policy_yaml)
        env = os.environ.copy()
        env["CUDA_VISIBLE_DEVICES"] = str(args.gpu)
        env["EVO_CDPRUNER_ENABLE"] = "1"
        env["EVO_CDPRUNER_DEBUG"] = "0"
        env["EVO_CDPRUNER_DEBUG_MASK"] = "0"
        env["CDPRUNER_POLICY"] = str(policy_path)
        env["EVO_FORCE_FIXED_TOKENS"] = str(args.token)
        env["EVO_TOKEN"] = str(args.token)
        env["EVO_MASK_DIAG_PATH"] = str(mask_diag_path)
        proc = subprocess.run(["bash", args.script, str(args.token)], cwd=Path.cwd(), env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        stdout_path.write_text(proc.stdout)
        if proc.returncode != 0:
            metrics: Dict[str, Any] = {"combined_score": 0.0, "objective_score": 0.0, "perception": 0.0, "cognition": 0.0, "raw_combined_score": 0.0, "mme_combined_score": 0.0, "balanced_score": 0.0, "valid": 0.0, "error": f"eval failed with returncode {proc.returncode}"}
        else:
            metrics = _parse_mme_output(proc.stdout)
            p = float(metrics.get("perception", 0.0)); c = float(metrics.get("cognition", 0.0))
            metrics["balanced_score"] = 0.75*p + 0.25*c
            objective = os.environ.get("EVO_OBJECTIVE", "perception")
            metrics["objective"] = objective
            metrics["objective_score"] = float(metrics.get(objective, p))
            metrics["combined_score"] = metrics["objective_score"]
            metrics["valid"] = 1.0
            metrics.update(_load_mask_diag(mask_diag_path))
        metrics["artifact"] = {"candidate_policy_path": str(policy_path), "stdout_path": str(stdout_path), "mask_diag_path": str(mask_diag_path), "eval_script": args.script, "gpu": str(args.gpu), "token": str(args.token), "forced_keep_tokens": str(os.environ.get("EVO_FORCE_FIXED_TOKENS", args.token))}
        print(json.dumps(metrics, indent=2, ensure_ascii=False))
        for key in ["perception", "cognition", "raw_combined_score", "balanced_score", "combined_score", "objective", "valid"]:
            if key in metrics: print(f"{key}: {metrics[key]}")
    except Exception as exc:
        metrics = {"combined_score": 0.0, "objective_score": 0.0, "perception": 0.0, "cognition": 0.0, "valid": 0.0, "error": repr(exc), "artifact": {"candidate_policy_path": str(policy_path), "stdout_path": str(stdout_path), "mask_diag_path": str(mask_diag_path), "eval_script": args.script, "gpu": str(args.gpu), "token": str(args.token)}}
        print(json.dumps(metrics, indent=2, ensure_ascii=False))
        print("combined_score: 0.0")
        print("valid: 0.0")

if __name__ == "__main__":
    main()
