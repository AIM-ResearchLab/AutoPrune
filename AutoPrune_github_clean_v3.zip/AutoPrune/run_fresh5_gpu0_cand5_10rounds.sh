#!/usr/bin/env bash
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$ROOT" || exit 1

export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
export CUDA_VISIBLE_DEVICES=0
export GPU=0
export EVO_GPU=0
export FRESH_GPUS="0"

export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0
export EVO_UNIMERGE_OUTPUT_MODE=inplace_full

export EVO_NUM_CANDIDATES=5
export EVO_N_CANDIDATES=5
export EVO_CANDIDATES_PER_ITER=5
export EVO_SAMPLES_PER_ITERATION=5
export EVO_BATCH_SIZE=5

PREFIX="${1:-fresh5_gpu0_cand5}"
START_ROUND="${2:-1}"
NUM_ROUNDS="${3:-10}"
NUM_CAND="${4:-5}"

BASE_HISTORY="${5:-openevolve/v18_llm_nas/fresh5_small5_history.md}"

LOOP_ROOT="openevolve/runs/v18_llm_nas_${PREFIX}_10rounds_controller"
mkdir -p "$LOOP_ROOT"

{
  echo "===== 10-ROUND CONTROLLER START ====="
  date
  echo "ROOT=$ROOT"
  echo "PREFIX=$PREFIX"
  echo "START_ROUND=$START_ROUND"
  echo "NUM_ROUNDS=$NUM_ROUNDS"
  echo "NUM_CAND=$NUM_CAND"
  echo "BASE_HISTORY=$BASE_HISTORY"
  env | sort | grep -E '^(CUDA_VISIBLE_DEVICES|GPU|EVO_|FRESH_GPUS)=' || true
  echo
  nvidia-smi || true
} > "$LOOP_ROOT/controller_env.txt" 2>&1

if [ ! -f "$BASE_HISTORY" ]; then
  echo "ERROR: base history not found: $BASE_HISTORY"
  exit 1
fi

HISTORY="$BASE_HISTORY"

END_ROUND=$((START_ROUND + NUM_ROUNDS - 1))

for i in $(seq "$START_ROUND" "$END_ROUND"); do
  ROUND="${PREFIX}_r$(printf "%02d" "$i")"
  ROUND_LOG_DIR="$LOOP_ROOT/$ROUND"
  mkdir -p "$ROUND_LOG_DIR"

  echo
  echo "============================================================"
  echo "ROUND=$ROUND"
  echo "HISTORY=$HISTORY"
  echo "NUM_CAND=$NUM_CAND"
  echo "============================================================"

  {
    echo "ROUND=$ROUND"
    echo "HISTORY=$HISTORY"
    echo "NUM_CAND=$NUM_CAND"
    echo "START_TIME=$(date '+%F %T')"
  } > "$ROUND_LOG_DIR/status.txt"

  # 1) 生成本轮 5 个候选 + materialize manifest
  echo "===== PLAN/MATERIALIZE $ROUND ====="
  bash openevolve/v18_llm_nas/run_fresh_pipeline_round_v2.sh "$ROUND" "$HISTORY" "$NUM_CAND" \
    > "$ROUND_LOG_DIR/pipeline.log" 2>&1

  PIPE_RET=$?
  echo "PIPELINE_EXIT=$PIPE_RET" >> "$ROUND_LOG_DIR/status.txt"

  if [ "$PIPE_RET" -ne 0 ]; then
    echo "ERROR: pipeline failed for $ROUND. See $ROUND_LOG_DIR/pipeline.log"
    exit 1
  fi

  MANIFEST="openevolve/policies/v18_llm_nas/${ROUND}/manifest.psv"

  if [ ! -f "$MANIFEST" ]; then
    echo "ERROR: manifest not found after pipeline: $MANIFEST"
    exit 1
  fi

  N_MANIFEST=$(tail -n +2 "$MANIFEST" | grep -v '^[[:space:]]*$' | wc -l)
  echo "MANIFEST=$MANIFEST" >> "$ROUND_LOG_DIR/status.txt"
  echo "N_MANIFEST=$N_MANIFEST" >> "$ROUND_LOG_DIR/status.txt"

  if [ "$N_MANIFEST" -ne "$NUM_CAND" ]; then
    echo "ERROR: expected $NUM_CAND candidates, but manifest has $N_MANIFEST"
    echo "Manifest:"
    cat "$MANIFEST"
    exit 1
  fi

  echo "Manifest candidate count OK: $N_MANIFEST"

  # 2) 用 GPU0 顺序评估这 5 个候选
  echo "===== EVALUATE $ROUND on GPU0 ====="
  bash openevolve/v18_llm_nas/run_round_gpu0_cand5_seq.sh "$ROUND" \
    > "$ROUND_LOG_DIR/eval.log" 2>&1

  EVAL_RET=$?
  echo "EVAL_EXIT=$EVAL_RET" >> "$ROUND_LOG_DIR/status.txt"

  if [ "$EVAL_RET" -ne 0 ]; then
    echo "ERROR: eval script returned non-zero for $ROUND. See $ROUND_LOG_DIR/eval.log"
    exit 1
  fi

  # 3) 尝试总结本轮结果，生成下一轮 history
  echo "===== SUMMARIZE $ROUND ====="

  SUMMARY_OK=0

  python openevolve/v18_llm_nas/summarize_round.py "$ROUND" \
    > "$ROUND_LOG_DIR/summarize.log" 2>&1 && SUMMARY_OK=1

  if [ "$SUMMARY_OK" -ne 1 ]; then
    python openevolve/v18_llm_nas/summarize_round.py --round "$ROUND" \
      > "$ROUND_LOG_DIR/summarize.log" 2>&1 && SUMMARY_OK=1
  fi

  echo "SUMMARY_OK=$SUMMARY_OK" >> "$ROUND_LOG_DIR/status.txt"

  # 4) 优先使用可能生成的 augmented history
  NEXT_HISTORY=""

  for cand in \
    "openevolve/v18_llm_nas/${ROUND}_augmented_history.md" \
    "openevolve/v18_llm_nas/${ROUND}_history.md" \
    "openevolve/runs/v18_llm_nas_${ROUND}_gpu0_cand5_seq/augmented_history.md" \
    "openevolve/runs/v18_llm_nas_${ROUND}_gpu0_cand5_seq/summary.md"
  do
    if [ -f "$cand" ]; then
      NEXT_HISTORY="$cand"
      break
    fi
  done

  if [ -n "$NEXT_HISTORY" ]; then
    HISTORY="$NEXT_HISTORY"
    echo "NEXT_HISTORY=$NEXT_HISTORY" >> "$ROUND_LOG_DIR/status.txt"
    echo "Next history: $NEXT_HISTORY"
  else
    echo "WARNING: no next history found. Reusing previous HISTORY=$HISTORY"
    echo "NEXT_HISTORY_REUSED=$HISTORY" >> "$ROUND_LOG_DIR/status.txt"
  fi

  echo "END_TIME=$(date '+%F %T')" >> "$ROUND_LOG_DIR/status.txt"
  echo "===== ROUND DONE: $ROUND ====="
done

echo
echo "===== ALL ${NUM_ROUNDS} ROUNDS DONE ====="
echo "Controller logs: $LOOP_ROOT"
