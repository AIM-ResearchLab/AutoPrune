import importlib.util
import os
import torch


_CACHED_CELL = None
_CACHED_PATH = None


def _load_cell(program_path: str):
    global _CACHED_CELL, _CACHED_PATH

    if _CACHED_CELL is not None and _CACHED_PATH == program_path:
        return _CACHED_CELL

    if not program_path:
        raise RuntimeError("TPC_CELL_PATH is empty.")
    if not os.path.exists(program_path):
        raise RuntimeError(f"TPC_CELL_PATH does not exist: {program_path}")

    spec = importlib.util.spec_from_file_location("tpc_candidate_cell", program_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load TPC cell from {program_path}")

    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    if not hasattr(mod, "select_tokens"):
        raise RuntimeError(f"TPC cell {program_path} has no select_tokens()")

    _CACHED_CELL = mod
    _CACHED_PATH = program_path
    return mod


def _make_grid_positions(n: int, device):
    side = int(torch.ceil(torch.sqrt(torch.tensor(float(n), device=device))).item())
    yy, xx = torch.meshgrid(
        torch.arange(side, device=device),
        torch.arange(side, device=device),
        indexing="ij",
    )
    pos = torch.stack([yy.reshape(-1), xx.reshape(-1)], dim=-1).float()[:n]
    return pos / float(max(side - 1, 1))


@torch.no_grad()
def select_index_masks_with_cell(
    image_features,
    image_embeds,
    text_embeds,
    visual_token_num: int,
    metadata=None,
):
    """
    Args:
        image_features: [B, N, D], projected visual token features
        image_embeds: [B, N, C] or [N, C] or None
        text_embeds: [M, C] or [B, M, C] or None
        visual_token_num: number of tokens to keep

    Returns:
        index_masks: [B, N] bool tensor
    """
    program_path = os.environ.get("TPC_CELL_PATH", "").strip()
    cell = _load_cell(program_path)

    if image_features.dim() != 3:
        raise ValueError(f"image_features must be [B, N, D], got {tuple(image_features.shape)}")

    B, N, _ = image_features.shape
    device = image_features.device
    budget = min(max(int(visual_token_num), 1), int(N))
    positions = _make_grid_positions(N, device)

    index_masks = torch.zeros(B, N, dtype=torch.bool, device=device)

    for b in range(B):
        if image_embeds is None:
            cur_image_embeds = None
        elif image_embeds.dim() == 3:
            cur_image_embeds = image_embeds[b]
        else:
            cur_image_embeds = image_embeds

        if text_embeds is None:
            cur_text_embeds = None
        elif text_embeds.dim() == 3:
            cur_text_embeds = text_embeds[b]
        else:
            cur_text_embeds = text_embeds

        selected = cell.select_tokens(
            image_features[b],
            cur_image_embeds,
            cur_text_embeds,
            positions,
            budget,
            metadata or {},
        )

        if not torch.is_tensor(selected):
            raise RuntimeError("select_tokens() must return a torch.Tensor")

        selected = selected.to(device).long().reshape(-1)
        selected = selected[(selected >= 0) & (selected < N)]
        selected = torch.unique(selected, sorted=False)

        if selected.numel() < budget:
            fill_mask = torch.ones(N, dtype=torch.bool, device=device)
            fill_mask[selected] = False
            fill = torch.where(fill_mask)[0][: budget - selected.numel()]
            selected = torch.cat([selected, fill], dim=0)

        selected = selected[:budget]
        index_masks[b, selected] = True

    return index_masks
