#!/usr/bin/env python3
from __future__ import annotations
import argparse, shutil
from datetime import datetime
from pathlib import Path

FILES = [
    ("cdpruner_policy/__init__.py", "cdpruner_policy/__init__.py"),
    ("cdpruner_policy/atoms.py", "cdpruner_policy/atoms.py"),
    ("cdpruner_policy/executor.py", "cdpruner_policy/executor.py"),
    ("cdpruner_policy/verifier.py", "cdpruner_policy/verifier.py"),
    ("configs/v5_full_token_seed_soft_cdpruner_prior.yaml", "configs/v5_full_token_seed_soft_cdpruner_prior.yaml"),
    ("tools/v5_direct_search.py", "tools/v5_direct_search.py"),
    ("yaml_policy/evaluator_mme_smoke.py", "yaml_policy/evaluator_mme_smoke.py"),
    ("yaml_policy/openevolve_yaml_search/evaluator.py", "yaml_policy/openevolve_yaml_search/evaluator.py"),
    ("openevolve/atom_registry.yaml", "openevolve/atom_registry.yaml"),
    ("openevolve/initial_program.py", "openevolve/initial_program.py"),
    ("openevolve/v5_policy_templates.py", "openevolve/v5_policy_templates.py"),
    ("openevolve/run_v5_full_token_search.sh", "openevolve/run_v5_full_token_search.sh"),
]

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", default=".")
    ap.add_argument("--no-backup", action="store_true")
    args = ap.parse_args()
    src_root = Path(__file__).resolve().parent
    repo = Path(args.repo).resolve()
    backup_root = repo / f".v5_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
    for src_rel, dst_rel in FILES:
        src = src_root / src_rel
        dst = repo / dst_rel
        if not src.exists():
            raise FileNotFoundError(src)
        dst.parent.mkdir(parents=True, exist_ok=True)
        if dst.exists() and not args.no_backup:
            b = backup_root / dst_rel
            b.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, b)
        shutil.copy2(src, dst)
        if dst.suffix in {".py", ".sh"}:
            try:
                dst.chmod(dst.stat().st_mode | 0o111)
            except Exception:
                pass
        print("installed", dst_rel)
    if not args.no_backup:
        print("backup root:", backup_root)
    print("v5 install done")

if __name__ == "__main__":
    main()
