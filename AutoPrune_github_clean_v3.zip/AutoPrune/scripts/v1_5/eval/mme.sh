#!/bin/bash
set -e

CKPT_DIR="${CKPT_DIR:-/path/to/hf_models}"
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../../.." && pwd)"
DATA_DIR="$ROOT/playground/data/eval"

CKPT="llava-v1.5-7b"
SPLIT="llava_mme"

TOKEN=${1}
EXP_NAME="${2:-}"
if [ -n "$EXP_NAME" ]; then
    PARAM="$EXP_NAME"
else
    PARAM="vtn_${TOKEN}"
fi

mkdir -p "./playground/data/eval/MME/answers/${SPLIT}/${CKPT}/${PARAM}"

python -m llava.eval.model_vqa_loader \
    --model-path ${CKPT_DIR}/${CKPT} \
    --question-file ./playground/data/eval/MME/${SPLIT}.jsonl \
    --image-folder ${DATA_DIR}/MME/MME_Benchmark_release_version \
    --answers-file ./playground/data/eval/MME/answers/${SPLIT}/${CKPT}/${PARAM}.jsonl \
    --visual_token_num ${TOKEN} \
    --temperature 0 \
    --conv-mode vicuna_v1

cd ./playground/data/eval/MME

python convert_answer_to_mme.py \
    --experiment ${SPLIT}/${CKPT}/${PARAM}

cd eval_tool

python calculation.py --results_dir answers/${SPLIT}/${CKPT}/${PARAM}
