#!/bin/bash
set -e

TOKEN=${1:?TOKEN required}
bash scripts/v1_5/eval/mme_named.sh "${TOKEN}" vtn_32_v16_best_1405p1568
