#!/bin/bash
set -e

# Force single visible GPU to avoid cuda:0/cuda:k tensor mismatch.
# If EVO_GPU is set, use it as the physical GPU id.
if [ -n "${EVO_GPU:-}" ]; then
    export CUDA_VISIBLE_DEVICES="${EVO_GPU}"
fi
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-unset}"


CKPT_DIR="${CKPT_DIR:-/path/to/hf_models}"
DATA_DIR="${DATA_DIR:-/path/to/eval_data}"

CKPT="llava-v1.5-7b"
SPLIT="llava_mme"

TOKEN=${1:?TOKEN required}
PARAM=${2:-vtn_${TOKEN}}

python -m llava.eval.model_vqa_loader \
    --model-path ${CKPT_DIR}/${CKPT} \
    --question-file ./playground/data/eval/MME/${SPLIT}.jsonl \
    --image-folder ${DATA_DIR}/MME/MME_Benchmark_release_version \
    --answers-file ./playground/data/eval/MME/answers/${SPLIT}/${CKPT}/${PARAM}.jsonl \
    --visual_token_num ${TOKEN} \
    --temperature 0 \
    --conv-mode vicuna_v1

cd ./playground/data/eval/MME

python convert_answer_to_mme.py \
    --experiment ${SPLIT}/${CKPT}/${PARAM}

cd eval_tool

python calculation.py --results_dir answers/${SPLIT}/${CKPT}/${PARAM}
