#!/bin/bash
set -e

CKPT_DIR="${CKPT_DIR:-/path/to/hf_models}"
DATA_DIR="${DATA_DIR:-/path/to/eval_data}"

CKPT="llava-v1.5-7b"
TOKEN=${1:-64}
TAG=${2:-baseline}
QUESTION_FILE=${3:-./playground/data/eval/pope/smoke/llava_pope_test_100.jsonl}

PARAM="${TAG}_vtn_${TOKEN}"
OUT_DIR="./playground/data/eval/pope/answers_tpc_smoke/${CKPT}"
ANS_FILE="${OUT_DIR}/${PARAM}.jsonl"
METRIC_FILE="${OUT_DIR}/${PARAM}_metrics.txt"

mkdir -p "${OUT_DIR}"

echo "========================================"
echo "CKPT=${CKPT}"
echo "TOKEN=${TOKEN}"
echo "TAG=${TAG}"
echo "TPC_USE_CELL=${TPC_USE_CELL:-0}"
echo "TPC_CELL_PATH=${TPC_CELL_PATH:-none}"
echo "QUESTION_FILE=${QUESTION_FILE}"
echo "ANS_FILE=${ANS_FILE}"
echo "METRIC_FILE=${METRIC_FILE}"
echo "========================================"

python -m llava.eval.model_vqa_loader \
    --model-path ${CKPT_DIR}/${CKPT} \
    --question-file ${QUESTION_FILE} \
    --image-folder ${DATA_DIR}/pope/val2014 \
    --answers-file ${ANS_FILE} \
    --visual_token_num ${TOKEN} \
    --temperature 0 \
    --conv-mode vicuna_v1

python llava/eval/eval_pope.py \
    --annotation-dir ${DATA_DIR}/pope/coco \
    --question-file ${QUESTION_FILE} \
    --result-file ${ANS_FILE} \
    | tee ${METRIC_FILE}

echo "Saved answers to: ${ANS_FILE}"
echo "Saved metrics to: ${METRIC_FILE}"
