#    Copyright 2023 Haotian Liu
#
#    Licensed under the Apache License, Version 2.0 (the "License");
#    you may not use this file except in compliance with the License.
#    You may obtain a copy of the License at
#
#        http://www.apache.org/licenses/LICENSE-2.0
#
#    Unless required by applicable law or agreed to in writing, software
#    distributed under the License is distributed on an "AS IS" BASIS,
#    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#    See the License for the specific language governing permissions and
#    limitations under the License.


from abc import ABC, abstractmethod

import torch
import os
from cdpruner_policy import load_policy, CDPrunerPolicyExecutor
from yaml_policy.v14_pipeline.feature_hook import apply_v14_processed_features_if_available
from cdpruner_policy.types import CDPrunerContext
import torch.nn as nn

from .multimodal_encoder.builder import build_vision_tower
from .multimodal_projector.builder import build_vision_projector

from llava.constants import IGNORE_INDEX, IMAGE_TOKEN_INDEX, DEFAULT_IMAGE_PATCH_TOKEN, DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN

from llava.mm_utils import get_anyres_image_grid_shape
import os


class LlavaMetaModel:

    def __init__(self, config, **kwargs):
        super(LlavaMetaModel, self).__init__(config, **kwargs)

        if hasattr(config, "mm_vision_tower"):
            self.vision_tower = build_vision_tower(config, delay_load=True)
            self.mm_projector = build_vision_projector(config)

            if 'unpad' in getattr(config, 'mm_patch_merge_type', ''):
                self.image_newline = nn.Parameter(
                    torch.empty(config.hidden_size, dtype=self.dtype)
                )

    def get_vision_tower(self):
        vision_tower = getattr(self, 'vision_tower', None)
        if type(vision_tower) is list:
            vision_tower = vision_tower[0]
        return vision_tower

    def initialize_vision_modules(self, model_args, fsdp=None):
        vision_tower = model_args.vision_tower
        mm_vision_select_layer = model_args.mm_vision_select_layer
        mm_vision_select_feature = model_args.mm_vision_select_feature
        pretrain_mm_mlp_adapter = model_args.pretrain_mm_mlp_adapter
        mm_patch_merge_type = model_args.mm_patch_merge_type

        self.config.mm_vision_tower = vision_tower

        if self.get_vision_tower() is None:
            vision_tower = build_vision_tower(model_args)

            if fsdp is not None and len(fsdp) > 0:
                self.vision_tower = [vision_tower]
            else:
                self.vision_tower = vision_tower
        else:
            if fsdp is not None and len(fsdp) > 0:
                vision_tower = self.vision_tower[0]
            else:
                vision_tower = self.vision_tower
            vision_tower.load_model()

        self.config.use_mm_proj = True
        self.config.mm_projector_type = getattr(model_args, 'mm_projector_type', 'linear')
        self.config.mm_hidden_size = vision_tower.hidden_size
        self.config.mm_vision_select_layer = mm_vision_select_layer
        self.config.mm_vision_select_feature = mm_vision_select_feature
        self.config.mm_patch_merge_type = mm_patch_merge_type

        if getattr(self, 'mm_projector', None) is None:
            self.mm_projector = build_vision_projector(self.config)

            if 'unpad' in mm_patch_merge_type:
                embed_std = 1 / torch.sqrt(torch.tensor(self.config.hidden_size, dtype=self.dtype))
                self.image_newline = nn.Parameter(
                    torch.randn(self.config.hidden_size, dtype=self.dtype) * embed_std
                )
        else:
            # In case it is frozen by LoRA
            for p in self.mm_projector.parameters():
                p.requires_grad = True

        if pretrain_mm_mlp_adapter is not None:
            mm_projector_weights = torch.load(pretrain_mm_mlp_adapter, map_location='cpu')
            def get_w(weights, keyword):
                return {k.split(keyword + '.')[1]: v for k, v in weights.items() if keyword in k}

            self.mm_projector.load_state_dict(get_w(mm_projector_weights, 'mm_projector'))


def unpad_image(tensor, original_size):
    """
    Unpads a PyTorch tensor of a padded and resized image.

    Args:
    tensor (torch.Tensor): The image tensor, assumed to be in CxHxW format.
    original_size (tuple): The original size of PIL image (width, height).

    Returns:
    torch.Tensor: The unpadded image tensor.
    """
    original_width, original_height = original_size
    current_height, current_width = tensor.shape[1:]

    original_aspect_ratio = original_width / original_height
    current_aspect_ratio = current_width / current_height

    if original_aspect_ratio > current_aspect_ratio:
        scale_factor = current_width / original_width
        new_height = int(original_height * scale_factor)
        padding = (current_height - new_height) // 2
        unpadded_tensor = tensor[:, padding:current_height - padding, :]
    else:
        scale_factor = current_height / original_height
        new_width = int(original_width * scale_factor)
        padding = (current_width - new_width) // 2
        unpadded_tensor = tensor[:, :, padding:current_width - padding]

    return unpadded_tensor


class LlavaMetaForCausalLM(ABC):

    @abstractmethod
    def get_model(self):
        pass

    def get_vision_tower(self):
        return self.get_model().get_vision_tower()

    # [CDPruner] Generate index masks using conditional DPP
    def encode_images(self, images, texts=None):
        image_features, image_embeds, text_embeds = self.get_model().get_vision_tower()(images, texts=texts)
        
        B, N, C = image_features.shape
        device = image_features.device
        index_masks = torch.ones(B, N, dtype=torch.bool, device=device)
        
        image_features = self.get_model().mm_projector(image_features)

        # [UniMerge v17] Universal token merge DSL pre branch.
        # Only active when EVO_UNIMERGE_MODE=pre.
        if os.environ.get("EVO_UNIMERGE_ENABLE", "0") == "1" and os.environ.get("EVO_UNIMERGE_MODE", "pre") == "pre":
            try:
                from openevolve.universal_token_merge.cdpruner_adapter import maybe_apply_universal_merge

                _unimerge_before_n = image_features.shape[1]
                image_features = maybe_apply_universal_merge(image_features)
                _unimerge_after_n = image_features.shape[1]

                index_masks = torch.ones(
                    (image_features.shape[0], image_features.shape[1]),
                    dtype=torch.bool,
                    device=image_features.device,
                )

                if os.environ.get("EVO_UNIMERGE_DEBUG", "0") == "1":
                    print(
                        f"[UniMerge] enabled before={_unimerge_before_n} "
                        f"after={_unimerge_after_n} shape={tuple(image_features.shape)}",
                        flush=True,
                    )

                return image_features, index_masks

            except Exception as e:
                if os.environ.get("EVO_UNIMERGE_STRICT", "0") == "1":
                    raise
                print(f"[UniMerge][fallback] disabled due to error: {repr(e)}", flush=True)

        # ===== Evo-CDPruner YAML policy hook =====
        # This branch is only enabled when EVO_CDPRUNER_ENABLE=1.
        # Otherwise, the original CDPruner logic below remains unchanged.
        if os.environ.get("EVO_CDPRUNER_ENABLE", "0") == "1":
            if os.environ.get("EVO_CDPRUNER_DEBUG", "0") == "1":
                print(f"[EVO_CDPRUNER] enabled policy={os.environ.get('CDPRUNER_POLICY')} visual_token_num={self.visual_token_num}", flush=True)
            policy_path = os.environ.get(
                "CDPRUNER_POLICY",
                "configs/cdpruner_default_policy_v0_5.yaml"
            )

            if (not hasattr(self, "_evo_cdpruner_policy_path")
                    or self._evo_cdpruner_policy_path != policy_path):
                self._evo_cdpruner_policy_path = policy_path
                self._evo_cdpruner_executor = CDPrunerPolicyExecutor(load_policy(policy_path))

            # v6.3: compute native CDPruner default mask before running YAML policy.
            # This mirrors the original CDPruner branch below and stores the mask as teacher signal.
            with torch.no_grad():
                _native_image_normalized = image_features / image_features.norm(dim=-1, keepdim=True)
                _native_image_normalized = _native_image_normalized.float()
                _native_similarity = torch.matmul(
                    _native_image_normalized,
                    _native_image_normalized.transpose(1, 2),
                )

                _native_image_embeds = image_embeds / image_embeds.norm(dim=-1, keepdim=True)
                _native_text_embeds = text_embeds / text_embeds.norm(dim=-1, keepdim=True)
                _native_relevance = torch.matmul(_native_image_embeds, _native_text_embeds.t())
                _native_relevance = (-_native_relevance).mean(dim=-1)
                _native_relevance = (_native_relevance - _native_relevance.min() + 1e-6) / (
                    _native_relevance.max() - _native_relevance.min()
                )

                _native_kernel = (
                    _native_relevance.unsqueeze(2)
                    * _native_similarity
                    * _native_relevance.unsqueeze(1)
                )

                _native_cis = torch.zeros((self.visual_token_num, B, N), device=device)
                _native_di2s = torch.diagonal(_native_kernel, dim1=1, dim2=2).clone()
                _native_select_idx = torch.empty((self.visual_token_num, B), dtype=torch.long, device=device)

                for _native_i in range(self.visual_token_num):
                    _native_j = torch.argmax(_native_di2s, dim=-1)
                    _native_select_idx[_native_i] = _native_j

                    _native_eis = (
                        _native_kernel[torch.arange(B), _native_j]
                        - torch.einsum(
                            'tb,tbn->bn',
                            _native_cis[:_native_i, torch.arange(B), _native_j],
                            _native_cis[:_native_i],
                        )
                    ) / torch.sqrt(_native_di2s[torch.arange(B), _native_j]).unsqueeze(-1)

                    _native_cis[_native_i, :, :] = _native_eis
                    _native_di2s -= torch.square(_native_eis)
                    _native_di2s[torch.arange(B), _native_j] = -float('inf')

                _native_select_idx = torch.sort(_native_select_idx.t()).values
                native_index_masks = torch.zeros(B, N, dtype=torch.bool, device=device)
                native_index_masks.scatter_(1, _native_select_idx, True)

            ctx = CDPrunerContext(
                image_features=image_features,
                image_embeds=image_embeds,
                text_embeds=text_embeds,
                visual_token_budget=int(self.visual_token_num),
                token_positions=None,
                metadata={
                    "texts": texts,
                    "stage": "encode_images",
                    "native_reference_mask": native_index_masks,
                },
            )

            index_masks = self._evo_cdpruner_executor.select(ctx)

            # ===== EVO_MASK_HASH_LOG_BEGIN =====
            try:
                if os.environ.get("EVO_CDPRUNER_MASK_HASH_LOG", "0") == "1":
                    import hashlib as _evo_hashlib
                    import json as _evo_json
                    import time as _evo_time
            
                    _mask_log_path = os.environ.get("EVO_MASK_HASH_LOG", "")
                    _mask_log_n = int(os.environ.get("EVO_MASK_HASH_LOG_N", "100000000"))
                    _mask_log_batch = int(os.environ.get("EVO_MASK_HASH_LOG_BATCH", "1"))
                    _count_attr = "_evo_mask_hash_log_count"
                    _cur_count = int(getattr(self, _count_attr, 0))
            
                    if _cur_count < _mask_log_n:
                        _sel = index_masks.detach().to(torch.bool)
                        if _sel.dim() == 1:
                            _sel = _sel.unsqueeze(0)
            
                        _B = int(_sel.shape[0])
                        _N = int(_sel.shape[-1])
                        _K = int(_sel[0].sum().item()) if _B > 0 else 0
            
                        _ref_tensor = None
                        if isinstance(ctx, dict):
                            for _key in ("reference_score", "reference", "native_reference_score", "reference_mask"):
                                _tmp = ctx.get(_key, None)
                                if _tmp is not None and hasattr(_tmp, "detach"):
                                    _ref_tensor = _tmp.detach()
                                    break
            
                        _ref_mask = None
                        if _ref_tensor is not None:
                            if _ref_tensor.dim() == 1:
                                _ref_tensor = _ref_tensor.unsqueeze(0)
                            if _ref_tensor.shape[-1] == _N:
                                if _ref_tensor.dtype == torch.bool:
                                    _ref_mask = _ref_tensor.to(torch.bool)
                                else:
                                    _topk = max(1, min(_K, _N))
                                    _ref_mask = torch.zeros_like(_sel, dtype=torch.bool)
                                    _idx = torch.topk(_ref_tensor.float(), k=_topk, dim=-1).indices
                                    _ref_mask.scatter_(dim=-1, index=_idx, value=True)
            
                        _rows = []
                        _limit = min(_B, _mask_log_batch)
                        for _b in range(_limit):
                            _sel_idx = torch.nonzero(_sel[_b], as_tuple=False).flatten().detach().cpu().to(torch.int64)
                            _sel_bytes = _sel_idx.numpy().tobytes()
                            _sel_hash = _evo_hashlib.sha1(_sel_bytes).hexdigest()[:16]
            
                            _rec = {
                                "kind": "evo_selected_mask_hash",
                                "time": _evo_time.time(),
                                "batch_index": int(_b),
                                "n_tokens": int(_N),
                                "selected_tokens": int(_sel_idx.numel()),
                                "selected_mask_hash": _sel_hash,
                                "selected_indices_head": [int(x) for x in _sel_idx[:16].tolist()],
                    "selected_indices": [int(x) for x in _sel_idx.tolist()],
                            }
            
                            if _ref_mask is not None and _b < _ref_mask.shape[0]:
                                _ref_idx = torch.nonzero(_ref_mask[_b], as_tuple=False).flatten().detach().cpu().to(torch.int64)
                                _ref_bytes = _ref_idx.numpy().tobytes()
                                _ref_hash = _evo_hashlib.sha1(_ref_bytes).hexdigest()[:16]
                                _overlap_count = int((_sel[_b] & _ref_mask[_b]).sum().item())
                                _denom = max(1, int(_sel_idx.numel()))
                                _rec.update({
                                    "reference_tokens": int(_ref_idx.numel()),
                                    "reference_mask_hash": _ref_hash,
                                    "reference_indices_head": [int(x) for x in _ref_idx[:16].tolist()],
                                    "overlap_with_reference": float(_overlap_count / _denom),
                                    "overlap_count": int(_overlap_count),
                                    "changed_tokens": int(_denom - _overlap_count),
                                })
            
                            _rows.append(_rec)
            
                        if _rows:
                            if _mask_log_path:
                                with open(_mask_log_path, "a", encoding="utf-8") as _f:
                                    for _r in _rows:
                                        _f.write(_evo_json.dumps(_r, ensure_ascii=False) + "\n")
                            else:
                                for _r in _rows:
                                    print("[EVO_MASK_HASH] " + _evo_json.dumps(_r, ensure_ascii=False), flush=True)
            
                            setattr(self, _count_attr, _cur_count + len(_rows))
            except Exception as _e:
                if os.environ.get("EVO_CDPRUNER_MASK_HASH_STRICT", "0") == "1":
                    raise
                if os.environ.get("EVO_CDPRUNER_MASK_HASH_DEBUG", "0") == "1":
                    print(f"[EVO_MASK_HASH_ERROR] {_e}", flush=True)
            # ===== EVO_MASK_HASH_LOG_END =====

            # v14: if policy produced processed visual features [B,K,D],
            # use them directly and return an all-True [B,K] mask so downstream
            # code keeps all processed tokens instead of pruning original [B,N,D].
            image_features, index_masks, _used_v14_processed = apply_v14_processed_features_if_available(
                self._evo_cdpruner_executor,
                image_features,
                index_masks,
            )

            if os.environ.get("EVO_CDPRUNER_DEBUG_MASK", "0") == "1":
                if not hasattr(self, "_evo_cdpruner_debug_mask_count"):
                    self._evo_cdpruner_debug_mask_count = 0
                if self._evo_cdpruner_debug_mask_count < int(os.environ.get("EVO_CDPRUNER_DEBUG_MASK_N", "5")):
                    _idx0 = index_masks[0].nonzero(as_tuple=False).flatten()
                    print(
                        "[EVO_CDPRUNER_MASK] "
                        f"policy={policy_path} "
                        f"mask_sum={index_masks.sum(dim=1).detach().cpu().tolist()} "
                        f"idx0_sum={int(_idx0.sum().detach().cpu())} "
                        f"idx0_first10={_idx0[:10].detach().cpu().tolist()}",
                        flush=True,
                    )
                    self._evo_cdpruner_debug_mask_count += 1

            # [UniMerge v17 hybrid-post] Reuse CDPruner/v16 selected tokens as anchors,
            # then merge residual information from the full token set into these anchors.
            if os.environ.get("EVO_UNIMERGE_ENABLE", "0") == "1" and os.environ.get("EVO_UNIMERGE_MODE", "pre") in {"post_cdpruner", "hybrid_v16_anchor"}:
                try:
                    from openevolve.universal_token_merge.cdpruner_adapter import maybe_apply_universal_merge_with_mask

                    _hybrid_before_n = image_features.shape[1]
                    _hybrid_anchor_n = int(index_masks.sum(dim=1).float().mean().item()) if index_masks is not None else -1

                    image_features, index_masks = maybe_apply_universal_merge_with_mask(
                        image_features,
                        index_masks,
                    )

                    _hybrid_after_n = image_features.shape[1]

                    if os.environ.get("EVO_UNIMERGE_DEBUG", "0") == "1":
                        print(
                            f"[UniMergeHybrid] before={_hybrid_before_n} "
                            f"anchors={_hybrid_anchor_n} after={_hybrid_after_n} "
                            f"shape={tuple(image_features.shape)}",
                            flush=True,
                        )

                except Exception as e:
                    if os.environ.get("EVO_UNIMERGE_STRICT", "0") == "1":
                        raise
                    print(f"[UniMergeHybrid][fallback] disabled due to error: {repr(e)}", flush=True)

            return image_features, index_masks
        # ===== End Evo-CDPruner YAML policy hook =====


        # [TPC-NAS] Use evolved CDPruner Token Pruning Cell if enabled.
        if os.environ.get("TPC_USE_CELL", "0") == "1":
            from tpc_cell_adapter import select_index_masks_with_cell
        
            index_masks = select_index_masks_with_cell(
                image_features=image_features,
                image_embeds=image_embeds,
                text_embeds=text_embeds,
                visual_token_num=self.visual_token_num,
                metadata={"source": "cdpruner_encode_images"},
            )
            # [UniMerge v17 hybrid-post] Reuse CDPruner/v16 selected tokens as anchors,
            # then merge residual information from the full token set into these anchors.
            if os.environ.get("EVO_UNIMERGE_ENABLE", "0") == "1" and os.environ.get("EVO_UNIMERGE_MODE", "pre") in {"post_cdpruner", "hybrid_v16_anchor"}:
                try:
                    from openevolve.universal_token_merge.cdpruner_adapter import maybe_apply_universal_merge_with_mask

                    _hybrid_before_n = image_features.shape[1]
                    _hybrid_anchor_n = int(index_masks.sum(dim=1).float().mean().item()) if index_masks is not None else -1

                    image_features, index_masks = maybe_apply_universal_merge_with_mask(
                        image_features,
                        index_masks,
                    )

                    _hybrid_after_n = image_features.shape[1]

                    if os.environ.get("EVO_UNIMERGE_DEBUG", "0") == "1":
                        print(
                            f"[UniMergeHybrid] before={_hybrid_before_n} "
                            f"anchors={_hybrid_anchor_n} after={_hybrid_after_n} "
                            f"shape={tuple(image_features.shape)}",
                            flush=True,
                        )

                except Exception as e:
                    if os.environ.get("EVO_UNIMERGE_STRICT", "0") == "1":
                        raise
                    print(f"[UniMergeHybrid][fallback] disabled due to error: {repr(e)}", flush=True)

            return image_features, index_masks
        
        # [CDPruner] Calculate cosine similarity
        image_normalized = image_features / image_features.norm(dim=-1, keepdim=True) # (B, N, D)
        image_normalized = image_normalized.float() # (B, N, D)
        similarity = torch.matmul(image_normalized, image_normalized.transpose(1, 2)) # (B, N, N)

        # [CDPruner] Calculate query relevance
        image_embeds = image_embeds / image_embeds.norm(dim=-1, keepdim=True) # (B, N, C)
        text_embeds = text_embeds / text_embeds.norm(dim=-1, keepdim=True) # (M, C)
        relevance = torch.matmul(image_embeds, text_embeds.t()) # (B, N, M)
        relevance = (-relevance).mean(dim=-1) # (B, N)
        relevance = (relevance - relevance.min() + 1e-6) / (relevance.max() - relevance.min()) # (B, N)

        # [CDPruner] Construct kernel matrix
        # You can use an additional hyperparameter theta to control the influence of the relevance score.
        # theta = 0.5
        # alpha = theta / (2 * (1 - theta))
        # relevance = torch.exp(alpha * relevance) # (B, N)
        kernel = relevance.unsqueeze(2) * similarity * relevance.unsqueeze(1) # (B, N, N)

        # [CDPruner] Fast MAP inference of conditional DPP
        cis = torch.zeros((self.visual_token_num, B, N), device=device) # (T, B, N)
        di2s = torch.diagonal(kernel, dim1=1, dim2=2).clone() # (B, N)
        select_idx = torch.empty((self.visual_token_num, B), dtype=torch.long, device=device) # (T, B)
        for i in range(self.visual_token_num):
            j = torch.argmax(di2s, dim=-1)
            select_idx[i] = j

            eis = (kernel[torch.arange(B), j] - torch.einsum('tb,tbn->bn', cis[:i, torch.arange(B), j], cis[:i])) \
                / torch.sqrt(di2s[torch.arange(B), j]).unsqueeze(-1)
            cis[i, :, :] = eis
            di2s -= torch.square(eis)
            di2s[torch.arange(B), j] = -float('inf')
        
        select_idx = torch.sort(select_idx.t()).values # (B, T)
        index_masks = torch.zeros(B, N, dtype=torch.bool, device=device)
        index_masks.scatter_(1, select_idx, True)
        
        return image_features, index_masks

    # [CDPruner] Prune visual tokens according to index masks
    def prepare_inputs_labels_for_multimodal(
        self, input_ids, position_ids, attention_mask, past_key_values, labels,
        images, image_sizes=None, texts=None
    ):
        vision_tower = self.get_vision_tower()
        if vision_tower is None or images is None or input_ids.shape[1] == 1:
            return input_ids, position_ids, attention_mask, past_key_values, None, labels

        # [CDPruner] Prune visual tokens
        if type(images) is list or images.ndim == 5:
            if type(images) is list:
                images = [x.unsqueeze(0) if x.ndim == 3 else x for x in images]
            concat_images = torch.cat([image for image in images], dim=0)
            image_features, index_masks = self.encode_images(concat_images, texts=texts)
            split_sizes = [image.shape[0] for image in images]
            image_features = torch.split(image_features, split_sizes, dim=0)
            index_masks = torch.split(index_masks, split_sizes, dim=0)
            mm_patch_merge_type = getattr(self.config, 'mm_patch_merge_type', 'flat')
            mm_patch_merge_type = mm_patch_merge_type.replace('_unpad', '')
            image_aspect_ratio = getattr(self.config, 'image_aspect_ratio', 'square')
            if mm_patch_merge_type == 'flat':
                image_features = [x.flatten(0, 1) for x in image_features]
                index_masks = [x.flatten(0, 1) for x in index_masks]
                image_features = [x[m] for x, m in zip(image_features, index_masks)]
            elif mm_patch_merge_type.startswith('spatial'):
                new_image_features = []
                for image_idx, (image_feature, index_mask) in enumerate(zip(image_features, index_masks)):
                    if image_feature.shape[0] > 1:
                        base_image_feature = image_feature[0]
                        image_feature = image_feature[1:]
                        base_index_mask = index_mask[0]
                        index_mask = index_mask[1:]
                        height = width = self.get_vision_tower().num_patches_per_side
                        assert height * width == base_image_feature.shape[0]
                        if image_aspect_ratio == 'anyres':
                            num_patch_width, num_patch_height = get_anyres_image_grid_shape(image_sizes[image_idx], self.config.image_grid_pinpoints, self.get_vision_tower().config.image_size)
                            image_feature = image_feature.view(num_patch_height, num_patch_width, height, width, -1)
                            index_mask = index_mask.view(num_patch_height, num_patch_width, height, width)
                        else:
                            raise NotImplementedError
                        if 'unpad' in mm_patch_merge_type:
                            image_feature = image_feature.permute(4, 0, 2, 1, 3).contiguous()
                            image_feature = image_feature.flatten(1, 2).flatten(2, 3)
                            image_feature = unpad_image(image_feature, image_sizes[image_idx])
                            image_feature = torch.cat((
                                image_feature,
                                self.model.image_newline[:, None, None].expand(*image_feature.shape[:-1], 1).to(image_feature.device)
                            ), dim=-1)
                            image_feature = image_feature.flatten(1, 2).transpose(0, 1)
                            index_mask = index_mask.permute(0, 2, 1, 3).contiguous().unsqueeze(0)
                            index_mask = index_mask.flatten(1, 2).flatten(2, 3)
                            index_mask = unpad_image(index_mask, image_sizes[image_idx])
                            index_mask = torch.cat((
                                index_mask,
                                torch.ones(*index_mask.shape[:-1], 1, dtype=torch.bool).to(index_mask.device)
                            ), dim=-1)
                            index_mask = index_mask.flatten(1, 2).squeeze(0)
                            image_feature = image_feature[index_mask]
                        else:
                            image_feature = image_feature.permute(0, 2, 1, 3, 4).contiguous()
                            image_feature = image_feature.flatten(0, 3)
                            index_mask = index_mask.permute(0, 2, 1, 3).contiguous()
                            index_mask = index_mask.flatten(0, 3)
                            image_feature = image_feature[index_mask]
                        base_image_feature = base_image_feature[base_index_mask]
                        image_feature = torch.cat((base_image_feature, image_feature))
                    else:
                        image_feature = image_feature[0]
                        index_mask = index_mask[0]
                        if 'unpad' in mm_patch_merge_type:
                            image_feature = torch.cat((
                                image_feature,
                                self.model.image_newline[None].to(image_feature.device)
                            ), dim=0)
                            index_mask = torch.cat((
                                index_mask,
                                torch.ones(1, dtype=torch.bool).to(index_mask.device)
                            ), dim=0)
                        image_feature = image_feature[index_mask]
                    new_image_features.append(image_feature)
                image_features = new_image_features
            else:
                raise ValueError(f"Unexpected mm_patch_merge_type: {self.config.mm_patch_merge_type}")
        else:
            image_features, index_masks = self.encode_images(images, texts=texts)
            image_features = image_features[index_masks].unsqueeze(0)

        # TODO: image start / end is not implemented here to support pretraining.
        if getattr(self.config, 'tune_mm_mlp_adapter', False) and getattr(self.config, 'mm_use_im_start_end', False):
            raise NotImplementedError

        # Let's just add dummy tensors if they do not exist,
        # it is a headache to deal with None all the time.
        # But it is not ideal, and if you have a better idea,
        # please open an issue / submit a PR, thanks.
        _labels = labels
        _position_ids = position_ids
        _attention_mask = attention_mask
        if attention_mask is None:
            attention_mask = torch.ones_like(input_ids, dtype=torch.bool)
        else:
            attention_mask = attention_mask.bool()
        if position_ids is None:
            position_ids = torch.arange(0, input_ids.shape[1], dtype=torch.long, device=input_ids.device)
        if labels is None:
            labels = torch.full_like(input_ids, IGNORE_INDEX)

        # remove the padding using attention_mask -- FIXME
        _input_ids = input_ids
        input_ids = [cur_input_ids[cur_attention_mask] for cur_input_ids, cur_attention_mask in zip(input_ids, attention_mask)]
        labels = [cur_labels[cur_attention_mask] for cur_labels, cur_attention_mask in zip(labels, attention_mask)]

        new_input_embeds = []
        new_labels = []
        cur_image_idx = 0
        for batch_idx, cur_input_ids in enumerate(input_ids):
            num_images = (cur_input_ids == IMAGE_TOKEN_INDEX).sum()
            if num_images == 0:
                cur_image_features = image_features[cur_image_idx]
                cur_input_embeds_1 = self.get_model().embed_tokens(cur_input_ids)
                cur_input_embeds = torch.cat([cur_input_embeds_1, cur_image_features[0:0]], dim=0)
                new_input_embeds.append(cur_input_embeds)
                new_labels.append(labels[batch_idx])
                cur_image_idx += 1
                continue

            image_token_indices = [-1] + torch.where(cur_input_ids == IMAGE_TOKEN_INDEX)[0].tolist() + [cur_input_ids.shape[0]]
            cur_input_ids_noim = []
            cur_labels = labels[batch_idx]
            cur_labels_noim = []
            for i in range(len(image_token_indices) - 1):
                cur_input_ids_noim.append(cur_input_ids[image_token_indices[i]+1:image_token_indices[i+1]])
                cur_labels_noim.append(cur_labels[image_token_indices[i]+1:image_token_indices[i+1]])
            split_sizes = [x.shape[0] for x in cur_labels_noim]
            cur_input_embeds = self.get_model().embed_tokens(torch.cat(cur_input_ids_noim))
            cur_input_embeds_no_im = torch.split(cur_input_embeds, split_sizes, dim=0)
            cur_new_input_embeds = []
            cur_new_labels = []

            for i in range(num_images + 1):
                cur_new_input_embeds.append(cur_input_embeds_no_im[i])
                cur_new_labels.append(cur_labels_noim[i])
                if i < num_images:
                    cur_image_features = image_features[cur_image_idx]
                    cur_image_idx += 1
                    cur_new_input_embeds.append(cur_image_features)
                    cur_new_labels.append(torch.full((cur_image_features.shape[0],), IGNORE_INDEX, device=cur_labels.device, dtype=cur_labels.dtype))

            cur_new_input_embeds = [x.to(self.device) for x in cur_new_input_embeds]

            cur_new_input_embeds = torch.cat(cur_new_input_embeds)
            cur_new_labels = torch.cat(cur_new_labels)

            new_input_embeds.append(cur_new_input_embeds)
            new_labels.append(cur_new_labels)

        # Truncate sequences to max length as image embeddings can make the sequence longer
        tokenizer_model_max_length = getattr(self.config, 'tokenizer_model_max_length', None)
        if tokenizer_model_max_length is not None:
            new_input_embeds = [x[:tokenizer_model_max_length] for x in new_input_embeds]
            new_labels = [x[:tokenizer_model_max_length] for x in new_labels]

        # Combine them
        max_len = max(x.shape[0] for x in new_input_embeds)
        batch_size = len(new_input_embeds)

        new_input_embeds_padded = []
        new_labels_padded = torch.full((batch_size, max_len), IGNORE_INDEX, dtype=new_labels[0].dtype, device=new_labels[0].device)
        attention_mask = torch.zeros((batch_size, max_len), dtype=attention_mask.dtype, device=attention_mask.device)
        position_ids = torch.zeros((batch_size, max_len), dtype=position_ids.dtype, device=position_ids.device)

        for i, (cur_new_embed, cur_new_labels) in enumerate(zip(new_input_embeds, new_labels)):
            cur_len = cur_new_embed.shape[0]
            if getattr(self.config, 'tokenizer_padding_side', 'right') == "left":
                new_input_embeds_padded.append(torch.cat((
                    torch.zeros((max_len - cur_len, cur_new_embed.shape[1]), dtype=cur_new_embed.dtype, device=cur_new_embed.device),
                    cur_new_embed
                ), dim=0))
                if cur_len > 0:
                    new_labels_padded[i, -cur_len:] = cur_new_labels
                    attention_mask[i, -cur_len:] = True
                    position_ids[i, -cur_len:] = torch.arange(0, cur_len, dtype=position_ids.dtype, device=position_ids.device)
            else:
                new_input_embeds_padded.append(torch.cat((
                    cur_new_embed,
                    torch.zeros((max_len - cur_len, cur_new_embed.shape[1]), dtype=cur_new_embed.dtype, device=cur_new_embed.device)
                ), dim=0))
                if cur_len > 0:
                    new_labels_padded[i, :cur_len] = cur_new_labels
                    attention_mask[i, :cur_len] = True
                    position_ids[i, :cur_len] = torch.arange(0, cur_len, dtype=position_ids.dtype, device=position_ids.device)

        new_input_embeds = torch.stack(new_input_embeds_padded, dim=0)

        if _labels is None:
            new_labels = None
        else:
            new_labels = new_labels_padded

        if _attention_mask is None:
            attention_mask = None
        else:
            attention_mask = attention_mask.to(dtype=_attention_mask.dtype)

        if _position_ids is None:
            position_ids = None

        return None, position_ids, attention_mask, past_key_values, new_input_embeds, new_labels, image_features[0].shape[0]

    def initialize_vision_tokenizer(self, model_args, tokenizer):
        if model_args.mm_use_im_patch_token:
            tokenizer.add_tokens([DEFAULT_IMAGE_PATCH_TOKEN], special_tokens=True)
            self.resize_token_embeddings(len(tokenizer))

        if model_args.mm_use_im_start_end:
            num_new_tokens = tokenizer.add_tokens([DEFAULT_IM_START_TOKEN, DEFAULT_IM_END_TOKEN], special_tokens=True)
            self.resize_token_embeddings(len(tokenizer))

            if num_new_tokens > 0:
                input_embeddings = self.get_input_embeddings().weight.data
                output_embeddings = self.get_output_embeddings().weight.data

                input_embeddings_avg = input_embeddings[:-num_new_tokens].mean(
                    dim=0, keepdim=True)
                output_embeddings_avg = output_embeddings[:-num_new_tokens].mean(
                    dim=0, keepdim=True)

                input_embeddings[-num_new_tokens:] = input_embeddings_avg
                output_embeddings[-num_new_tokens:] = output_embeddings_avg

            if model_args.tune_mm_mlp_adapter:
                for p in self.get_input_embeddings().parameters():
                    p.requires_grad = True
                for p in self.get_output_embeddings().parameters():
                    p.requires_grad = False

            if model_args.pretrain_mm_mlp_adapter:
                mm_projector_weights = torch.load(model_args.pretrain_mm_mlp_adapter, map_location='cpu')
                embed_tokens_weight = mm_projector_weights['model.embed_tokens.weight']
                assert num_new_tokens == 2
                if input_embeddings.shape == embed_tokens_weight.shape:
                    input_embeddings[-num_new_tokens:] = embed_tokens_weight[-num_new_tokens:]
                elif embed_tokens_weight.shape[0] == num_new_tokens:
                    input_embeddings[-num_new_tokens:] = embed_tokens_weight
                else:
                    raise ValueError(f"Unexpected embed_tokens_weight shape. Pretrained: {embed_tokens_weight.shape}. Current: {input_embeddings.shape}. Numer of new tokens: {num_new_tokens}.")
        elif model_args.mm_use_im_patch_token:
            if model_args.tune_mm_mlp_adapter:
                for p in self.get_input_embeddings().parameters():
                    p.requires_grad = False
                for p in self.get_output_embeddings().parameters():
                    p.requires_grad = False
