#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

mkdir -p configs/v18_trust_region/anchors
mkdir -p openevolve/policies/v18_trust_region/merge
mkdir -p openevolve/policies/v18_trust_region/manifests

echo "===== Step 1: generate v18 anchor-edit policies ====="

python - <<'PY'
from pathlib import Path
import copy
import yaml

root = Path("/data/lz/openevolve_pruner/CDPruner")
q0_src = root / "configs/v16_v1_clean_cdpruner_k32_reference_q0.yaml"
best_src = root / "openevolve/runs/v16_cdpruner_seed_full_perception_K32_fullmme/best/best_policy.yaml"

if not q0_src.exists():
    if not best_src.exists():
        raise FileNotFoundError(f"missing both {q0_src} and {best_src}")
    data = yaml.safe_load(best_src.read_text())
    data["policy_name"] = "v16_v1_clean_cdpruner_k32_reference_q0"
    data["name"] = "v16_v1_clean_cdpruner_k32_reference_q0"
    data["keep_tokens"] = 32
    for step in data.get("pipeline", []):
        if step.get("op") == "select" and step.get("name") == "native_reference_residual_exchange_selector":
            params = step.setdefault("params", {})
            params["replace_quota"] = 0
            params["min_reference_keep"] = 32
            params["sort_selected"] = True
    data.setdefault("meta", {})
    data["meta"]["method"] = "v16_v1_clean_cdpruner_k32_reference_q0"
    data["meta"]["base_source"] = "v16_generation0_clean_cdpruner_k32_baseline"
    data["meta"]["expected_perception"] = 1382.8248299319728
    data["meta"]["expected_cognition"] = 304.2857142857143
    q0_src.write_text(yaml.safe_dump(data, sort_keys=False, allow_unicode=True))

base = yaml.safe_load(q0_src.read_text())

out_dir = root / "configs/v18_trust_region/anchors"
out_dir.mkdir(parents=True, exist_ok=True)

def make_anchor(name, replace_quota, min_reference_keep, diversity_lambda=0.12, reference_keep_weight=0.22, candidate_quality_power=1.0):
    d = copy.deepcopy(base)
    d["policy_name"] = name
    d["name"] = name
    d["keep_tokens"] = 32

    for step in d.get("pipeline", []):
        if step.get("op") == "select" and step.get("name") == "native_reference_residual_exchange_selector":
            params = step.setdefault("params", {})
            params["replace_quota"] = int(replace_quota)
            params["min_reference_keep"] = int(min_reference_keep)
            params["diversity_lambda"] = float(diversity_lambda)
            params["reference_keep_weight"] = float(reference_keep_weight)
            params["candidate_quality_power"] = float(candidate_quality_power)
            params["sort_selected"] = True

    d.setdefault("meta", {})
    d["meta"].update({
        "method": "v18_trust_region_anchor_edit",
        "base_source": "v16_v1_clean_cdpruner_k32_reference_q0",
        "replace_quota": int(replace_quota),
        "min_reference_keep": int(min_reference_keep),
        "diversity_lambda": float(diversity_lambda),
        "reference_keep_weight": float(reference_keep_weight),
        "candidate_quality_power": float(candidate_quality_power),
        "expected_initial_perception": 1382.8248299319728,
        "token_budget": 32,
    })

    path = out_dir / f"{name}.yaml"
    path.write_text(yaml.safe_dump(d, sort_keys=False, allow_unicode=True))
    print(path)

# q0: v18 initial, no token-set edit.
make_anchor(
    "v18_anchor_q0_ref32_clean_cdpruner_k32",
    replace_quota=0,
    min_reference_keep=32,
    diversity_lambda=0.12,
    reference_keep_weight=0.22,
    candidate_quality_power=1.0,
)

# q1: only change one token, trust-region.
make_anchor("v18_anchor_q1_ref31_div012_refw022", 1, 31, 0.12, 0.22, 1.0)
make_anchor("v18_anchor_q1_ref31_div008_refw035", 1, 31, 0.08, 0.35, 1.0)
make_anchor("v18_anchor_q1_ref31_div015_refw050", 1, 31, 0.15, 0.50, 1.0)
make_anchor("v18_anchor_q1_ref31_div012_refw070", 1, 31, 0.12, 0.70, 1.0)

# q2: allow two token changes, still constrained.
make_anchor("v18_anchor_q2_ref30_div012_refw022", 2, 30, 0.12, 0.22, 1.0)
make_anchor("v18_anchor_q2_ref30_div008_refw035", 2, 30, 0.08, 0.35, 1.0)
make_anchor("v18_anchor_q2_ref30_div015_refw050", 2, 30, 0.15, 0.50, 1.0)
PY

echo "===== Step 2: generate v18 merge-refinement policies ====="

python - <<'PY'
from pathlib import Path
import copy
import yaml

root = Path("/data/lz/openevolve_pruner/CDPruner")
merge_dir = root / "openevolve/policies/v18_trust_region/merge"
merge_dir.mkdir(parents=True, exist_ok=True)

initial_src = root / "openevolve/policies/v17_formal/v17_cdpruner_anchor_initial.yaml"
res_src = root / "openevolve/policies/v17_formal/candidates/v17_cdpruner_anchor_residual_s005.yaml"

if not initial_src.exists():
    raise FileNotFoundError(initial_src)
if not res_src.exists():
    raise FileNotFoundError(res_src)

# initial merge: no embedding residual.
initial = yaml.safe_load(initial_src.read_text())
initial["policy_name"] = "v18_merge_initial_anchor_only"
initial["name"] = "v18_merge_initial_anchor_only"
initial.setdefault("meta", {})
initial["meta"].update({
    "method": "v18_initial_no_embedding_refinement",
    "expected_initial_perception": 1382.8248299319728,
})
(merge_dir / "v18_merge_initial_anchor_only.yaml").write_text(
    yaml.safe_dump(initial, sort_keys=False, allow_unicode=True)
)
print(merge_dir / "v18_merge_initial_anchor_only.yaml")

res_base = yaml.safe_load(res_src.read_text())

def replace_float_values(obj, old=0.005, new=0.005):
    changed = 0
    if isinstance(obj, dict):
        for k, v in list(obj.items()):
            if isinstance(v, float) and abs(v - old) < 1e-12:
                obj[k] = float(new)
                changed += 1
            else:
                changed += replace_float_values(v, old, new)
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            if isinstance(v, float) and abs(v - old) < 1e-12:
                obj[i] = float(new)
                changed += 1
            else:
                changed += replace_float_values(v, old, new)
    return changed

def make_residual(scale):
    name = f"v18_merge_anchor_residual_s{int(round(scale*10000)):04d}"
    d = copy.deepcopy(res_base)
    d["policy_name"] = name
    d["name"] = name

    changed = replace_float_values(d, old=0.005, new=scale)
    if changed == 0:
        # fallback: patch common keys if the source file uses a different default.
        def patch_common_keys(obj):
            n = 0
            if isinstance(obj, dict):
                for k in list(obj.keys()):
                    if k in {"scale", "residual_scale", "alpha", "merge_scale"} and isinstance(obj[k], (int, float)):
                        obj[k] = float(scale)
                        n += 1
                    else:
                        n += patch_common_keys(obj[k])
            elif isinstance(obj, list):
                for x in obj:
                    n += patch_common_keys(x)
            return n
        changed = patch_common_keys(d)

    d.setdefault("meta", {})
    d["meta"].update({
        "method": "v18_embedding_refinement",
        "embedding_refiner": "anchor_residual",
        "residual_scale": float(scale),
        "base_source": "v17_residual_s005",
    })

    path = merge_dir / f"{name}.yaml"
    path.write_text(yaml.safe_dump(d, sort_keys=False, allow_unicode=True))
    print(path, "changed_fields=", changed)

for s in [0.0035, 0.0040, 0.0045, 0.0050, 0.0055, 0.0060, 0.0065, 0.0070]:
    make_residual(s)
PY

echo "===== Step 3: write v18 two-level wrapper ====="

cat > openevolve/run_with_v18_twolevel_cdpruner_anchor_env.sh <<'BASH2'
#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"

if [ "$#" -lt 3 ]; then
  echo "Usage: $0 <anchor_policy_yaml> <merge_policy_yaml> <command...>"
  exit 1
fi

ANCHOR_POLICY="$1"
MERGE_POLICY="$2"
shift 2

case "$ANCHOR_POLICY" in
  /*) ;;
  *) ANCHOR_POLICY="${CDPRUNER_ROOT}/${ANCHOR_POLICY}" ;;
esac

case "$MERGE_POLICY" in
  /*) ;;
  *) MERGE_POLICY="${CDPRUNER_ROOT}/${MERGE_POLICY}" ;;
esac

if [ ! -f "$ANCHOR_POLICY" ]; then
  echo "ERROR: anchor policy not found: $ANCHOR_POLICY"
  exit 1
fi

if [ ! -f "$MERGE_POLICY" ]; then
  echo "ERROR: merge policy not found: $MERGE_POLICY"
  exit 1
fi

export V16_ANCHOR_POLICY="$ANCHOR_POLICY"

echo "=== v18 two-level trust-region CDPruner anchor ==="
echo "Anchor policy: $ANCHOR_POLICY"
echo "Merge policy: $MERGE_POLICY"
echo "EVO_GPU=${EVO_GPU:-unset}"
echo "EVO_TOKEN=${EVO_TOKEN:-unset}"

exec "${CDPRUNER_ROOT}/openevolve/run_with_v17_cdpruner_anchor_env.sh" "$MERGE_POLICY" "$@"
BASH2

chmod +x openevolve/run_with_v18_twolevel_cdpruner_anchor_env.sh
bash -n openevolve/run_with_v18_twolevel_cdpruner_anchor_env.sh

echo "===== Step 4: write v18 candidate manifest ====="

cat > openevolve/policies/v18_trust_region/manifests/v18_gpu7_seq.tsv <<'TSV'
phasenameanchor_policymerge_policy
initialv18_initial_q0_anchor_onlyconfigs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq0_residual_s0035configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0035.yaml
searchq0_residual_s0040configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0040.yaml
searchq0_residual_s0045configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0045.yaml
searchq0_residual_s0050configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0050.yaml
searchq0_residual_s0055configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0055.yaml
searchq0_residual_s0060configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0060.yaml
searchq0_residual_s0065configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0065.yaml
searchq0_residual_s0070configs/v18_trust_region/anchors/v18_anchor_q0_ref32_clean_cdpruner_k32.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0070.yaml
searchq1_ref31_div012_refw022_onlyconfigs/v18_trust_region/anchors/v18_anchor_q1_ref31_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq1_ref31_div008_refw035_onlyconfigs/v18_trust_region/anchors/v18_anchor_q1_ref31_div008_refw035.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq1_ref31_div015_refw050_onlyconfigs/v18_trust_region/anchors/v18_anchor_q1_ref31_div015_refw050.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq1_ref31_div012_refw070_onlyconfigs/v18_trust_region/anchors/v18_anchor_q1_ref31_div012_refw070.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq2_ref30_div012_refw022_onlyconfigs/v18_trust_region/anchors/v18_anchor_q2_ref30_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq2_ref30_div008_refw035_onlyconfigs/v18_trust_region/anchors/v18_anchor_q2_ref30_div008_refw035.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq2_ref30_div015_refw050_onlyconfigs/v18_trust_region/anchors/v18_anchor_q2_ref30_div015_refw050.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_initial_anchor_only.yaml
searchq1_ref31_div012_refw022_residual_s0045configs/v18_trust_region/anchors/v18_anchor_q1_ref31_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0045.yaml
searchq1_ref31_div012_refw022_residual_s0050configs/v18_trust_region/anchors/v18_anchor_q1_ref31_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0050.yaml
searchq1_ref31_div012_refw022_residual_s0055configs/v18_trust_region/anchors/v18_anchor_q1_ref31_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0055.yaml
searchq2_ref30_div012_refw022_residual_s0040configs/v18_trust_region/anchors/v18_anchor_q2_ref30_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0040.yaml
searchq2_ref30_div012_refw022_residual_s0045configs/v18_trust_region/anchors/v18_anchor_q2_ref30_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0045.yaml
searchq2_ref30_div012_refw022_residual_s0050configs/v18_trust_region/anchors/v18_anchor_q2_ref30_div012_refw022.yamlopenevolve/policies/v18_trust_region/merge/v18_merge_anchor_residual_s0050.yaml
TSV

echo "===== Step 5: write sequential GPU7 runner ====="

cat > openevolve/run_v18_twolevel_initial_and_search_gpu7_seq.sh <<'BASH2'
#!/usr/bin/env bash
set -u

cd /data/lz/openevolve_pruner/CDPruner || exit 1

export PYTHONPATH="/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}"
export EVO_GPU=7
export CUDA_VISIBLE_DEVICES=7
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0
export EVO_UNIMERGE_OUTPUT_MODE=inplace_full

MANIFEST="${1:-openevolve/policies/v18_trust_region/manifests/v18_gpu7_seq.tsv}"
RUN_ROOT="openevolve/runs/v18_twolevel_initial_and_search_gpu7_seq"
mkdir -p "$RUN_ROOT"

run_one() {
  local phase="$1"
  local name="$2"
  local anchor_policy="$3"
  local merge_policy="$4"

  local out_dir="$RUN_ROOT/${phase}_${name}"
  mkdir -p "$out_dir"

  local exp="v18_${phase}_${name}_g7_$(date +%Y%m%d_%H%M%S)"

  {
    echo "PHASE=$phase"
    echo "NAME=$name"
    echo "ANCHOR_POLICY=$anchor_policy"
    echo "MERGE_POLICY=$merge_policy"
    echo "EXP=$exp"
    echo "GPU=7"
    echo "START_TIME=$(date '+%F %T')"
  } > "$out_dir/status.txt"

  rm -f "playground/data/eval/MME/answers/${exp}.jsonl" 2>/dev/null || true
  rm -f "playground/data/eval/MME/answers/${exp}.txt" 2>/dev/null || true

  echo "===== RUN $phase $name on GPU 7 ====="
  echo "ANCHOR=$anchor_policy"
  echo "MERGE=$merge_policy"

  openevolve/run_with_v18_twolevel_cdpruner_anchor_env.sh \
    "$anchor_policy" \
    "$merge_policy" \
    bash scripts/v1_5/eval/mme.sh 32 "$exp" \
    > "$out_dir/mme_full.log" 2>&1

  local ret=$?

  echo "EXIT_CODE=$ret" >> "$out_dir/status.txt"
  echo "END_TIME=$(date '+%F %T')" >> "$out_dir/status.txt"

  grep -n "CDPRUNER_POLICY\|V16 anchor policy\|Anchor policy\|Merge policy\|UniMergeHybridDelta\|UniMergeHybrid\|vtn=\|Traceback\|JSONDecodeError\|===========\|total score:\|score:" "$out_dir/mme_full.log" \
    | tail -280 \
    > "$out_dir/mme_full_score_summary.txt" || true

  if [ "$ret" -eq 0 ]; then
    echo "===== DONE_OK $phase $name ====="
  else
    echo "===== DONE_FAIL $phase $name, see $out_dir/mme_full.log ====="
  fi

  return 0
}

check_initial() {
  local dir="$RUN_ROOT/initial_v18_initial_q0_anchor_only"
  local log="$dir/mme_full.log"

  python - "$log" <<'PY'
import sys, re
from pathlib import Path

log = Path(sys.argv[1])
text = log.read_text(errors="ignore") if log.exists() else ""

totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
vtns = re.findall(r"vtn=(\d+)", text)

if len(totals) < 2:
    print("INITIAL_CHECK_FAIL no MME score found")
    raise SystemExit(2)

perception, cognition = totals[0], totals[1]
vtn = int(vtns[-1]) if vtns else -1

print(f"INITIAL_CHECK vtn={vtn} perception={perception:.6f} cognition={cognition:.6f}")

if vtn != 32:
    print("INITIAL_CHECK_FAIL vtn is not 32")
    raise SystemExit(3)

if abs(perception - 1382.8248299319728) > 2.0:
    print("INITIAL_CHECK_FAIL initial is not aligned with v16 v1 clean baseline")
    raise SystemExit(4)

print("INITIAL_CHECK_OK")
PY
}

if [ ! -f "$MANIFEST" ]; then
  echo "ERROR: manifest not found: $MANIFEST"
  exit 1
fi

echo "===== v18 two-level trust-region sequential search ====="
echo "MANIFEST=$MANIFEST"
echo "RUN_ROOT=$RUN_ROOT"
echo "GPU=7"

tail -n +2 "$MANIFEST" | while IFS=$'\t' read -r phase name anchor_policy merge_policy; do
  if [ -z "${phase:-}" ]; then
    continue
  fi

  if [ "$phase" = "initial" ]; then
    run_one "$phase" "$name" "$anchor_policy" "$merge_policy"

    if ! check_initial; then
      echo "Initial check failed. Stop search."
      exit 2
    fi
  else
    run_one "$phase" "$name" "$anchor_policy" "$merge_policy"
  fi
done

echo "All v18 sequential GPU7 jobs finished."
BASH2

chmod +x openevolve/run_v18_twolevel_initial_and_search_gpu7_seq.sh
bash -n openevolve/run_v18_twolevel_initial_and_search_gpu7_seq.sh

echo "===== Step 6: write summarizer ====="

cat > openevolve/summarize_v18_twolevel.py <<'PY'
from pathlib import Path
import re

root = Path("openevolve/runs/v18_twolevel_initial_and_search_gpu7_seq")
rows = []

for d in sorted(root.iterdir()):
    if not d.is_dir():
        continue

    summary = d / "mme_full_score_summary.txt"
    status = d / "status.txt"

    info = {
        "phase": "",
        "name": d.name,
        "anchor": "",
        "merge": "",
        "exit": "NA",
    }

    if status.exists():
        st = status.read_text(errors="ignore")
        for key, out_key in [
            ("PHASE", "phase"),
            ("NAME", "name"),
            ("ANCHOR_POLICY", "anchor"),
            ("MERGE_POLICY", "merge"),
            ("EXIT_CODE", "exit"),
        ]:
            m = re.findall(rf"{key}=(.*)", st)
            if m:
                info[out_key] = m[-1]

    if not summary.exists():
        rows.append((info, None, None, None, "", "no_summary"))
        continue

    text = summary.read_text(errors="ignore")
    totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
    vtns = re.findall(r"vtn=(\d+)", text)
    vtn = vtns[-1] if vtns else ""

    if len(totals) >= 2:
        p, c = totals[0], totals[1]
        rows.append((info, p, c, p + c, vtn, "ok"))
    else:
        note = "json_error" if "JSONDecodeError" in text else "no_score"
        rows.append((info, None, None, None, vtn, note))

baseline_p = None
baseline_raw = None
for info, p, c, raw, vtn, note in rows:
    if info["phase"] == "initial" and p is not None:
        baseline_p = p
        baseline_raw = raw

print("| Name | Phase | Exit | VTN | Perception | Cognition | Raw | Delta P | Delta Raw | Note | Anchor | Merge |")
print("|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|")

def sort_key(row):
    info, p, c, raw, vtn, note = row
    return (info["phase"] != "initial", -999999 if p is None else -p, info["name"])

for info, p, c, raw, vtn, note in sorted(rows, key=sort_key):
    if p is None:
        print(f"| {info['name']} | {info['phase']} | {info['exit']} | {vtn} |  |  |  |  |  | {note} | `{info['anchor']}` | `{info['merge']}` |")
    else:
        dp = 0.0 if baseline_p is None else p - baseline_p
        dr = 0.0 if baseline_raw is None else raw - baseline_raw
        print(f"| {info['name']} | {info['phase']} | {info['exit']} | {vtn} | {p:.2f} | {c:.2f} | {raw:.2f} | {dp:+.2f} | {dr:+.2f} | {note} | `{info['anchor']}` | `{info['merge']}` |")
PY

echo "===== v18 setup done ====="
