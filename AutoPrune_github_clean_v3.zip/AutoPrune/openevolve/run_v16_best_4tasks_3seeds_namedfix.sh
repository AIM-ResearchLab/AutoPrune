#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_TOKEN}"
export EVO_EVAL_TIMEOUT="${EVO_EVAL_TIMEOUT:-28800}"

LOGDIR="openevolve/runs/v16_best_1405_table_eval_4tasks_3seeds_namedfix"
mkdir -p "$LOGDIR"

GPUS=(2 3 4 6)
SEEDS=(42 43 44)
TASKS=(mmbench mmbench_cn mmvet vizwiz)

JOBS=()
for seed in "${SEEDS[@]}"; do
  for task in "${TASKS[@]}"; do
    JOBS+=("${task}:${seed}")
  done
done

run_one() {
  local gpu="$1"
  local task="$2"
  local seed="$3"

  local script="scripts/v1_5/eval_named/${task}_named.sh"
  local param="vtn_32_v16_best_1405p1568_${task}_seed${seed}"
  local log="${LOGDIR}/${task}_seed${seed}_v16_best.log"

  if [ ! -f "$script" ]; then
    echo "[GPU ${gpu}] missing script: $script" | tee -a "$log"
    return 0
  fi

  echo "=============================="
  echo "[GPU ${gpu}] TASK=${task} SEED=${seed}"
  echo "SCRIPT=${script}"
  echo "PARAM=${param}"
  echo "=============================="

  timeout "${EVO_EVAL_TIMEOUT}" \
    env \
      EVO_GPU="$gpu" \
      EVO_TOKEN="$EVO_TOKEN" \
      EVO_FORCE_FIXED_TOKENS="$EVO_TOKEN" \
      PYTHONHASHSEED="$seed" \
      SEED="$seed" \
      EVAL_SEED="$seed" \
      LLAVA_EVAL_SEED="$seed" \
      openevolve/run_with_v16_best_policy_env.sh \
      bash "$script" "$EVO_TOKEN" "$param" \
    2>&1 | tee "$log" || echo "[GPU ${gpu}] V16_BEST failed: ${task} seed=${seed}" | tee -a "$log"

  echo "[GPU ${gpu}] finished ${task} seed=${seed}" | tee -a "$log"
}

worker() {
  local gpu="$1"
  local worker_id="$2"
  local n_gpus="${#GPUS[@]}"

  echo "[GPU ${gpu}] worker ${worker_id} started"

  for i in "${!JOBS[@]}"; do
    if [ $(( i % n_gpus )) -ne "$worker_id" ]; then
      continue
    fi

    item="${JOBS[$i]}"
    task="${item%%:*}"
    seed="${item##*:}"
    run_one "$gpu" "$task" "$seed"
  done

  echo "[GPU ${gpu}] worker ${worker_id} finished"
}

for idx in "${!GPUS[@]}"; do
  gpu="${GPUS[$idx]}"
  worker "$gpu" "$idx" > "${LOGDIR}/worker_gpu${gpu}.log" 2>&1 &
  echo "started worker gpu=${gpu}, pid=$!"
done

wait

echo "All 4-task 3-seed workers finished."
echo "Logs: $LOGDIR"
