from __future__ import annotations

import ast
import json
import os
import re
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, Dict

import yaml


ROOT = Path("/data/lz/openevolve_pruner/CDPruner")
PYTHON = Path("/data/lz/conda/env/cdpruner/bin/python")


def _extract_first_json(text: str) -> Dict[str, Any]:
    for line in text.splitlines():
        line = line.strip()
        if line.startswith("{") and line.endswith("}"):
            try:
                obj = json.loads(line)
                if isinstance(obj, dict):
                    return obj
            except Exception:
                pass

    m = re.search(r"\{.*\}", text, flags=re.S)
    if m:
        obj = json.loads(m.group(0))
        if isinstance(obj, dict):
            return obj

    raise ValueError("no JSON metrics found")


def _extract_policy_yaml(program_text: str) -> str:
    try:
        tree = ast.parse(program_text)
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "POLICY_YAML":
                        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                            return node.value.value
    except Exception:
        pass

    m = re.search(r"POLICY_YAML\s*=\s*r?([\"']{3})(.*?)\1", program_text, flags=re.S)
    if m:
        return m.group(2)

    return ""


def _read_policy_meta(program_path: str) -> Dict[str, Any]:
    try:
        text = Path(program_path).read_text(encoding="utf-8", errors="ignore")
        yml = _extract_policy_yaml(text)
        obj = yaml.safe_load(yml) if yml else {}
        if not isinstance(obj, dict):
            return {}
        meta = obj.get("meta", {})
        if not isinstance(meta, dict):
            meta = {}
        return {
            "policy_name": obj.get("name") or obj.get("policy_name"),
            "policy_fp": obj.get("policy_fp"),
            "mutation_family": meta.get("mutation_family"),
            "mutation_detail": meta.get("mutation_detail"),
            "base_source": meta.get("base_source"),
            "method": meta.get("method"),
        }
    except Exception as e:
        return {"meta_error": repr(e)}


def _invalid(reason: str, extra: Dict[str, Any] | None = None) -> Dict[str, Any]:
    out = {}
    if extra:
        out.update(extra)
    out.update({
        "valid": 0.0,
        "combined_score": 0.0,
        "objective_score": 0.0,
        "objective": "perception",
        "ood_acc": 0.0,
        "error": reason,
    })
    return out


def _apply_v15_guard(metrics: Dict[str, Any]) -> Dict[str, Any]:
    if float(metrics.get("valid", 0.0) or 0.0) != 1.0:
        return _invalid("v15_invalid_base", metrics)

    selected = float(metrics.get("selected_tokens_avg", -1.0) or -1.0)
    overlap = float(metrics.get("overlap_with_reference_avg", -1.0) or -1.0)
    changed = float(metrics.get("changed_tokens_avg", 999.0) or 999.0)

    min_overlap = float(os.environ.get("EVO_V15_MIN_OVERLAP", "0.90"))
    max_changed = float(os.environ.get("EVO_V15_MAX_CHANGED", "3.0"))

    if abs(selected - 32.0) > 1e-4:
        return _invalid(f"v15_guard_failed:selected_tokens_avg={selected}", metrics)

    if overlap < min_overlap:
        return _invalid(f"v15_guard_failed:overlap={overlap}", metrics)

    if changed > max_changed:
        return _invalid(f"v15_guard_failed:changed={changed}", metrics)

    perception = float(metrics.get("perception", metrics.get("raw_combined_score", 0.0)) or 0.0)
    raw = float(metrics.get("raw_combined_score", metrics.get("mme_combined_score", 0.0)) or 0.0)

    # Critical: v15 optimizes full MME perception.
    metrics["objective"] = "perception"
    metrics["objective_score"] = perception
    metrics["combined_score"] = perception
    metrics["ood_acc"] = perception
    metrics["raw_combined_score"] = raw
    metrics["mme_combined_score"] = float(metrics.get("mme_combined_score", raw) or raw)
    metrics["valid"] = 1.0
    return metrics


def _feedback_path() -> Path:
    return Path(os.environ.get(
        "EVO_V15_FEEDBACK_PATH",
        str(ROOT / "openevolve/runs/v15_full_perception_bandit_K32_fullmme/v15_feedback.jsonl"),
    ))


def _append_feedback(program_path: str, metrics: Dict[str, Any]) -> None:
    meta = _read_policy_meta(program_path)

    row = {
        "time": time.time(),
        "program_path": program_path,
        **meta,
        "valid": metrics.get("valid"),
        "perception": metrics.get("perception"),
        "cognition": metrics.get("cognition"),
        "raw_combined_score": metrics.get("raw_combined_score"),
        "combined_score": metrics.get("combined_score"),
        "objective_score": metrics.get("objective_score"),
        "overlap_with_reference_avg": metrics.get("overlap_with_reference_avg"),
        "changed_tokens_avg": metrics.get("changed_tokens_avg"),
        "selected_tokens_avg": metrics.get("selected_tokens_avg"),
        "selected_score_avg": metrics.get("selected_score_avg"),
        "mask_diag_num_rows": metrics.get("mask_diag_num_rows"),
        "v14_effective_alpha": metrics.get("v14_effective_alpha"),
        "v14_top_merge_neighbors": metrics.get("v14_top_merge_neighbors"),
        "v14_feature_delta_norm_avg": metrics.get("v14_feature_delta_norm_avg"),
        "error": metrics.get("error", ""),
    }

    p = _feedback_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n")


def evaluate(program_path: str) -> Dict[str, Any]:
    program_path = str(program_path)

    gpu = os.environ.get("EVO_GPU", "4")
    token = os.environ.get("EVO_TOKEN", "32")
    script = os.environ.get("EVO_EVAL_SCRIPT", "scripts/v1_5/eval/mme.sh")

    log_dir = ROOT / "openevolve/runs/v15_full_perception_eval_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    eval_log = log_dir / "candidate.log"

    cmd = [
        str(PYTHON),
        str(ROOT / "yaml_policy/openevolve_yaml_search/evaluator.py"),
        program_path,
        "--gpu", str(gpu),
        "--token", str(token),
        "--script", str(script),
        "--log", str(eval_log),
    ]

    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT) + ":" + env.get("PYTHONPATH", "")
    env["EVO_CDPRUNER_ENABLE"] = "1"
    env["EVO_CDPRUNER_V14_ENABLE"] = "1"
    env["EVO_FORCE_FIXED_TOKENS"] = str(token)

    try:
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=int(os.environ.get("EVO_EVAL_TIMEOUT", "7200")),
        )
        text = proc.stdout or ""
        metrics = _extract_first_json(text)
        metrics["candidate_program_path"] = program_path
        metrics["eval_script"] = script
        metrics["gpu"] = str(gpu)
        metrics["token"] = str(token)

        if proc.returncode != 0 and float(metrics.get("valid", 0.0) or 0.0) != 1.0:
            metrics["error"] = metrics.get("error", f"subprocess_returncode={proc.returncode}")

        metrics = _apply_v15_guard(metrics)
        _append_feedback(program_path, metrics)
        return metrics

    except Exception as e:
        metrics = _invalid(repr(e), {
            "candidate_program_path": program_path,
            "eval_script": script,
            "gpu": str(gpu),
            "token": str(token),
        })
        _append_feedback(program_path, metrics)
        return metrics


if __name__ == "__main__":
    if len(sys.argv) < 2:
        raise SystemExit("usage: python openevolve/evaluator_v15_full_perception.py <program.py>")
    result = evaluate(sys.argv[1])
    print(json.dumps(result, indent=2, ensure_ascii=False))
