#!/usr/bin/env bash
set -euo pipefail

ROOT="/data/lz/openevolve_pruner/CDPruner/openevolve"
CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"
PY="/data/lz/conda/env/cdpruner/bin/python"

cd "${CDPRUNER_ROOT}"

if [ ! -x "$PY" ]; then
  echo "ERROR: cdpruner python not found: $PY"
  exit 1
fi

export PATH="/data/lz/conda/env/cdpruner/bin:${PATH}"
export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1
export EVO_V15_FULL_PERCEPTION_BANDIT=0
export EVO_V15_1_FULL_PERCEPTION_MICRO=0
export EVO_V15_2_FULL_PERCEPTION_TARGETED=1
export EVO_V14B_PROCESSING_ONLY=0
export EVO_V14B_STRICT=0
export EVO_V14C_STRICT=1

export EVO_V14C_MIN_OVERLAP=${EVO_V14C_MIN_OVERLAP:-0.85}
export EVO_V14C_MAX_CHANGED=${EVO_V14C_MAX_CHANGED:-5.0}

export EVO_EVAL_SCRIPT=scripts/v1_5/eval/mme.sh
export EVO_GPU="${EVO_GPU:-5}"
export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"
export EVO_OBJECTIVE="${EVO_OBJECTIVE:-perception}"
export EVO_OE_SELECTION_METRIC="${EVO_OE_SELECTION_METRIC:-raw_combined_score}"
export EVO_EVAL_TIMEOUT="${EVO_EVAL_TIMEOUT:-1800}"

export EVO_V4_LLM_PLANNER=1
export EVO_V32_LLM_PLANNER=1
export EVO_V10_PIPELINE_PLANNER=1
export EVO_V4_PLANNER_TEMPERATURE="${EVO_V4_PLANNER_TEMPERATURE:-0.35}"
export EVO_V4_PLANNER_MAX_TOKENS="${EVO_V4_PLANNER_MAX_TOKENS:-4600}"
export EVO_V4_EXPLORATION_RATE="${EVO_V4_EXPLORATION_RATE:-0.25}"
export EVO_V32_EXPLORATION_RATE="${EVO_V32_EXPLORATION_RATE:-0.25}"

export EVO_WORK_DIR="yaml_policy/evo_candidates/v15_2_full_perception_targeted_K${EVO_TOKEN}_fullmme"

OUT="${ROOT}/runs/v15_2_full_perception_targeted_K${EVO_TOKEN}_fullmme"
mkdir -p "${OUT}" "${CDPRUNER_ROOT}/${EVO_WORK_DIR}"

echo "python=$($PY -c 'import sys; print(sys.executable)')"
echo "OUT=${OUT}"
echo "EVO_V14B_PROCESSING_ONLY=${EVO_V14B_PROCESSING_ONLY}"
echo "EVO_V14B_STRICT=${EVO_V14B_STRICT}"
echo "EVO_EVAL_SCRIPT=${EVO_EVAL_SCRIPT}"
echo "EVO_GPU=${EVO_GPU}"
echo "EVO_TOKEN=${EVO_TOKEN}"

"$PY" "${ROOT}/openevolve-run.py" \
  "${ROOT}/initial_program.py" \
  "${ROOT}/evaluator_v15_full_perception.py" \
  --config "${ROOT}/config_yaml_policy.yaml" \
  --output "${OUT}" \
  --iterations "${EVO_ITERATIONS:-40}"

export EVO_V14C_COUPLED_JOINT=0

export EVO_V15_MIN_OVERLAP=${EVO_V15_MIN_OVERLAP:-0.90}

export EVO_V15_MAX_CHANGED=${EVO_V15_MAX_CHANGED:-3.0}

export EVO_V15_FEEDBACK_PATH=${EVO_V15_FEEDBACK_PATH:-/data/lz/openevolve_pruner/CDPruner/openevolve/runs/v15_2_full_perception_targeted_K32_fullmme/v15_feedback.jsonl}

export EVO_V15_ANCHOR_PERCEPTION=${EVO_V15_ANCHOR_PERCEPTION:-1404.9353741496598}

export EVO_V15_ANCHOR_RAW=${EVO_V15_ANCHOR_RAW:-1706.3639455782313}
