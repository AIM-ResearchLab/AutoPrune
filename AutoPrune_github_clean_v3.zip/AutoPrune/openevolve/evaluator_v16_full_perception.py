from __future__ import annotations

import importlib.util
import os
import re
import subprocess
from pathlib import Path
from typing import Dict, Any


ROOT = Path("/data/lz/openevolve_pruner/CDPruner")
DEFAULT_BASELINE_SCORE_CACHE = ROOT / "openevolve/runs/mme_vtn32_cdpruner_clean_score.txt"


def _load_module_from_path(program_path: str):
    path = Path(program_path)
    spec = importlib.util.spec_from_file_location("_v16_candidate_module", str(path))
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot load module from {program_path}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _has_policy_yaml(program_path: str) -> bool:
    try:
        mod = _load_module_from_path(program_path)
        if hasattr(mod, "POLICY_YAML"):
            y = getattr(mod, "POLICY_YAML")
            return isinstance(y, str) and bool(y.strip())
        f = getattr(mod, "get_policy_yaml", None)
        if callable(f):
            y = f()
            return isinstance(y, str) and bool(y.strip())
        return False
    except Exception:
        return False


def _parse_mme_score_text(text: str) -> Dict[str, Any]:
    metrics: Dict[str, Any] = {}

    m = re.search(
        r"=+\s*Perception\s*=+.*?total score:\s*([0-9.]+)",
        text,
        flags=re.S | re.I,
    )
    if m:
        metrics["perception"] = float(m.group(1))

    m = re.search(
        r"=+\s*Cognition\s*=+.*?total score:\s*([0-9.]+)",
        text,
        flags=re.S | re.I,
    )
    if m:
        metrics["cognition"] = float(m.group(1))

    # Parse category scores such as:
    # existence  score: 190.0
    for name, val in re.findall(r"\n\s*([A-Za-z_]+)\s+score:\s*([0-9.]+)", text):
        key = f"mme_{name}"
        metrics[key] = float(val)

    return metrics


def _run_clean_cdpruner_baseline() -> Dict[str, Any]:
    token = str(os.environ.get("EVO_TOKEN", "32"))
    gpu = str(os.environ.get("EVO_GPU", "0"))

    param = os.environ.get("EVO_V16_BASELINE_PARAM", f"vtn_{token}_cdpruner_clean_v16_initial")

    env = os.environ.copy()

    # Remove Evo/YAML policy hooks so that llava runs the clean default CDPruner path.
    for k in [
        "EVO_POLICY_YAML",
        "EVO_POLICY_YAML_PATH",
        "EVO_CANDIDATE_POLICY_YAML",
        "EVO_CANDIDATE_POLICY_PATH",
        "EVO_V14_FEATURE_PROCESSING",
        "EVO_V14_PROCESSING",
        "EVO_V15_FEEDBACK_PATH",
        "EVO_V15_MIN_OVERLAP",
        "EVO_V15_MAX_CHANGED",
        "EVO_V15_ANCHOR_PERCEPTION",
        "EVO_V15_ANCHOR_RAW",
    ]:
        env.pop(k, None)

    env["EVO_GPU"] = gpu
    env["CUDA_VISIBLE_DEVICES"] = gpu

    cmd = [
        "bash",
        "scripts/v1_5/eval/mme_named.sh",
        token,
        param,
    ]

    proc = subprocess.run(
        cmd,
        cwd=str(ROOT),
        env=env,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        timeout=int(os.environ.get("EVO_EVAL_TIMEOUT", "7200")),
    )

    out = proc.stdout or ""
    log_path = ROOT / f"openevolve/runs/mme_{param}_eval_from_v16.log"
    log_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.write_text(out, errors="ignore")

    if proc.returncode != 0:
        return {
            "valid": 0.0,
            "perception": 0.0,
            "cognition": 0.0,
            "combined_score": 0.0,
            "objective": "perception",
            "objective_score": 0.0,
            "ood_acc": 0.0,
            "error": f"v16_clean_baseline_eval_failed_returncode_{proc.returncode}",
            "stdout_path": str(log_path),
        }

    metrics = _parse_mme_score_text(out)
    return _format_clean_metrics(metrics, source=f"run:{param}", stdout_path=str(log_path))


def _format_clean_metrics(metrics: Dict[str, Any], source: str, stdout_path: str = "") -> Dict[str, Any]:
    perception = float(metrics.get("perception", 0.0) or 0.0)
    cognition = float(metrics.get("cognition", 0.0) or 0.0)
    raw = perception + cognition

    if perception <= 0:
        return {
            "valid": 0.0,
            "perception": 0.0,
            "cognition": 0.0,
            "combined_score": 0.0,
            "objective": "perception",
            "objective_score": 0.0,
            "ood_acc": 0.0,
            "error": "v16_clean_baseline_score_parse_failed",
            "source": source,
            "stdout_path": stdout_path,
        }

    out = {
        "valid": 1.0,
        "perception": perception,
        "cognition": cognition,
        "raw_combined_score": raw,
        "mme_combined_score": raw,
        "combined_score": perception,
        "objective": "perception",
        "objective_score": perception,
        "ood_acc": perception,
        "selected_tokens_avg": float(os.environ.get("EVO_TOKEN", "32")),
        "token_budget": float(os.environ.get("EVO_TOKEN", "32")),
        # For clean baseline: no YAML residual exchange relative to teacher mask.
        "overlap_with_reference_avg": 1.0,
        "changed_tokens_avg": 0.0,
        "selected_score_avg": 0.0,
        "v14_feature_delta_norm_avg": 0.0,
        "v14_effective_alpha": 0.0,
        "v14_top_merge_neighbors": 0.0,
        "source": source,
        "stdout_path": stdout_path,
        "error": "",
    }

    # Keep category scores too.
    for k, v in metrics.items():
        if k.startswith("mme_"):
            out[k] = v

    return out


def _eval_clean_cdpruner_from_cache_or_run() -> Dict[str, Any]:
    cache = Path(os.environ.get("EVO_V16_BASELINE_SCORE_CACHE", str(DEFAULT_BASELINE_SCORE_CACHE)))

    if cache.exists():
        text = cache.read_text(errors="ignore")
        metrics = _parse_mme_score_text(text)
        if float(metrics.get("perception", 0.0) or 0.0) > 0:
            return _format_clean_metrics(metrics, source=f"cache:{cache}", stdout_path=str(cache))

    return _run_clean_cdpruner_baseline()


def evaluate(program_path: str) -> Dict[str, Any]:
    """
    v16 evaluator:
    - No POLICY_YAML  -> clean CDPruner K=32 baseline.
    - Has POLICY_YAML -> delegate to v15 full-perception YAML evaluator.
    """
    if not _has_policy_yaml(program_path):
        return _eval_clean_cdpruner_from_cache_or_run()

    from openevolve.evaluator_v15_full_perception import evaluate as eval_v15
    metrics = eval_v15(program_path)

    # v16 objective is still perception only.
    p = float(metrics.get("perception", 0.0) or 0.0)
    metrics["objective"] = "perception"
    metrics["objective_score"] = p
    metrics["combined_score"] = p
    metrics["ood_acc"] = p
    return metrics
