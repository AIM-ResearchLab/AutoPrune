import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import torch
from pathlib import Path
from openevolve.universal_token_merge.schema import load_policy_yaml
from openevolve.universal_token_merge.operators import apply_universal_merge

yaml_path = Path("openevolve/policies/v17_universal_merge_init.yaml")
policy = load_policy_yaml(yaml_path.read_text())

for shape in [(576, 4096), (1, 576, 4096), (2, 576, 4096)]:
    x = torch.randn(*shape, dtype=torch.float16, device="cuda" if torch.cuda.is_available() else "cpu")
    y = apply_universal_merge(x, policy)
    print("input:", tuple(x.shape), "output:", tuple(y.shape))

    if len(shape) == 2:
        assert y.shape == (32, shape[-1])
    else:
        assert y.shape == (shape[0], 32, shape[-1])

print("PASS")
