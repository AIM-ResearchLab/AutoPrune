#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

export PYTHONPATH="/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}"
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0
export EVO_UNIMERGE_OUTPUT_MODE=inplace_full

# 正式 CDPruner anchor initial：当前实测 Perception=1403.87
export CDPRUNER_INITIAL_POLICY="/data/lz/openevolve_pruner/CDPruner/configs/cdpruner_v3_2_perception1378_fixed32.yaml"

RUN_ROOT="openevolve/runs/v17_parallel_full_mme_gpus_2467"
mkdir -p "$RUN_ROOT"

GPUS=(2 4 6 7)

POLICIES=(
  "openevolve/policies/v17_formal/v17_cdpruner_anchor_initial.yaml"
  "openevolve/policies/v17_formal/candidates_exchange/v17_cdpruner_anchor_exchange_q2_a015.yaml"
  "openevolve/policies/v17_formal/candidates_exchange/v17_cdpruner_anchor_exchange_q4_a015.yaml"
  "openevolve/policies/v17_formal/candidates_exchange/v17_cdpruner_anchor_exchange_q8_a020.yaml"
)

run_one() {
  local idx="$1"
  local policy="$2"
  local gpu="${GPUS[$((idx % ${#GPUS[@]}))]}"
  local name
  name="$(basename "$policy" .yaml)"

  local out_dir="$RUN_ROOT/$name"
  mkdir -p "$out_dir"

  echo "===== START $name on GPU $gpu ====="

  (
    export EVO_GPU="$gpu"

    openevolve/run_with_v17_cdpruner_initial_anchor_env.sh \
      "$policy" \
      bash scripts/v1_5/eval/mme.sh 32 "v17_${name}_full_g${gpu}" \
      > "$out_dir/mme_full.log" 2>&1

    grep -n "CDPRUNER_POLICY\|UniMergeHybridDelta\|===========\|total score:\|score:" "$out_dir/mme_full.log" \
      | tail -150 \
      > "$out_dir/mme_full_score_summary.txt"

    echo "===== DONE $name on GPU $gpu ====="
  ) &
}

for i in "${!POLICIES[@]}"; do
  run_one "$i" "${POLICIES[$i]}"
done

wait

echo "All jobs finished."
