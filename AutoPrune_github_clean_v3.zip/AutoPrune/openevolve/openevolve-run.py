#!/usr/bin/env python
"""
Entry point script for local OpenEvolve / GraphIR-Evolve project.

This project keeps OpenEvolve source files directly in the project root, e.g.

    graph_nas/
      cli.py
      controller.py
      database.py
      evaluator.py
      process_parallel.py
      prompt/
      utils/
      graphir.py
      openevolve-run.py

Many internal files import modules as `openevolve.xxx`.
This launcher creates a local package alias named `openevolve` that points to
this project root, so imports such as `openevolve.controller` resolve locally.
"""

import multiprocessing as mp

try:
    mp.set_start_method("spawn", force=True)
except RuntimeError:
    pass

import os
import sys
import types


ROOT = os.path.abspath(os.path.dirname(__file__))
PARENT = os.path.dirname(ROOT)

# Make both current root and parent importable.
for path in (ROOT, PARENT):
    if path not in sys.path:
        sys.path.insert(0, path)


def _install_local_openevolve_alias() -> None:
    """
    Register the current project root as package `openevolve`.

    We intentionally do NOT import local __init__.py here, because some versions
    expect openevolve._version and may fail before the local alias is established.
    """
    pkg = types.ModuleType("openevolve")
    pkg.__file__ = os.path.join(ROOT, "__init__.py")
    pkg.__path__ = [ROOT]
    pkg.__package__ = "openevolve"
    pkg.__version__ = "local"
    sys.modules["openevolve"] = pkg


_install_local_openevolve_alias()

# Import controller through the local alias, then expose OpenEvolve at package level.
# This makes `from openevolve import OpenEvolve` work inside cli.py.
from openevolve.controller import OpenEvolve  # noqa: E402
import openevolve  # noqa: E402

openevolve.OpenEvolve = OpenEvolve

print("ROOT =", ROOT)
print("openevolve alias path =", list(openevolve.__path__))
print("OpenEvolve loaded from =", OpenEvolve.__module__)

from openevolve.cli import main  # noqa: E402


if __name__ == "__main__":
    sys.exit(main())