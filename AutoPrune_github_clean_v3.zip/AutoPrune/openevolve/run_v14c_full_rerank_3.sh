#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

PY=/data/lz/conda/env/cdpruner/bin/python
RUN=openevolve/runs/v14_c_coupled_joint_K32_rawselect
OUT=openevolve/runs/v14_c_coupled_full_rerank_3

mkdir -p "$OUT"

export PYTHONPATH=/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}
export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1
export EVO_FORCE_FIXED_TOKENS=32

export EVO_GPU=${EVO_GPU:-4}
export EVO_TOKEN=${EVO_TOKEN:-32}
export EVO_EVAL_SCRIPT=scripts/v1_5/eval/mme.sh
export EVO_EVAL_TIMEOUT=${EVO_EVAL_TIMEOUT:-7200}

export EVO_V14C_MIN_OVERLAP=${EVO_V14C_MIN_OVERLAP:-0.85}
export EVO_V14C_MAX_CHANGED=${EVO_V14C_MAX_CHANGED:-5.0}

echo "===== Full MME rerank config ====="
echo "RUN=$RUN"
echo "OUT=$OUT"
echo "EVO_GPU=$EVO_GPU"
echo "EVO_TOKEN=$EVO_TOKEN"
echo "EVO_EVAL_SCRIPT=$EVO_EVAL_SCRIPT"
echo "EVO_EVAL_TIMEOUT=$EVO_EVAL_TIMEOUT"
echo

echo "===== 1. Prepare initial seed and smoke best ====="
cp openevolve/initial_program.py "$OUT/initial_seed.py"
cp "$RUN/best/best_program.py" "$OUT/smoke_best.py"

echo "initial_seed=$OUT/initial_seed.py"
echo "smoke_best=$OUT/smoke_best.py"
echo

echo "===== 2. Extract cognition-high candidate from latest checkpoint ====="
"$PY" - <<'PY'
import json
import re
from pathlib import Path

RUN = Path("openevolve/runs/v14_c_coupled_joint_K32_rawselect")
OUT = Path("openevolve/runs/v14_c_coupled_full_rerank_3")
OUT.mkdir(parents=True, exist_ok=True)

ckpts = sorted(
    (RUN / "checkpoints").glob("checkpoint_*"),
    key=lambda p: int(re.search(r"checkpoint_(\d+)", p.name).group(1)) if re.search(r"checkpoint_(\d+)", p.name) else -1,
)
if not ckpts:
    raise SystemExit(f"No checkpoints found under {RUN}/checkpoints")

ckpt = ckpts[-1]
print("latest_checkpoint:", ckpt)

rows = []

def maybe_collect(obj, source):
    if not isinstance(obj, dict):
        return

    metrics = obj.get("metrics")
    if not isinstance(metrics, dict):
        return

    code = None
    for k in ["code", "program", "source", "program_code"]:
        v = obj.get(k)
        if isinstance(v, str) and ("POLICY_YAML" in v or "get_policy_yaml" in v):
            code = v
            break

    if code is None:
        # Some formats store code deeper.
        policy = obj.get("policy")
        if isinstance(policy, dict):
            v = policy.get("__program_code__")
            if isinstance(v, str) and ("POLICY_YAML" in v or "get_policy_yaml" in v):
                code = v

    if code is None:
        return

    try:
        valid = float(metrics.get("valid", 0.0) or 0.0)
        selected = float(metrics.get("selected_tokens_avg", -1.0) or -1.0)
        raw = float(metrics.get("raw_combined_score", metrics.get("mme_combined_score", 0.0)) or 0.0)
        cognition = float(metrics.get("cognition", 0.0) or 0.0)
        perception = float(metrics.get("perception", 0.0) or 0.0)
        overlap = float(metrics.get("overlap_with_reference_avg", -1.0) or -1.0)
        changed = float(metrics.get("changed_tokens_avg", 999.0) or 999.0)
    except Exception:
        return

    if valid != 1.0:
        return
    if abs(selected - 32.0) > 1e-4:
        return

    rows.append({
        "source": str(source),
        "id": obj.get("id"),
        "generation": obj.get("generation"),
        "iteration_found": obj.get("iteration_found"),
        "raw": raw,
        "perception": perception,
        "cognition": cognition,
        "overlap": overlap,
        "changed": changed,
        "code": code,
        "metrics": metrics,
    })

def walk(obj, source):
    if isinstance(obj, dict):
        maybe_collect(obj, source)
        for v in obj.values():
            walk(v, source)
    elif isinstance(obj, list):
        for v in obj:
            walk(v, source)

for p in ckpt.rglob("*.json"):
    try:
        obj = json.loads(p.read_text(encoding="utf-8", errors="ignore"))
    except Exception:
        continue
    walk(obj, p)

if not rows:
    raise SystemExit(f"No program rows with code+metrics found in {ckpt}")

# Prefer the cognition-improved candidate. If multiple candidates have the same cognition,
# pick the one with higher raw, then higher perception.
rows_sorted = sorted(
    rows,
    key=lambda r: (r["cognition"], r["raw"], r["perception"], -r["changed"]),
    reverse=True,
)

best_cog = rows_sorted[0]

cand_path = OUT / "cognition_candidate.py"
cand_path.write_text(best_cog["code"], encoding="utf-8")

meta = {k: v for k, v in best_cog.items() if k != "code"}
(OUT / "cognition_candidate_selection.json").write_text(
    json.dumps(meta, indent=2, ensure_ascii=False),
    encoding="utf-8",
)

print("selected cognition candidate:")
print(json.dumps(meta, indent=2, ensure_ascii=False))
print("written:", cand_path)
PY

echo
echo "===== 3. Sequential full MME evaluation ====="

eval_one () {
  local label="$1"
  local program="$2"
  local json_out="$OUT/${label}.full.metrics.json"
  local txt_out="$OUT/${label}.full.stdout.txt"

  echo
  echo "========== FULL MME: $label =========="
  echo "program=$program"
  echo "json_out=$json_out"
  echo "txt_out=$txt_out"
  date

  "$PY" - "$program" "$json_out" <<'PY' 2>&1 | tee "$txt_out"
import json
import sys
from pathlib import Path

from openevolve.evaluator_v14c_coupled import evaluate

program_path = sys.argv[1]
json_out = Path(sys.argv[2])

metrics = evaluate(program_path)

text = json.dumps(metrics, indent=2, ensure_ascii=False)
print(text)
json_out.write_text(text + "\n", encoding="utf-8")
PY

  # Preserve the evaluator inner log for this candidate if it exists.
  if [ -f openevolve/runs/v14_c_coupled_eval_logs/candidate.log ]; then
    cp openevolve/runs/v14_c_coupled_eval_logs/candidate.log "$OUT/${label}.inner_eval.log" || true
  fi

  echo "finished $label"
  date
}

eval_one "initial_seed" "$OUT/initial_seed.py"
eval_one "smoke_best" "$OUT/smoke_best.py"
eval_one "cognition_candidate" "$OUT/cognition_candidate.py"

echo
echo "===== 4. Build summary ====="
"$PY" - <<'PY'
import json
from pathlib import Path

OUT = Path("openevolve/runs/v14_c_coupled_full_rerank_3")
labels = ["initial_seed", "smoke_best", "cognition_candidate"]

rows = []
for label in labels:
    p = OUT / f"{label}.full.metrics.json"
    if not p.exists():
        rows.append({"label": label, "error": "missing metrics json"})
        continue
    d = json.loads(p.read_text(encoding="utf-8"))
    rows.append({
        "label": label,
        "valid": d.get("valid"),
        "perception": d.get("perception"),
        "cognition": d.get("cognition"),
        "raw": d.get("raw_combined_score", d.get("mme_combined_score")),
        "combined": d.get("combined_score"),
        "overlap": d.get("overlap_with_reference_avg"),
        "changed": d.get("changed_tokens_avg"),
        "selected": d.get("selected_tokens_avg"),
        "delta": d.get("v14_feature_delta_norm_avg"),
        "alpha": d.get("v14_effective_alpha"),
        "top_k": d.get("v14_top_merge_neighbors"),
        "error": d.get("error", ""),
    })

md = []
md.append("| candidate | valid | raw | perception | cognition | overlap | changed | selected | delta | alpha | top_k | error |")
md.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")

for r in rows:
    def fmt(x, nd=4):
        if x is None:
            return ""
        if isinstance(x, str):
            return x
        try:
            return f"{float(x):.{nd}f}"
        except Exception:
            return str(x)

    md.append(
        f"| {r['label']} | {fmt(r.get('valid'), 1)} | {fmt(r.get('raw'))} | "
        f"{fmt(r.get('perception'))} | {fmt(r.get('cognition'))} | "
        f"{fmt(r.get('overlap'))} | {fmt(r.get('changed'))} | {fmt(r.get('selected'), 1)} | "
        f"{fmt(r.get('delta'), 6)} | {fmt(r.get('alpha'))} | {fmt(r.get('top_k'), 0)} | "
        f"{r.get('error','')} |"
    )

summary = "\n".join(md) + "\n"
print(summary)
(OUT / "summary.md").write_text(summary, encoding="utf-8")
(OUT / "summary.json").write_text(json.dumps(rows, indent=2, ensure_ascii=False), encoding="utf-8")

print("summary saved to:", OUT / "summary.md")
PY

echo
echo "===== Done ====="
echo "Outputs:"
echo "  $OUT/initial_seed.full.metrics.json"
echo "  $OUT/smoke_best.full.metrics.json"
echo "  $OUT/cognition_candidate.full.metrics.json"
echo "  $OUT/cognition_candidate_selection.json"
echo "  $OUT/summary.md"
