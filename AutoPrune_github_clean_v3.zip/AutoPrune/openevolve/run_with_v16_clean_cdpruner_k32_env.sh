#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"

export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1
export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"

# Critical: v16 initial intentionally uses NO YAML policy.
unset CDPRUNER_POLICY
unset EVO_POLICY_YAML_PATH
unset EVO_CANDIDATE_POLICY_PATH
unset EVO_POLICY_YAML
unset EVO_CANDIDATE_POLICY_YAML

if [ -n "${EVO_GPU:-}" ]; then
  export CUDA_VISIBLE_DEVICES="${EVO_GPU}"
fi

echo "Using clean CDPruner K32 baseline: NO YAML policy"
echo "CDPRUNER_POLICY=${CDPRUNER_POLICY:-unset}"
echo "EVO_POLICY_YAML_PATH=${EVO_POLICY_YAML_PATH:-unset}"
echo "EVO_GPU=${EVO_GPU:-unset}"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-unset}"
echo "EVO_TOKEN=${EVO_TOKEN}"

exec "$@"
