from __future__ import annotations

from typing import Any, Dict, Tuple

from openevolve.v15_full_perception_bandit import (
    _load_anchor_policy,
    _strip_program_fields,
    _ensure_process_node,
    _set_process_semantic,
    _get_process,
    _get_fusion_weights,
    _policy_fingerprint,
    _policy_to_program,
    _feedback_path,
    ANCHOR_FULL_PERCEPTION,
    ANCHOR_FULL_RAW,
)


def _reset_to_anchor() -> Dict[str, Any]:
    policy = _strip_program_fields(_load_anchor_policy())
    _ensure_process_node(policy)

    # Anchor-locked processing.
    _set_process_semantic(
        policy,
        alpha=0.010,
        top_k=1,
        gate=0.65,
        temp=0.07,
    )

    # Anchor-locked fusion weights.
    weights = _get_fusion_weights(policy)
    weights.update({
        "semantic": 0.30,
        "attn": 0.10,
        "spatial": 0.10,
        "redundancy": 0.07,
        "contrast": 0.06,
    })
    return policy


def _get_select_node(policy: Dict[str, Any]) -> Dict[str, Any]:
    for node in policy.get("pipeline", []):
        if isinstance(node, dict) and node.get("op") == "select":
            return node
    raise ValueError("missing select node")


def _set_margin_selector(
    policy: Dict[str, Any],
    *,
    max_replace_quota: int,
    margin_threshold: float,
    diversity_lambda: float,
    reference_keep_weight: float,
    candidate_quality_power: float,
) -> None:
    node = _get_select_node(policy)
    node["name"] = "native_reference_margin_gated_exchange_selector"
    node["inputs"] = {
        "quality": "quality_score",
        "reference": "reference_score",
        "kernel": "sim_kernel",
    }
    node["params"] = {
        "max_replace_quota": int(max_replace_quota),
        "margin_threshold": float(margin_threshold),
        "diversity_lambda": float(diversity_lambda),
        "reference_keep_weight": float(reference_keep_weight),
        "candidate_quality_power": float(candidate_quality_power),
        "sort_selected": True,
    }
    node["output"] = "selected"


def build_v15_3_policy_and_program(
    iteration: int,
    parent: Any = None,
    inspirations: Any = None,
    config: Any = None,
) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
    """
    v15.3: full-MME perception-only margin-gated token exchange search.

    This version does NOT optimize raw/cognition.
    It only tests whether margin-gated exchange can improve perception over the
    current full-MME best anchor.
    """
    iteration = max(1, int(iteration))
    policy = _reset_to_anchor()

    # Phase A: anchor selector weights, only margin changes.
    # max_replace_quota=2 because anchor changed_tokens_avg=2.
    phase_a = [
        {"max_replace_quota": 2, "margin_threshold": -0.020, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
        {"max_replace_quota": 2, "margin_threshold": -0.010, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
        {"max_replace_quota": 2, "margin_threshold":  0.000, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
        {"max_replace_quota": 2, "margin_threshold":  0.005, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
        {"max_replace_quota": 2, "margin_threshold":  0.010, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
        {"max_replace_quota": 2, "margin_threshold":  0.020, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
        {"max_replace_quota": 2, "margin_threshold":  0.040, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
        {"max_replace_quota": 2, "margin_threshold":  0.060, "diversity_lambda": 0.08, "reference_keep_weight": 0.20, "candidate_quality_power": 1.00},
    ]

    # Phase B: combine margin with v15.2 safe selector plateau.
    phase_b = []
    for div in [0.07, 0.09]:
        for refw in [0.20, 0.22]:
            for margin in [0.000, 0.005, 0.010, 0.020]:
                phase_b.append({
                    "max_replace_quota": 2,
                    "margin_threshold": margin,
                    "diversity_lambda": div,
                    "reference_keep_weight": refw,
                    "candidate_quality_power": 1.00,
                })

    plans = phase_a + phase_b
    edit = plans[(iteration - 1) % len(plans)]

    _set_margin_selector(policy, **edit)

    # Keep processing/fusion locked after selector mutation.
    _set_process_semantic(policy, alpha=0.010, top_k=1, gate=0.65, temp=0.07)
    weights = _get_fusion_weights(policy)
    weights.update({
        "semantic": 0.30,
        "attn": 0.10,
        "spatial": 0.10,
        "redundancy": 0.07,
        "contrast": 0.06,
    })

    tag = "_".join(f"{k}{str(v).replace('.', 'p').replace('-', 'm')}" for k, v in edit.items())
    name = f"v15_3_margin_i{iteration:04d}_{tag}"

    policy["policy_name"] = name
    policy["name"] = name
    policy["keep_tokens"] = 32
    policy.setdefault("meta", {})
    policy["meta"].update({
        "method": "v15_3_full_perception_margin_gated_exchange",
        "iteration": iteration,
        "base_source": "anchor",
        "mutation_family": "margin_gated_exchange",
        "mutation_detail": edit,
        "objective": "full_mme_perception_only",
        "anchor_full_perception": ANCHOR_FULL_PERCEPTION,
        "anchor_full_raw": ANCHOR_FULL_RAW,
    })

    policy["policy_fp"] = _policy_fingerprint(policy)
    program = _policy_to_program(policy)
    policy["__program_code__"] = program

    sel = _get_select_node(policy)
    proc = _get_process(policy)
    weights = _get_fusion_weights(policy)

    meta = {
        "name": name,
        "policy_fp": policy["policy_fp"],
        "base_source": "anchor",
        "mutation_family": "margin_gated_exchange",
        "mutation_detail": edit,
        "selector_name": sel.get("name"),
        "selector_params": sel.get("params"),
        "process_name": proc.get("name"),
        "process_params": proc.get("params"),
        "weights": dict(weights),
        "feedback_path": str(_feedback_path()),
    }
    return policy, program, meta
