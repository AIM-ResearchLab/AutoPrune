#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export EVO_GPU=${EVO_GPU:-3}
export EVO_TOKEN=${EVO_TOKEN:-32}
export EVO_FORCE_FIXED_TOKENS=${EVO_FORCE_FIXED_TOKENS:-$EVO_TOKEN}
export EVO_OBJECTIVE=${EVO_OBJECTIVE:-perception}
export EVO_EVAL_SCRIPT=${EVO_EVAL_SCRIPT:-scripts/v1_5/eval/mme_yaml_smoke21.sh}
export EVO_MAX_CANDIDATES=${EVO_MAX_CANDIDATES:-24}
python tools/v5_direct_search.py   --gpu "$EVO_GPU"   --token "$EVO_TOKEN"   --script "$EVO_EVAL_SCRIPT"   --objective "$EVO_OBJECTIVE"   --max-candidates "$EVO_MAX_CANDIDATES"   --out-dir "openevolve/runs/v5_full_token_direct_K${EVO_TOKEN}_$(basename "$EVO_EVAL_SCRIPT" .sh)"
