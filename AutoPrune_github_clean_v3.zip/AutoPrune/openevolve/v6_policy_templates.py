from pathlib import Path

def seed_policy_yaml() -> str:
    p = Path("configs/v6_full_token_seed.yaml")
    return p.read_text() if p.exists() else ""
