#!/usr/bin/env python3
import argparse
import json
import os
import re
import sys
import urllib.request
from pathlib import Path


CLEAN_P = 1382.8248299319728
CLEAN_C = 304.2857142857143

KNOWN_BEST_P = 1406.8248299319728
KNOWN_BEST_C = 296.7857142857143

BALANCED_BEST_P = 1405.9148299319728
BALANCED_BEST_C = 300.0


def read_text(path: Path) -> str:
    return path.read_text(errors="ignore") if path.exists() else ""


def call_openai_compatible(messages, temperature=0.65, max_tokens=5000) -> str:
    api_key = os.environ.get("OPENAI_API_KEY")
    base_url = os.environ.get("OPENAI_BASE_URL", "").rstrip("/")
    model = os.environ.get("OPENAI_MODEL")

    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not set")
    if not base_url:
        raise RuntimeError("OPENAI_BASE_URL is not set")
    if not model:
        raise RuntimeError("OPENAI_MODEL is not set")

    url = base_url + "/chat/completions"
    payload = {
        "model": model,
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }

    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )

    with urllib.request.urlopen(req, timeout=180) as resp:
        obj = json.loads(resp.read().decode("utf-8"))

    return obj["choices"][0]["message"]["content"]


def extract_jsonl(text: str):
    rows = []

    for line in text.splitlines():
        s = line.strip()
        if not s or s.startswith("```"):
            continue
        if s.startswith("{") and s.endswith("}"):
            try:
                rows.append(json.loads(s))
            except Exception:
                pass

    if not rows:
        for m in re.finditer(r"\{[^{}]*\}", text, flags=re.S):
            try:
                rows.append(json.loads(m.group(0)))
            except Exception:
                pass

    return rows


def validate_candidate(x):
    required = [
        "name",
        "replace_quota",
        "min_reference_keep",
        "diversity_lambda",
        "reference_keep_weight",
        "candidate_quality_power",
        "residual_scale",
    ]
    for k in required:
        if k not in x:
            raise ValueError(f"missing key {k}: {x}")

    name = str(x["name"])
    if not re.match(r"^[A-Za-z0-9_]+$", name):
        raise ValueError(f"bad name: {name}")

    rq = int(x["replace_quota"])
    mk = int(x["min_reference_keep"])
    div = float(x["diversity_lambda"])
    refw = float(x["reference_keep_weight"])
    power = float(x["candidate_quality_power"])
    rs = float(x["residual_scale"])

    if not (0 <= rq <= 3):
        raise ValueError(f"replace_quota out of range: {x}")
    if not (29 <= mk <= 32):
        raise ValueError(f"min_reference_keep out of range: {x}")
    if mk < 32 - rq:
        raise ValueError(f"min_reference_keep too small for replace_quota: {x}")
    if not (0.04 <= div <= 0.20):
        raise ValueError(f"diversity_lambda out of range: {x}")
    if not (0.10 <= refw <= 0.80):
        raise ValueError(f"reference_keep_weight out of range: {x}")
    if not (0.70 <= power <= 1.50):
        raise ValueError(f"candidate_quality_power out of range: {x}")
    if not (0.0 <= rs <= 0.006):
        raise ValueError(f"residual_scale out of range: {x}")

    # Strong safety rule: q2/q3 with residual must use weak residual.
    if rq >= 2 and rs > 0.003:
        raise ValueError(f"q2/q3 residual should be weak <=0.003: {x}")

    return {
        "name": name,
        "replace_quota": rq,
        "min_reference_keep": mk,
        "diversity_lambda": div,
        "reference_keep_weight": refw,
        "candidate_quality_power": power,
        "residual_scale": rs,
    }


def build_prompt(history: str, num_candidates: int, round_name: str) -> str:
    return f"""
You are an LLM NAS planner for a constrained DSL-based CDPruner token refinement system.

TRUE BASELINE:
- Clean CDPruner K=32.
- Baseline Perception = {CLEAN_P:.6f}.
- Baseline Cognition = {CLEAN_C:.6f}.
- A candidate is successful if Perception > {CLEAN_P:.6f}.
- Do NOT optimize against 1405 or 1406 as the base. Those are only historical priors.

CURRENT STRONG PRIORS:
- Perception-best prior:
  q2_ref30_div012_refw022_residual_s0020
  Perception ≈ {KNOWN_BEST_P:.2f}, Cognition ≈ {KNOWN_BEST_C:.2f}.
- Balanced/raw prior:
  q2_ref30_div014_refw020_cqp105_rs0000
  Perception ≈ {BALANCED_BEST_P:.2f}, Cognition ≈ {BALANCED_BEST_C:.2f}.
- q2 trust-region token editing is the main source of gain.
- q0 residual alone gives small improvement but limited upper bound.
- q1 and q2_ref31 are usually weak.
- Many similar q2 anchor-only settings may collapse to the same selected token set; avoid producing only near-duplicates.

ROUND OBJECTIVE:
This is {round_name}. Generate {num_candidates} targeted candidates.
Focus on q2_ref30 candidates around the known strong region.
Try to find:
1. Higher Perception than 1406.82 using q2 + weak residual.
2. Better balanced Raw/Cognition using q2 anchor-only.
3. A few diagnostic variants to check whether mask selection changes.

SEARCH SPACE:
Each JSON object must contain:
- name: short unique identifier using only letters, numbers, underscores.
- replace_quota: integer 0, 1, 2, or 3.
- min_reference_keep: integer 29 to 32, with min_reference_keep >= 32 - replace_quota.
- diversity_lambda: float in [0.04, 0.20].
- reference_keep_weight: float in [0.10, 0.80].
- candidate_quality_power: float in [0.70, 1.50].
- residual_scale: float in [0.0, 0.006]. Use 0.0 for no residual.

TARGETED PRIORS FOR THIS ROUND:
Prefer:
- replace_quota = 2.
- min_reference_keep = 30.
- diversity_lambda in [0.12, 0.16].
- reference_keep_weight in [0.17, 0.25].
- candidate_quality_power in [0.95, 1.15].
- residual_scale in [0.0012, 0.0024] for q2 + residual.
- residual_scale = 0.0 for balanced q2 anchor-only.

Avoid:
- q1-only unless one diagnostic is useful.
- q2_ref31, because it behaved like q1 and was weak.
- q3 unless it is a single conservative diagnostic with residual_scale=0.
- residual_scale >= 0.003 for q2/q3.
- q4/q8 aggressive exchange.
- repeating exact candidates from previous summary.


MASK_HASH_ROUND4_FEEDBACK_BEGIN:
Mask/hash feedback from round3:
- Candidate policies collapsed mainly into two selected-mask families.
- Cluster A top hash: 1adc5248df74e163. This family is usually better balanced, with Cognition around 300.
- Cluster B top hash: 570db3d5748f7083. This family often gives high Perception but lower Cognition.
- Do not only generate tiny variants that likely stay inside the same two mask families.
- Include candidates that may create a third selected-mask family by changing diversity_lambda, reference_keep_weight, or candidate_quality_power more meaningfully.
- Still keep replace_quota=2 and min_reference_keep=30 as the main high-performing region.

Round4 targeted focus:
- Generate about 5 candidates around Cluster A. Try weak residual_scale between 0.0006 and 0.0016 while keeping Cognition around 300.
- Generate about 4 candidates around Cluster B. Try improving Cognition with lower residual or anchor-only variants.
- Generate about 2 candidates to probe a new mask family with diversity_lambda outside the current narrow range, for example 0.09-0.11 or 0.17-0.19.
- Generate 1 conservative q3 diagnostic with residual_scale=0.0 only.
- Avoid q1-only and q2_ref31 candidates unless used as a single diagnostic.
- Avoid residual_scale >= 0.003 for q2/q3.
MASK_HASH_ROUND4_FEEDBACK_END

Current feedback / leaderboard:
{history}

OUTPUT RULES:
- Output exactly JSONL.
- One JSON object per line.
- No markdown.
- No explanations.
- Generate diverse candidates, not only tiny floating-point variants that may select the same token set.
""".strip()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", required=True)
    parser.add_argument("--history", required=True)
    parser.add_argument("--num", type=int, default=5)
    parser.add_argument("--out-jsonl", required=True)
    args = parser.parse_args()

    history = read_text(Path(args.history))
    if not history:
        history = "No history file found."

    prompt = build_prompt(history, args.num, args.round)

    messages = [
        {"role": "system", "content": "You are a careful NAS planner. Output valid JSONL only."},
        {"role": "user", "content": prompt},
    ]

    raw = call_openai_compatible(messages)
    rows = extract_jsonl(raw)

    valid = []
    seen = set()

    for x in rows:
        try:
            y = validate_candidate(x)
        except Exception as e:
            print(f"[skip invalid] {e}", file=sys.stderr)
            continue
        if y["name"] in seen:
            print(f"[skip duplicate] {y['name']}", file=sys.stderr)
            continue
        seen.add(y["name"])
        valid.append(y)

    if len(valid) < max(3, args.num // 2):
        print("Raw LLM output:", raw, file=sys.stderr)
        raise RuntimeError(f"Too few valid candidates: {len(valid)}")

    out = Path(args.out_jsonl)
    out.parent.mkdir(parents=True, exist_ok=True)

    with out.open("w") as f:
        for y in valid[:args.num]:
            f.write(json.dumps(y, ensure_ascii=False) + "\n")

    out.with_suffix(".raw.txt").write_text(raw)

    print(f"wrote {out}")
    print(f"num_valid={len(valid[:args.num])}")


if __name__ == "__main__":
    main()
