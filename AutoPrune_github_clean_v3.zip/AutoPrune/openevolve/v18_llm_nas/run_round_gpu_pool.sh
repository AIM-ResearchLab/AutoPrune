#!/usr/bin/env bash
set -u

ROUND="${1:?Usage: $0 <round> <gpu_csv>}"
GPU_CSV="${2:?Usage: $0 <round> <gpu_csv>}"

cd /data/lz/openevolve_pruner/CDPruner || exit 1

export PYTHONPATH="/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}"
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0
export EVO_UNIMERGE_OUTPUT_MODE=inplace_full

export EVO_CDPRUNER_MASK_HASH_LOG=1
export EVO_MASK_HASH_LOG_N="${EVO_MASK_HASH_LOG_N:-100000000}"
export EVO_MASK_HASH_LOG_BATCH="${EVO_MASK_HASH_LOG_BATCH:-1}"
export EVO_CDPRUNER_MASK_HASH_DEBUG="${EVO_CDPRUNER_MASK_HASH_DEBUG:-0}"

MANIFEST="openevolve/policies/v18_llm_nas/${ROUND}/manifest.psv"
RUN_ROOT="openevolve/runs/v18_llm_nas_${ROUND}_gpu7_seq"
mkdir -p "$RUN_ROOT"

if [ ! -f "$MANIFEST" ]; then
  echo "ERROR: manifest not found: $MANIFEST"
  exit 1
fi

IFS=',' read -r -a GPUS <<< "$GPU_CSV"
NGPU="${#GPUS[@]}"

if [ "$NGPU" -lt 1 ]; then
  echo "ERROR: no GPU provided"
  exit 1
fi

run_one() {
  local name="$1"
  local anchor_policy="$2"
  local merge_policy="$3"
  local gpu="$4"

  local out_dir="$RUN_ROOT/$name"
  mkdir -p "$out_dir"

  local exp="v18llm_${ROUND}_${name}_gpu${gpu}_$(date +%Y%m%d_%H%M%S)"
  local mask_hash_log_abs
  mask_hash_log_abs="$(pwd)/$out_dir/mask_hash.jsonl"

  rm -f "$mask_hash_log_abs"

  {
    echo "ROUND=$ROUND"
    echo "NAME=$name"
    echo "ANCHOR_POLICY=$anchor_policy"
    echo "MERGE_POLICY=$merge_policy"
    echo "EXP=$exp"
    echo "GPU=$gpu"
    echo "MASK_HASH_LOG=$mask_hash_log_abs"
    echo "START_TIME=$(date '+%F %T')"
  } > "$out_dir/status.txt"

  echo "===== RUN ${ROUND}/${name} on GPU ${gpu} ====="
  echo "ANCHOR=$anchor_policy"
  echo "MERGE=$merge_policy"

  CUDA_VISIBLE_DEVICES="$gpu" \
  EVO_GPU="$gpu" \
  EVO_MASK_HASH_LOG="$mask_hash_log_abs" \
  openevolve/run_with_v18_twolevel_cdpruner_anchor_env.sh \
    "$anchor_policy" \
    "$merge_policy" \
    bash scripts/v1_5/eval/mme.sh 32 "$exp" \
    > "$out_dir/mme_full.log" 2>&1

  local ret=$?

  echo "EXIT_CODE=$ret" >> "$out_dir/status.txt"
  echo "END_TIME=$(date '+%F %T')" >> "$out_dir/status.txt"

  grep -n "CDPRUNER_POLICY\|V16 anchor policy\|Anchor policy\|Merge policy\|EVO_MASK_HASH\|UniMergeHybridDelta\|UniMergeHybrid\|vtn=\|Traceback\|JSONDecodeError\|===========\|total score:\|score:" "$out_dir/mme_full.log" \
    | tail -320 \
    > "$out_dir/mme_full_score_summary.txt" || true

  if [ -f "$mask_hash_log_abs" ]; then
    echo "MASK_HASH_ROWS=$(wc -l < "$mask_hash_log_abs")" >> "$out_dir/status.txt"
  else
    echo "MASK_HASH_ROWS=0" >> "$out_dir/status.txt"
  fi

  if [ "$ret" -eq 0 ]; then
    echo "===== DONE_OK ${ROUND}/${name} on GPU ${gpu} ====="
  else
    echo "===== DONE_FAIL ${ROUND}/${name} on GPU ${gpu} ====="
  fi
}

echo "===== v18 LLM NAS ${ROUND} GPU pool runner ====="
echo "MANIFEST=$MANIFEST"
echo "RUN_ROOT=$RUN_ROOT"
echo "GPUS=$GPU_CSV"

idx=0

tail -n +2 "$MANIFEST" | while IFS='|' read -r name anchor_policy merge_policy; do
  gpu="${GPUS[$((idx % NGPU))]}"
  idx=$((idx + 1))

  run_one "$name" "$anchor_policy" "$merge_policy" "$gpu" &

  while [ "$(jobs -pr | wc -l)" -ge "$NGPU" ]; do
    wait -n
  done
done

wait

echo "All jobs for ${ROUND} finished."
