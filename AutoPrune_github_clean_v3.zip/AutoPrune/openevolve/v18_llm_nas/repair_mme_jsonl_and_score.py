#!/usr/bin/env python3
import argparse
import json
import os
import re
import shutil
import subprocess
from pathlib import Path


def read_status(d: Path):
    info = {}
    p = d / "status.txt"
    if not p.exists():
        return info
    for line in p.read_text(errors="ignore").splitlines():
        if "=" in line:
            k, v = line.split("=", 1)
            info[k.strip()] = v.strip()
    return info


def clean_jsonl(ans: Path):
    if not ans.exists():
        return False, 0, 0

    lines = ans.read_text(errors="ignore").splitlines()
    good = []
    bad = []

    for i, line in enumerate(lines, 1):
        s = line.strip()
        if not s:
            bad.append((i, "EMPTY"))
            continue
        try:
            json.loads(s)
            good.append(s)
        except Exception as e:
            bad.append((i, repr(e)))

    if not bad:
        return False, len(good), 0

    backup = ans.with_suffix(ans.suffix + ".badbak")
    shutil.copy2(ans, backup)
    ans.write_text("\n".join(good) + ("\n" if good else ""))

    return True, len(good), len(bad)


def run_scoring(exp: str, workdir: Path, log_path: Path):
    # The original MME scripts normally run these two steps from playground/data/eval/MME.
    # convert_answer_to_mme.py reads answers/{exp}.jsonl and writes eval_tool/answers/{exp}
    cmd = (
        f"cd {workdir} && "
        f"python convert_answer_to_mme.py --experiment {exp} && "
        f"cd eval_tool && "
        f"python calculation.py --results_dir answers/{exp}"
    )

    with log_path.open("w") as f:
        ret = subprocess.run(cmd, shell=True, stdout=f, stderr=subprocess.STDOUT).returncode

    return ret


def extract_score_summary(log_path: Path, out_path: Path):
    pats = re.compile(r"===========|total score:|score:|Traceback|JSONDecodeError|RuntimeError|ValueError")
    keep = []
    if log_path.exists():
        for i, line in enumerate(log_path.read_text(errors="ignore").splitlines(), 1):
            if pats.search(line):
                keep.append(f"{i}:{line}")
    out_path.write_text("\n".join(keep[-320:]) + ("\n" if keep else ""))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--round", required=True)
    args = parser.parse_args()

    run_root = Path(f"openevolve/runs/v18_llm_nas_{args.round}_gpu7_seq")
    mme_dir = Path("playground/data/eval/MME")

    if not run_root.exists():
        raise FileNotFoundError(run_root)

    for d in sorted(run_root.iterdir()):
        if not d.is_dir():
            continue

        info = read_status(d)
        exp = info.get("EXP", "")
        if not exp:
            continue

        ans = mme_dir / "answers" / f"{exp}.jsonl"
        if not ans.exists():
            print(f"[MISS] {d.name}: no answer file {ans}")
            continue

        changed, good, bad = clean_jsonl(ans)
        print(f"[CHECK] {d.name}: changed={changed}, good={good}, bad={bad}")

        # Re-score all checked files, because some ret=1 may already have complete valid answers.
        score_log = d / "mme_rescore.log"
        ret = run_scoring(exp, mme_dir, score_log)
        extract_score_summary(score_log, d / "mme_full_score_summary.txt")

        with (d / "status.txt").open("a") as f:
            f.write(f"RESCORE_EXIT_CODE={ret}\n")
            f.write(f"JSONL_CLEAN_GOOD={good}\n")
            f.write(f"JSONL_CLEAN_BAD={bad}\n")

        print(f"[RESCORE] {d.name}: ret={ret}, log={score_log}")


if __name__ == "__main__":
    main()
