#!/usr/bin/env python3
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path
from collections import defaultdict


CLEAN_P = 1382.8248299319728
CLEAN_C = 304.2857142857143


def parse_round_from_summary_path(path: Path):
    s = str(path)
    m = re.search(r"v18_llm_nas_(.+?)_gpu7_seq/summary\.md", s)
    return m.group(1) if m else None


def parse_summary(path: Path):
    rows = []
    if not path.exists():
        return rows

    for line in path.read_text(errors="ignore").splitlines():
        if not line.startswith("|"):
            continue
        if "Perception" in line or "---" in line:
            continue

        parts = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(parts) < 6:
            continue

        try:
            name = parts[0]
            p = float(parts[3])
            c = float(parts[4])
            raw = float(parts[5])
            rows.append({
                "name": name,
                "perception": p,
                "cognition": c,
                "raw": raw,
                "line": line,
            })
        except Exception:
            continue

    return rows


def read_specs(round_name):
    spec = Path(f"openevolve/policies/v18_llm_nas/{round_name}/candidates_{round_name}.jsonl")
    out = {}
    if not spec.exists():
        return out

    for line in spec.read_text(errors="ignore").splitlines():
        if not line.strip():
            continue
        try:
            x = json.loads(line)
            out[str(x.get("name"))] = x
        except Exception:
            pass

    return out


def dataset_signature_groups(run_root: Path):
    sig_by_name = {}
    groups = defaultdict(list)

    for p in sorted(run_root.glob("*/mask_hash.jsonl")):
        name = p.parent.name
        hashes = []

        for line in p.read_text(errors="ignore").splitlines():
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            h = obj.get("selected_mask_hash")
            if h:
                hashes.append(h)

        if not hashes:
            continue

        sig = hashlib.sha1("\n".join(hashes).encode()).hexdigest()[:16]
        sig_by_name[name] = sig
        groups[sig].append(name)

    return sig_by_name, groups


def write_augmented_history(history: Path, out_path: Path, next_round: str):
    rows = parse_summary(history)
    rows = sorted(rows, key=lambda x: (-x["perception"], -x["raw"]))

    prev_round = parse_round_from_summary_path(history)
    specs = read_specs(prev_round) if prev_round else {}

    sig_by_name, groups = dataset_signature_groups(history.parent)

    lines = []
    lines.append("# Fresh AutoNAS v2 Augmented History")
    lines.append("")
    lines.append(f"Next round to plan: {next_round}")
    lines.append("")
    lines.append("True baseline:")
    lines.append(f"- clean CDPruner K=32 Perception = {CLEAN_P:.6f}")
    lines.append(f"- clean CDPruner K=32 Cognition = {CLEAN_C:.6f}")
    lines.append("- VTN must remain 32.")
    lines.append("")
    lines.append("Important:")
    lines.append("- This is a fresh automated NAS run.")
    lines.append("- Do not directly copy any manually selected final policy.")
    lines.append("- Learn from the parameter-result table below.")
    lines.append("- The task is token pruning / trust-region token-set editing.")
    lines.append("")

    if rows:
        b = rows[0]
        lines.append("## Previous best")
        lines.append(f"- name: {b['name']}")
        lines.append(f"- perception: {b['perception']:.2f}")
        lines.append(f"- cognition: {b['cognition']:.2f}")
        lines.append(f"- raw: {b['raw']:.2f}")
        lines.append("")

    if rows:
        lines.append("## Parameter-result table")
        lines.append("| Name | P | C | Raw | rq | ref_keep | div | refw | cqp | residual | dataset_sig |")
        lines.append("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")

        for r in rows[:30]:
            name = r["name"]
            sp = specs.get(name, {})
            sig = sig_by_name.get(name, "")
            lines.append(
                f"| {name} | {r['perception']:.2f} | {r['cognition']:.2f} | {r['raw']:.2f} | "
                f"{sp.get('replace_quota','')} | {sp.get('min_reference_keep','')} | "
                f"{sp.get('diversity_lambda','')} | {sp.get('reference_keep_weight','')} | "
                f"{sp.get('candidate_quality_power','')} | {sp.get('residual_scale','')} | {sig} |"
            )
        lines.append("")

    if groups:
        lines.append("## Dataset-level selected-mask signature groups")
        for sig, names in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            lines.append(f"- {sig}: {len(names)} candidates")
            for n in names[:5]:
                lines.append(f"  - {n}")
        lines.append("")

    lines.append("## Planning guidance")
    lines.append("- Candidate succeeds if Perception > 1382.8248.")
    lines.append("- To retest whether the automated loop can reach the 1411 level, do not stop too early.")
    lines.append("- Prefer q2 trust-region token pruning with min_reference_keep=30.")
    lines.append("- If q2 candidates above 1405 appear, exploit around them.")
    lines.append("- Explore diversity_lambda more broadly, especially 0.16-0.22.")
    lines.append("- Explore reference_keep_weight around 0.16-0.24.")
    lines.append("- Explore candidate_quality_power around 0.95-1.15.")
    lines.append("- Include anchor-only candidates with residual_scale=0.0.")
    lines.append("- Include weak residual variants with residual_scale 0.0004-0.0018.")
    lines.append("- Include at most one q3 diagnostic with residual_scale=0.0.")
    lines.append("- Avoid q4/q8 aggressive exchange.")
    lines.append("- Avoid producing many q1-only candidates after q2 is clearly better.")
    lines.append("")
    lines.append("## Original previous summary")
    lines.append(history.read_text(errors="ignore") if history.exists() else "")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines))


def run_cmd(cmd: str, log_path: Path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w") as f:
        p = subprocess.run(cmd, shell=True, stdout=f, stderr=subprocess.STDOUT)
    return p.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prefix", default="fresh2")
    parser.add_argument("--max-rounds", type=int, default=5)
    parser.add_argument("--min-rounds", type=int, default=4)
    parser.add_argument("--num", type=int, default=5)
    parser.add_argument("--history", default="openevolve/v18_llm_nas/fresh/initial_history.md")
    parser.add_argument("--min-improve", type=float, default=0.20)
    parser.add_argument("--patience", type=int, default=2)
    parser.add_argument("--target-p", type=float, default=1411.0)
    args = parser.parse_args()

    history = Path(args.history)
    best_p = CLEAN_P
    no_improve = 0

    print(f"[FreshAutoNAS-v2] prefix={args.prefix}")
    print(f"[FreshAutoNAS-v2] history={history}")
    print(f"[FreshAutoNAS-v2] min_rounds={args.min_rounds}, max_rounds={args.max_rounds}")
    print(f"[FreshAutoNAS-v2] target_p={args.target_p}")

    for i in range(1, args.max_rounds + 1):
        round_name = f"{args.prefix}_round{i}"
        aug_history = Path(f"openevolve/v18_llm_nas/{round_name}_augmented_history.md")
        write_augmented_history(history, aug_history, round_name)

        log_path = Path(f"openevolve/v18_llm_nas/{round_name}_pipeline.log")
        cmd = (
            f"bash openevolve/v18_llm_nas/run_fresh_pipeline_round_v2.sh "
            f"{round_name} {aug_history} {args.num}"
        )

        print(f"[FreshAutoNAS-v2] running {round_name}")
        print(f"[FreshAutoNAS-v2] log={log_path}")
        ret = run_cmd(cmd, log_path)
        print(f"[FreshAutoNAS-v2] {round_name} exit={ret}")

        summary = Path(f"openevolve/runs/v18_llm_nas_{round_name}_gpu7_seq/summary.md")
        rows = parse_summary(summary)

        if not rows:
            print(f"[FreshAutoNAS-v2] no valid rows, stop")
            break

        rows = sorted(rows, key=lambda x: (-x["perception"], -x["raw"]))
        b = rows[0]
        round_best = b["perception"]

        print(
            f"[FreshAutoNAS-v2] {round_name} best={b['name']} "
            f"P={b['perception']:.2f} C={b['cognition']:.2f} Raw={b['raw']:.2f}"
        )

        improve = round_best - best_p
        if improve > args.min_improve:
            best_p = round_best
            no_improve = 0
            print(f"[FreshAutoNAS-v2] improved by {improve:.2f}; best_p={best_p:.2f}")
        else:
            no_improve += 1
            print(f"[FreshAutoNAS-v2] no significant improvement; no_improve={no_improve}")

        history = summary

        if best_p >= args.target_p and i >= args.min_rounds:
            print(f"[FreshAutoNAS-v2] target reached and min_rounds satisfied; stop")
            break

        if i >= args.min_rounds and no_improve >= args.patience:
            print(f"[FreshAutoNAS-v2] patience reached after min_rounds; stop")
            break

    print(f"[FreshAutoNAS-v2] finished best_p={best_p:.2f}")


if __name__ == "__main__":
    main()
