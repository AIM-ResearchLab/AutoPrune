# Fresh AutoNAS Initial History

This is a fresh automated NAS run.

True baseline:
- Method: clean CDPruner K=32
- Perception = 1382.8248299319728
- Cognition = 304.2857142857143
- Raw = 1687.110544217687
- VTN = 32

Goal:
- Search DSL policies that improve Perception over the clean CDPruner K=32 baseline.
- A candidate is successful if Perception > 1382.8248299319728.
- Keep VTN fixed at 32.

No previous LLM-NAS final policy is provided as a prior.
