#!/usr/bin/env bash
set -euo pipefail

ROUND="${1:-round1}"
HISTORY="${2:-openevolve/runs/v18_twolevel_initial_and_search_gpu0_cand5_seq_fixed/summary.md}"
NUM="${3:-5}"

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT"

export PYTHONPATH="$ROOT:${PYTHONPATH:-}"
export EVO_GPU=7
export CUDA_VISIBLE_DEVICES=7
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0
export EVO_UNIMERGE_OUTPUT_MODE=inplace_full

SPEC_DIR="openevolve/policies/v18_llm_nas/${ROUND}"
SPEC_JSONL="${SPEC_DIR}/candidates_${ROUND}.jsonl"
RUN_ROOT="openevolve/runs/v18_llm_nas_${ROUND}_gpu0_cand5_seq"

mkdir -p "$SPEC_DIR"
mkdir -p "$RUN_ROOT"

echo "===== v18 LLM NAS pipeline ====="
echo "ROUND=$ROUND"
echo "HISTORY=$HISTORY"
echo "NUM=$NUM"
echo "OPENAI_BASE_URL=${OPENAI_BASE_URL:-unset}"
echo "OPENAI_MODEL=${OPENAI_MODEL:-unset}"
echo "EVO_GPU=$EVO_GPU"
echo "CUDA_VISIBLE_DEVICES=$CUDA_VISIBLE_DEVICES"
echo "BASELINE=clean_cdpruner_k32_1382.8248"
echo

if [ ! -f "$HISTORY" ]; then
  echo "ERROR: history summary not found: $HISTORY"
  exit 1
fi

for f in \
  openevolve/v18_llm_nas/plan_round.py \
  openevolve/v18_llm_nas/materialize_round.py \
  openevolve/v18_llm_nas/run_round_gpu0_cand5_seq.sh \
  openevolve/v18_llm_nas/summarize_round.py \
  openevolve/run_with_v18_twolevel_cdpruner_anchor_env.sh
do
  if [ ! -f "$f" ]; then
    echo "ERROR: required file missing: $f"
    exit 1
  fi
done

echo "===== Step 1: LLM planner ====="
python openevolve/v18_llm_nas/plan_round.py \
  --round "$ROUND" \
  --history "$HISTORY" \
  --num "$NUM" \
  --out-jsonl "$SPEC_JSONL"

echo
echo "===== Step 2: materialize YAML policies ====="
python openevolve/v18_llm_nas/materialize_round.py \
  --round "$ROUND" \
  --spec-jsonl "$SPEC_JSONL"

echo
echo "===== Step 3: run MME on GPU 0 sequentially ====="
rm -rf "$RUN_ROOT"
mkdir -p "$RUN_ROOT"

bash openevolve/v18_llm_nas/run_round_gpu0_cand5_seq.sh "$ROUND" \
  > "$RUN_ROOT/launcher.log" 2>&1

echo
echo "===== Step 4: summarize ====="
python openevolve/v18_llm_nas/summarize_round.py --round "$ROUND" \
  | tee "$RUN_ROOT/summary.md"

echo
echo "===== Done $ROUND ====="
echo "summary: $RUN_ROOT/summary.md"
