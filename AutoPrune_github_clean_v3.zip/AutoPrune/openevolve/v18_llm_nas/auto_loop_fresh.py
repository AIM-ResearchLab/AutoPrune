#!/usr/bin/env python3
import argparse
import hashlib
import json
import re
import subprocess
from pathlib import Path
from collections import defaultdict


CLEAN_P = 1382.8248299319728
CLEAN_C = 304.2857142857143


def parse_summary(path: Path):
    rows = []
    if not path.exists():
        return rows

    for line in path.read_text(errors="ignore").splitlines():
        if not line.startswith("|"):
            continue
        if "Perception" in line or "---" in line:
            continue

        parts = [x.strip() for x in line.strip().strip("|").split("|")]
        if len(parts) < 6:
            continue

        try:
            name = parts[0]
            p = float(parts[3])
            c = float(parts[4])
            raw = float(parts[5])
            rows.append({
                "name": name,
                "perception": p,
                "cognition": c,
                "raw": raw,
            })
        except Exception:
            continue

    return rows


def dataset_signature_groups(run_root: Path):
    groups = defaultdict(list)

    for p in sorted(run_root.glob("*/mask_hash.jsonl")):
        name = p.parent.name
        hashes = []

        for line in p.read_text(errors="ignore").splitlines():
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except Exception:
                continue
            h = obj.get("selected_mask_hash")
            if h:
                hashes.append(h)

        if not hashes:
            continue

        sig = hashlib.sha1("\n".join(hashes).encode()).hexdigest()[:16]
        groups[sig].append(name)

    return groups


def write_augmented_history(prev_summary: Path, out_path: Path, round_name: str):
    rows = parse_summary(prev_summary)
    rows = sorted(rows, key=lambda x: (-x["perception"], -x["raw"]))

    lines = []
    lines.append("# Fresh AutoNAS Augmented History")
    lines.append("")
    lines.append(f"Round to plan: {round_name}")
    lines.append("")
    lines.append("True baseline:")
    lines.append(f"- clean CDPruner K=32 Perception = {CLEAN_P:.6f}")
    lines.append(f"- clean CDPruner K=32 Cognition = {CLEAN_C:.6f}")
    lines.append("- VTN must remain 32")
    lines.append("")
    lines.append("Important:")
    lines.append("- This is a fresh AutoNAS run.")
    lines.append("- Do not assume or copy any existing manually selected final policy.")
    lines.append("- Use only this history and the DSL constraints.")
    lines.append("")

    if rows:
        best = rows[0]
        lines.append("Previous best parsed from this fresh run:")
        lines.append(f"- name: {best['name']}")
        lines.append(f"- perception: {best['perception']:.2f}")
        lines.append(f"- cognition: {best['cognition']:.2f}")
        lines.append(f"- raw: {best['raw']:.2f}")
        lines.append("")

    run_root = prev_summary.parent
    groups = dataset_signature_groups(run_root)
    if groups:
        lines.append("Dataset-level selected-mask signature groups from previous round:")
        for sig, names in sorted(groups.items(), key=lambda kv: -len(kv[1])):
            lines.append(f"- {sig}: {len(names)} candidates")
            for n in names[:5]:
                lines.append(f"  - {n}")
        lines.append("")

    lines.append("Planner guidance:")
    lines.append("- Candidate is successful if Perception > clean baseline 1382.8248.")
    lines.append("- Prefer trust-region token pruning / token-set editing.")
    lines.append("- Explore q1/q2 early; exploit q2_ref30 if it performs well.")
    lines.append("- Keep replace_quota <= 3.")
    lines.append("- Keep min_reference_keep >= 29.")
    lines.append("- Use residual_scale=0.0 for anchor-only candidates.")
    lines.append("- Use weak residual only for q2/q3: 0.0005~0.003.")
    lines.append("- Avoid q4/q8 aggressive exchange.")
    lines.append("")
    lines.append("Original previous summary:")
    lines.append(prev_summary.read_text(errors="ignore") if prev_summary.exists() else "")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines))


def run_cmd(cmd: str, log_path: Path):
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("w") as f:
        p = subprocess.run(cmd, shell=True, stdout=f, stderr=subprocess.STDOUT)
    return p.returncode


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--prefix", default="fresh0")
    parser.add_argument("--max-rounds", type=int, default=4)
    parser.add_argument("--num", type=int, default=5)
    parser.add_argument("--history", default="openevolve/v18_llm_nas/fresh/initial_history.md")
    parser.add_argument("--min-improve", type=float, default=0.30)
    parser.add_argument("--patience", type=int, default=1)
    parser.add_argument("--stop-p", type=float, default=9999.0)
    args = parser.parse_args()

    history = Path(args.history)

    if not history.exists():
        raise FileNotFoundError(history)

    best_p = CLEAN_P
    initial_rows = parse_summary(history)
    if initial_rows:
        best_p = max(best_p, max(x["perception"] for x in initial_rows))

    no_improve = 0

    print(f"[FreshAutoNAS] prefix={args.prefix}")
    print(f"[FreshAutoNAS] initial_history={history}")
    print(f"[FreshAutoNAS] initial best_p={best_p:.2f}")

    for i in range(1, args.max_rounds + 1):
        round_name = f"{args.prefix}_round{i}"
        aug_history = Path(f"openevolve/v18_llm_nas/{round_name}_augmented_history.md")
        write_augmented_history(history, aug_history, round_name)

        log_path = Path(f"openevolve/v18_llm_nas/{round_name}_pipeline.log")
        cmd = (
            f"bash openevolve/v18_llm_nas/run_fresh_pipeline_round.sh "
            f"{round_name} {aug_history} {args.num}"
        )

        print(f"[FreshAutoNAS] running {round_name}")
        print(f"[FreshAutoNAS] log={log_path}")
        ret = run_cmd(cmd, log_path)
        print(f"[FreshAutoNAS] {round_name} exit={ret}")

        summary = Path(f"openevolve/runs/v18_llm_nas_{round_name}_gpu7_seq/summary.md")
        rows = parse_summary(summary)

        if not rows:
            print(f"[FreshAutoNAS] no valid summary rows for {round_name}; stop")
            break

        round_best = max(x["perception"] for x in rows)
        round_best_row = sorted(rows, key=lambda x: (-x["perception"], -x["raw"]))[0]

        print(
            f"[FreshAutoNAS] {round_name} best="
            f"{round_best_row['name']} P={round_best_row['perception']:.2f} "
            f"C={round_best_row['cognition']:.2f} Raw={round_best_row['raw']:.2f}"
        )

        improve = round_best - best_p
        if improve > args.min_improve:
            best_p = round_best
            no_improve = 0
            print(f"[FreshAutoNAS] improved by {improve:.2f}; best_p={best_p:.2f}")
        else:
            no_improve += 1
            print(f"[FreshAutoNAS] no significant improvement; no_improve={no_improve}")

        history = summary

        if best_p >= args.stop_p:
            print(f"[FreshAutoNAS] stop because best_p >= stop_p")
            break

        if no_improve >= args.patience:
            print(f"[FreshAutoNAS] stop because patience reached")
            break

    print(f"[FreshAutoNAS] finished best_p={best_p:.2f}")


if __name__ == "__main__":
    main()
