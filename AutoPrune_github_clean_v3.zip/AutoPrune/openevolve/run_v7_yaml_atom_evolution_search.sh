#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export EVO_GPU=${EVO_GPU:-3}
export EVO_TOKEN=${EVO_TOKEN:-32}
export EVO_FORCE_FIXED_TOKENS=${EVO_FORCE_FIXED_TOKENS:-$EVO_TOKEN}
export V7_FAMILIES=${V7_FAMILIES:-10}
export V7_VARIANTS_PER_FAMILY=${V7_VARIANTS_PER_FAMILY:-10}
export V7_CHUNKS=${V7_CHUNKS:-0,1,2}
export V7_NUM_CHUNKS=${V7_NUM_CHUNKS:-21}
python tools/v7_yaml_atom_evolution_search.py \
  --gpu "$EVO_GPU" \
  --token "$EVO_TOKEN" \
  --base-script "${EVO_EVAL_SCRIPT:-scripts/v1_5/eval/mme_yaml_smoke21.sh}" \
  --chunks "$V7_CHUNKS" \
  --num-chunks "$V7_NUM_CHUNKS" \
  --families "$V7_FAMILIES" \
  --variants-per-family "$V7_VARIANTS_PER_FAMILY" \
  --out-dir "openevolve/runs/v7_yaml_atom_evolution_K${EVO_TOKEN}_multismoke"
