from __future__ import annotations

import ast
import copy
import hashlib
import json
import math
import os
import random
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml


ROOT = Path("/data/lz/openevolve_pruner/CDPruner")
ANCHOR_PROGRAM = ROOT / "openevolve/initial_program.py"

ANCHOR_FULL_PERCEPTION = float(os.environ.get("EVO_V15_ANCHOR_PERCEPTION", "1404.9353741496598"))
ANCHOR_FULL_RAW = float(os.environ.get("EVO_V15_ANCHOR_RAW", "1706.3639455782313"))

ALLOWED_PROCESS_NAMES = {
    "semantic_gated_residual_merge",
    "similarity_weighted_residual_merge",
    "spatial_local_residual_merge",
    "score_rescale_selected_features",
}

MUTATION_FAMILIES = [
    "selector_local",
    "fusion_local",
    "processing_strength",
    "processing_gate",
    "module_replace",
    "anchor_mix",
]


def _read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="ignore")


def _extract_policy_yaml_from_program_text(text: str) -> str:
    # AST first.
    try:
        tree = ast.parse(text)
        for node in ast.walk(tree):
            if isinstance(node, ast.Assign):
                for target in node.targets:
                    if isinstance(target, ast.Name) and target.id == "POLICY_YAML":
                        if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                            return node.value.value
            if isinstance(node, ast.AnnAssign):
                if isinstance(node.target, ast.Name) and node.target.id == "POLICY_YAML":
                    if isinstance(node.value, ast.Constant) and isinstance(node.value.value, str):
                        return node.value.value
    except Exception:
        pass

    m = re.search(r"POLICY_YAML\s*=\s*r?([\"']{3})(.*?)\1", text, flags=re.S)
    if m:
        return m.group(2)

    # Accept raw YAML as fallback.
    if "pipeline:" in text and ("keep_tokens:" in text or "policy_name:" in text):
        return text

    raise ValueError("cannot extract POLICY_YAML")


def _load_policy_from_program_path(path: Path) -> Dict[str, Any]:
    yml = _extract_policy_yaml_from_program_text(_read_text(path))
    obj = yaml.safe_load(yml)
    if not isinstance(obj, dict):
        raise ValueError(f"invalid policy object from {path}")
    return obj


def _load_anchor_policy() -> Dict[str, Any]:
    return _load_policy_from_program_path(ANCHOR_PROGRAM)


def _extract_parent_policy(parent: Any) -> Optional[Dict[str, Any]]:
    """
    Best-effort extraction from OpenEvolve Program-like objects.
    If unavailable, return None and use anchor.
    """
    candidates = []

    # object attributes
    for attr in ["code", "program", "source", "source_code", "text"]:
        try:
            v = getattr(parent, attr)
            if isinstance(v, str):
                candidates.append(v)
        except Exception:
            pass

    # dict fields
    if isinstance(parent, dict):
        stack = [parent]
        while stack:
            x = stack.pop()
            if isinstance(x, dict):
                for k, v in x.items():
                    if k in {"code", "program", "source", "source_code", "__program_code__"} and isinstance(v, str):
                        candidates.append(v)
                    elif isinstance(v, (dict, list)):
                        stack.append(v)
            elif isinstance(x, list):
                stack.extend(x)

    for text in candidates:
        try:
            yml = _extract_policy_yaml_from_program_text(text)
            obj = yaml.safe_load(yml)
            if isinstance(obj, dict) and "pipeline" in obj:
                return obj
        except Exception:
            continue

    return None


def _strip_program_fields(policy: Dict[str, Any]) -> Dict[str, Any]:
    p = copy.deepcopy(policy)
    p.pop("__program_code__", None)
    return p


def _find_node(pipe: List[Dict[str, Any]], op: str, name: Optional[str] = None) -> Optional[Dict[str, Any]]:
    for node in pipe:
        if not isinstance(node, dict):
            continue
        if node.get("op") != op:
            continue
        if name is not None and node.get("name") != name:
            continue
        return node
    return None


def _ensure_process_node(policy: Dict[str, Any]) -> None:
    pipe = policy.setdefault("pipeline", [])
    pipe[:] = [n for n in pipe if isinstance(n, dict)]

    if _find_node(pipe, "process_tokens") is None:
        pipe.append({
            "op": "process_tokens",
            "name": "semantic_gated_residual_merge",
            "inputs": {
                "features": "image_features",
                "selected": "selected",
                "quality": "quality_score",
                "semantic": "semantic_score",
                "kernel": "sim_kernel",
            },
            "params": {
                "norm_preserve": True,
                "merge_alpha": 0.010,
                "top_merge_neighbors": 1,
                "temperature": 0.07,
                "semantic_gate_threshold": 0.65,
            },
            "output": "processed_features",
        })


def _get_selector(policy: Dict[str, Any]) -> Dict[str, Any]:
    node = _find_node(policy.get("pipeline", []), "select", "native_reference_residual_exchange_selector")
    if node is None:
        raise ValueError("missing native_reference_residual_exchange_selector")
    node.setdefault("params", {})
    return node["params"]


def _get_fusion_weights(policy: Dict[str, Any]) -> Dict[str, float]:
    node = _find_node(policy.get("pipeline", []), "product_fuse_score", "weighted_product_fusion")
    if node is None:
        raise ValueError("missing weighted_product_fusion")
    node.setdefault("params", {})
    node["params"].setdefault("weights", {})
    w = node["params"]["weights"]

    defaults = {
        "semantic": 0.30,
        "attn": 0.10,
        "spatial": 0.10,
        "redundancy": 0.07,
        "contrast": 0.06,
    }
    for k, v in defaults.items():
        try:
            w[k] = float(w.get(k, v))
        except Exception:
            w[k] = v
    return w


def _get_process(policy: Dict[str, Any]) -> Dict[str, Any]:
    _ensure_process_node(policy)
    node = _find_node(policy.get("pipeline", []), "process_tokens")
    if node is None:
        raise ValueError("missing process_tokens")
    node.setdefault("params", {})
    return node


def _clamp(x: Any, lo: float, hi: float) -> float:
    try:
        v = float(x)
    except Exception:
        v = lo
    return max(lo, min(hi, v))


def _clamp_int(x: Any, lo: int, hi: int) -> int:
    try:
        v = int(round(float(x)))
    except Exception:
        v = lo
    return max(lo, min(hi, v))


def _feedback_path() -> Path:
    return Path(os.environ.get(
        "EVO_V15_FEEDBACK_PATH",
        str(ROOT / "openevolve/runs/v15_full_perception_bandit_K32_fullmme/v15_feedback.jsonl"),
    ))


def _read_feedback() -> List[Dict[str, Any]]:
    p = _feedback_path()
    if not p.exists():
        return []
    rows = []
    for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                rows.append(obj)
        except Exception:
            pass
    return rows


def _family_stats(rows: List[Dict[str, Any]]) -> Dict[str, Dict[str, float]]:
    stats = {f: {"n": 0.0, "sum_reward": 0.0, "best": -1e9} for f in MUTATION_FAMILIES}
    for r in rows:
        fam = r.get("mutation_family")
        if fam not in stats:
            continue
        try:
            valid = float(r.get("valid", 0.0) or 0.0)
            perception = float(r.get("perception", 0.0) or 0.0)
        except Exception:
            continue

        # invalid candidates receive hard penalty.
        reward = (perception - ANCHOR_FULL_PERCEPTION) if valid == 1.0 else -100.0
        stats[fam]["n"] += 1.0
        stats[fam]["sum_reward"] += reward
        stats[fam]["best"] = max(stats[fam]["best"], reward)
    return stats


def _select_family(iteration: int) -> str:
    rows = _read_feedback()

    # Warm-up: one pass over all families.
    if iteration <= len(MUTATION_FAMILIES):
        return MUTATION_FAMILIES[(iteration - 1) % len(MUTATION_FAMILIES)]

    stats = _family_stats(rows)
    total = sum(v["n"] for v in stats.values()) + 1.0

    # UCB with conservative exploration.
    c = float(os.environ.get("EVO_V15_UCB_C", "1.25"))
    scores = {}
    for fam, st in stats.items():
        n = st["n"]
        if n <= 0:
            scores[fam] = 1e6
        else:
            avg = st["sum_reward"] / n
            ucb = c * math.sqrt(math.log(total + 1.0) / n)
            # best reward is included weakly to avoid losing rare good modules.
            scores[fam] = avg + ucb + 0.15 * st["best"]

    best_score = max(scores.values())
    best_fams = [f for f, s in scores.items() if abs(s - best_score) < 1e-9]

    rng = random.Random(1009 + iteration)
    return rng.choice(best_fams)


def _base_policy(parent: Any) -> Tuple[Dict[str, Any], str]:
    anchor = _load_anchor_policy()
    anchor = _strip_program_fields(anchor)

    parent_policy = _extract_parent_policy(parent)
    if parent_policy is None:
        return anchor, "anchor"

    parent_policy = _strip_program_fields(parent_policy)

    # Use parent only if it is structurally compatible and not obviously unsafe.
    try:
        _get_selector(parent_policy)
        _get_fusion_weights(parent_policy)
        _get_process(parent_policy)
        return parent_policy, "parent"
    except Exception:
        return anchor, "anchor"


def _set_selector_safe(policy: Dict[str, Any], q: int, min_ref: int, div: float, ref_w: float, power: float) -> None:
    params = _get_selector(policy)
    q = _clamp_int(q, 1, 3)
    min_ref = _clamp_int(min_ref, 29, 31)

    # Full-MME perception anchor is q=2, min_ref=30.
    if q == 1:
        min_ref = max(min_ref, 31)
    elif q == 2:
        min_ref = _clamp_int(min_ref, 30, 31)
    elif q == 3:
        min_ref = min(min_ref, 29)

    params.update({
        "replace_quota": q,
        "min_reference_keep": min_ref,
        "diversity_lambda": round(_clamp(div, 0.04, 0.12), 4),
        "reference_keep_weight": round(_clamp(ref_w, 0.10, 0.30), 4),
        "candidate_quality_power": round(_clamp(power, 0.8, 1.25), 4),
        "sort_selected": True,
    })


def _set_process_semantic(policy: Dict[str, Any], alpha: float, top_k: int, gate: float, temp: float = 0.07) -> None:
    node = _get_process(policy)
    node["name"] = "semantic_gated_residual_merge"
    node["inputs"] = {
        "features": "image_features",
        "selected": "selected",
        "quality": "quality_score",
        "semantic": "semantic_score",
        "kernel": "sim_kernel",
    }
    node["params"] = {
        "norm_preserve": True,
        "merge_alpha": round(_clamp(alpha, 0.006, 0.018), 4),
        "top_merge_neighbors": _clamp_int(top_k, 1, 2),
        "temperature": round(_clamp(temp, 0.05, 0.12), 4),
        "semantic_gate_threshold": round(_clamp(gate, 0.55, 0.75), 4),
    }
    node["output"] = "processed_features"


def _set_process_similarity(policy: Dict[str, Any], alpha: float, top_k: int, qgate: float, temp: float = 0.07) -> None:
    node = _get_process(policy)
    node["name"] = "similarity_weighted_residual_merge"
    node["inputs"] = {
        "features": "image_features",
        "selected": "selected",
        "quality": "quality_score",
        "semantic": "semantic_score",
        "kernel": "sim_kernel",
    }
    node["params"] = {
        "norm_preserve": True,
        "merge_alpha": round(_clamp(alpha, 0.006, 0.014), 4),
        "top_merge_neighbors": _clamp_int(top_k, 1, 2),
        "temperature": round(_clamp(temp, 0.05, 0.12), 4),
        "quality_gate_threshold": round(_clamp(qgate, 0.0, 0.20), 4),
    }
    node["output"] = "processed_features"


def _mutate_selector_local(policy: Dict[str, Any], iteration: int) -> Dict[str, Any]:
    # Anchor-oriented: mostly q=2, occasional q=1/3.
    choices = [
        (2, 30, 0.08, 0.20, 1.00),
        (2, 30, 0.06, 0.20, 1.00),
        (2, 30, 0.10, 0.20, 1.00),
        (2, 31, 0.08, 0.25, 1.00),
        (2, 30, 0.08, 0.15, 1.10),
        (1, 31, 0.08, 0.20, 1.00),
        (3, 29, 0.06, 0.20, 0.95),
    ]
    q, mr, div, rw, pw = choices[(iteration - 1) % len(choices)]
    _set_selector_safe(policy, q, mr, div, rw, pw)
    return {"q": q, "min_ref": mr, "diversity_lambda": div, "reference_keep_weight": rw, "candidate_quality_power": pw}


def _mutate_fusion_local(policy: Dict[str, Any], iteration: int) -> Dict[str, Any]:
    w = _get_fusion_weights(policy)

    # Small local reweighting only. Avoid large smoke-overfit moves.
    patterns = [
        {"semantic": +0.02, "attn": -0.01},
        {"semantic": -0.02, "attn": +0.02},
        {"spatial": +0.02, "redundancy": -0.01},
        {"redundancy": +0.02, "contrast": +0.01, "semantic": -0.02},
        {"contrast": +0.02, "attn": +0.01, "semantic": -0.01},
        {"semantic": +0.01, "spatial": +0.01, "contrast": -0.01},
    ]
    pat = patterns[(iteration - 1) % len(patterns)]

    bounds = {
        "semantic": (0.26, 0.34),
        "attn": (0.08, 0.14),
        "spatial": (0.08, 0.14),
        "redundancy": (0.05, 0.10),
        "contrast": (0.04, 0.09),
    }

    for k, delta in pat.items():
        lo, hi = bounds[k]
        w[k] = round(_clamp(float(w.get(k, 0.0)) + delta, lo, hi), 4)

    return {"weights": dict(w), "pattern": pat}


def _mutate_processing_strength(policy: Dict[str, Any], iteration: int) -> Dict[str, Any]:
    choices = [
        (0.008, 1, 0.65, 0.07),
        (0.010, 1, 0.65, 0.07),
        (0.012, 1, 0.65, 0.07),
        (0.014, 1, 0.65, 0.07),
        (0.010, 2, 0.65, 0.07),
        (0.012, 1, 0.70, 0.07),
        (0.010, 1, 0.60, 0.07),
    ]
    alpha, top_k, gate, temp = choices[(iteration - 1) % len(choices)]
    _set_process_semantic(policy, alpha, top_k, gate, temp)
    return {"process": "semantic_gated_residual_merge", "alpha": alpha, "top_k": top_k, "gate": gate, "temperature": temp}


def _mutate_processing_gate(policy: Dict[str, Any], iteration: int) -> Dict[str, Any]:
    choices = [
        (0.010, 1, 0.60, 0.05),
        (0.010, 1, 0.65, 0.05),
        (0.010, 1, 0.70, 0.05),
        (0.012, 1, 0.65, 0.05),
        (0.008, 1, 0.65, 0.05),
        (0.010, 2, 0.70, 0.05),
    ]
    alpha, top_k, gate, temp = choices[(iteration - 1) % len(choices)]
    _set_process_semantic(policy, alpha, top_k, gate, temp)
    return {"process": "semantic_gated_residual_merge", "alpha": alpha, "top_k": top_k, "gate": gate, "temperature": temp}


def _mutate_module_replace(policy: Dict[str, Any], iteration: int) -> Dict[str, Any]:
    choices = [
        ("semantic", 0.010, 1, 0.65),
        ("similarity", 0.008, 1, 0.05),
        ("similarity", 0.010, 1, 0.05),
        ("semantic", 0.012, 1, 0.65),
        ("semantic", 0.010, 2, 0.70),
    ]
    kind, alpha, top_k, gate = choices[(iteration - 1) % len(choices)]
    if kind == "similarity":
        _set_process_similarity(policy, alpha, top_k, qgate=gate, temp=0.07)
        return {"process": "similarity_weighted_residual_merge", "alpha": alpha, "top_k": top_k, "quality_gate": gate}
    _set_process_semantic(policy, alpha, top_k, gate=gate, temp=0.07)
    return {"process": "semantic_gated_residual_merge", "alpha": alpha, "top_k": top_k, "gate": gate}


def _mutate_anchor_mix(policy: Dict[str, Any], iteration: int) -> Dict[str, Any]:
    # Restore anchor-like safe structure, then make exactly one small change.
    anchor = _load_anchor_policy()
    policy.clear()
    policy.update(_strip_program_fields(anchor))
    _ensure_process_node(policy)

    choices = [
        ("alpha", 0.012),
        ("alpha", 0.008),
        ("gate", 0.70),
        ("gate", 0.60),
        ("diversity", 0.06),
        ("diversity", 0.10),
        ("ref_weight", 0.25),
        ("power", 1.10),
    ]
    key, val = choices[(iteration - 1) % len(choices)]

    sel = _get_selector(policy)
    proc = _get_process(policy)

    if key == "alpha":
        proc.setdefault("params", {})["merge_alpha"] = float(val)
    elif key == "gate":
        proc.setdefault("params", {})["semantic_gate_threshold"] = float(val)
    elif key == "diversity":
        sel["diversity_lambda"] = float(val)
    elif key == "ref_weight":
        sel["reference_keep_weight"] = float(val)
    elif key == "power":
        sel["candidate_quality_power"] = float(val)

    return {"anchor_edit": key, "value": val}


def _apply_mutation(policy: Dict[str, Any], family: str, iteration: int) -> Dict[str, Any]:
    # Keep full-MME-safe defaults before mutation.
    try:
        _set_selector_safe(policy, q=2, min_ref=30, div=0.08, ref_w=0.20, power=1.00)
    except Exception:
        pass

    try:
        _set_process_semantic(policy, alpha=0.010, top_k=1, gate=0.65, temp=0.07)
    except Exception:
        pass

    if family == "selector_local":
        return _mutate_selector_local(policy, iteration)
    if family == "fusion_local":
        return _mutate_fusion_local(policy, iteration)
    if family == "processing_strength":
        return _mutate_processing_strength(policy, iteration)
    if family == "processing_gate":
        return _mutate_processing_gate(policy, iteration)
    if family == "module_replace":
        return _mutate_module_replace(policy, iteration)
    if family == "anchor_mix":
        return _mutate_anchor_mix(policy, iteration)

    return _mutate_anchor_mix(policy, iteration)


def _policy_fingerprint(policy: Dict[str, Any]) -> str:
    slim = copy.deepcopy(policy)
    slim.pop("__program_code__", None)
    text = yaml.safe_dump(slim, sort_keys=True, allow_unicode=True)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def _policy_to_program(policy: Dict[str, Any]) -> str:
    obj = copy.deepcopy(policy)
    obj.pop("__program_code__", None)
    yml = yaml.safe_dump(obj, sort_keys=False, allow_unicode=True)
    return (
        '"""OpenEvolve candidate program for v15 full-MME perception module-bandit Evo-CDPruner."""\n\n'
        'POLICY_YAML = r"""\n'
        + yml
        + '\n"""\n\n'
        'def get_policy_yaml():\n'
        '    return POLICY_YAML\n'
    )


def build_v15_policy_and_program(
    iteration: int,
    parent: Any = None,
    inspirations: Any = None,
    config: Any = None,
) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
    iteration = max(1, int(iteration))

    family = _select_family(iteration)
    policy, base_source = _base_policy(parent)
    policy = _strip_program_fields(policy)
    _ensure_process_node(policy)

    mutation_detail = _apply_mutation(policy, family, iteration)

    name = f"v15_fullperc_i{iteration:04d}_{family}"
    policy["policy_name"] = name
    policy["name"] = name
    policy["keep_tokens"] = 32

    policy.setdefault("meta", {})
    policy["meta"].update({
        "method": "v15_full_perception_module_bandit",
        "iteration": iteration,
        "base_source": base_source,
        "mutation_family": family,
        "mutation_detail": mutation_detail,
        "objective": "full_mme_perception",
        "anchor_full_perception": ANCHOR_FULL_PERCEPTION,
        "anchor_full_raw": ANCHOR_FULL_RAW,
    })

    policy["policy_fp"] = _policy_fingerprint(policy)
    program = _policy_to_program(policy)
    policy["__program_code__"] = program

    sel = _get_selector(policy)
    proc = _get_process(policy)
    weights = _get_fusion_weights(policy)

    meta = {
        "name": name,
        "policy_fp": policy["policy_fp"],
        "base_source": base_source,
        "mutation_family": family,
        "mutation_detail": mutation_detail,
        "replace_quota": sel.get("replace_quota"),
        "min_reference_keep": sel.get("min_reference_keep"),
        "process_name": proc.get("name"),
        "process_params": proc.get("params"),
        "weights": dict(weights),
        "feedback_path": str(_feedback_path()),
    }
    return policy, program, meta
