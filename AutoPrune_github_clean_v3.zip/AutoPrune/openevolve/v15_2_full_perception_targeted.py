from __future__ import annotations

from typing import Any, Dict, Tuple

from openevolve.v15_full_perception_bandit import (
    _load_anchor_policy,
    _strip_program_fields,
    _ensure_process_node,
    _set_selector_safe,
    _set_process_semantic,
    _get_selector,
    _get_process,
    _get_fusion_weights,
    _policy_fingerprint,
    _policy_to_program,
    _feedback_path,
    ANCHOR_FULL_PERCEPTION,
    ANCHOR_FULL_RAW,
)


def _reset_to_anchor() -> Dict[str, Any]:
    policy = _strip_program_fields(_load_anchor_policy())
    _ensure_process_node(policy)

    _set_selector_safe(
        policy,
        q=2,
        min_ref=30,
        div=0.08,
        ref_w=0.20,
        power=1.00,
    )
    _set_process_semantic(
        policy,
        alpha=0.010,
        top_k=1,
        gate=0.65,
        temp=0.07,
    )

    weights = _get_fusion_weights(policy)
    weights.update({
        "semantic": 0.30,
        "attn": 0.10,
        "spatial": 0.10,
        "redundancy": 0.07,
        "contrast": 0.06,
    })
    return policy


def build_v15_2_policy_and_program(
    iteration: int,
    parent: Any = None,
    inspirations: Any = None,
    config: Any = None,
) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
    """
    v15.2: full-MME perception-only targeted search.

    It uses only perception-safe regions found by v15.1:
    - diversity_lambda: 0.07 / 0.09
    - reference_keep_weight: 0.18 / 0.20 / 0.22 / 0.24
    - candidate_quality_power: small changes around 1.0

    No raw/cognition tie-break is used here.
    """
    iteration = max(1, int(iteration))

    policy = _reset_to_anchor()
    sel = _get_selector(policy)
    proc = _get_process(policy)
    weights = _get_fusion_weights(policy)

    # Phase A: selector plateau combination search.
    # These are all near the v15.1 perception-safe plateau.
    phase_a = []
    for div in [0.07, 0.09]:
        for refw in [0.18, 0.20, 0.22, 0.24]:
            for power in [0.95, 1.00, 1.05]:
                phase_a.append(
                    ("selector_combo", {
                        "diversity_lambda": div,
                        "reference_keep_weight": refw,
                        "candidate_quality_power": power,
                    })
                )

    # Phase B: only if you run beyond Phase A.
    # These keep selector in safe plateau and apply tiny processing perturbations.
    phase_b = []
    for div, refw in [(0.07, 0.20), (0.09, 0.20), (0.07, 0.22), (0.09, 0.22)]:
        for alpha in [0.009, 0.010, 0.011]:
            phase_b.append(
                ("selector_processing_combo", {
                    "diversity_lambda": div,
                    "reference_keep_weight": refw,
                    "candidate_quality_power": 1.00,
                    "merge_alpha": alpha,
                    "semantic_gate_threshold": 0.65,
                })
            )
        for gate in [0.63, 0.65, 0.67]:
            phase_b.append(
                ("selector_processing_combo", {
                    "diversity_lambda": div,
                    "reference_keep_weight": refw,
                    "candidate_quality_power": 1.00,
                    "merge_alpha": 0.010,
                    "semantic_gate_threshold": gate,
                })
            )

    plans = phase_a + phase_b
    family, edit = plans[(iteration - 1) % len(plans)]

    sel["diversity_lambda"] = float(edit.get("diversity_lambda", sel.get("diversity_lambda", 0.08)))
    sel["reference_keep_weight"] = float(edit.get("reference_keep_weight", sel.get("reference_keep_weight", 0.20)))
    sel["candidate_quality_power"] = float(edit.get("candidate_quality_power", sel.get("candidate_quality_power", 1.00)))
    sel["replace_quota"] = 2
    sel["min_reference_keep"] = 30
    sel["sort_selected"] = True

    proc.setdefault("params", {})
    alpha = float(edit.get("merge_alpha", proc["params"].get("merge_alpha", 0.010)))
    gate = float(edit.get("semantic_gate_threshold", proc["params"].get("semantic_gate_threshold", 0.65)))
    _set_process_semantic(policy, alpha=alpha, top_k=1, gate=gate, temp=0.07)

    # Keep fusion anchor-locked.
    weights = _get_fusion_weights(policy)
    weights.update({
        "semantic": 0.30,
        "attn": 0.10,
        "spatial": 0.10,
        "redundancy": 0.07,
        "contrast": 0.06,
    })

    tag = "_".join(f"{k}{str(v).replace('.', 'p')}" for k, v in edit.items())
    name = f"v15_2_perc_i{iteration:04d}_{family}_{tag}"

    policy["policy_name"] = name
    policy["name"] = name
    policy["keep_tokens"] = 32
    policy.setdefault("meta", {})
    policy["meta"].update({
        "method": "v15_2_full_perception_targeted",
        "iteration": iteration,
        "base_source": "anchor",
        "mutation_family": family,
        "mutation_detail": edit,
        "objective": "full_mme_perception_only",
        "anchor_full_perception": ANCHOR_FULL_PERCEPTION,
        "anchor_full_raw": ANCHOR_FULL_RAW,
    })

    policy["policy_fp"] = _policy_fingerprint(policy)
    program = _policy_to_program(policy)
    policy["__program_code__"] = program

    sel = _get_selector(policy)
    proc = _get_process(policy)
    weights = _get_fusion_weights(policy)

    meta = {
        "name": name,
        "policy_fp": policy["policy_fp"],
        "base_source": "anchor",
        "mutation_family": family,
        "mutation_detail": edit,
        "replace_quota": sel.get("replace_quota"),
        "min_reference_keep": sel.get("min_reference_keep"),
        "process_name": proc.get("name"),
        "process_params": proc.get("params"),
        "weights": dict(weights),
        "feedback_path": str(_feedback_path()),
    }
    return policy, program, meta
