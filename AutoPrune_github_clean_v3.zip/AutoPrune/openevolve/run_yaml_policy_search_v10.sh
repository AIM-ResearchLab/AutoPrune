#!/usr/bin/env bash
set -euo pipefail

ROOT="/data/lz/openevolve_pruner/CDPruner/openevolve"
CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"
cd "${CDPRUNER_ROOT}"
export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

echo "ROOT = ${ROOT}"
echo "OpenEvolve v10 LLM-driven executable YAML pipeline search"

python - <<'PY'
import sys
sys.path.insert(0, "/data/lz/openevolve_pruner/CDPruner/openevolve")
from openevolve.controller import OpenEvolve
print("OpenEvolve loaded from = openevolve.controller")
PY

export EVO_EVAL_SCRIPT="${EVO_EVAL_SCRIPT:-scripts/v1_5/eval/mme_yaml_smoke21.sh}"
export EVO_GPU="${EVO_GPU:-5}"
export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"
export EVO_OBJECTIVE="${EVO_OBJECTIVE:-perception}"
export EVO_EVAL_TIMEOUT="${EVO_EVAL_TIMEOUT:-1800}"

export EVO_V4_LLM_PLANNER="${EVO_V4_LLM_PLANNER:-1}"
export EVO_V32_LLM_PLANNER="${EVO_V32_LLM_PLANNER:-${EVO_V4_LLM_PLANNER}}"
export EVO_V10_PIPELINE_PLANNER="${EVO_V10_PIPELINE_PLANNER:-1}"

export EVO_V4_PLANNER_TEMPERATURE="${EVO_V4_PLANNER_TEMPERATURE:-0.85}"
export EVO_V4_PLANNER_MAX_TOKENS="${EVO_V4_PLANNER_MAX_TOKENS:-4200}"

export EVO_RUN_TAG="${EVO_RUN_TAG:-v10_llm_anchor_product_K${EVO_TOKEN}_${EVO_OBJECTIVE}}"
export EVO_WORK_DIR="yaml_policy/evo_candidates/${EVO_RUN_TAG}"

OUT="${ROOT}/runs/${EVO_RUN_TAG}"
mkdir -p "${OUT}" "${CDPRUNER_ROOT}/${EVO_WORK_DIR}"

python "${ROOT}/openevolve-run.py" \
  "${ROOT}/initial_program.py" \
  "${CDPRUNER_ROOT}/yaml_policy/openevolve_yaml_search/evaluator_openevolve_v10.py" \
  --config "${ROOT}/config_yaml_policy.yaml" \
  --output "${OUT}" \
  --iterations "${EVO_ITERATIONS:-60}"
