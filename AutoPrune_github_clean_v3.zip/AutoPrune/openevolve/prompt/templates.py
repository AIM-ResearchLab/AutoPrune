"""Prompt templates for OpenEvolve + Evo-CDPruner YAML policy search.

This file restores the TemplateManager API required by
`openevolve.prompt.sampler.PromptSampler`, while keeping Evo-CDPruner
balanced-registry YAML policy prompts available for compatibility.

Why this file exists:
- OpenEvolve imports `TemplateManager` from `openevolve.prompt.templates`.
- The previous simplified templates.py removed `TemplateManager`, causing:
  ImportError: cannot import name 'TemplateManager'
- The active Evo-CDPruner controller now uses grammar/registry operators, but
  OpenEvolve still initializes PromptSampler and therefore still requires this
  module to be API-compatible.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any, Dict, Optional

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Core OpenEvolve templates
# ---------------------------------------------------------------------------

BASE_SYSTEM_TEMPLATE = """You are an expert software developer tasked with iteratively improving a codebase.
Analyze the current program and suggest targeted changes that improve the reported metrics.
Focus on making valid, minimal, measurable improvements.
"""

BASE_EVALUATOR_SYSTEM_TEMPLATE = """You are an expert code reviewer.
Your job is to analyze the provided code and evaluate it systematically.
"""

DIFF_USER_TEMPLATE = """# Current Program Information
- Current performance metrics:
{metrics}

- Areas identified for improvement:
{improvement_areas}

{artifacts}

# Program Evolution History
{evolution_history}

# Current Program
```{language}
{current_program}
```

# Task
Suggest improvements to the program that will lead to better performance on the specified metrics.

You MUST use the exact SEARCH/REPLACE diff format:

<<<<<<< SEARCH
# Original code to find and replace
=======
# New replacement code
>>>>>>> REPLACE

Each SEARCH section must exactly match code in the current program.
Focus on targeted improvements rather than rewriting unrelated parts.
"""

FULL_REWRITE_USER_TEMPLATE = """# Current Program Information
- Current performance metrics:
{metrics}

- Areas identified for improvement:
{improvement_areas}

{artifacts}

# Program Evolution History
{evolution_history}

# Current Program
```{language}
{current_program}
```

# Task
Rewrite the program to improve its performance on the specified metrics.
Return the complete new program code.

```{language}
# Your rewritten program here
```
"""

YAML_POLICY_USER_TEMPLATE = """Evo-CDPruner YAML policy mutation.

Priority:
1. maximize balanced_score on smoke21;
2. preserve perception relative to the TopK smoke21 baseline;
3. allow cognition gains only when perception does not collapse;
4. do not perform power-only monotonic no-op edits.

Important:
- The active balanced-registry controller uses typed grammar operators rather
  than free-form YAML rewriting.
- This template is kept for OpenEvolve PromptSampler compatibility and possible
  future LLM-planner mode.
"""

EVOLUTION_HISTORY_TEMPLATE = """## Previous Attempts
{previous_attempts}

## Top Performing Programs
{top_programs}

{inspirations_section}
"""

PREVIOUS_ATTEMPT_TEMPLATE = """### Attempt {attempt_number}
- Changes: {changes}
- Performance: {performance}
- Outcome: {outcome}
"""

TOP_PROGRAM_TEMPLATE = """### Program {program_number} (Score: {score})
```{language}
{program_snippet}
```
Key features: {key_features}
"""

INSPIRATIONS_SECTION_TEMPLATE = """## Inspiration Programs
These programs represent diverse approaches and creative solutions that may inspire new ideas:

{inspiration_programs}
"""

INSPIRATION_PROGRAM_TEMPLATE = """### Inspiration {program_number} (Score: {score}, Type: {program_type})
```{language}
{program_snippet}
```
Unique approach: {unique_features}
"""

EVALUATION_TEMPLATE = """Evaluate the following code on a scale of 0.0 to 1.0 for:
1. Readability
2. Maintainability
3. Efficiency

Code:
```python
{current_program}
```

Return JSON:
{{
  "readability": 0.0,
  "maintainability": 0.0,
  "efficiency": 0.0,
  "reasoning": "brief explanation"
}}
"""

SYSTEM_MESSAGE_WITH_CHANGES_DESCRIPTION = """{system_message}

{system_message_changes_description}
"""

SYSTEM_MESSAGE_CHANGES_DESCRIPTION = """Programs may be represented as change descriptions.
Preserve the intended behavior while improving performance.
"""

USER_MESSAGE_WITH_CHANGES_DESCRIPTION = """{user_message}

# Current changes description
{changes_description}
"""


DEFAULT_TEMPLATES: Dict[str, str] = {
    "system_message": BASE_SYSTEM_TEMPLATE,
    "evaluator_system_message": BASE_EVALUATOR_SYSTEM_TEMPLATE,
    "diff_user": DIFF_USER_TEMPLATE,
    "full_rewrite_user": FULL_REWRITE_USER_TEMPLATE,
    "yaml_policy_user": YAML_POLICY_USER_TEMPLATE,
    "evolution_history": EVOLUTION_HISTORY_TEMPLATE,
    "previous_attempt": PREVIOUS_ATTEMPT_TEMPLATE,
    "top_program": TOP_PROGRAM_TEMPLATE,
    "inspirations_section": INSPIRATIONS_SECTION_TEMPLATE,
    "inspiration_program": INSPIRATION_PROGRAM_TEMPLATE,
    "evaluation": EVALUATION_TEMPLATE,
    "system_message_with_changes_description": SYSTEM_MESSAGE_WITH_CHANGES_DESCRIPTION,
    "system_message_changes_description": SYSTEM_MESSAGE_CHANGES_DESCRIPTION,
    "user_message_with_changes_description": USER_MESSAGE_WITH_CHANGES_DESCRIPTION,
}


# ---------------------------------------------------------------------------
# Fragments used by PromptSampler
# ---------------------------------------------------------------------------

DEFAULT_FRAGMENTS: Dict[str, str] = {
    "fitness_improved": "Fitness improved from {prev:.4f} to {current:.4f}. Build on the successful change.",
    "fitness_declined": "Fitness declined from {prev:.4f} to {current:.4f}. Avoid repeating the likely harmful change.",
    "fitness_stable": "Fitness stayed around {current:.4f}. Try a more meaningful structural change.",
    "no_feature_coordinates": "No MAP-Elites feature coordinates are available.",
    "exploring_region": "Exploring feature region: {features}.",
    "code_too_long": "The code is longer than the configured threshold ({threshold}); consider simplifying it.",
    "no_specific_guidance": "No specific guidance available. Prefer a small, valid, measurable improvement.",

    "attempt_unknown_changes": "changes unknown",
    "attempt_mixed_metrics": "mixed metric changes",
    "attempt_all_metrics_improved": "all comparable metrics improved",
    "attempt_all_metrics_regressed": "all comparable metrics regressed",

    "top_program_metrics_prefix": "metric",
    "diverse_programs_title": "Diverse Programs",
    "diverse_program_metrics_prefix": "metric",

    "inspirations_section": "Inspiration Programs",
    "inspiration_type_diverse": "diverse",
    "inspiration_type_migrant": "migrant",
    "inspiration_type_random": "random",
    "inspiration_type_score_high_performer": "high performer",
    "inspiration_type_score_alternative": "alternative",
    "inspiration_type_score_experimental": "experimental",
    "inspiration_type_score_exploratory": "exploratory",
    "inspiration_changes_prefix": "changes: {changes}",
    "inspiration_metrics_excellent": "{metric_name} is excellent ({value:.4f})",
    "inspiration_metrics_alternative": "{metric_name} is unusually low, may explore a different trade-off",
    "inspiration_code_with_class": "uses class-based structure",
    "inspiration_code_with_numpy": "uses NumPy/vectorized operations",
    "inspiration_code_with_mixed_iteration": "uses mixed iteration patterns",
    "inspiration_code_with_concise_line": "concise implementation",
    "inspiration_code_with_comprehensive_line": "comprehensive implementation",
    "inspiration_no_features_postfix": "representative {program_type} approach",

    "artifact_title": "Execution Artifacts",
}


class TemplateManager:
    """Manage OpenEvolve prompt templates and fragments.

    This implementation intentionally keeps the public API small and compatible
    with `openevolve.prompt.sampler.PromptSampler`.

    Supported API:
    - `templates`: dict of template_name -> template_text
    - `fragments`: dict of fragment_name -> fragment_text
    - `get_template(name, default=None)`
    - `get_fragment(name, **kwargs)`
    - `set_template(name, value)`
    - `set_fragment(name, value)`
    - `update_templates(values)`
    - `update_fragments(values)`

    Loading behavior:
    - Built-in defaults are always available.
    - If `custom_template_dir` exists, *.txt and *.md files are loaded as
      templates using their stem as the key.
    - `templates.json` and `fragments.json` are also supported.
    """

    def __init__(self, custom_template_dir: Optional[str] = None):
        self.default_dir = Path(__file__).parent.parent / "prompts" / "defaults"
        self.custom_dir = Path(custom_template_dir) if custom_template_dir else None

        self.templates: Dict[str, str] = dict(DEFAULT_TEMPLATES)
        self.fragments: Dict[str, str] = dict(DEFAULT_FRAGMENTS)

        self._load_from_directory(self.default_dir)
        if self.custom_dir:
            self._load_from_directory(self.custom_dir)

    def _load_from_directory(self, directory: Path) -> None:
        """Load templates/fragments from a directory if it exists."""
        if not directory or not directory.exists() or not directory.is_dir():
            return

        for path in sorted(directory.iterdir()):
            if not path.is_file():
                continue

            try:
                if path.name == "templates.json":
                    data = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        self.templates.update({str(k): str(v) for k, v in data.items()})

                elif path.name == "fragments.json":
                    data = json.loads(path.read_text(encoding="utf-8"))
                    if isinstance(data, dict):
                        self.fragments.update({str(k): str(v) for k, v in data.items()})

                elif path.suffix.lower() in {".txt", ".md"}:
                    self.templates[path.stem] = path.read_text(encoding="utf-8")

            except Exception as exc:
                logger.warning("Failed to load prompt template file %s: %s", path, exc)

    def get_template(self, name: str, default: Optional[str] = None) -> str:
        """Return a template by key.

        If `name` looks like literal prompt content instead of a template key,
        return it directly. This preserves OpenEvolve's flexible config style,
        where config.system_message may be either a template key or literal text.
        """
        if name in self.templates:
            return self.templates[name]

        if default is not None:
            return default

        if isinstance(name, str) and ("\n" in name or " " in name):
            return name

        logger.warning("Unknown prompt template '%s'; returning empty string.", name)
        return ""

    def get_fragment(self, name: str, **kwargs: Any) -> str:
        """Return a fragment by key and optionally format it."""
        template = self.fragments.get(name, name)

        if kwargs:
            try:
                return template.format(**kwargs)
            except Exception:
                return template

        return template

    def set_template(self, name: str, value: str) -> None:
        self.templates[name] = value

    def set_fragment(self, name: str, value: str) -> None:
        self.fragments[name] = value

    def update_templates(self, values: Dict[str, str]) -> None:
        self.templates.update(values)

    def update_fragments(self, values: Dict[str, str]) -> None:
        self.fragments.update(values)
