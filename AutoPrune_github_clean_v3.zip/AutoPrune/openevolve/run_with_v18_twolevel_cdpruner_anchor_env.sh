#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ "$#" -lt 3 ]; then
  echo "Usage: $0 <anchor_policy_yaml> <merge_policy_yaml> <command...>"
  exit 1
fi

ANCHOR_POLICY="$1"
MERGE_POLICY="$2"
shift 2

case "$ANCHOR_POLICY" in
  /*) ;;
  *) ANCHOR_POLICY="${CDPRUNER_ROOT}/${ANCHOR_POLICY}" ;;
esac

case "$MERGE_POLICY" in
  /*) ;;
  *) MERGE_POLICY="${CDPRUNER_ROOT}/${MERGE_POLICY}" ;;
esac

if [ ! -f "$ANCHOR_POLICY" ]; then
  echo "ERROR: anchor policy not found: $ANCHOR_POLICY"
  exit 1
fi

if [ ! -f "$MERGE_POLICY" ]; then
  echo "ERROR: merge policy not found: $MERGE_POLICY"
  exit 1
fi

export V16_ANCHOR_POLICY="$ANCHOR_POLICY"

echo "=== v18 two-level trust-region CDPruner anchor ==="
echo "Anchor policy: $ANCHOR_POLICY"
echo "Merge policy: $MERGE_POLICY"
echo "EVO_GPU=${EVO_GPU:-unset}"
echo "EVO_TOKEN=${EVO_TOKEN:-unset}"

exec "${CDPRUNER_ROOT}/openevolve/run_with_v17_cdpruner_anchor_env.sh" "$MERGE_POLICY" "$@"
