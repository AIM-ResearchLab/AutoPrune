"""Typed policy grammar utilities for Evo-CDPruner Search Space v2.

This module is intentionally independent from OpenEvolve internals.  It turns the
large atom registry into a compact executable summary and provides validated
policy constructors used by operator_generator.py.

Key idea:
    atom_registry.yaml is the knowledge base;
    this file is the typed compiler layer;
    operator_generator.py is the mutation/search layer.
"""
from __future__ import annotations

import copy
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence

import yaml

Policy = Dict[str, Any]
REGISTRY_PATH = Path(__file__).with_name("atom_registry.yaml")


@dataclass(frozen=True)
class AtomSpec:
    id: str
    family: str
    executable_stage1: bool
    raw: Dict[str, Any]


class AtomRegistry:
    """Lightweight typed registry reader.

    The registry may include many conceptual atoms.  Only atoms with
    executable_stage1=true are emitted by the current generator.
    """

    def __init__(self, path: Optional[Path] = None):
        self.path = path or REGISTRY_PATH
        self.raw: Dict[str, Any] = self._load(self.path)
        atoms = self.raw.get("atoms", []) or []
        self.atoms: Dict[str, AtomSpec] = {}
        for item in atoms:
            if not isinstance(item, dict) or "id" not in item:
                continue
            spec = AtomSpec(
                id=str(item["id"]),
                family=str(item.get("family", "unknown")),
                executable_stage1=bool(item.get("executable_stage1", False)),
                raw=item,
            )
            self.atoms[spec.id] = spec

    @staticmethod
    def _load(path: Path) -> Dict[str, Any]:
        if not path.exists():
            return {"metadata": {}, "atoms": [], "policy_families": []}
        with path.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {"metadata": {}, "atoms": [], "policy_families": []}

    def by_family(self, family: str, executable_only: bool = True) -> List[AtomSpec]:
        out = [a for a in self.atoms.values() if a.family == family]
        if executable_only:
            out = [a for a in out if a.executable_stage1]
        return sorted(out, key=lambda x: x.id)

    def has_executable(self, atom_id: str) -> bool:
        a = self.atoms.get(atom_id)
        return bool(a and a.executable_stage1)

    def choices(self, atom_id: str, param: str, default: Optional[Sequence[Any]] = None) -> List[Any]:
        spec = self.atoms.get(atom_id)
        if not spec:
            return list(default or [])
        node = spec.raw.get("params", {}).get(param, {})
        if isinstance(node, dict) and isinstance(node.get("choices"), list):
            return node["choices"]
        return list(default or [])

    def summary(self) -> Dict[str, Any]:
        families: Dict[str, Dict[str, int]] = {}
        for a in self.atoms.values():
            f = families.setdefault(a.family, {"total": 0, "executable_stage1": 0})
            f["total"] += 1
            if a.executable_stage1:
                f["executable_stage1"] += 1
        return {
            "registry_path": str(self.path),
            "num_atoms": len(self.atoms),
            "families": families,
            "policy_families": [p.get("id") for p in self.raw.get("policy_families", []) if isinstance(p, dict)],
        }

    def llm_planner_summary(self, max_atoms_per_family: int = 12) -> str:
        """Compact text summary for future LLM-planner mode.

        This is the right way to let an LLM 'see' a large YAML registry without
        sending the entire YAML file at every iteration.
        """
        lines = []
        lines.append("Evo-CDPruner Search Space v2 summary")
        lines.append(json.dumps(self.summary(), ensure_ascii=False, indent=2))
        for family in sorted({a.family for a in self.atoms.values()}):
            atoms = self.by_family(family, executable_only=False)
            lines.append(f"\n[{family}] total={len(atoms)}")
            for a in atoms[:max_atoms_per_family]:
                tags = a.raw.get("semantic_tags", [])
                tags = ",".join(tags) if isinstance(tags, list) else str(tags)
                status = "EXEC" if a.executable_stage1 else "PLAN"
                lines.append(f"- {a.id} ({status}) {tags}")
        return "\n".join(lines)


def deep_copy(x: Any) -> Any:
    return copy.deepcopy(x)


def base_step() -> Dict[str, Any]:
    return {
        "id": "visual_token_selection",
        "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
        "target": {"atom": "image_patch_tokens"},
    }


def wrap_policy(step: Dict[str, Any], name: str = "evolved_cdpruner_policy") -> Policy:
    return {
        "version": "0.5-light",
        "policy_name": name,
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "stage1_functional_search",
        "pipeline": [step],
    }


def protection_spatial(grid_size: int = 4, min_keep_per_cell: int = 1) -> Dict[str, Any]:
    return {
        "atom": "spatial_coverage_preservation",
        "params": {"grid_size": int(grid_size), "min_keep_per_cell": int(min_keep_per_cell)},
    }


def protection_anchor(topk: int = 8) -> Dict[str, Any]:
    return {"atom": "top_relevance_anchor_preservation", "params": {"topk": int(topk)}}


def budget_fixed_tokens() -> Dict[str, Any]:
    return {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}}


def budget_ratio(keep_ratio: float, min_keep_tokens: int = 16) -> Dict[str, Any]:
    return {"atom": "fixed_keep_ratio", "params": {"keep_ratio": float(keep_ratio), "min_keep_tokens": int(min_keep_tokens)}}


def relevance_scorer(sign: str, transform: str, power: float = 1.0) -> Dict[str, Any]:
    return {
        "atom": "instruction_guided_visual_relevance",
        "params": {"sign": str(sign), "transform": str(transform), "power": float(power)},
    }


def similarity_scorer(atom: str = "pairwise_token_similarity", metric: str = "cosine", conditioning: str = "none", transform: str = "identity") -> Dict[str, Any]:
    params = {"similarity_metric": str(metric), "similarity_transform": str(transform)}
    if atom == "conditional_similarity_score":
        params["conditioning_mode"] = str(conditioning)
    return {"atom": str(atom), "params": params}


def topk_policy(
    sign: str = "negative_mean",
    transform: str = "rank_norm",
    power: float = 1.0,
    fusion_norm: Optional[str] = None,
    budget: Optional[Dict[str, Any]] = None,
    protection: Optional[List[Dict[str, Any]]] = None,
) -> Policy:
    fusion_norm = fusion_norm or transform
    step = base_step()
    step.update({
        "scorer": {"main": relevance_scorer(sign, transform, power)},
        "fusion": {"atom": "weighted_sum_score_fusion", "params": {"score_normalization": fusion_norm, "weights": [1.0]}},
        "budget": budget or budget_fixed_tokens(),
        "selector": {"atom": "topk_selector", "params": {"largest": True}},
        "action": {"atom": "hard_prune"},
        "protection": protection or [],
    })
    return wrap_policy(step)


def mmr_policy(
    sign: str = "negative_mean",
    transform: str = "rank_norm",
    power: float = 1.0,
    sim_atom: str = "pairwise_token_similarity",
    metric: str = "cosine",
    conditioning: str = "none",
    lambda_relevance: float = 0.6,
    budget: Optional[Dict[str, Any]] = None,
    protection: Optional[List[Dict[str, Any]]] = None,
) -> Policy:
    step = base_step()
    step.update({
        "scorer": {
            "quality": relevance_scorer(sign, transform, power),
            "similarity": similarity_scorer(sim_atom, metric=metric, conditioning=conditioning),
        },
        "fusion": {"atom": "mmr_relevance_diversity_fusion", "params": {"lambda_relevance": float(lambda_relevance)}},
        "budget": budget or budget_fixed_tokens(),
        "selector": {"atom": "mmr_selector", "params": {"init_by": "top_relevance"}},
        "action": {"atom": "hard_prune"},
        "protection": protection or [],
    })
    return wrap_policy(step)


def dpp_policy(
    sign: str = "negative_mean",
    transform: str = "minmax",
    power: float = 1.0,
    sim_atom: str = "conditional_similarity_score",
    metric: str = "cosine",
    conditioning: str = "none",
    quality_power: float = 1.0,
    similarity_power: float = 1.0,
    budget: Optional[Dict[str, Any]] = None,
    protection: Optional[List[Dict[str, Any]]] = None,
) -> Policy:
    step = base_step()
    step.update({
        "scorer": {
            "quality": relevance_scorer(sign, transform, power),
            "similarity": similarity_scorer(sim_atom, metric=metric, conditioning=conditioning),
        },
        "fusion": {
            "atom": "quality_diversity_kernel",
            "params": {
                "quality_power": float(quality_power),
                "similarity_power": float(similarity_power),
                "eps": 1.0e-6,
                "symmetrize": True,
            },
        },
        "budget": budget or budget_fixed_tokens(),
        "selector": {"atom": "dpp_selector", "params": {"algorithm": "fast_map", "postprocess": "sort_by_position"}},
        "action": {"atom": "dpp_subset_prune"},
        "protection": protection or [],
    })
    return wrap_policy(step)


def policy_family(policy: Policy) -> str:
    try:
        step = policy["pipeline"][0]
        return str(step.get("selector", {}).get("atom", "unknown"))
    except Exception:
        return "unknown"


def iter_executable_family_ids(registry: Optional[AtomRegistry] = None) -> Iterable[str]:
    registry = registry or AtomRegistry()
    for fam in registry.raw.get("policy_families", []) or []:
        if isinstance(fam, dict) and fam.get("executable_stage1"):
            yield str(fam.get("id"))


if __name__ == "__main__":
    reg = AtomRegistry()
    print(reg.llm_planner_summary())

# -----------------------------------------------------------------------------
# v4 budget-general baseline-anchored residual policy constructors
# -----------------------------------------------------------------------------

def baseline_anchored_residual_policy(
    baseline_sign: str = "negative_mean",
    baseline_transform: str = "minmax",
    aux_atom: str = "spatial_centrality_prior",
    aux_transform: str = "minmax",
    aux_total_weight: float = 0.10,
    scheduler: str = "sqrt",
    alpha: float = 1.2,
    min_residual: int = 2,
    max_residual_ratio: float = 0.375,
    candidate_pool_multiplier: float = 4.0,
    gate_baseline_weight: float = 0.65,
    gate_residual_weight: float = 0.35,
    min_gain: float = 0.0,
) -> Policy:
    """Budget-general residual policy.

    K is not fixed in the YAML.  The host argument / EVO_TOKEN controls K.
    The selector derives residual_keep from K using the scheduler.
    """
    step = base_step()
    if aux_atom == "visual_token_norm_saliency":
        aux = {"atom": aux_atom, "params": {"transform": aux_transform, "power": 1.0}}
    elif aux_atom == "redundancy_density_penalty":
        aux = {"atom": aux_atom, "params": {"k_neighbors": 8, "metric": "cosine", "transform": aux_transform}}
    elif aux_atom == "attention_proxy_saliency":
        aux = {"atom": aux_atom, "params": {"proxy": "feature_norm", "transform": aux_transform}}
    else:
        aux = {"atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": aux_transform}}
    step.update({
        "scorer": {
            "baseline": relevance_scorer(baseline_sign, baseline_transform, 1.0),
            "aux": aux,
        },
        "fusion": {
            "atom": "baseline_residual_score_fusion",
            "params": {"baseline_weight": 1.0, "aux_total_weight": float(aux_total_weight), "score_normalization": "minmax"},
        },
        "budget": budget_fixed_tokens(),
        "selector": {
            "atom": "baseline_anchored_residual_selector",
            "params": {
                "scheduler": str(scheduler),
                "alpha": float(alpha),
                "min_residual": int(min_residual),
                "max_residual_ratio": float(max_residual_ratio),
                "candidate_pool_multiplier": float(candidate_pool_multiplier),
                "gate_baseline_weight": float(gate_baseline_weight),
                "gate_residual_weight": float(gate_residual_weight),
                "min_gain": float(min_gain),
            },
        },
        "action": {"atom": "hard_prune"},
        "protection": [],
    })
    return wrap_policy(step, name="evolved_cdpruner_v4_baseline_anchored_residual")



def true_cdpruner_anchor_residual_policy(
    aux_scorers: Optional[List[Dict[str, Any]]] = None,
    aux_total_weight: float = 0.05,
    scheduler: str = "sqrt",
    alpha: float = 0.8,
    min_residual: int = 0,
    max_residual_ratio: float = 0.125,
    candidate_pool_multiplier: float = 4.0,
    gate_baseline_weight: float = 0.85,
    gate_residual_weight: float = 0.15,
    min_gain: float = 0.01,
    no_op_if_no_positive_gain: bool = True,
) -> Policy:
    """v4.3 true-CDPruner-mask anchored residual policy constructor."""
    step = base_step()
    scorers: Dict[str, Any] = {
        "baseline": relevance_scorer("negative_mean", "minmax", 1.0),
    }
    if not aux_scorers:
        aux_scorers = [{"atom": "visual_token_norm_saliency", "params": {"transform": "minmax", "power": 1.0}}]
    for i, aux in enumerate(aux_scorers[:4]):
        if not isinstance(aux, dict):
            continue
        key = str(aux.get("id", f"aux{i+1}"))
        if key == "baseline" or key in scorers:
            key = f"aux{i+1}"
        scorers[key] = {"atom": aux.get("atom", "visual_token_norm_saliency"), "params": aux.get("params", {}) if isinstance(aux.get("params", {}), dict) else {}}
    step.update({
        "scorer": scorers,
        "fusion": {"atom": "baseline_residual_score_fusion", "params": {"baseline_weight": 1.0, "aux_total_weight": float(aux_total_weight), "score_normalization": "minmax"}},
        "budget": budget_fixed_tokens(),
        "selector": {"atom": "cdpruner_mask_anchored_residual_selector", "params": {
            "true_cdpruner_anchor": True,
            "scheduler": str(scheduler),
            "alpha": float(alpha),
            "min_residual": int(min_residual),
            "max_residual_ratio": float(max_residual_ratio),
            "candidate_pool_multiplier": float(candidate_pool_multiplier),
            "gate_baseline_weight": float(gate_baseline_weight),
            "gate_residual_weight": float(gate_residual_weight),
            "min_gain": float(min_gain),
            "no_op_if_no_positive_gain": bool(no_op_if_no_positive_gain),
        }},
        "action": {"atom": "hard_prune"},
        "protection": [],
    })
    return wrap_policy(step, name="evolved_cdpruner_v4_3_true_anchor_residual")
