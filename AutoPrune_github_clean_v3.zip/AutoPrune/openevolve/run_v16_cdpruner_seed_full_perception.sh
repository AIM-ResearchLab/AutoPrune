#!/usr/bin/env bash
set -euo pipefail

ROOT="/data/lz/openevolve_pruner/CDPruner/openevolve"
CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"
PY="/data/lz/conda/env/cdpruner/bin/python"

cd "${CDPRUNER_ROOT}"

if [ ! -x "$PY" ]; then
  echo "ERROR: cdpruner python not found: $PY"
  exit 1
fi

export PATH="/data/lz/conda/env/cdpruner/bin:${PATH}"
export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1
export EVO_V15_FULL_PERCEPTION_BANDIT=0
export EVO_V15_1_FULL_PERCEPTION_MICRO=0
export EVO_V15_2_FULL_PERCEPTION_TARGETED=0
export EVO_V15_3_FULL_PERCEPTION_MARGIN=0
export EVO_V16_CDPRUNER_SEED_FULL_PERCEPTION=1
export EVO_V14B_PROCESSING_ONLY=0
export EVO_V14B_STRICT=0
export EVO_V14C_STRICT=1

export EVO_V14C_MIN_OVERLAP=${EVO_V14C_MIN_OVERLAP:-0.85}
export EVO_V14C_MAX_CHANGED=${EVO_V14C_MAX_CHANGED:-5.0}

export EVO_EVAL_SCRIPT=scripts/v1_5/eval/mme.sh
export EVO_GPU="${EVO_GPU:-5}"
export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"
export EVO_OBJECTIVE="${EVO_OBJECTIVE:-perception}"
export EVO_OE_SELECTION_METRIC="${EVO_OE_SELECTION_METRIC:-perception}"
export EVO_EVAL_TIMEOUT="${EVO_EVAL_TIMEOUT:-1800}"

export EVO_V4_LLM_PLANNER=1
export EVO_V32_LLM_PLANNER=1
export EVO_V10_PIPELINE_PLANNER=1
export EVO_V4_PLANNER_TEMPERATURE="${EVO_V4_PLANNER_TEMPERATURE:-0.35}"
export EVO_V4_PLANNER_MAX_TOKENS="${EVO_V4_PLANNER_MAX_TOKENS:-4600}"
export EVO_V4_EXPLORATION_RATE="${EVO_V4_EXPLORATION_RATE:-0.25}"
export EVO_V32_EXPLORATION_RATE="${EVO_V32_EXPLORATION_RATE:-0.25}"

export EVO_WORK_DIR="yaml_policy/evo_candidates/v16_cdpruner_seed_full_perception_K${EVO_TOKEN}_fullmme"

OUT="${ROOT}/runs/v16_cdpruner_seed_full_perception_K${EVO_TOKEN}_fullmme"
mkdir -p "${OUT}" "${CDPRUNER_ROOT}/${EVO_WORK_DIR}"

echo "python=$($PY -c 'import sys; print(sys.executable)')"
echo "OUT=${OUT}"
echo "EVO_V14B_PROCESSING_ONLY=${EVO_V14B_PROCESSING_ONLY}"
echo "EVO_V14B_STRICT=${EVO_V14B_STRICT}"
echo "EVO_EVAL_SCRIPT=${EVO_EVAL_SCRIPT}"
echo "EVO_GPU=${EVO_GPU}"
echo "EVO_TOKEN=${EVO_TOKEN}"


# V16_RUNTIME_ENV_BEFORE_RUN
export EVO_V14C_COUPLED_JOINT=0
export EVO_V15_MIN_OVERLAP="${EVO_V15_MIN_OVERLAP:-0.0}"
export EVO_V15_MAX_CHANGED="${EVO_V15_MAX_CHANGED:-999.0}"
export EVO_V15_FEEDBACK_PATH="${EVO_V15_FEEDBACK_PATH:-/data/lz/openevolve_pruner/CDPruner/openevolve/runs/v16_cdpruner_seed_full_perception_K32_fullmme/v16_feedback.jsonl}"
export EVO_V16_BASELINE_SCORE_CACHE="${EVO_V16_BASELINE_SCORE_CACHE:-/data/lz/openevolve_pruner/CDPruner/openevolve/runs/mme_vtn32_cdpruner_clean_score.txt}"
export EVO_V16_INCLUDE_REPLAY="${EVO_V16_INCLUDE_REPLAY:-1}"

echo "EVO_OE_SELECTION_METRIC=${EVO_OE_SELECTION_METRIC}"
echo "EVO_V15_MIN_OVERLAP=${EVO_V15_MIN_OVERLAP}"
echo "EVO_V15_MAX_CHANGED=${EVO_V15_MAX_CHANGED}"
echo "EVO_V15_FEEDBACK_PATH=${EVO_V15_FEEDBACK_PATH}"
echo "EVO_V16_BASELINE_SCORE_CACHE=${EVO_V16_BASELINE_SCORE_CACHE}"
echo "EVO_V16_INCLUDE_REPLAY=${EVO_V16_INCLUDE_REPLAY}"

"$PY" "${ROOT}/openevolve-run.py" \
  "${ROOT}/initial_program.py" \
  "${ROOT}/evaluator_v16_full_perception.py" \
  --config "${ROOT}/config_yaml_policy.yaml" \
  --output "${OUT}" \
  --iterations "${EVO_ITERATIONS:-40}"

export EVO_V14C_COUPLED_JOINT=0

export EVO_V15_MIN_OVERLAP=${EVO_V15_MIN_OVERLAP:-0.0}

export EVO_V15_MAX_CHANGED=${EVO_V15_MAX_CHANGED:-999.0}

export EVO_V15_FEEDBACK_PATH=${EVO_V15_FEEDBACK_PATH:-/data/lz/openevolve_pruner/CDPruner/openevolve/runs/v16_cdpruner_seed_full_perception_K32_fullmme/v16_feedback.jsonl}

export EVO_V15_ANCHOR_PERCEPTION=${EVO_V15_ANCHOR_PERCEPTION:-1404.9353741496598}

export EVO_V15_ANCHOR_RAW=${EVO_V15_ANCHOR_RAW:-1706.3639455782313}

export EVO_V16_BASELINE_SCORE_CACHE=${EVO_V16_BASELINE_SCORE_CACHE:-/data/lz/openevolve_pruner/CDPruner/openevolve/runs/mme_vtn32_cdpruner_clean_score.txt}

export EVO_V16_INCLUDE_REPLAY=${EVO_V16_INCLUDE_REPLAY:-1}
