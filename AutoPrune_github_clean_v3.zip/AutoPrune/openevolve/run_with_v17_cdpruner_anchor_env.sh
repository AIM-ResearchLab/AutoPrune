#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"

V16_ANCHOR_POLICY="${V16_ANCHOR_POLICY:-${CDPRUNER_ROOT}/openevolve/runs/v16_cdpruner_seed_full_perception_K32_fullmme/best/best_policy.yaml}"
DEFAULT_MERGE_POLICY="${CDPRUNER_ROOT}/openevolve/policies/v17_formal/v17_cdpruner_anchor_initial.yaml"

MERGE_POLICY="${1:-$DEFAULT_MERGE_POLICY}"
shift || true

if [ ! -f "$V16_ANCHOR_POLICY" ]; then
  echo "ERROR: v16/CDPruner anchor policy not found: $V16_ANCHOR_POLICY"
  exit 1
fi

if [ ! -f "$MERGE_POLICY" ]; then
  echo "ERROR: UniMerge policy not found: $MERGE_POLICY"
  exit 1
fi

if [ "$#" -eq 0 ]; then
  echo "Usage: $0 <merge_policy_yaml> <command...>"
  exit 1
fi

export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

# CDPruner-specific anchor provider.
export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1

# Important: llava_arch.py actually reads CDPRUNER_POLICY.
export CDPRUNER_POLICY="$V16_ANCHOR_POLICY"

# Keep old EVO variables for compatibility.
export EVO_POLICY_YAML_PATH="$V16_ANCHOR_POLICY"
export EVO_CANDIDATE_POLICY_PATH="$V16_ANCHOR_POLICY"
export EVO_POLICY_YAML="$(cat "$V16_ANCHOR_POLICY")"
export EVO_CANDIDATE_POLICY_YAML="$EVO_POLICY_YAML"

# Universal merge DSL layer.
export EVO_UNIMERGE_ENABLE="${EVO_UNIMERGE_ENABLE:-1}"
export EVO_UNIMERGE_MODE="hybrid_v16_anchor"
export EVO_UNIMERGE_POLICY_PATH="$MERGE_POLICY"
export EVO_UNIMERGE_POLICY_YAML="$(cat "$MERGE_POLICY")"
export EVO_UNIMERGE_DEBUG="${EVO_UNIMERGE_DEBUG:-0}"
export EVO_UNIMERGE_OUTPUT_MODE="${EVO_UNIMERGE_OUTPUT_MODE:-inplace_full}"

export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"

if [ -n "${EVO_GPU:-}" ]; then
  export CUDA_VISIBLE_DEVICES="${EVO_GPU}"
fi

echo "=== v17 CDPruner-anchored UniMerge ==="
echo "Anchor provider: cdpruner_v16"
echo "V16 anchor policy: $V16_ANCHOR_POLICY"
echo "Merge policy: $MERGE_POLICY"
echo "CDPRUNER_POLICY=${CDPRUNER_POLICY}"
echo "EVO_GPU=${EVO_GPU:-unset}"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-unset}"
echo "EVO_TOKEN=${EVO_TOKEN}"
echo "EVO_UNIMERGE_MODE=${EVO_UNIMERGE_MODE}"
echo "EVO_UNIMERGE_ENABLE=${EVO_UNIMERGE_ENABLE}"
echo "EVO_UNIMERGE_OUTPUT_MODE=${EVO_UNIMERGE_OUTPUT_MODE}"

exec "$@"
