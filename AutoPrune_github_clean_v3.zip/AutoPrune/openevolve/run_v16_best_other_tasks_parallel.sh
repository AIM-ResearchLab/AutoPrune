#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_TOKEN}"
export EVO_EVAL_TIMEOUT="${EVO_EVAL_TIMEOUT:-14400}"

LOGDIR="openevolve/runs/v16_best_1405_other_tasks_parallel"
mkdir -p "$LOGDIR"

GPUS=(2 3 4 6)

TASKS=(
  pope
  mmbench
  mmbench_cn
  textvqa
  gqa
  sqa
  vizwiz
  vqav2
  mmvet
)

archive_modified_files() {
  local marker="$1"
  local out_list="$2"
  local archive_dir="$3"

  mkdir -p "$archive_dir"

  find playground/data/eval -type f -newer "$marker" | sort > "$out_list" || true

  while IFS= read -r f; do
    [ -f "$f" ] || continue
    rel="$f"
    mkdir -p "$archive_dir/$(dirname "$rel")"
    cp -a "$f" "$archive_dir/$rel" || true
  done < "$out_list"
}

run_one() {
  local gpu="$1"
  local task="$2"
  local variant="$3"

  local script="scripts/v1_5/eval/${task}.sh"
  local log="${LOGDIR}/${task}_${variant}.log"
  local marker="${LOGDIR}/${task}_${variant}.marker"
  local modified="${LOGDIR}/${task}_${variant}_modified_files.txt"
  local archive="${LOGDIR}/archive/${task}_${variant}"

  if [ ! -f "$script" ]; then
    echo "[GPU ${gpu}] SKIP missing script: $script" | tee -a "$log"
    return 0
  fi

  echo
  echo "=============================="
  echo "[GPU ${gpu}] TASK=${task} VARIANT=${variant}"
  echo "SCRIPT=${script}"
  echo "TOKEN=${EVO_TOKEN}"
  echo "=============================="

  touch "$marker"

  if [ "$variant" = "clean" ]; then
    timeout "${EVO_EVAL_TIMEOUT}" \
      env EVO_GPU="$gpu" EVO_TOKEN="$EVO_TOKEN" EVO_FORCE_FIXED_TOKENS="$EVO_TOKEN" \
      openevolve/run_clean_cdpruner_env.sh bash "$script" "$EVO_TOKEN" \
      2>&1 | tee "$log" || echo "[GPU ${gpu}] CLEAN failed: $task" | tee -a "$log"
  elif [ "$variant" = "v16_best" ]; then
    timeout "${EVO_EVAL_TIMEOUT}" \
      env EVO_GPU="$gpu" EVO_TOKEN="$EVO_TOKEN" EVO_FORCE_FIXED_TOKENS="$EVO_TOKEN" \
      openevolve/run_with_v16_best_policy_env.sh bash "$script" "$EVO_TOKEN" \
      2>&1 | tee "$log" || echo "[GPU ${gpu}] V16_BEST failed: $task" | tee -a "$log"
  else
    echo "Unknown variant: $variant" | tee -a "$log"
    return 1
  fi

  archive_modified_files "$marker" "$modified" "$archive"

  echo "[GPU ${gpu}] finished ${task} ${variant}" | tee -a "$log"
  echo "[GPU ${gpu}] modified files saved to $modified" | tee -a "$log"
  echo "[GPU ${gpu}] archive saved to $archive" | tee -a "$log"
}

worker() {
  local gpu="$1"
  local worker_id="$2"
  local n_gpus="${#GPUS[@]}"

  echo "[GPU ${gpu}] worker ${worker_id} started"

  for i in "${!TASKS[@]}"; do
    if [ $(( i % n_gpus )) -ne "$worker_id" ]; then
      continue
    fi

    task="${TASKS[$i]}"

    run_one "$gpu" "$task" clean
    run_one "$gpu" "$task" v16_best
  done

  echo "[GPU ${gpu}] worker ${worker_id} finished"
}

for idx in "${!GPUS[@]}"; do
  gpu="${GPUS[$idx]}"
  worker "$gpu" "$idx" > "${LOGDIR}/worker_gpu${gpu}.log" 2>&1 &
  echo "started worker gpu=${gpu}, pid=$!"
done

wait

echo "All workers finished."
echo "Logs: $LOGDIR"
