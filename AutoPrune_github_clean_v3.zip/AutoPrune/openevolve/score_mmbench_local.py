from pathlib import Path
import re
import pandas as pd

ROOT = Path("/data/lz/openevolve_pruner/CDPruner")

TASKS = {
    "mmbench": {
        "tsv": ROOT / "playground/data/eval/mmbench/mmbench_dev_20230712.tsv",
        "upload_dir": ROOT / "playground/data/eval/mmbench/answers_upload/mmbench_dev_20230712/llava-v1.5-7b",
        "prefix": "vtn_32_v16_best_1405p1568_mmbench_seed",
    },
    "mmbench_cn": {
        "tsv": ROOT / "playground/data/eval/mmbench_cn/mmbench_dev_cn_20231003.tsv",
        "upload_dir": ROOT / "playground/data/eval/mmbench_cn/answers_upload/mmbench_dev_cn_20231003/llava-v1.5-7b",
        "prefix": "vtn_32_v16_best_1405p1568_mmbench_cn_seed",
    },
}

def norm_ans(x):
    if pd.isna(x):
        return ""
    s = str(x).strip()
    m = re.search(r"\b([A-D])\b", s.upper())
    return m.group(1) if m else s.upper()

for task, cfg in TASKS.items():
    print(f"\n========== {task} ==========")
    tsv = cfg["tsv"]
    if not tsv.exists():
        print("TSV missing:", tsv)
        continue

    gt = pd.read_csv(tsv, sep="\t")
    print("GT columns:", list(gt.columns)[:20])

    if "index" not in gt.columns or "answer" not in gt.columns:
        print("Cannot score locally: TSV has no index/answer columns.")
        continue

    gt = gt[["index", "answer"]].copy()
    gt["index"] = gt["index"].astype(str)
    gt["answer_norm"] = gt["answer"].map(norm_ans)

    for seed in [42, 43, 44]:
        xlsx = cfg["upload_dir"] / f"{cfg['prefix']}{seed}.xlsx"
        if not xlsx.exists():
            print(f"seed {seed}: missing {xlsx}")
            continue

        pred = pd.read_excel(xlsx)
        print(f"\nseed {seed} file: {xlsx}")
        print("Pred columns:", list(pred.columns)[:20])

        if "index" not in pred.columns:
            print("No index column; cannot join.")
            continue

        pred_col = None
        for c in ["prediction", "pred", "answer", "output"]:
            if c in pred.columns:
                pred_col = c
                break

        if pred_col is None:
            # fallback: use the last non-index column
            candidates = [c for c in pred.columns if c != "index"]
            if candidates:
                pred_col = candidates[-1]

        if pred_col is None:
            print("No prediction-like column found.")
            continue

        pred = pred[["index", pred_col]].copy()
        pred["index"] = pred["index"].astype(str)
        pred["pred_norm"] = pred[pred_col].map(norm_ans)

        merged = gt.merge(pred, on="index", how="inner")
        if len(merged) == 0:
            print("No matched rows.")
            continue

        acc = (merged["answer_norm"] == merged["pred_norm"]).mean() * 100
        print(f"matched={len(merged)} / gt={len(gt)}")
        print(f"accuracy={acc:.2f}")
