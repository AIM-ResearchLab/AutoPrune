from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Dict, Tuple

import yaml

from openevolve.v15_full_perception_bandit import (
    _policy_fingerprint,
    _policy_to_program,
    _feedback_path,
)


ROOT = Path("/data/lz/openevolve_pruner/CDPruner")
V14A_BEST = ROOT / "openevolve/runs/v14_a_processing_grid/policies/0040_v14a_from_real0021_semmerge_a0p01_t1_g0p65.yaml"

ANCHOR_CLEAN_PERCEPTION = 1382.8248299319728
TARGET_V14A_PERCEPTION = 1404.9353741496598


def _score_pipeline(*, center_bias: float = 1.0, weights: Dict[str, float] | None = None) -> list:
    if weights is None:
        weights = {
            "semantic": 0.30,
            "attn": 0.10,
            "spatial": 0.10,
            "redundancy": 0.07,
            "contrast": 0.06,
        }

    return [
        {"op": "compute_score", "name": "native_teacher_mask_prior", "params": {"keep_tokens": 32}, "output": "reference_score"},
        {"op": "compute_score", "name": "instruction_guided_visual_relevance", "output": "semantic_score"},
        {"op": "compute_score", "name": "attention_proxy_saliency", "output": "attn_score"},
        {"op": "compute_score", "name": "spatial_centrality_prior", "params": {"center_bias": float(center_bias), "transform": "minmax"}, "output": "spatial_score"},
        {"op": "compute_score", "name": "redundancy_density_penalty", "params": {"transform": "minmax"}, "output": "redundancy_score"},
        {"op": "compute_score", "name": "local_contrast_saliency", "output": "contrast_score"},
        {"op": "compute_kernel", "name": "pairwise_cosine_kernel", "output": "sim_kernel"},
        {
            "op": "product_fuse_score",
            "name": "weighted_product_fusion",
            "inputs": {
                "scores": {
                    "semantic": "semantic_score",
                    "attn": "attn_score",
                    "spatial": "spatial_score",
                    "redundancy": "redundancy_score",
                    "contrast": "contrast_score",
                }
            },
            "params": {"weights": dict(weights)},
            "output": "quality_score",
        },
    ]


def _residual_selector(
    *,
    replace_quota: int = 2,
    min_reference_keep: int = 30,
    diversity_lambda: float = 0.08,
    reference_keep_weight: float = 0.20,
    candidate_quality_power: float = 1.0,
) -> dict:
    return {
        "op": "select",
        "name": "native_reference_residual_exchange_selector",
        "inputs": {
            "quality": "quality_score",
            "reference": "reference_score",
            "kernel": "sim_kernel",
        },
        "params": {
            "replace_quota": int(replace_quota),
            "min_reference_keep": int(min_reference_keep),
            "diversity_lambda": float(diversity_lambda),
            "reference_keep_weight": float(reference_keep_weight),
            "candidate_quality_power": float(candidate_quality_power),
            "sort_selected": True,
        },
        "output": "selected",
    }


def _margin_selector(
    *,
    max_replace_quota: int = 2,
    margin_threshold: float = 0.0,
    diversity_lambda: float = 0.08,
    reference_keep_weight: float = 0.20,
    candidate_quality_power: float = 1.0,
) -> dict:
    return {
        "op": "select",
        "name": "native_reference_margin_gated_exchange_selector",
        "inputs": {
            "quality": "quality_score",
            "reference": "reference_score",
            "kernel": "sim_kernel",
        },
        "params": {
            "max_replace_quota": int(max_replace_quota),
            "margin_threshold": float(margin_threshold),
            "diversity_lambda": float(diversity_lambda),
            "reference_keep_weight": float(reference_keep_weight),
            "candidate_quality_power": float(candidate_quality_power),
            "sort_selected": True,
        },
        "output": "selected",
    }


def _semantic_process(
    *,
    alpha: float = 0.010,
    top_k: int = 1,
    gate: float = 0.65,
    temp: float = 0.07,
) -> dict:
    return {
        "op": "process_tokens",
        "name": "semantic_gated_residual_merge",
        "inputs": {
            "features": "image_features",
            "selected": "selected",
            "quality": "quality_score",
            "semantic": "semantic_score",
            "kernel": "sim_kernel",
        },
        "params": {
            "norm_preserve": True,
            "merge_alpha": float(alpha),
            "top_merge_neighbors": int(top_k),
            "temperature": float(temp),
            "semantic_gate_threshold": float(gate),
        },
        "output": "processed_features",
    }


def _similarity_process(*, alpha: float = 0.006, top_k: int = 1, temp: float = 0.07) -> dict:
    return {
        "op": "process_tokens",
        "name": "similarity_weighted_residual_merge",
        "inputs": {
            "features": "image_features",
            "selected": "selected",
            "quality": "quality_score",
            "kernel": "sim_kernel",
        },
        "params": {
            "norm_preserve": True,
            "merge_alpha": float(alpha),
            "top_merge_neighbors": int(top_k),
            "temperature": float(temp),
        },
        "output": "processed_features",
    }


def _make_policy(name: str, pipeline: list, meta: Dict[str, Any]) -> Dict[str, Any]:
    policy = {
        "policy_name": name,
        "name": name,
        "keep_tokens": 32,
        "pipeline": pipeline,
        "meta": {
            "method": "v16_cdpruner_seed_full_perception",
            "objective": "full_mme_perception_only",
            "base_source": "clean_cdpruner_k32_baseline",
            "clean_baseline_perception": ANCHOR_CLEAN_PERCEPTION,
            "target_v14a_perception": TARGET_V14A_PERCEPTION,
            **meta,
        },
    }
    policy["policy_fp"] = _policy_fingerprint(policy)
    return policy


def _load_v14a_replay(iteration: int) -> Dict[str, Any]:
    if not V14A_BEST.exists():
        raise FileNotFoundError(f"V14A best policy not found: {V14A_BEST}")

    policy = yaml.safe_load(V14A_BEST.read_text())
    name = f"v16_i{iteration:04d}_replay_v14a_1404p935"
    policy["policy_name"] = name
    policy["name"] = name
    policy["keep_tokens"] = 32
    policy.setdefault("meta", {})
    policy["meta"].update({
        "method": "v16_cdpruner_seed_full_perception",
        "mutation_family": "replay_v14a_best",
        "mutation_detail": {"source": str(V14A_BEST)},
        "objective": "full_mme_perception_only",
        "base_source": "clean_cdpruner_k32_baseline",
        "clean_baseline_perception": ANCHOR_CLEAN_PERCEPTION,
        "target_v14a_perception": TARGET_V14A_PERCEPTION,
    })
    policy["policy_fp"] = _policy_fingerprint(policy)
    return policy


def _plan(iteration: int) -> Tuple[str, Dict[str, Any], Dict[str, Any]]:
    include_replay = os.environ.get("EVO_V16_INCLUDE_REPLAY", "1").strip() != "0"

    plans = []

    if include_replay:
        plans.append(("replay_v14a_best", {"replay": True}, {}))

    # A. residual exchange: reproduce and vary the known useful family.
    plans += [
        ("residual_q2_no_process", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "none"}, {}),
        ("residual_q2_sem_a010", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.010, "gate": 0.65}, {}),
        ("residual_q1_sem_a010", {"selector": "residual", "q": 1, "min_ref": 31, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.010, "gate": 0.65}, {}),
        ("residual_q3_sem_a008", {"selector": "residual", "q": 3, "min_ref": 29, "div": 0.10, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.008, "gate": 0.65}, {}),
    ]

    # B. position-recovery: v14-A improved count/color but hurt position, so try spatially safer variants.
    plans += [
        ("position_recovery_spatial_high", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.10, "refw": 0.22, "power": 1.00, "process": "semantic", "alpha": 0.010, "gate": 0.65},
         {"center_bias": 0.75, "weights": {"semantic": 0.28, "attn": 0.10, "spatial": 0.16, "redundancy": 0.07, "contrast": 0.06}}),
        ("position_recovery_less_center", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.12, "refw": 0.22, "power": 1.00, "process": "semantic", "alpha": 0.008, "gate": 0.65},
         {"center_bias": 0.50, "weights": {"semantic": 0.28, "attn": 0.10, "spatial": 0.14, "redundancy": 0.08, "contrast": 0.06}}),
        ("position_recovery_no_process", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.12, "refw": 0.22, "power": 1.00, "process": "none"},
         {"center_bias": 0.75, "weights": {"semantic": 0.28, "attn": 0.10, "spatial": 0.16, "redundancy": 0.07, "contrast": 0.06}}),
    ]

    # C. margin-gated variants: allow safer exchange from clean baseline.
    plans += [
        ("margin_m001_sem", {"selector": "margin", "max_q": 2, "margin": -0.01, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.010, "gate": 0.65}, {}),
        ("margin_000_sem", {"selector": "margin", "max_q": 2, "margin": 0.00, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.010, "gate": 0.65}, {}),
        ("margin_001_sem", {"selector": "margin", "max_q": 2, "margin": 0.01, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.010, "gate": 0.65}, {}),
        ("margin_position_safe", {"selector": "margin", "max_q": 2, "margin": 0.00, "div": 0.12, "refw": 0.22, "power": 1.00, "process": "semantic", "alpha": 0.008, "gate": 0.65},
         {"center_bias": 0.75, "weights": {"semantic": 0.28, "attn": 0.10, "spatial": 0.16, "redundancy": 0.07, "contrast": 0.06}}),
    ]

    # D. processing variants.
    plans += [
        ("sem_alpha_006", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.006, "gate": 0.65}, {}),
        ("sem_alpha_012", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.012, "gate": 0.65}, {}),
        ("sem_gate_060", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "semantic", "alpha": 0.010, "gate": 0.60}, {}),
        ("sim_process_a006", {"selector": "residual", "q": 2, "min_ref": 30, "div": 0.08, "refw": 0.20, "power": 1.00, "process": "similarity", "alpha": 0.006}, {}),
    ]

    idx = (iteration - 1) % len(plans)
    return plans[idx]


def build_v16_policy_and_program(
    iteration: int,
    parent: Any = None,
    inspirations: Any = None,
    config: Any = None,
) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
    iteration = max(1, int(iteration))
    family, edit, aux = _plan(iteration)

    if edit.get("replay"):
        policy = _load_v14a_replay(iteration)
    else:
        center_bias = float(aux.get("center_bias", 1.0))
        weights = aux.get("weights", None)

        pipeline = _score_pipeline(center_bias=center_bias, weights=weights)

        if edit["selector"] == "residual":
            pipeline.append(_residual_selector(
                replace_quota=edit.get("q", 2),
                min_reference_keep=edit.get("min_ref", 30),
                diversity_lambda=edit.get("div", 0.08),
                reference_keep_weight=edit.get("refw", 0.20),
                candidate_quality_power=edit.get("power", 1.00),
            ))
        elif edit["selector"] == "margin":
            pipeline.append(_margin_selector(
                max_replace_quota=edit.get("max_q", 2),
                margin_threshold=edit.get("margin", 0.0),
                diversity_lambda=edit.get("div", 0.08),
                reference_keep_weight=edit.get("refw", 0.20),
                candidate_quality_power=edit.get("power", 1.00),
            ))
        else:
            raise ValueError(f"unknown selector: {edit['selector']}")

        if edit.get("process") == "semantic":
            pipeline.append(_semantic_process(
                alpha=edit.get("alpha", 0.010),
                top_k=edit.get("top_k", 1),
                gate=edit.get("gate", 0.65),
                temp=edit.get("temp", 0.07),
            ))
        elif edit.get("process") == "similarity":
            pipeline.append(_similarity_process(
                alpha=edit.get("alpha", 0.006),
                top_k=edit.get("top_k", 1),
                temp=edit.get("temp", 0.07),
            ))
        elif edit.get("process") in ("none", None):
            pass
        else:
            raise ValueError(f"unknown process: {edit.get('process')}")

        tag = family
        name = f"v16_i{iteration:04d}_{tag}"
        policy = _make_policy(
            name=name,
            pipeline=pipeline,
            meta={
                "iteration": iteration,
                "mutation_family": family,
                "mutation_detail": edit,
                "aux": aux,
            },
        )

    program = _policy_to_program(policy)
    policy["__program_code__"] = program

    meta = {
        "name": policy.get("name"),
        "policy_fp": policy.get("policy_fp"),
        "mutation_family": family,
        "mutation_detail": edit,
        "aux": aux,
        "feedback_path": str(_feedback_path()),
        "last_op": policy.get("pipeline", [{}])[-1].get("op"),
        "last_name": policy.get("pipeline", [{}])[-1].get("name"),
    }
    return policy, program, meta
