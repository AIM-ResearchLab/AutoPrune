from __future__ import annotations
from pathlib import Path

def seed_policy_yaml() -> str:
    p = Path("configs/v5_full_token_seed_soft_cdpruner_prior.yaml")
    return p.read_text() if p.exists() else ""
