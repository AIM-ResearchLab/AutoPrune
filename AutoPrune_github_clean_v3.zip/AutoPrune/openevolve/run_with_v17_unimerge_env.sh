#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"
DEFAULT_POLICY="${CDPRUNER_ROOT}/openevolve/policies/v17_universal_merge_init.yaml"

POLICY_YAML="${1:-$DEFAULT_POLICY}"
shift || true

if [ ! -f "$POLICY_YAML" ]; then
  echo "ERROR: policy yaml not found: $POLICY_YAML"
  exit 1
fi

if [ "$#" -eq 0 ]; then
  echo "Usage: $0 <policy_yaml> <command...>"
  exit 1
fi

export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

export EVO_UNIMERGE_ENABLE=1
export EVO_UNIMERGE_POLICY_PATH="$POLICY_YAML"
export EVO_UNIMERGE_POLICY_YAML="$(cat "$POLICY_YAML")"
export EVO_UNIMERGE_DEBUG="${EVO_UNIMERGE_DEBUG:-1}"

# Important: do not enable old CDPruner branch here.
unset EVO_CDPRUNER_ENABLE
unset EVO_CDPRUNER_V14_ENABLE
unset EVO_CANDIDATE_POLICY_YAML
unset EVO_CANDIDATE_POLICY_PATH
unset EVO_POLICY_YAML
unset EVO_POLICY_YAML_PATH

export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"

if [ -n "${EVO_GPU:-}" ]; then
  export CUDA_VISIBLE_DEVICES="${EVO_GPU}"
fi

echo "Using UniMerge policy: $POLICY_YAML"
echo "EVO_GPU=${EVO_GPU:-unset}"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-unset}"
echo "EVO_TOKEN=${EVO_TOKEN}"
echo "EVO_UNIMERGE_ENABLE=${EVO_UNIMERGE_ENABLE}"

exec "$@"
