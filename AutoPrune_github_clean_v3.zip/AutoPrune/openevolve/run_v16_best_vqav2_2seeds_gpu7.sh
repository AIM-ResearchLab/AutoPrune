#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_TOKEN}"
export EVO_EVAL_TIMEOUT="${EVO_EVAL_TIMEOUT:-72000}"

LOGDIR="openevolve/runs/v16_best_1405_vqav2_2seeds_gpu7"
mkdir -p "$LOGDIR"

GPU=7
TASK=vqav2
SCRIPT="scripts/v1_5/eval_named/vqav2_named.sh"
SEEDS=(42 43)

if [ ! -f "$SCRIPT" ]; then
  echo "missing script: $SCRIPT"
  exit 1
fi

for seed in "${SEEDS[@]}"; do
  param="vtn_32_v16_best_1405p1568_vqav2_seed${seed}"
  log="${LOGDIR}/vqav2_seed${seed}_v16_best.log"

  echo "=============================="
  echo "[GPU ${GPU}] TASK=vqav2 SEED=${seed}"
  echo "SCRIPT=${SCRIPT}"
  echo "PARAM=${param}"
  echo "=============================="

  timeout "${EVO_EVAL_TIMEOUT}" \
    env \
      EVO_GPU="$GPU" \
      EVO_TOKEN="$EVO_TOKEN" \
      EVO_FORCE_FIXED_TOKENS="$EVO_TOKEN" \
      PYTHONHASHSEED="$seed" \
      SEED="$seed" \
      EVAL_SEED="$seed" \
      LLAVA_EVAL_SEED="$seed" \
      openevolve/run_with_v16_best_policy_env.sh \
      bash "$SCRIPT" "$EVO_TOKEN" "$param" \
    2>&1 | tee "$log" || echo "[GPU ${GPU}] V16_BEST failed: vqav2 seed=${seed}" | tee -a "$log"

  echo "[GPU ${GPU}] finished vqav2 seed=${seed}" | tee -a "$log"
done

echo "VQAv2 2-seed run finished."
