#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

export PYTHONPATH="/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}"
export EVO_GPU="${EVO_GPU:-6}"
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0

RUN_ROOT="openevolve/runs/v17_nonanchor_smoke21"
mkdir -p "$RUN_ROOT"

POLICIES=(
  "openevolve/policies/v17_formal/v17_cdpruner_anchor_initial.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0010.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0030.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0050.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0100.yaml"
)

for P in "${POLICIES[@]}"; do
  NAME="$(basename "$P" .yaml)"
  echo "===== Running $NAME ====="
  mkdir -p "$RUN_ROOT/$NAME"

  openevolve/run_with_v17_cdpruner_anchor_env.sh \
    "$P" \
    bash scripts/v1_5/eval/mme_yaml_smoke21.sh 32 "$NAME" \
    > "$RUN_ROOT/$NAME/mme_smoke21.log" 2>&1

  grep -n "===========\|total score:\|score:" "$RUN_ROOT/$NAME/mme_smoke21.log" \
    | tail -120 \
    | tee "$RUN_ROOT/$NAME/mme_smoke21_score_summary.txt"

  echo "===== Finished $NAME ====="
done
