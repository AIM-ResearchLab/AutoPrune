from pathlib import Path
import re

rounds = ["round1", "round2", "round3", "round4", "confirm_top"]

CLEAN_P = 1382.8248299319728
CLEAN_C = 304.2857142857143

rows = []

for r in rounds:
    root = Path(f"openevolve/runs/v18_llm_nas_{r}_gpu7_seq")
    if not root.exists():
        continue
    for d in root.iterdir():
        if not d.is_dir():
            continue
        summary = d / "mme_full_score_summary.txt"
        status = d / "status.txt"
        if not summary.exists():
            continue

        name = d.name
        anchor = ""
        merge = ""
        if status.exists():
            st = status.read_text(errors="ignore")
            m = re.findall(r"ANCHOR_POLICY=(.*)", st)
            if m: anchor = m[-1]
            m = re.findall(r"MERGE_POLICY=(.*)", st)
            if m: merge = m[-1]

        text = summary.read_text(errors="ignore")
        totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
        vtns = re.findall(r"vtn=(\d+)", text)
        vtn = vtns[-1] if vtns else ""

        if len(totals) >= 2:
            p, c = totals[0], totals[1]
            raw = p + c
            rows.append({
                "round": r,
                "name": name,
                "vtn": vtn,
                "perception": p,
                "cognition": c,
                "raw": raw,
                "delta_p": p - CLEAN_P,
                "delta_c": c - CLEAN_C,
                "anchor": anchor,
                "merge": merge,
            })

rows.sort(key=lambda x: (-x["perception"], -x["raw"], x["round"], x["name"]))

out = Path("openevolve/policies/v18_llm_nas/final/full_leaderboard.md")
with out.open("w") as f:
    f.write("| Rank | Round | Name | VTN | Perception | Cognition | Raw | ΔP clean | ΔC clean |\n")
    f.write("|---:|---|---|---:|---:|---:|---:|---:|---:|\n")
    for i, x in enumerate(rows, 1):
        f.write(
            f"| {i} | {x['round']} | {x['name']} | {x['vtn']} | "
            f"{x['perception']:.2f} | {x['cognition']:.2f} | {x['raw']:.2f} | "
            f"{x['delta_p']:+.2f} | {x['delta_c']:+.2f} |\n"
        )

print(out)
