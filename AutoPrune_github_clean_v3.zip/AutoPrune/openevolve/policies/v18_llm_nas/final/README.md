# v18 LLM NAS Final Policy

Baseline:
- Clean CDPruner K=32
- Perception = 1382.8248
- Cognition = 304.2857

Selected final policy:
- q2_ref30_div019_refw020_cqp102_rs0000
- replace_quota = 2
- min_reference_keep = 30
- diversity_lambda = 0.19
- reference_keep_weight = 0.20
- candidate_quality_power = 1.02
- residual_scale = 0.0

Round4 result:
- Perception = 1411.04
- Cognition = 300.00
- Raw = 1711.04
- Delta Perception over clean CDPruner = +28.21

Interpretation:
- Main gain comes from LLM-guided trust-region token-set editing.
- Embedding residual is useful but not the strongest final variant.
