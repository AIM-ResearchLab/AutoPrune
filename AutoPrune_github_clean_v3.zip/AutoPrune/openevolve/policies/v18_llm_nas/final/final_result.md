# v18 LLM-Guided DSL NAS Final Result

## Baseline

Clean CDPruner K=32:

| Metric | Value |
|---|---:|
| Perception | 1382.8248 |
| Cognition | 304.2857 |
| Raw | 1687.1105 |
| VTN | 32 |

## Final Policy

Policy name:

`q2_ref30_div019_refw020_cqp102_rs0000`

DSL parameters:

| Parameter | Value |
|---|---:|
| replace_quota | 2 |
| min_reference_keep | 30 |
| diversity_lambda | 0.19 |
| reference_keep_weight | 0.20 |
| candidate_quality_power | 1.02 |
| residual_scale | 0.0 |

## Confirmed Result

| Candidate | VTN | Perception | Cognition | Raw | ΔP clean | ΔC clean |
|---|---:|---:|---:|---:|---:|---:|
| best_round4_anchor_only | 32 | 1411.04 | 300.00 | 1711.04 | +28.21 | -4.29 |

## Interpretation

The strongest policy discovered by LLM-guided DSL NAS is an anchor-only trust-region token-set editing policy. It keeps the token budget fixed at 32 and only allows a small edit over the CDPruner-selected token set. The main performance gain comes from constrained token-set replacement rather than embedding residual refinement.

The confirmed final policy improves MME Perception from 1382.82 to 1411.04, giving +28.21 over the clean CDPruner K=32 baseline.
