from pathlib import Path
import re

root = Path("openevolve/runs/v18_twolevel_initial_and_search_gpu7_seq_fixed")
rows = []

for d in sorted(root.iterdir()):
    if not d.is_dir():
        continue

    summary = d / "mme_full_score_summary.txt"
    status = d / "status.txt"

    info = {
        "phase": "",
        "name": d.name,
        "anchor": "",
        "merge": "",
        "exit": "NA",
    }

    if status.exists():
        st = status.read_text(errors="ignore")
        for key, out_key in [
            ("PHASE", "phase"),
            ("NAME", "name"),
            ("ANCHOR_POLICY", "anchor"),
            ("MERGE_POLICY", "merge"),
            ("EXIT_CODE", "exit"),
        ]:
            m = re.findall(rf"{key}=(.*)", st)
            if m:
                info[out_key] = m[-1]

    if not summary.exists():
        rows.append((info, None, None, None, "", "no_summary"))
        continue

    text = summary.read_text(errors="ignore")
    totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
    vtns = re.findall(r"vtn=(\d+)", text)
    vtn = vtns[-1] if vtns else ""

    if len(totals) >= 2:
        p, c = totals[0], totals[1]
        rows.append((info, p, c, p + c, vtn, "ok"))
    else:
        note = "json_error" if "JSONDecodeError" in text else "no_score"
        rows.append((info, None, None, None, vtn, note))

baseline_p = None
baseline_raw = None
for info, p, c, raw, vtn, note in rows:
    if info["phase"] == "initial" and p is not None:
        baseline_p = p
        baseline_raw = raw

print("| Name | Phase | Exit | VTN | Perception | Cognition | Raw | Delta P | Delta Raw | Note | Anchor | Merge |")
print("|---|---|---:|---:|---:|---:|---:|---:|---:|---|---|---|")

def sort_key(row):
    info, p, c, raw, vtn, note = row
    if info["phase"] == "initial":
        return (0, 0, info["name"])
    if p is None:
        return (1, 999999, info["name"])
    return (1, -p, info["name"])

for info, p, c, raw, vtn, note in sorted(rows, key=sort_key):
    if p is None:
        print(f"| {info['name']} | {info['phase']} | {info['exit']} | {vtn} |  |  |  |  |  | {note} | `{info['anchor']}` | `{info['merge']}` |")
    else:
        dp = 0.0 if baseline_p is None else p - baseline_p
        dr = 0.0 if baseline_raw is None else raw - baseline_raw
        print(f"| {info['name']} | {info['phase']} | {info['exit']} | {vtn} | {p:.2f} | {c:.2f} | {raw:.2f} | {dp:+.2f} | {dr:+.2f} | {note} | `{info['anchor']}` | `{info['merge']}` |")
