"""
Initial program for v16: clean CDPruner K=32 baseline.

Important:
- This file intentionally does NOT define POLICY_YAML.
- It should trigger the original/default CDPruner path in the evaluator.
- Expected full-MME K=32 perception is around 1382.8248.
"""

def baseline_name():
    return "clean_cdpruner_k32_baseline_no_yaml_policy"
