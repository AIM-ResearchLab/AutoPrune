"""Neutral compact atom-card builder for Evo-CDPruner Search Space v3.1.

V3.1 design goal:
- Let the LLM see as many YAML atoms as possible in a compact way.
- Avoid directional hints such as "GOOD", "BAD", "best family", or "risk".
- Preserve only objective facts: slot/family, executable status, I/O contract,
  parameter choices, compatibility, source, and tags.

The LLM proposes a policy graph from these neutral atom cards.  The typed
compiler in llm_policy_planner.py validates executability and compiles the graph
into the currently supported CDPruner YAML policy format.
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

REGISTRY_PATH = Path(__file__).with_name("atom_registry.yaml")


@dataclass(frozen=True)
class AtomCard:
    id: str
    slot: str
    status: str
    io: str
    params: str
    compatible_with: str = ""
    source: str = ""
    tags: str = ""
    notes: str = ""

    def one_line(self) -> str:
        parts = [
            f"- {self.id}",
            f"slot={self.slot}",
            f"status={self.status}",
            f"io={self.io}",
            f"params={self.params}",
        ]
        if self.compatible_with:
            parts.append(f"compatible={self.compatible_with}")
        if self.source:
            parts.append(f"source={self.source}")
        if self.tags:
            parts.append(f"tags={self.tags}")
        if self.notes:
            parts.append(f"notes={self.notes}")
        return "; ".join(parts)


def _load_registry(path: Optional[Path] = None) -> Dict[str, Any]:
    path = path or REGISTRY_PATH
    if not path.exists():
        return {"metadata": {}, "atoms": [], "policy_families": []}
    with path.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {"metadata": {}, "atoms": [], "policy_families": []}


def _compact_value(x: Any, max_len: int = 96) -> str:
    if x is None:
        return ""
    if isinstance(x, list):
        s = ",".join(map(str, x))
    elif isinstance(x, dict):
        parts = []
        for k, v in x.items():
            if isinstance(v, (str, int, float, bool)):
                parts.append(f"{k}:{v}")
            elif isinstance(v, list):
                parts.append(f"{k}:[{','.join(map(str, v[:8]))}]")
            else:
                parts.append(str(k))
        s = ", ".join(parts)
    else:
        s = str(x)
    return s[:max_len]


def _param_choices(raw: Dict[str, Any]) -> str:
    params = raw.get("params", {}) or {}
    if not isinstance(params, dict):
        return "{}"
    out = []
    for name, spec in params.items():
        if not isinstance(spec, dict):
            continue
        choices = spec.get("choices")
        if isinstance(choices, list):
            out.append(f"{name}={choices}")
        elif "default" in spec:
            out.append(f"{name}=default:{spec.get('default')}")
        elif spec.get("type"):
            out.append(f"{name}:{spec.get('type')}")
    return ", ".join(out) if out else "{}"


def _io_hint(raw: Dict[str, Any], family: str) -> str:
    inputs = raw.get("inputs")
    outputs = raw.get("outputs")
    if inputs or outputs:
        return f"{_compact_value(inputs)} -> {_compact_value(outputs)}"
    if family == "scorer":
        return "ctx(image,text) -> score[B,N]"
    if family == "scorer_similarity":
        return "ctx(image tokens) -> similarity[B,N,N]"
    if family == "fusion":
        return "scores/similarity -> fused score or kernel"
    if family == "selector":
        return "score/kernel + budget -> mask[B,N]"
    if family == "budget":
        return "host/context -> K or keep ratio"
    if family == "protection":
        return "score/mask -> constrained mask[B,N]"
    if family == "action":
        return "mask + tokens -> pruned tokens"
    return "policy slot component"


def _compatibility(raw: Dict[str, Any]) -> str:
    keys = [
        "compatible_selectors",
        "compatible_fusion",
        "compatible_with",
        "requires",
        "outputs",
    ]
    parts = []
    for k in keys:
        if k in raw:
            parts.append(f"{k}={_compact_value(raw.get(k), max_len=80)}")
    return "; ".join(parts)


def build_atom_cards(path: Optional[Path] = None, include_planned: bool = True) -> List[AtomCard]:
    reg = _load_registry(path)
    cards: List[AtomCard] = []
    for raw in reg.get("atoms", []) or []:
        if not isinstance(raw, dict) or "id" not in raw:
            continue
        executable = bool(raw.get("executable_stage1", False))
        if (not executable) and (not include_planned):
            continue
        atom_id = str(raw["id"])
        family = str(raw.get("family", "unknown"))
        tags = raw.get("semantic_tags", [])
        source = raw.get("source", [])
        notes = raw.get("notes") or raw.get("implementation_hint") or ""
        cards.append(
            AtomCard(
                id=atom_id,
                slot=family,
                status="EXEC" if executable else "PLAN",
                io=_io_hint(raw, family),
                params=_param_choices(raw),
                compatible_with=_compatibility(raw),
                source=_compact_value(source, max_len=80),
                tags=_compact_value(tags, max_len=80),
                notes=_compact_value(notes, max_len=120),
            )
        )
    return cards


def grouped_cards_text(max_cards: int = 72, include_planned: bool = True) -> str:
    cards = build_atom_cards(include_planned=include_planned)
    groups: Dict[str, List[AtomCard]] = {}
    for c in cards:
        groups.setdefault(c.slot, []).append(c)
    order = [
        "trigger",
        "target",
        "scorer",
        "scorer_similarity",
        "scorer_budget",
        "fusion",
        "budget",
        "selector",
        "protection",
        "action",
        "unknown",
    ]
    lines: List[str] = []
    used = 0
    total = sum(len(v) for v in groups.values())
    for slot in order:
        items = groups.get(slot, [])
        if not items:
            continue
        lines.append(f"\n[{slot} atoms]")
        for c in items:
            if used >= max_cards:
                lines.append(f"- ... truncated, {total - used} more cards omitted")
                return "\n".join(lines)
            lines.append(c.one_line())
            used += 1
    return "\n".join(lines)


def cards_json(max_cards: int = 96, include_planned: bool = True) -> str:
    cards = build_atom_cards(include_planned=include_planned)[:max_cards]
    return json.dumps([asdict(c) for c in cards], ensure_ascii=False, indent=2)


if __name__ == "__main__":
    print(grouped_cards_text())
