from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict


ROOT = Path("/data/lz/openevolve_pruner/CDPruner")
CLI_EVALUATOR = ROOT / "yaml_policy/openevolve_yaml_search/evaluator.py"


def _parse_first_json(text: str) -> Dict[str, Any]:
    text = text.lstrip()
    decoder = json.JSONDecoder()
    obj, _ = decoder.raw_decode(text)
    if not isinstance(obj, dict):
        raise ValueError("first JSON object is not a dict")
    return obj


def evaluate(program_path: str) -> Dict[str, Any]:
    py = os.environ.get("PYTHON", "/data/lz/conda/env/cdpruner/bin/python")
    gpu = os.environ.get("EVO_GPU", "5")
    token = os.environ.get("EVO_TOKEN", "32")
    script = os.environ.get("EVO_EVAL_SCRIPT", "scripts/v1_5/eval/mme_yaml_smoke21.sh")

    log_dir = ROOT / "openevolve/runs/v14_b_fixed_eval_logs"
    log_dir.mkdir(parents=True, exist_ok=True)

    stem = Path(program_path).stem
    log_path = log_dir / f"{stem}.log"

    env = os.environ.copy()
    env["PYTHONPATH"] = f"{ROOT}:{env.get('PYTHONPATH', '')}"
    env["EVO_CDPRUNER_ENABLE"] = "1"
    env["EVO_CDPRUNER_V14_ENABLE"] = "1"
    env["EVO_V14B_PROCESSING_ONLY"] = env.get("EVO_V14B_PROCESSING_ONLY", "1")
    env["EVO_V14B_STRICT"] = env.get("EVO_V14B_STRICT", "1")

    cmd = [
        py,
        str(CLI_EVALUATOR),
        str(program_path),
        "--gpu",
        str(gpu),
        "--token",
        str(token),
        "--script",
        str(script),
        "--log",
        str(log_path),
    ]

    proc = subprocess.run(
        cmd,
        cwd=str(ROOT),
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True,
    )

    try:
        metrics = _parse_first_json(proc.stdout)
    except Exception as e:
        metrics = {
            "combined_score": 0.0,
            "objective_score": 0.0,
            "raw_combined_score": 0.0,
            "mme_combined_score": 0.0,
            "balanced_score": 0.0,
            "perception": 0.0,
            "cognition": 0.0,
            "valid": 0.0,
            "error": f"v14b_wrapper_parse_error:{repr(e)}",
            "stdout_tail": proc.stdout[-4000:],
        }

    if proc.returncode != 0:
        metrics["valid"] = 0.0
        metrics["error"] = metrics.get("error") or f"v14b_wrapper_eval_failed_returncode_{proc.returncode}"
        metrics["stdout_tail"] = proc.stdout[-4000:]

    # OpenEvolve sometimes expects these aliases.
    raw = float(metrics.get("raw_combined_score", metrics.get("combined_score", 0.0)) or 0.0)
    metrics.setdefault("combined_score", raw)
    metrics.setdefault("objective_score", raw)
    metrics.setdefault("ood_acc", raw)

    metrics["candidate_program_path"] = str(program_path)
    metrics["eval_script"] = script
    metrics["gpu"] = gpu
    metrics["token"] = token

    return metrics
