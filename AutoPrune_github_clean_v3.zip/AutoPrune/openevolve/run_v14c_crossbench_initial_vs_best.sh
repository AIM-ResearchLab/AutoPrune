#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

PY=/data/lz/conda/env/cdpruner/bin/python
RUN=openevolve/runs/v14_c_coupled_joint_K32_rawselect
OUT=openevolve/runs/v14_c_crossbench_initial_vs_best

mkdir -p "$OUT/programs" "$OUT/raw_stdout" "$OUT/json" "$OUT/inner_logs"

export PYTHONPATH=/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}
export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1
export EVO_FORCE_FIXED_TOKENS=32

export EVO_GPU=${EVO_GPU:-4}
export EVO_TOKEN=${EVO_TOKEN:-32}
export EVO_EVAL_TIMEOUT=${EVO_EVAL_TIMEOUT:-7200}

cp openevolve/initial_program.py "$OUT/programs/initial_seed.py"
cp "$RUN/best/best_program.py" "$OUT/programs/smoke_best.py"

echo "===== Cross-benchmark evaluation ====="
echo "GPU=$EVO_GPU"
echo "TOKEN=$EVO_TOKEN"
echo "OUT=$OUT"
echo "initial=$OUT/programs/initial_seed.py"
echo "best=$OUT/programs/smoke_best.py"
echo

pick_script () {
  local regex="$1"
  find scripts/v1_5/eval -maxdepth 1 -type f -name "*.sh" \
    | grep -Ei "$regex" \
    | grep -Evi "smoke|quick|debug|tmp" \
    | sort \
    | head -1
}

declare -A TASK_REGEX
TASK_REGEX["vqav2"]="vqav2|vqa.*v2"
TASK_REGEX["gqa"]="(^|/)gqa"
TASK_REGEX["vizwiz"]="vizwiz"
TASK_REGEX["sqa_img"]="sqa|scienceqa"
TASK_REGEX["textvqa"]="textvqa|text.*vqa|vqa.*text"
TASK_REGEX["pope"]="pope"
TASK_REGEX["mme"]="(^|/)mme\.sh$|(^|/)mme$"
TASK_REGEX["mmb_en"]="mmb.*en|mmbench.*en"
TASK_REGEX["mmb_cn"]="mmb.*cn|mmbench.*cn"
TASK_REGEX["mmvet"]="mmvet|mm-vet"

TASKS=("vqav2" "gqa" "vizwiz" "sqa_img" "textvqa" "pope" "mme" "mmb_en" "mmb_cn" "mmvet")

if [ "${INCLUDE_MME:-1}" = "0" ]; then
  TASKS=("vqav2" "gqa" "vizwiz" "sqa_img" "textvqa" "pope" "mmb_en" "mmb_cn" "mmvet")
fi

echo "===== Resolve eval scripts ====="
: > "$OUT/script_map.tsv"

for task in "${TASKS[@]}"; do
  script=$(pick_script "${TASK_REGEX[$task]}" || true)
  if [ -z "${script:-}" ]; then
    echo -e "$task\tMISSING" | tee -a "$OUT/script_map.tsv"
  else
    echo -e "$task\t$script" | tee -a "$OUT/script_map.tsv"
  fi
done

echo
echo "===== Start sequential evaluation ====="

eval_one () {
  local task="$1"
  local script="$2"
  local label="$3"
  local program="$4"

  local prefix="${task}.${label}"
  local stdout_path="$OUT/raw_stdout/${prefix}.stdout.txt"
  local json_path="$OUT/json/${prefix}.json"
  local inner_log="$OUT/inner_logs/${prefix}.inner.log"

  echo
  echo "========== $task / $label =========="
  echo "script=$script"
  echo "program=$program"
  echo "stdout=$stdout_path"
  echo "json=$json_path"
  date

  export EVO_EVAL_SCRIPT="$script"

  set +e
  "$PY" yaml_policy/openevolve_yaml_search/evaluator.py \
    "$program" \
    --gpu "$EVO_GPU" \
    --token "$EVO_TOKEN" \
    --script "$script" \
    --log "$inner_log" \
    > "$stdout_path" 2>&1
  status=$?
  set -e

  "$PY" - "$stdout_path" "$json_path" "$task" "$label" "$script" "$status" <<'PY'
import json
import re
import sys
from pathlib import Path

stdout_path = Path(sys.argv[1])
json_path = Path(sys.argv[2])
task = sys.argv[3]
label = sys.argv[4]
script = sys.argv[5]
status = int(sys.argv[6])

text = stdout_path.read_text(encoding="utf-8", errors="ignore")

obj = None
for line in text.splitlines():
    line = line.strip()
    if line.startswith("{") and line.endswith("}"):
        try:
            cand = json.loads(line)
            if isinstance(cand, dict):
                obj = cand
        except Exception:
            pass

if obj is None:
    m = re.search(r"\{.*\}", text, flags=re.S)
    if m:
        try:
            cand = json.loads(m.group(0))
            if isinstance(cand, dict):
                obj = cand
        except Exception:
            pass

if obj is None:
    obj = {
        "valid": 0.0,
        "error": "no_json_metrics_found",
        "stdout_tail": text[-4000:],
    }

obj["_task"] = task
obj["_label"] = label
obj["_script"] = script
obj["_returncode"] = status

json_path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
print(json.dumps(obj, ensure_ascii=False))
PY

  echo "finished $task / $label, status=$status"
  date
}

while IFS=$'\t' read -r task script; do
  if [ "$script" = "MISSING" ]; then
    echo "skip $task because eval script is missing"
    continue
  fi

  eval_one "$task" "$script" "initial_seed" "$OUT/programs/initial_seed.py"
  eval_one "$task" "$script" "smoke_best" "$OUT/programs/smoke_best.py"

done < "$OUT/script_map.tsv"

echo
echo "===== Build summary ====="

"$PY" - <<'PY'
import json
from pathlib import Path

OUT = Path("openevolve/runs/v14_c_crossbench_initial_vs_best")
json_dir = OUT / "json"

def pick_score(d):
    keys = [
        "raw_combined_score",
        "mme_combined_score",
        "combined_score",
        "objective_score",
        "score",
        "accuracy",
        "acc",
        "overall",
        "rel",
    ]
    for k in keys:
        v = d.get(k)
        try:
            if v is not None:
                return k, float(v)
        except Exception:
            pass
    return "", None

records = []
for p in sorted(json_dir.glob("*.json")):
    d = json.loads(p.read_text(encoding="utf-8"))
    key, score = pick_score(d)
    records.append({
        "task": d.get("_task"),
        "label": d.get("_label"),
        "script": d.get("_script"),
        "returncode": d.get("_returncode"),
        "valid": d.get("valid"),
        "score_key": key,
        "score": score,
        "perception": d.get("perception"),
        "cognition": d.get("cognition"),
        "raw_combined_score": d.get("raw_combined_score"),
        "combined_score": d.get("combined_score"),
        "error": d.get("error", ""),
    })

by_task = {}
for r in records:
    by_task.setdefault(r["task"], {})[r["label"]] = r

md = []
md.append("| task | initial score | best score | delta | score key | initial valid | best valid | script | error |")
md.append("|---|---:|---:|---:|---|---:|---:|---|---|")

for task in sorted(by_task):
    a = by_task[task].get("initial_seed", {})
    b = by_task[task].get("smoke_best", {})

    ai = a.get("score")
    bi = b.get("score")
    delta = None
    if ai is not None and bi is not None:
        delta = bi - ai

    def fmt(x):
        if x is None:
            return ""
        try:
            return f"{float(x):.4f}"
        except Exception:
            return str(x)

    err = b.get("error") or a.get("error") or ""
    script = b.get("script") or a.get("script") or ""

    md.append(
        f"| {task} | {fmt(ai)} | {fmt(bi)} | {fmt(delta)} | "
        f"{b.get('score_key') or a.get('score_key') or ''} | "
        f"{fmt(a.get('valid'))} | {fmt(b.get('valid'))} | "
        f"{script} | {err} |"
    )

summary = "\n".join(md) + "\n"
print(summary)

(OUT / "summary.md").write_text(summary, encoding="utf-8")
(OUT / "summary.json").write_text(json.dumps(records, indent=2, ensure_ascii=False), encoding="utf-8")

print("summary saved:", OUT / "summary.md")
PY

echo
echo "===== Done ====="
echo "Summary:"
echo "  $OUT/summary.md"
echo "JSON:"
echo "  $OUT/summary.json"
