#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export EVO_GPU=${EVO_GPU:-3}
export EVO_TOKEN=${EVO_TOKEN:-32}
export EVO_FORCE_FIXED_TOKENS=${EVO_FORCE_FIXED_TOKENS:-$EVO_TOKEN}
export V6_FAMILIES=${V6_FAMILIES:-8}
export V6_VARIANTS_PER_FAMILY=${V6_VARIANTS_PER_FAMILY:-12}
export V6_CHUNKS=${V6_CHUNKS:-0,1,2}
export V6_NUM_CHUNKS=${V6_NUM_CHUNKS:-21}
python tools/v6_2_llm_full_token_search.py \
  --gpu "$EVO_GPU" \
  --token "$EVO_TOKEN" \
  --base-script "${EVO_EVAL_SCRIPT:-scripts/v1_5/eval/mme_yaml_smoke21.sh}" \
  --chunks "$V6_CHUNKS" \
  --num-chunks "$V6_NUM_CHUNKS" \
  --families "$V6_FAMILIES" \
  --variants-per-family "$V6_VARIANTS_PER_FAMILY" \
  --out-dir "openevolve/runs/v6_2_reference_prior_K${EVO_TOKEN}_multismoke"
