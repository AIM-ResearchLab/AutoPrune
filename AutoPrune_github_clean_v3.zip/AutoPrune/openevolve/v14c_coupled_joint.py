from __future__ import annotations

import copy
import hashlib
from pathlib import Path
from typing import Any, Dict, List, Tuple

import yaml


BASE_0021_PATH = Path(
    "openevolve/runs/v12_native_reference_full_check/0021_v12_native_balanced_rq02.yaml"
)

V14A_SEED_PATH = Path(
    "openevolve/runs/v14_a_processing_grid/policies/0040_v14a_from_real0021_semmerge_a0p01_t1_g0p65.yaml"
)

ALLOWED_PROCESS_NAMES = {
    "semantic_gated_residual_merge",
    "similarity_weighted_residual_merge",
    "spatial_local_residual_merge",
    "score_rescale_selected_features",
}

BASE_WEIGHTS = {
    "semantic": 0.30,
    "attn": 0.10,
    "spatial": 0.10,
    "redundancy": 0.07,
    "contrast": 0.06,
}

WEIGHT_BOUNDS = {
    "semantic": (0.22, 0.42),
    "attn": (0.05, 0.18),
    "spatial": (0.04, 0.18),
    "redundancy": (0.03, 0.14),
    "contrast": (0.02, 0.12),
}


def _load_yaml(path: Path) -> Dict[str, Any]:
    with path.open("r", encoding="utf-8") as f:
        obj = yaml.safe_load(f)
    if not isinstance(obj, dict):
        raise ValueError(f"invalid yaml object: {path}")
    return obj


def _clamp(x: Any, lo: float, hi: float) -> float:
    try:
        v = float(x)
    except Exception:
        v = lo
    return max(lo, min(hi, v))


def _clamp_int(x: Any, lo: int, hi: int) -> int:
    try:
        v = int(round(float(x)))
    except Exception:
        v = lo
    return max(lo, min(hi, v))


def _selection_base_pipeline() -> List[Dict[str, Any]]:
    """
    Load the v12/0021 token-selection pipeline and remove any post-selection processing.
    """
    if BASE_0021_PATH.exists():
        policy = _load_yaml(BASE_0021_PATH)
    elif V14A_SEED_PATH.exists():
        policy = _load_yaml(V14A_SEED_PATH)
    else:
        raise FileNotFoundError(
            f"Cannot find base policy: {BASE_0021_PATH} or {V14A_SEED_PATH}"
        )

    pipe = []
    for node in policy.get("pipeline", []):
        if not isinstance(node, dict):
            continue
        if node.get("op") == "process_tokens":
            continue
        pipe.append(copy.deepcopy(node))
    return pipe


def _find_node(pipe: List[Dict[str, Any]], op: str, name: str | None = None) -> Dict[str, Any] | None:
    for node in pipe:
        if node.get("op") != op:
            continue
        if name is not None and node.get("name") != name:
            continue
        return node
    return None


def _sanitize_weights(weights: Dict[str, Any]) -> Dict[str, float]:
    out = {}
    for k, base_v in BASE_WEIGHTS.items():
        lo, hi = WEIGHT_BOUNDS[k]
        out[k] = round(_clamp(weights.get(k, base_v), lo, hi), 4)
    return out


def _selection_variant(iteration: int) -> Dict[str, Any]:
    """
    Local-joint selection search around 0021.

    Design:
    - keep_tokens remains 32.
    - replace_quota controls how many reference tokens can be exchanged.
    - min_reference_keep is coupled with replace_quota.
    - weights are local perturbations around the strong 0021 product-fusion weights.
    """
    # Exploit-biased local joint search.
    # The first smoke test showed q=1 improves, q=4/5 often hurts cognition.
    # Therefore emphasize conservative exchange while keeping limited exploration.
    q_cycle = [1, 1, 2, 1, 2, 3, 1, 2, 3, 4]
    q = q_cycle[(iteration - 1) % len(q_cycle)]

    min_ref_by_q = {
        1: [31, 30],
        2: [30, 29],
        3: [29, 28],
        4: [28, 27],
        5: [27],
    }
    min_ref = min_ref_by_q[q][((iteration - 1) // len(q_cycle)) % len(min_ref_by_q[q])]

    # Local weight perturbation patterns.
    # Avoid huge jumps; keep the search anchored.
    weight_patterns = [
        {},
        {"semantic": +0.04, "attn": -0.02},
        {"semantic": -0.04, "attn": +0.04},
        {"semantic": +0.03, "spatial": +0.03, "redundancy": -0.02},
        {"semantic": -0.02, "contrast": +0.04, "attn": +0.02},
        {"spatial": +0.05, "redundancy": +0.02, "semantic": -0.03},
        {"redundancy": +0.04, "contrast": +0.03, "attn": -0.02},
        {"attn": +0.06, "semantic": -0.03},
        {"contrast": +0.05, "spatial": -0.02},
        {"semantic": +0.06, "contrast": -0.02},
        {"attn": +0.03, "spatial": +0.04, "redundancy": +0.02},
        {"semantic": -0.05, "redundancy": +0.05, "contrast": +0.04},
    ]
    pat = weight_patterns[((iteration - 1) // 3) % len(weight_patterns)]
    weights = dict(BASE_WEIGHTS)
    for k, delta in pat.items():
        weights[k] = weights.get(k, BASE_WEIGHTS[k]) + delta
    weights = _sanitize_weights(weights)

    diversity_values = [0.04, 0.06, 0.08, 0.10, 0.12, 0.15, 0.18]
    ref_weight_values = [0.10, 0.15, 0.20, 0.25, 0.30]
    power_values = [0.8, 1.0, 1.2, 1.4]

    diversity_lambda = diversity_values[((iteration - 1) // 5) % len(diversity_values)]
    reference_keep_weight = ref_weight_values[((iteration - 1) // 7) % len(ref_weight_values)]
    candidate_quality_power = power_values[((iteration - 1) // 11) % len(power_values)]

    return {
        "weights": weights,
        "selector": {
            "replace_quota": q,
            "min_reference_keep": min_ref,
            "diversity_lambda": round(diversity_lambda, 4),
            "reference_keep_weight": round(reference_keep_weight, 4),
            "candidate_quality_power": round(candidate_quality_power, 4),
            "sort_selected": True,
        },
    }


def _coupled_processing_variant(iteration: int, selector: Dict[str, Any]) -> Dict[str, Any]:
    """
    Coupled rule:
    - If replace_quota is small, we can use moderately stronger processing.
    - If replace_quota is large, processing must be conservative.
    - top_k>=2 also reduces alpha.
    """
    q = _clamp_int(selector.get("replace_quota", 2), 1, 5)

    module_cycle = [
        "semantic_gated_residual_merge",
        "similarity_weighted_residual_merge",
        "semantic_gated_residual_merge",
        "spatial_local_residual_merge",
        "similarity_weighted_residual_merge",
        "score_rescale_selected_features",
    ]
    name = module_cycle[((iteration - 1) // 4) % len(module_cycle)]

    top_k_values = [1, 2, 1, 3, 2]
    top_k = top_k_values[(iteration - 1) % len(top_k_values)]

    # Conservative alpha when selection is more aggressive.
    if q <= 2:
        alpha_pool = [0.004, 0.006, 0.008, 0.010, 0.012, 0.016, 0.020, 0.025]
    elif q == 3:
        alpha_pool = [0.003, 0.004, 0.006, 0.008, 0.010, 0.012, 0.014]
    else:
        alpha_pool = [0.002, 0.003, 0.004, 0.006, 0.008, 0.010, 0.012]

    alpha = alpha_pool[((iteration - 1) // 2) % len(alpha_pool)]
    if top_k >= 2:
        alpha = min(alpha, 0.014 if q <= 2 else 0.010)

    temp_pool = [0.05, 0.07, 0.10, 0.15]
    temperature = temp_pool[((iteration - 1) // 13) % len(temp_pool)]

    if name == "semantic_gated_residual_merge":
        gate_pool = [0.50, 0.55, 0.60, 0.65, 0.70, 0.75, 0.80]
        gate = gate_pool[((iteration - 1) // 3) % len(gate_pool)]
        return {
            "name": name,
            "params": {
                "norm_preserve": True,
                "merge_alpha": round(alpha, 4),
                "top_merge_neighbors": int(top_k),
                "temperature": float(temperature),
                "semantic_gate_threshold": float(gate),
            },
        }

    if name == "similarity_weighted_residual_merge":
        quality_gate_pool = [0.0, 0.05, 0.10, 0.20, 0.30]
        quality_gate = quality_gate_pool[((iteration - 1) // 5) % len(quality_gate_pool)]
        return {
            "name": name,
            "params": {
                "norm_preserve": True,
                "merge_alpha": round(alpha, 4),
                "top_merge_neighbors": int(top_k),
                "temperature": float(temperature),
                "quality_gate_threshold": float(quality_gate),
            },
        }

    if name == "spatial_local_residual_merge":
        radius_pool = [1.5, 2.0, 3.0, 4.0]
        radius = radius_pool[((iteration - 1) // 6) % len(radius_pool)]
        return {
            "name": name,
            "params": {
                "norm_preserve": True,
                "merge_alpha": round(alpha, 4),
                "top_merge_neighbors": int(min(top_k, 2)),
                "temperature": float(temperature),
                "spatial_radius": float(radius),
            },
        }

    # score_rescale_selected_features: use beta instead of alpha.
    beta_pool = [0.002, 0.004, 0.006, 0.008, 0.010, 0.014, 0.020]
    beta = beta_pool[((iteration - 1) // 3) % len(beta_pool)]
    if q >= 4:
        beta = min(beta, 0.010)
    return {
        "name": "score_rescale_selected_features",
        "params": {
            "norm_preserve": True,
            "rescale_beta": float(beta),
            "center_score": True,
        },
    }


def _apply_selection(pipe: List[Dict[str, Any]], selection: Dict[str, Any]) -> None:
    fuse = _find_node(pipe, "product_fuse_score", "weighted_product_fusion")
    if fuse is None:
        raise ValueError("missing weighted_product_fusion node")
    fuse.setdefault("params", {})
    fuse["params"]["weights"] = _sanitize_weights(selection.get("weights", {}))

    sel = _find_node(pipe, "select", "native_reference_residual_exchange_selector")
    if sel is None:
        raise ValueError("missing native_reference_residual_exchange_selector node")
    sel.setdefault("params", {})
    selector = selection.get("selector", {})

    q = _clamp_int(selector.get("replace_quota", 2), 1, 5)
    min_ref = _clamp_int(selector.get("min_reference_keep", 30), 27, 31)
    # hard consistency guard: min_reference_keep should not exceed 32 - q + 1 too much.
    # Keep it local and safe.
    min_ref = max(min_ref, 27)
    min_ref = min(min_ref, 31)

    sel["params"].update({
        "replace_quota": q,
        "min_reference_keep": min_ref,
        "diversity_lambda": round(_clamp(selector.get("diversity_lambda", 0.08), 0.02, 0.18), 4),
        "reference_keep_weight": round(_clamp(selector.get("reference_keep_weight", 0.20), 0.05, 0.35), 4),
        "candidate_quality_power": round(_clamp(selector.get("candidate_quality_power", 1.0), 0.7, 1.5), 4),
        "sort_selected": True,
    })


def _process_node(processing: Dict[str, Any]) -> Dict[str, Any]:
    name = str(processing.get("name", "semantic_gated_residual_merge"))
    if name not in ALLOWED_PROCESS_NAMES:
        name = "semantic_gated_residual_merge"

    params = copy.deepcopy(processing.get("params", {}))
    params["norm_preserve"] = True

    if name in {"semantic_gated_residual_merge", "similarity_weighted_residual_merge", "spatial_local_residual_merge"}:
        params["merge_alpha"] = round(_clamp(params.get("merge_alpha", 0.010), 0.002, 0.030), 4)
        params["top_merge_neighbors"] = _clamp_int(params.get("top_merge_neighbors", 1), 1, 3)
        params["temperature"] = round(_clamp(params.get("temperature", 0.07), 0.04, 0.20), 4)

    if name == "semantic_gated_residual_merge":
        params["semantic_gate_threshold"] = round(_clamp(params.get("semantic_gate_threshold", 0.65), 0.45, 0.85), 4)

    if name == "similarity_weighted_residual_merge":
        params["quality_gate_threshold"] = round(_clamp(params.get("quality_gate_threshold", 0.0), 0.0, 0.35), 4)

    if name == "spatial_local_residual_merge":
        params["spatial_radius"] = round(_clamp(params.get("spatial_radius", 2.0), 1.0, 5.0), 4)

    if name == "score_rescale_selected_features":
        params["rescale_beta"] = round(_clamp(params.get("rescale_beta", 0.006), 0.001, 0.030), 4)
        params["center_score"] = bool(params.get("center_score", True))

    return {
        "op": "process_tokens",
        "name": name,
        "inputs": {
            "features": "image_features",
            "selected": "selected",
            "quality": "quality_score",
            "semantic": "semantic_score",
            "kernel": "sim_kernel",
        },
        "params": params,
        "output": "processed_features",
    }


def _policy_fingerprint(policy: Dict[str, Any]) -> str:
    slim = copy.deepcopy(policy)
    slim.pop("__program_code__", None)
    text = yaml.safe_dump(slim, sort_keys=True, allow_unicode=True)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()[:16]


def _policy_to_program(policy: Dict[str, Any]) -> str:
    policy_for_yaml = copy.deepcopy(policy)
    policy_for_yaml.pop("__program_code__", None)
    yml = yaml.safe_dump(policy_for_yaml, sort_keys=False, allow_unicode=True)
    return (
        '"""OpenEvolve candidate program for v14-C++ coupled local-joint Evo-CDPruner."""\n\n'
        'POLICY_YAML = r"""\n'
        + yml
        + '\n"""\n\n'
        'def get_policy_yaml():\n'
        '    return POLICY_YAML\n'
    )


def build_v14c_policy_and_program(
    iteration: int,
    parent: Any = None,
    inspirations: Any = None,
    config: Any = None,
) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
    iteration = max(1, int(iteration))

    selection = _selection_variant(iteration)
    processing = _coupled_processing_variant(iteration, selection["selector"])

    pipe = _selection_base_pipeline()
    _apply_selection(pipe, selection)
    pipe.append(_process_node(processing))

    selector = selection["selector"]
    proc_name = processing["name"]
    proc_params = processing["params"]

    q = selector["replace_quota"]
    min_ref = selector["min_reference_keep"]

    name_bits = [
        f"q{q}",
        f"mr{min_ref}",
        f"dl{str(selector['diversity_lambda']).replace('.', 'p')}",
        f"rw{str(selector['reference_keep_weight']).replace('.', 'p')}",
        f"pw{str(selector['candidate_quality_power']).replace('.', 'p')}",
        proc_name.replace("_", "")[:10],
    ]
    if "merge_alpha" in proc_params:
        name_bits.append("a" + str(proc_params["merge_alpha"]).replace(".", "p"))
    if "rescale_beta" in proc_params:
        name_bits.append("b" + str(proc_params["rescale_beta"]).replace(".", "p"))
    if "top_merge_neighbors" in proc_params:
        name_bits.append("k" + str(proc_params["top_merge_neighbors"]))

    name = "v14c_coupled_i%04d_" % iteration + "_".join(name_bits)

    policy = {
        "policy_name": name,
        "name": name,
        "keep_tokens": 32,
        "pipeline": pipe,
        "meta": {
            "method": "v14c_coupled_local_joint",
            "iteration": iteration,
            "selection": selection,
            "processing": processing,
            "coupling_rule": "aggressive_selection_uses_conservative_processing",
        },
    }
    policy["policy_fp"] = _policy_fingerprint(policy)

    program = _policy_to_program(policy)
    policy["__program_code__"] = program

    meta = {
        "name": name,
        "policy_fp": policy["policy_fp"],
        "replace_quota": q,
        "min_reference_keep": min_ref,
        "process_name": proc_name,
        "process_params": proc_params,
        "weights": selection["weights"],
    }
    return policy, program, meta
