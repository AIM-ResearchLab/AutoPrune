#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"

DEFAULT_INITIAL="${CDPRUNER_ROOT}/configs/cdpruner_default_policy_v0_5.yaml"
if [ ! -f "$DEFAULT_INITIAL" ]; then
  DEFAULT_INITIAL="${CDPRUNER_ROOT}/openevolve/policies/cdpruner_default_policy_v0_5.yaml"
fi

INITIAL_YAML="${CDPRUNER_INITIAL_POLICY:-$DEFAULT_INITIAL}"

if [ ! -f "$INITIAL_YAML" ]; then
  echo "ERROR: initial policy yaml not found: $INITIAL_YAML"
  echo "Please set CDPRUNER_INITIAL_POLICY=/path/to/your/v16_initial_or_cdpruner_default.yaml"
  exit 1
fi

export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1
export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"

# llava_arch.py actually reads this.
export CDPRUNER_POLICY="$INITIAL_YAML"

# Compatibility variables.
export EVO_POLICY_YAML_PATH="$INITIAL_YAML"
export EVO_CANDIDATE_POLICY_PATH="$INITIAL_YAML"
export EVO_POLICY_YAML="$(cat "$INITIAL_YAML")"
export EVO_CANDIDATE_POLICY_YAML="$EVO_POLICY_YAML"

if [ -n "${EVO_GPU:-}" ]; then
  export CUDA_VISIBLE_DEVICES="${EVO_GPU}"
fi

echo "Using v16 initial/CDPruner default policy: $INITIAL_YAML"
echo "CDPRUNER_POLICY=${CDPRUNER_POLICY}"
echo "EVO_GPU=${EVO_GPU:-unset}"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-unset}"
echo "EVO_TOKEN=${EVO_TOKEN}"

exec "$@"
