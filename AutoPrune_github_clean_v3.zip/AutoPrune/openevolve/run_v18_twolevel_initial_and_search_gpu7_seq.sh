#!/usr/bin/env bash
set -u

cd /data/lz/openevolve_pruner/CDPruner || exit 1

export PYTHONPATH="/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}"
export EVO_GPU=7
export CUDA_VISIBLE_DEVICES=7
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0
export EVO_UNIMERGE_OUTPUT_MODE=inplace_full

MANIFEST="${1:-openevolve/policies/v18_trust_region/manifests/v18_gpu7_seq.tsv}"
RUN_ROOT="openevolve/runs/v18_twolevel_initial_and_search_gpu7_seq"
mkdir -p "$RUN_ROOT"

run_one() {
  local phase="$1"
  local name="$2"
  local anchor_policy="$3"
  local merge_policy="$4"

  local out_dir="$RUN_ROOT/${phase}_${name}"
  mkdir -p "$out_dir"

  local exp="v18_${phase}_${name}_g7_$(date +%Y%m%d_%H%M%S)"

  {
    echo "PHASE=$phase"
    echo "NAME=$name"
    echo "ANCHOR_POLICY=$anchor_policy"
    echo "MERGE_POLICY=$merge_policy"
    echo "EXP=$exp"
    echo "GPU=7"
    echo "START_TIME=$(date '+%F %T')"
  } > "$out_dir/status.txt"

  rm -f "playground/data/eval/MME/answers/${exp}.jsonl" 2>/dev/null || true
  rm -f "playground/data/eval/MME/answers/${exp}.txt" 2>/dev/null || true

  echo "===== RUN $phase $name on GPU 7 ====="
  echo "ANCHOR=$anchor_policy"
  echo "MERGE=$merge_policy"

  openevolve/run_with_v18_twolevel_cdpruner_anchor_env.sh \
    "$anchor_policy" \
    "$merge_policy" \
    bash scripts/v1_5/eval/mme.sh 32 "$exp" \
    > "$out_dir/mme_full.log" 2>&1

  local ret=$?

  echo "EXIT_CODE=$ret" >> "$out_dir/status.txt"
  echo "END_TIME=$(date '+%F %T')" >> "$out_dir/status.txt"

  grep -n "CDPRUNER_POLICY\|V16 anchor policy\|Anchor policy\|Merge policy\|UniMergeHybridDelta\|UniMergeHybrid\|vtn=\|Traceback\|JSONDecodeError\|===========\|total score:\|score:" "$out_dir/mme_full.log" \
    | tail -280 \
    > "$out_dir/mme_full_score_summary.txt" || true

  if [ "$ret" -eq 0 ]; then
    echo "===== DONE_OK $phase $name ====="
  else
    echo "===== DONE_FAIL $phase $name, see $out_dir/mme_full.log ====="
  fi

  return 0
}

check_initial() {
  local dir="$RUN_ROOT/initial_v18_initial_q0_anchor_only"
  local log="$dir/mme_full.log"

  python - "$log" <<'PY'
import sys, re
from pathlib import Path

log = Path(sys.argv[1])
text = log.read_text(errors="ignore") if log.exists() else ""

totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
vtns = re.findall(r"vtn=(\d+)", text)

if len(totals) < 2:
    print("INITIAL_CHECK_FAIL no MME score found")
    raise SystemExit(2)

perception, cognition = totals[0], totals[1]
vtn = int(vtns[-1]) if vtns else -1

print(f"INITIAL_CHECK vtn={vtn} perception={perception:.6f} cognition={cognition:.6f}")

if vtn != 32:
    print("INITIAL_CHECK_FAIL vtn is not 32")
    raise SystemExit(3)

if abs(perception - 1382.8248299319728) > 2.0:
    print("INITIAL_CHECK_FAIL initial is not aligned with v16 v1 clean baseline")
    raise SystemExit(4)

print("INITIAL_CHECK_OK")
PY
}

if [ ! -f "$MANIFEST" ]; then
  echo "ERROR: manifest not found: $MANIFEST"
  exit 1
fi

echo "===== v18 two-level trust-region sequential search ====="
echo "MANIFEST=$MANIFEST"
echo "RUN_ROOT=$RUN_ROOT"
echo "GPU=7"

tail -n +2 "$MANIFEST" | while IFS=$'\t' read -r phase name anchor_policy merge_policy; do
  if [ -z "${phase:-}" ]; then
    continue
  fi

  if [ "$phase" = "initial" ]; then
    run_one "$phase" "$name" "$anchor_policy" "$merge_policy"

    if ! check_initial; then
      echo "Initial check failed. Stop search."
      exit 2
    fi
  else
    run_one "$phase" "$name" "$anchor_policy" "$merge_policy"
  fi
done

echo "All v18 sequential GPU7 jobs finished."
