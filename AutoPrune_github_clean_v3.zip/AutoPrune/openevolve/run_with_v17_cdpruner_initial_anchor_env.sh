#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"

DEFAULT_INITIAL="${CDPRUNER_ROOT}/configs/cdpruner_default_policy_v0_5.yaml"
if [ ! -f "$DEFAULT_INITIAL" ]; then
  DEFAULT_INITIAL="${CDPRUNER_ROOT}/openevolve/policies/cdpruner_default_policy_v0_5.yaml"
fi

export V16_ANCHOR_POLICY="${CDPRUNER_INITIAL_POLICY:-$DEFAULT_INITIAL}"

if [ ! -f "$V16_ANCHOR_POLICY" ]; then
  echo "ERROR: v16 initial/CDPruner default policy not found: $V16_ANCHOR_POLICY"
  echo "Please set CDPRUNER_INITIAL_POLICY=/path/to/your/v16_initial_or_cdpruner_default.yaml"
  exit 1
fi

exec "${CDPRUNER_ROOT}/openevolve/run_with_v17_cdpruner_anchor_env.sh" "$@"
