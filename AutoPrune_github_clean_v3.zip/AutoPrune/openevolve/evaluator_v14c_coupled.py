from __future__ import annotations

import json
import os
import re
import subprocess
from pathlib import Path
from typing import Any, Dict


ROOT = Path("/data/lz/openevolve_pruner/CDPruner")
PYTHON = Path("/data/lz/conda/env/cdpruner/bin/python")


def _extract_first_json(text: str) -> Dict[str, Any]:
    # Prefer line-wise JSON.
    for line in text.splitlines():
        line = line.strip()
        if not line.startswith("{") or not line.endswith("}"):
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                return obj
        except Exception:
            pass

    # Fallback: greedy object scan.
    m = re.search(r"\{.*\}", text, flags=re.S)
    if m:
        obj = json.loads(m.group(0))
        if isinstance(obj, dict):
            return obj

    raise ValueError("no JSON metrics found")


def _invalid(reason: str, extra: Dict[str, Any] | None = None) -> Dict[str, Any]:
    out = {}
    if extra:
        out.update(extra)

    # Keep diagnostic fields from the original metrics, but force the
    # optimization-facing fields to a hard invalid penalty.
    out.update({
        "valid": 0.0,
        "combined_score": 0.0,
        "objective_score": 0.0,
        "objective": "raw_combined_score",
        "raw_combined_score": 0.0,
        "mme_combined_score": 0.0,
        "ood_acc": 0.0,
        "error": reason,
    })
    return out


def _apply_v14c_guard(metrics: Dict[str, Any]) -> Dict[str, Any]:
    if float(metrics.get("valid", 0.0) or 0.0) != 1.0:
        return _invalid("v14c_invalid_base", metrics)

    selected = float(metrics.get("selected_tokens_avg", -1.0) or -1.0)
    overlap = float(metrics.get("overlap_with_reference_avg", -1.0) or -1.0)
    changed = float(metrics.get("changed_tokens_avg", 999.0) or 999.0)

    if abs(selected - 32.0) > 1e-4:
        return _invalid(f"v14c_guard_failed:selected_tokens_avg={selected}", metrics)

    if overlap < float(os.environ.get("EVO_V14C_MIN_OVERLAP", "0.85")):
        return _invalid(f"v14c_guard_failed:overlap={overlap}", metrics)

    if changed > float(os.environ.get("EVO_V14C_MAX_CHANGED", "5.0")):
        return _invalid(f"v14c_guard_failed:changed={changed}", metrics)

    # Feature processing should normally be active, but do not hard reject score_rescale
    # edge cases if the evaluator does not report delta for some module.
    delta = metrics.get("v14_feature_delta_norm_avg", None)
    if delta is not None:
        try:
            if float(delta) < 0.0:
                return _invalid(f"v14c_guard_failed:negative_delta={delta}", metrics)
        except Exception:
            pass

    raw = float(metrics.get("raw_combined_score", metrics.get("mme_combined_score", 0.0)) or 0.0)
    metrics["raw_combined_score"] = raw
    metrics["mme_combined_score"] = float(metrics.get("mme_combined_score", raw) or raw)

    # Critical: OpenEvolve should optimize raw MME combined, not perception-only.
    metrics["objective"] = "raw_combined_score"
    metrics["objective_score"] = raw
    metrics["combined_score"] = raw
    metrics["ood_acc"] = raw
    metrics["valid"] = 1.0
    return metrics


def evaluate(program_path: str) -> Dict[str, Any]:
    program_path = str(program_path)

    gpu = os.environ.get("EVO_GPU", "5")
    token = os.environ.get("EVO_TOKEN", "32")
    script = os.environ.get("EVO_EVAL_SCRIPT", "scripts/v1_5/eval/mme_yaml_smoke21.sh")

    log_dir = ROOT / "openevolve/runs/v14_c_coupled_eval_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    eval_log = log_dir / "candidate.log"

    cmd = [
        str(PYTHON),
        str(ROOT / "yaml_policy/openevolve_yaml_search/evaluator.py"),
        program_path,
        "--gpu", str(gpu),
        "--token", str(token),
        "--script", str(script),
        "--log", str(eval_log),
    ]

    env = os.environ.copy()
    env["PYTHONPATH"] = str(ROOT) + ":" + env.get("PYTHONPATH", "")
    env["EVO_CDPRUNER_ENABLE"] = "1"
    env["EVO_CDPRUNER_V14_ENABLE"] = "1"
    env["EVO_FORCE_FIXED_TOKENS"] = str(token)

    try:
        proc = subprocess.run(
            cmd,
            cwd=str(ROOT),
            env=env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            timeout=int(os.environ.get("EVO_EVAL_TIMEOUT", "900")),
        )
        text = proc.stdout or ""
        metrics = _extract_first_json(text)
        metrics["candidate_program_path"] = program_path
        metrics["eval_script"] = script
        metrics["gpu"] = str(gpu)
        metrics["token"] = str(token)
        if proc.returncode != 0 and float(metrics.get("valid", 0.0) or 0.0) != 1.0:
            metrics["error"] = metrics.get("error", f"subprocess_returncode={proc.returncode}")
        return _apply_v14c_guard(metrics)

    except Exception as e:
        return _invalid(repr(e), {
            "candidate_program_path": program_path,
            "eval_script": script,
            "gpu": str(gpu),
            "token": str(token),
        })
