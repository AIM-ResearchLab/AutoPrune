#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"

export V16_ANCHOR_POLICY="${CDPRUNER_ROOT}/configs/v16_v1_clean_cdpruner_k32_reference_q0.yaml"

if [ ! -f "$V16_ANCHOR_POLICY" ]; then
  echo "ERROR: v16 v1 clean baseline policy not found: $V16_ANCHOR_POLICY"
  exit 1
fi

exec "${CDPRUNER_ROOT}/openevolve/run_with_v17_cdpruner_anchor_env.sh" "$@"
