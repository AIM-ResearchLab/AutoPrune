"""v10/v4 LLM policy planner for Evo-CDPruner.

This file keeps the old v4.3 baseline-anchored residual planner as the
fallback behavior, and adds an executable v10 pipeline-policy planner behind
EVO_V10_PIPELINE_PLANNER=1.

v10 mode asks the LLM to output a directly executable YAML-like policy dict with
primitive names such as weighted_product_fusion, quality_pool_builder, and
runtime_reference_anchor_pool_dpp_selector.  It is intended for LLM-driven NAS /
policy search over the calibrated v9/v10 CDPruner YAML pipeline grammar.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from openevolve.atom_cards import grouped_cards_text
from openevolve.policy_grammar import Policy, wrap_policy, base_step
from openevolve.v14b_processing_only import build_v14b_prompt, canonicalize_plan_to_policy


BASELINE = {
    "perception": 1388.1590879595083,
    "cognition": 311.42857142857144,
    "raw_combined": 1699.5876593880798,
}

EXEC_SCORERS = {
    "instruction_guided_visual_relevance",
    "visual_token_norm_saliency",
    "spatial_centrality_prior",
    "redundancy_density_penalty",
    "attention_proxy_saliency",
}
EXEC_SIMILARITY = {"pairwise_token_similarity", "conditional_similarity_score"}
EXEC_FUSIONS = {
    "weighted_sum_score_fusion",
    "mmr_relevance_diversity_fusion",
    "quality_diversity_kernel",
    "baseline_residual_score_fusion",
}
EXEC_SELECTORS = {
    "topk_selector",
    "mmr_selector",
    "dpp_selector",
    "topk_pool_mmr_selector",
    "topk_pool_dpp_selector",
    "baseline_anchored_residual_selector",
    "cdpruner_mask_anchored_residual_selector",
}
EXEC_PROTECTIONS = {
    "spatial_coverage_preservation",
    "top_relevance_anchor_preservation",
    "special_token_preservation",
}
EXEC_ACTIONS = {"hard_prune", "dpp_subset_prune"}

DEFAULT_BASELINE_SCORER = {
    "atom": "instruction_guided_visual_relevance",
    "params": {"sign": "negative_mean", "transform": "minmax", "power": 1.0},
}

TYPE_RULES = """
V4 baseline-anchored residual patch rules:
- The strong CDPruner/default policy is the reliability anchor. Do NOT replace the whole policy.
- Always keep budget as fixed_keep_tokens with keep_tokens=host_argument. The user controls K externally through EVO_TOKEN / --visual_token_num.
- Emit a residual_patch or a policy_graph that compiles to:
  scorer.baseline + scorer.residual_* -> baseline_residual_score_fusion -> cdpruner_mask_anchored_residual_selector -> hard_prune.
- The selector must use the full CDPruner/default mask as the reliability anchor, not relevance top-K.
- The selector automatically derives residual_keep from K using a scheduler. Do not hard-code 8/16/32/64/128 in the policy.
- Use min_residual=0 and no_op_if_no_positive_gain=true unless deliberately exploring. A no-op is allowed if no residual candidate beats the CDPruner baseline tail.
- DPP/MMR/spatial/diversity atoms should be used only as auxiliary residual signals, not as full replacement selectors for all K tokens.
- The compiler validates atom IDs, parameter ranges, and uses host_argument budget.
""".strip()

SYSTEM_PROMPT = """You are an expert in multimodal visual-token pruning and program synthesis.
Design exactly ONE baseline-anchored residual patch using the provided YAML atom cards.
The goal is not to replace the strong baseline, but to recover complementary residual tokens while preserving a high-overlap baseline anchor.
Return JSON only. Do not output YAML or Markdown.
"""

V10_SYSTEM_PROMPT = """You are an expert in LLM-driven neural architecture / policy search for multimodal visual-token pruning.
You must propose exactly ONE executable v10 YAML pipeline policy as JSON.
Do not output Markdown. Do not output old residual_patch format.
Return JSON only with keys: rationale, policy, expected_effect.
"""


@dataclass
class PlannerResult:
    policy: Optional[Policy]
    plan: Optional[Dict[str, Any]]
    raw_response: str
    prompt: str
    error: Optional[str] = None
    downcompile_note: Optional[str] = None
    mode: str = "exploration"


def _safe_float(x: Any, default: float) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)


def _safe_int(x: Any, default: int) -> int:
    try:
        return int(round(float(x)))
    except Exception:
        return int(default)


def _clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, float(x)))


def _env_flag(name: str, default: str = "0") -> bool:
    return str(os.environ.get(name, default)).strip().lower() in {"1", "true", "yes", "y", "on"}


def _json_extract(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    text = text.strip()
    try:
        obj = json.loads(text)
        return obj if isinstance(obj, dict) else None
    except Exception:
        pass
    m = re.search(r"```(?:json)?\s*(\{.*?\})\s*```", text, flags=re.S | re.I)
    if m:
        try:
            obj = json.loads(m.group(1))
            return obj if isinstance(obj, dict) else None
        except Exception:
            pass
    m = re.search(r"(\{.*\})", text, flags=re.S)
    if m:
        try:
            obj = json.loads(m.group(1))
            return obj if isinstance(obj, dict) else None
        except Exception:
            pass
    return None


def _model_cfg(config: Any) -> Dict[str, Any]:
    llm = getattr(config, "llm", None)
    models = getattr(llm, "models", []) or []
    model0 = models[0] if models else None

    def g(obj: Any, name: str, default: Any = None) -> Any:
        return getattr(obj, name, default) if obj is not None else default

    return {
        "name": g(
            model0,
            "name",
            os.environ.get("EVO_V4_LLM_MODEL", os.environ.get("EVO_V32_LLM_MODEL", "qwen-plus")),
        ),
        "api_key": g(model0, "api_key", None)
        or g(llm, "api_key", None)
        or os.environ.get("OPENAI_API_KEY")
        or os.environ.get("OPENAI_ADMIN_KEY"),
        "base_url": g(model0, "api_base", None)
        or g(llm, "api_base", None)
        or os.environ.get("OPENAI_BASE_URL")
        or "https://dashscope.aliyuncs.com/compatible-mode/v1",
        "timeout": float(g(llm, "timeout", 120) or 120),
        "max_tokens": int(
            os.environ.get("EVO_V4_PLANNER_MAX_TOKENS", os.environ.get("EVO_V32_PLANNER_MAX_TOKENS", "3200"))
        ),
        "temperature": float(
            os.environ.get("EVO_V4_PLANNER_TEMPERATURE", os.environ.get("EVO_V32_PLANNER_TEMPERATURE", "0.85"))
        ),
    }


def _choose_mode(iteration: int) -> str:
    forced = os.environ.get("EVO_V4_PLANNER_MODE", os.environ.get("EVO_V32_PLANNER_MODE", "auto")).strip().lower()
    if forced in {"exploration", "exploitation"}:
        return forced
    rate = _clamp(
        _safe_float(os.environ.get("EVO_V4_EXPLORATION_RATE", os.environ.get("EVO_V32_EXPLORATION_RATE", 0.65)), 0.65),
        0.0,
        1.0,
    )
    return "exploration" if ((iteration * 37) % 100) < int(rate * 100) else "exploitation"


def _program_measurement(program: Any, include_metrics: bool) -> Dict[str, Any]:
    if program is None:
        return {}
    metrics = getattr(program, "metrics", {}) or {}
    meta = getattr(program, "metadata", {}) or {}
    item = {
        "id": getattr(program, "id", None),
        "policy_fp": meta.get("policy_fp"),
        "sketch": meta.get("operator") or meta.get("changes"),
    }
    if include_metrics:
        item["measurements"] = {
            "objective": metrics.get("objective"),
            "combined_score": metrics.get("combined_score"),
            "perception": metrics.get("perception"),
            "cognition": metrics.get("cognition"),
            "raw_combined": metrics.get("raw_combined_score", metrics.get("mme_combined_score")),
            "overlap": metrics.get("overlap_with_reference_avg"),
            "changed": metrics.get("changed_tokens_avg"),
        }
    return {k: v for k, v in item.items() if v is not None}


def _archive(parent: Any, inspirations: List[Any], include_metrics: bool, limit: int = 8) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    seen = set()
    for item in [parent] + list(inspirations or []):
        rec = _program_measurement(item, include_metrics=include_metrics)
        if not rec:
            continue
        key = rec.get("policy_fp") or rec.get("sketch") or rec.get("id")
        if key in seen:
            continue
        seen.add(key)
        out.append(rec)
    return out[:limit]


def _focus_for_iteration(iteration: int) -> str:
    families = [
        ("visual_token_norm_saliency", "Use feature-norm saliency as the main auxiliary residual signal. Do not use spatial_centrality_prior alone."),
        ("redundancy_density_penalty", "Use redundancy_density_penalty to recover non-redundant residual tokens. Do not use spatial_centrality_prior alone."),
        ("attention_proxy_saliency", "Use attention_proxy_saliency / feature_norm proxy as the auxiliary residual signal. Do not use spatial_centrality_prior alone."),
        ("spatial_variant", "If using spatial_centrality_prior, change at least two selector/fusion parameters from the default: aux_total_weight, alpha, max_residual_ratio, gate weights, or min_gain."),
        ("two_aux_norm_redundancy", "Use a two-auxiliary branch combining visual_token_norm_saliency and redundancy_density_penalty."),
        ("two_aux_spatial_norm", "Use a two-auxiliary branch combining spatial_centrality_prior and visual_token_norm_saliency with conservative aux_total_weight."),
    ]
    name, desc = families[int(iteration) % len(families)]
    return f"Exploration focus for this iteration: {name}. {desc}"


# =========================
# v10 executable pipeline planner helpers
# =========================

V10_COMPUTE_SCORE_NAMES = {
    "cdpruner_reference_mask_prior",
    "native_teacher_mask_prior",
    "instruction_guided_visual_relevance",
    "attention_proxy_saliency",
    "spatial_centrality_prior",
    "redundancy_density_penalty",
    "local_contrast_saliency",
    "visual_token_norm_saliency",
}

V10_FUSION_NAMES = {"weighted_product_fusion", "reference_confidence_weighted_product_fusion", "question_aware_weighted_product_fusion"}

V10_KERNEL_NAMES = {
    "pairwise_cosine_kernel",
    "runtime_conditional_similarity_kernel",
    "cdpruner_conditional_similarity_kernel",
}

V10_POOL_NAMES = {"quality_pool_builder", "top_quality_pool_builder", "spatial_coverage_pool_builder"}

V10_SELECTOR_NAMES = {"runtime_reference_anchor_pool_dpp_selector", "adaptive_reference_anchor_pool_dpp_selector",
    "native_reference_residual_exchange_selector",
    "native_reference_margin_gated_exchange_selector",
    "native_reference_strict_margin_exchange_selector",
}


def _v10_archive(parent: Any, inspirations: List[Any], include_metrics: bool) -> str:
    try:
        return json.dumps(_archive(parent, inspirations, include_metrics=include_metrics, limit=10), ensure_ascii=False, indent=2)
    except Exception:
        return "[]"


def _build_v10_planner_prompt(

    parent: Any,
    inspirations: List[Any],
    iteration: int,
    max_cards: int = 120,
    mode: Optional[str] = None,
) -> str:
    # EVO_V14B_PROCESSING_ONLY_PROMPT_OVERRIDE
    if os.environ.get("EVO_V14B_PROCESSING_ONLY", "0").strip() == "1":
        _iter = locals().get("iteration", 0)
        _mode = locals().get("mode", "exploration")
        try:
            _iter = int(_iter)
        except Exception:
            _iter = 0
        return build_v14b_prompt(iteration=_iter, mode=str(_mode))

    from pathlib import Path

    mode = mode or _choose_mode(iteration)
    include_metrics = mode == "exploitation"

    k = os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "32"))
    objective = os.environ.get("EVO_OBJECTIVE", "perception")

    seed_paths = [
        Path("openevolve/runs/v10_llm_driven_seed/seed_.yaml"),
        Path("/data/lz/openevolve_pruner/CDPruner/openevolve/runs/v10_llm_driven_seed/seed_.yaml"),
    ]
    seed_yaml = ""
    for seed_path in seed_paths:
        if seed_path.exists():
            seed_yaml = seed_path.read_text(errors="ignore")
            break

    space_paths = [
        Path("openevolve/v10_llm_yaml_search_space.md"),
        Path("/data/lz/openevolve_pruner/CDPruner/openevolve/v10_llm_yaml_search_space.md"),
    ]
    search_space = ""
    for space_path in space_paths:
        if space_path.exists():
            search_space = space_path.read_text(errors="ignore")
            break
    if not search_space:
        search_space = """
Allowed executable v10 policy schema:
policy_name: string
name: string
keep_tokens: 32
pipeline:
  - op: compute_score | product_fuse_score | compute_kernel | build_pool | select
    name: string
    inputs: optional dict
    params: optional dict
    output: string

Allowed compute_score:
- cdpruner_reference_mask_prior
- native_teacher_mask_prior
- instruction_guided_visual_relevance
- attention_proxy_saliency
- spatial_centrality_prior
- redundancy_density_penalty
- local_contrast_saliency
- visual_token_norm_saliency

Allowed product_fuse_score:
- weighted_product_fusion
- reference_confidence_weighted_product_fusion
- question_aware_weighted_product_fusion

Allowed compute_kernel:
- pairwise_cosine_kernel
- runtime_conditional_similarity_kernel

Allowed build_pool:
- quality_pool_builder

Allowed select:
- runtime_reference_anchor_pool_dpp_selector
- native_reference_residual_exchange_selector
- native_reference_margin_gated_exchange_selector
- native_reference_strict_margin_exchange_selector
- adaptive_reference_anchor_pool_dpp_selector
""".strip()

    schema = {
        "rationale": "why this child may improve perception/raw while preserving cognition",
        "policy": {
            "policy_name": "v10_llm_child_name",
            "name": "v10_llm_child_name",
            "keep_tokens": 32,
            "pipeline": [
                {"op": "compute_score", "name": "cdpruner_reference_mask_prior", "output": "reference_score"},
                {"op": "compute_score", "name": "instruction_guided_visual_relevance", "output": "semantic_score"},
                {"op": "compute_score", "name": "attention_proxy_saliency", "output": "attn_score"},
                {"op": "compute_score", "name": "spatial_centrality_prior", "output": "spatial_score"},
                {"op": "compute_score", "name": "redundancy_density_penalty", "output": "redundancy_score"},
                {"op": "compute_score", "name": "local_contrast_saliency", "output": "contrast_score"},
                {
                    "op": "product_fuse_score",
                    "name": "weighted_product_fusion",
                    "inputs": {
                        "scores": {
                            "semantic": "semantic_score",
                            "attn": "attn_score",
                            "spatial": "spatial_score",
                            "redundancy": "redundancy_score",
                            "contrast": "contrast_score",
                        }
                    },
                    "params": {
                        "weights": {
                            "semantic": 0.35,
                            "attn": 0.10,
                            "spatial": 0.15,
                            "redundancy": 0.30,
                            "contrast": 0.10,
                        }
                    },
                    "output": "quality_score",
                },
                {"op": "compute_kernel", "name": "pairwise_cosine_kernel", "output": "sim_kernel"},
                {
                    "op": "build_pool",
                    "name": "quality_pool_builder",
                    "inputs": {"quality": "quality_score"},
                    "params": {"pool_factor": 3.0},
                    "output": "pool",
                },
                {
                    "op": "select",
                    "name": "runtime_reference_anchor_pool_dpp_selector",
                    "inputs": {
                        "pool": "pool",
                        "quality": "quality_score",
                        "kernel": "sim_kernel",
                        "reference": "reference_score",
                    },
                    "params": {
                        "anchor_quota": 8,
                        "diversity_lambda": 0.18,
                        "exclude_unanchored_reference": True,
                        "sort_selected": True,
                    },
                    "output": "selected",
                },
            ],
        },
        "expected_effect": {
            "perception": "unknown|increase|preserve|decrease",
            "cognition": "unknown|increase|preserve|decrease",
            "risk": "low|medium|high",
        },
    }

    return f"""
Iteration: {iteration}
Planner mode: {mode}
Objective metric: {objective}
Host-controlled keep_tokens K={k}

You are now in v10 executable pipeline-policy search mode.
Do NOT output residual_patch.
Do NOT output policy_graph.
Do NOT output old v4 baseline_residual_score_fusion policies.
Do NOT use planner-only atoms.
Return JSON only.

Current calibrated seed full MME:
- policy: 0021_v12_native_balanced_rq02
- perception = 1402.8128
- cognition  = 299.2857
- raw        = 1702.0985
- overlap_with_reference_avg = 0.9375
- changed_tokens_avg = 2.00
- keep_tokens = 32

Goal:
- Search native-only residual exchange policies.
- Beat native CDPruner base raw_combined_score > 1687.1105.
- Preserve high perception.
- Keep overlap_with_reference_avg >= 0.90.
- Keep changed_tokens_avg <= 3.
- Use native_teacher_mask_prior as the only reference.
- Do NOT use cdpruner_reference_mask_prior.
- Do NOT avoid native/default reference; v12 is intentionally native-reference anchored.
- Do NOT return runtime_reference_anchor_pool_dpp_selector.
- Prefer native_reference_residual_exchange_selector with replace_quota in {1, 2, 3}.


V13-LOCAL CRITICAL INSTRUCTIONS:
- The seed is 0021_v12_native_balanced_rq02.
- The seed full raw score is 1702.0985.
- The goal is to improve over this seed, not merely over CDPruner base.
- Use native_teacher_mask_prior as the only reference.
- Use native_reference_residual_exchange_selector as the only selector.
- Do not use cdpruner_reference_mask_prior.
- Do not use margin_gated or strict_margin selectors in v13-local.
- Do not use runtime_reference_anchor_pool_dpp_selector.
- Keep replace_quota in {1, 2}.
- Keep min_reference_keep in {30, 31}.
- Keep overlap >= 0.90 and changed_tokens_avg <= 2.5.


V14-B CRITICAL INSTRUCTIONS:
- The current seed is v14-A best: 0040_v14a_from_real0021_semmerge_a0p01_t1_g0p65.
- The seed full raw score is 1706.3639.
- Improve beyond 1706.3639, not merely beyond 1702.0985.
- This is a post-selection token processing search.
- Do not change the first 9 selection nodes.
- Do not change keep_tokens.
- Do not change replace_quota or min_reference_keep.
- Keep native_teacher_mask_prior and native_reference_residual_exchange_selector.
- Only mutate the final process_tokens node and its parameters.
- Prefer conservative feature changes: norm_preserve=true, small alpha, top_merge_neighbors 1 or 2.
- A good candidate should have overlap_with_reference_avg=0.9375, changed_tokens_avg=2.0, and v14_feature_delta_norm_avg>0.

Allowed v10 search space:
{search_space}

Strong seed YAML:
```yaml
{seed_yaml}
```

Already evaluated local archive:
{_v10_archive(parent, inspirations, include_metrics=include_metrics)}

Required mutation rule:
The child must change at least one meaningful design factor from the seed:
- fusion weights
- anchor_quota
- diversity_lambda
- pool_factor
- kernel choice
- score branch set
- selector params

Recommended valid ranges:
- anchor_quota: integer in [6, 10], recommended around 8
- diversity_lambda: float in [0.08, 0.30]
- pool_factor: float in [2.0, 4.0]
- semantic weight: [0.25, 0.55]
- redundancy weight: [0.15, 0.45]
- contrast weight: [0.05, 0.30]
- attn/spatial weights: [0.05, 0.25]

Return JSON only with this schema:
{json.dumps(schema, ensure_ascii=False, indent=2)}
""".strip()


def _sanitize_v10_policy_from_plan(plan: Dict[str, Any]) -> Tuple[Optional[Policy], Optional[str]]:
    if not isinstance(plan, dict):
        return None, "v10_plan_not_dict"

    pol = plan.get("policy", plan)
    if not isinstance(pol, dict):
        return None, "v10_policy_not_dict"

    pipe = pol.get("pipeline")
    if not isinstance(pipe, list) or not pipe:
        return None, "v10_missing_pipeline"

    out: Dict[str, Any] = {
        "policy_name": str(pol.get("policy_name") or pol.get("name") or "v10_llm_pipeline_child"),
        "name": str(pol.get("name") or pol.get("policy_name") or "v10_llm_pipeline_child"),
        "keep_tokens": 32,
        "pipeline": [],
    }

    has_ref = False
    has_quality = False
    has_pool = False
    has_selector = False

    for idx, node in enumerate(pipe):
        if not isinstance(node, dict):
            return None, f"v10_node_{idx}_not_dict"

        op = str(node.get("op", ""))
        name = str(node.get("name", ""))
        new_node: Dict[str, Any] = {"op": op, "name": name}

        if "inputs" in node and isinstance(node.get("inputs"), dict):
            new_node["inputs"] = json.loads(json.dumps(node["inputs"]))
        if "params" in node and isinstance(node.get("params"), dict):
            new_node["params"] = json.loads(json.dumps(node["params"]))
        if "output" in node:
            new_node["output"] = str(node["output"])

        if op == "compute_score":
            if name not in V10_COMPUTE_SCORE_NAMES:
                return None, f"v10_bad_compute_score:{name}"
            if name in {"cdpruner_reference_mask_prior", "native_teacher_mask_prior"}:
                has_ref = True
                new_node.setdefault("output", "reference_score")
            else:
                new_node.setdefault("output", f"score_{idx}")

        elif op == "product_fuse_score":
            if name not in V10_FUSION_NAMES:
                return None, f"v10_bad_product_fusion:{name}"
            params = new_node.setdefault("params", {})
            weights = params.get("weights", {})
            if not isinstance(weights, dict) or not weights:
                weights = {
                    "semantic": 0.35,
                    "attn": 0.10,
                    "spatial": 0.15,
                    "redundancy": 0.30,
                    "contrast": 0.10,
                }
            fixed = {}
            for wk, wv in weights.items():
                try:
                    fixed[str(wk)] = _clamp(float(wv), 0.0, 1.0)
                except Exception:
                    pass
            if not fixed:
                fixed = {
                    "semantic": 0.35,
                    "attn": 0.10,
                    "spatial": 0.15,
                    "redundancy": 0.30,
                    "contrast": 0.10,
                }
            params["weights"] = fixed
            new_node.setdefault("output", "quality_score")
            has_quality = True

        elif op == "compute_kernel":
            if name not in V10_KERNEL_NAMES:
                return None, f"v10_bad_kernel:{name}"
            if name in {"runtime_conditional_similarity_kernel", "cdpruner_conditional_similarity_kernel"}:
                inputs = new_node.setdefault("inputs", {})
                inputs.setdefault("quality", "quality_score")
                params = new_node.setdefault("params", {})
                params["quality_power"] = _clamp(_safe_float(params.get("quality_power", 1.0), 1.0), 0.5, 2.0)
                params["shift_similarity"] = bool(params.get("shift_similarity", True))
            new_node.setdefault("output", "sim_kernel")

        elif op == "build_pool":
            if name not in V10_POOL_NAMES:
                return None, f"v10_bad_pool:{name}"
            inputs = new_node.setdefault("inputs", {})
            inputs.setdefault("quality", "quality_score")
            params = new_node.setdefault("params", {})
            params["pool_factor"] = _clamp(_safe_float(params.get("pool_factor", 3.0), 3.0), 1.0, 6.0)
            new_node.setdefault("output", "pool")
            has_pool = True

        elif op == "select":
            if name not in V10_SELECTOR_NAMES:
                return None, f"v10_bad_selector:{name}"
            inputs = new_node.setdefault("inputs", {})
            inputs.setdefault("pool", "pool")
            inputs.setdefault("quality", "quality_score")
            inputs.setdefault("kernel", "sim_kernel")
            inputs.setdefault("reference", "reference_score")
            params = new_node.setdefault("params", {})
            params["anchor_quota"] = max(6, min(_safe_int(params.get("anchor_quota", 8), 8), 10))
            params["diversity_lambda"] = _clamp(_safe_float(params.get("diversity_lambda", 0.18), 0.18), 0.08, 0.30)
            params["exclude_unanchored_reference"] = bool(params.get("exclude_unanchored_reference", True))
            params["sort_selected"] = bool(params.get("sort_selected", True))
            new_node.setdefault("output", "selected")
            has_selector = True

        else:
            return None, f"v10_bad_op:{op}"

        out["pipeline"].append(new_node)

    if not has_ref:
        return None, "v10_missing_reference_score"
    if not has_quality:
        return None, "v10_missing_quality_fusion"
    if not has_pool:
        return None, "v10_missing_pool"
    if not has_selector:
        return None, "v10_missing_runtime_anchor_selector"

    return out, "v10_pipeline_policy"


def build_planner_prompt(
    parent: Any,
    inspirations: List[Any],
    iteration: int,
    max_cards: int = 120,
    mode: Optional[str] = None,
) -> str:
    if _env_flag("EVO_V10_PIPELINE_PLANNER", "0"):
        return _build_v10_planner_prompt(parent, inspirations, iteration, max_cards=max_cards, mode=mode)

    mode = mode or _choose_mode(iteration)
    include_metrics = mode == "exploitation"
    archive = _archive(parent, inspirations, include_metrics=include_metrics, limit=8)
    k = os.environ.get("EVO_TOKEN", os.environ.get("EVO_FORCE_FIXED_TOKENS", "host_argument"))
    objective = os.environ.get("EVO_OBJECTIVE", "perception")
    focus_text = _focus_for_iteration(iteration)
    archive_text = (
        "Unranked evaluated measurements for local refinement:"
        if include_metrics
        else "Already evaluated sketches only for duplicate avoidance; no scores are provided:"
    )
    schema = {
        "rationale": "why this residual branch complements the baseline without replacing it",
        "residual_patch": {
            "baseline": {
                "atom": "instruction_guided_visual_relevance",
                "params": {"sign": "negative_mean", "transform": "minmax", "power": 1.0},
            },
            "auxiliary_scorers": [
                {
                    "id": "aux1",
                    "atom": "visual_token_norm_saliency|redundancy_density_penalty|attention_proxy_saliency|spatial_centrality_prior",
                    "params": {},
                }
            ],
            "fusion": {
                "atom": "baseline_residual_score_fusion",
                "params": {"baseline_weight": 1.0, "aux_total_weight": 0.1, "score_normalization": "minmax"},
            },
            "selector": {
                "atom": "cdpruner_mask_anchored_residual_selector",
                "params": {
                    "true_cdpruner_anchor": True,
                    "scheduler": "sqrt",
                    "alpha": 0.8,
                    "min_residual": 0,
                    "max_residual_ratio": 0.125,
                    "candidate_pool_multiplier": 4.0,
                    "gate_baseline_weight": 0.85,
                    "gate_residual_weight": 0.15,
                    "min_gain": 0.01,
                    "no_op_if_no_positive_gain": True,
                },
            },
        },
        "expected_effect": {
            "perception": "unknown|decrease|preserve|increase",
            "cognition": "unknown|decrease|preserve|increase",
            "risk": "low|medium|high",
        },
    }
    return f"""
Iteration: {iteration}
Planner mode: {mode}
Objective metric: {objective}. Current host-controlled token budget K={k}.
Reference metrics, shown only for scale; optimize the objective above: {json.dumps(BASELINE, ensure_ascii=False)}
{focus_text}

Diversity rule: do not repeat an already evaluated residual_patch fingerprint. If prior residual attempts under min_residual>0 or max_residual_ratio>=0.375 reduced the score, make the next move more conservative: min_residual=0, max_residual_ratio<=0.125, gate_baseline_weight>=0.85, min_gain>=0.01.

Failed-move memory rule: if several auxiliary families produce the same lower score, change the replacement operator/gate parameters, not only the auxiliary atom. Prefer no-op-safe residuals over forced replacements.

{TYPE_RULES}

Baseline policy to preserve as reliability anchor:
- true anchor mask: full CDPruner default = instruction-guided quality + conditional similarity + quality_diversity_kernel + DPP selector.
- baseline scorer inside residual fusion remains instruction_guided_visual_relevance(sign=negative_mean, transform=minmax, power=1.0), but it is NOT the anchor mask.
- budget: fixed_keep_tokens(keep_tokens=host_argument), so K is controlled externally by EVO_TOKEN / --visual_token_num.
- residual branch may add generic auxiliary YAML atoms, but may only replace baseline-tail tokens through a no-op-safe gate.

Compact YAML atom cards, neutral factual summary:
{grouped_cards_text(max_cards=max_cards, include_planned=True)}

{archive_text}
{json.dumps(archive, ensure_ascii=False, indent=2)}

Task:
Construct one budget-general baseline-anchored residual_patch. K must remain host_argument.
Prefer generic, dataset-agnostic auxiliary atoms. Do not use MME-subtask labels or benchmark-specific rules.
Return JSON only with this schema shape:
{json.dumps(schema, ensure_ascii=False, indent=2)}
""".strip()


def _params(node: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(node, dict):
        return {}
    p = node.get("params", {})
    return p if isinstance(p, dict) else {}


def _compile_scorer(node: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    atom = str(node.get("atom", ""))
    if atom not in EXEC_SCORERS:
        return None
    p = _params(node)
    if atom == "instruction_guided_visual_relevance":
        sign = str(p.get("sign", "negative_mean"))
        if sign not in {"negative_mean", "positive_mean", "max"}:
            sign = "negative_mean"
        transform = str(p.get("transform", p.get("score_normalization", "minmax")))
        if transform not in {"rank_norm", "minmax", "sigmoid", "softmax", "none"}:
            transform = "minmax"
        return {
            "atom": atom,
            "params": {"sign": sign, "transform": transform, "power": _clamp(_safe_float(p.get("power", 1.0), 1.0), 0.5, 2.5)},
        }
    if atom in {"visual_token_norm_saliency", "spatial_centrality_prior", "redundancy_density_penalty", "attention_proxy_saliency"}:
        out = dict(p)
        if "transform" in out and out["transform"] not in {"rank_norm", "minmax", "sigmoid", "softmax", "none"}:
            out["transform"] = "minmax"
        return {"atom": atom, "params": out}
    return None


def _patch_from_plan(plan: Dict[str, Any]) -> Dict[str, Any]:
    if isinstance(plan.get("residual_patch"), dict):
        return plan["residual_patch"]
    # Fallback: convert old policy_graph nodes into a residual patch.
    pg = plan.get("policy_graph") or {}
    nodes = pg.get("nodes", []) if isinstance(pg, dict) else []
    aux = []
    baseline = None
    fusion = None
    selector = None
    for node in nodes:
        if not isinstance(node, dict):
            continue
        slot, atom = str(node.get("slot", "")), str(node.get("atom", ""))
        if slot == "scorer" and atom == "instruction_guided_visual_relevance" and baseline is None:
            baseline = node
        elif slot == "scorer" and atom in EXEC_SCORERS:
            aux.append(node)
        elif slot == "fusion" and atom == "baseline_residual_score_fusion":
            fusion = node
        elif slot == "selector" and atom in {"baseline_anchored_residual_selector", "cdpruner_mask_anchored_residual_selector"}:
            selector = node
    return {
        "baseline": baseline
        or {"atom": "instruction_guided_visual_relevance", "params": {"sign": "negative_mean", "transform": "minmax", "power": 1.0}},
        "auxiliary_scorers": aux[:3],
        "fusion": fusion
        or {"atom": "baseline_residual_score_fusion", "params": {"baseline_weight": 1.0, "aux_total_weight": 0.1, "score_normalization": "minmax"}},
        "selector": selector
        or {
            "atom": "cdpruner_mask_anchored_residual_selector",
            "params": {
                "true_cdpruner_anchor": True,
                "scheduler": "sqrt",
                "alpha": 0.8,
                "min_residual": 0,
                "max_residual_ratio": 0.125,
                "candidate_pool_multiplier": 4.0,
                "gate_baseline_weight": 0.85,
                "gate_residual_weight": 0.15,
                "min_gain": 0.01,
                "no_op_if_no_positive_gain": True,
            },
        },
    }


def compile_plan_to_policy(plan: Dict[str, Any]) -> Tuple[Optional[Policy], Optional[str]]:
    if not isinstance(plan, dict):
        return None, "plan_not_dict"

    if _env_flag("EVO_V10_PIPELINE_PLANNER", "0"):
        pol, note = _sanitize_v10_policy_from_plan(plan)
        if pol is None:
            return None, note or "v10_compile_failed"
        return pol, note

    patch = _patch_from_plan(plan)
    baseline = _compile_scorer(patch.get("baseline", {}) if isinstance(patch.get("baseline"), dict) else {}) or DEFAULT_BASELINE_SCORER
    aux_nodes = patch.get("auxiliary_scorers", [])
    if not isinstance(aux_nodes, list):
        aux_nodes = []
    scorers: Dict[str, Any] = {"baseline": baseline}
    used = {"baseline"}
    for i, node in enumerate(aux_nodes[:4]):
        if not isinstance(node, dict):
            continue
        spec = _compile_scorer(node)
        if not spec:
            continue
        key = str(node.get("id", f"aux_{i}"))
        if key in used or key == "similarity":
            key = f"aux_{i}"
        used.add(key)
        scorers[key] = spec
    if len(scorers) == 1:
        # Always include one safe generic residual scorer so the branch can do something.
        scorers["aux_spatial"] = {"atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}}

    fusion_params = _params(patch.get("fusion"))
    aux_total = _clamp(_safe_float(fusion_params.get("aux_total_weight", fusion_params.get("aux_weight", 0.1)), 0.1), 0.0, 0.5)
    norm = str(fusion_params.get("score_normalization", "minmax"))
    if norm not in {"minmax", "rank_norm", "sigmoid", "none"}:
        norm = "minmax"

    selector_params = _params(patch.get("selector"))
    scheduler = str(selector_params.get("scheduler", selector_params.get("mode", "sqrt")))
    if scheduler not in {"sqrt", "ratio", "fixed"}:
        scheduler = "sqrt"
    sel = {
        "true_cdpruner_anchor": True,
        "scheduler": scheduler,
        "alpha": _clamp(_safe_float(selector_params.get("alpha", 0.8), 0.8), 0.1, 3.0),
        "min_residual": max(0, min(_safe_int(selector_params.get("min_residual", 0), 0), 16)),
        "max_residual_ratio": _clamp(_safe_float(selector_params.get("max_residual_ratio", 0.125), 0.125), 0.0, 0.75),
        "candidate_pool_multiplier": _clamp(
            _safe_float(selector_params.get("candidate_pool_multiplier", selector_params.get("pool_multiplier", 4.0)), 4.0),
            1.0,
            12.0,
        ),
        "gate_baseline_weight": _clamp(_safe_float(selector_params.get("gate_baseline_weight", 0.85), 0.85), 0.0, 1.0),
        "gate_residual_weight": _clamp(_safe_float(selector_params.get("gate_residual_weight", 0.15), 0.15), 0.0, 1.0),
        "min_gain": _clamp(_safe_float(selector_params.get("min_gain", 0.01), 0.01), -0.25, 0.5),
        "no_op_if_no_positive_gain": bool(selector_params.get("no_op_if_no_positive_gain", True)),
    }

    step = base_step()
    step.update(
        {
            "scorer": scorers,
            "fusion": {
                "atom": "baseline_residual_score_fusion",
                "params": {"baseline_weight": 1.0, "aux_total_weight": aux_total, "score_normalization": norm},
            },
            "budget": {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}},
            "selector": {"atom": "cdpruner_mask_anchored_residual_selector", "params": sel},
            "action": {"atom": "hard_prune"},
            "protection": [],
        }
    )
    return wrap_policy(step, name="evolved_cdpruner_v4_3_true_anchor_residual"), None


def call_llm_json_planner(config: Any, prompt: str) -> Tuple[Optional[Dict[str, Any]], str, Optional[str]]:
    cfg = _model_cfg(config)
    if not cfg.get("api_key"):
        return None, "", "missing_api_key"
    try:
        import openai

        client = openai.OpenAI(api_key=cfg["api_key"], base_url=cfg["base_url"], timeout=cfg["timeout"])
        system_prompt = V10_SYSTEM_PROMPT if _env_flag("EVO_V10_PIPELINE_PLANNER", "0") else SYSTEM_PROMPT
        resp = client.chat.completions.create(
            model=cfg["name"],
            messages=[{"role": "system", "content": system_prompt}, {"role": "user", "content": prompt}],
            temperature=cfg["temperature"],
            max_tokens=cfg["max_tokens"],
        )
        text = resp.choices[0].message.content or ""
        obj = _json_extract(text)
        if obj is None:
            return None, text, "json_parse_failed"
        return obj, text, None
    except Exception as e:
        return None, "", f"llm_call_failed:{e}"


def propose_policy_with_llm(config: Any, parent: Any, inspirations: List[Any], iteration: int) -> PlannerResult:
    mode = _choose_mode(iteration)
    prompt = build_planner_prompt(parent, inspirations, iteration, mode=mode)
    plan, raw, err = call_llm_json_planner(config, prompt)
    # EVO_V14B_PROCESSING_ONLY_DOWNCOMPILE_IN_PLANNER
    if os.environ.get("EVO_V14B_PROCESSING_ONLY", "0").strip() == "1":
        if err is not None or not isinstance(plan, dict):
            return PlannerResult(
                policy=None,
                plan=plan,
                raw_response=raw,
                prompt=prompt,
                error=f"v14b_llm_error:{err}",
                downcompile_note=None,
                mode=str(mode),
            )
        try:
            v14b_policy = canonicalize_plan_to_policy(plan)
            return PlannerResult(
                policy=v14b_policy,
                plan=plan,
                raw_response=raw,
                prompt=prompt,
                error=None,
                downcompile_note="v14b_processing_only_policy",
                mode=str(mode),
            )
        except Exception as e:
            return PlannerResult(
                policy=None,
                plan=plan,
                raw_response=raw,
                prompt=prompt,
                error=f"v14b_downcompile_error:{repr(e)}",
                downcompile_note=None,
                mode=str(mode),
            )

    if err:
        return PlannerResult(policy=None, plan=plan, raw_response=raw, prompt=prompt, error=err, mode=mode)
    policy, note = compile_plan_to_policy(plan or {})
    if policy is None:
        return PlannerResult(policy=None, plan=plan, raw_response=raw, prompt=prompt, error=note or "compile_failed", mode=mode)
    return PlannerResult(policy=policy, plan=plan, raw_response=raw, prompt=prompt, downcompile_note=note, mode=mode)


if __name__ == "__main__":
    print(build_planner_prompt(parent=None, inspirations=[], iteration=0)[:12000])

# ---------------------------------------------------------------------
# v14-B direct planner override
# ---------------------------------------------------------------------
# The original v10 downcompiler rejects `process_tokens` as a bad v10 op.
# In v14-B mode we bypass the v10 validator and directly emit:
# canonical 0021 selection pipeline + one process_tokens node.

try:
    _ORIG_PROPOSE_POLICY_WITH_LLM_V14B = propose_policy_with_llm
except NameError:
    _ORIG_PROPOSE_POLICY_WITH_LLM_V14B = None


def _v14b_iteration_int_from_call(args, kwargs):
    for key in ["iteration", "iter_idx", "i"]:
        if key in kwargs:
            try:
                return int(kwargs[key])
            except Exception:
                pass
    for x in args:
        try:
            if isinstance(x, int):
                return int(x)
        except Exception:
            pass
    return 0


def _v14b_mode_from_call(args, kwargs):
    mode = kwargs.get("mode", None)
    if mode is None:
        mode = "exploration"
    return str(mode)


def _v14b_direct_plan(iteration: int, mode: str):
    # Deterministic but diverse process-token proposals.
    # This guarantees generation>0 children and avoids old v10 validator.
    sem_alphas = [0.004, 0.006, 0.008, 0.010, 0.012, 0.014, 0.016, 0.020]
    sem_gates = [0.55, 0.60, 0.65, 0.70, 0.75]
    temps = [0.05, 0.07, 0.10]
    neigh = [1, 2, 3]

    specs = []

    for a in sem_alphas:
        for g in sem_gates:
            for t in neigh[:2]:
                specs.append((
                    "semantic_gated_residual_merge",
                    {
                        "merge_alpha": a,
                        "top_merge_neighbors": t,
                        "temperature": 0.07,
                        "semantic_gate_threshold": g,
                        "norm_preserve": True,
                    },
                ))

    for a in [0.004, 0.006, 0.008, 0.010, 0.012, 0.014, 0.016, 0.020]:
        for t in neigh:
            for temp in temps:
                specs.append((
                    "similarity_weighted_residual_merge",
                    {
                        "merge_alpha": a,
                        "top_merge_neighbors": t,
                        "temperature": temp,
                        "quality_gate_threshold": 0.0,
                        "norm_preserve": True,
                    },
                ))

    for a in [0.004, 0.008, 0.012, 0.016, 0.020]:
        for t in [1, 2]:
            for r in [1.5, 2.0, 3.0]:
                specs.append((
                    "spatial_local_residual_merge",
                    {
                        "merge_alpha": a,
                        "top_merge_neighbors": t,
                        "temperature": 0.07,
                        "spatial_radius": r,
                        "norm_preserve": True,
                    },
                ))

    for b in [0.002, 0.004, 0.006, 0.008, 0.010, 0.014, 0.020]:
        specs.append((
            "score_rescale_selected_features",
            {
                "rescale_beta": b,
                "center_score": True,
                "norm_preserve": True,
            },
        ))

    # Use iteration index to choose a candidate. Skip seed-like exact duplicate early.
    idx = max(0, int(iteration) - 1) % len(specs)
    proc, params = specs[idx]

    name_bits = []
    for k, v in params.items():
        if isinstance(v, float):
            name_bits.append(f"{k[:3]}{str(v).replace('.', 'p')}")
        elif isinstance(v, int):
            name_bits.append(f"{k[:3]}{v}")

    name = f"v14b_direct_i{iteration:04d}_{proc}_" + "_".join(name_bits[:4])

    return {
        "expected_effect": {
            "perception": "increase",
            "cognition": "preserve",
            "risk": "low",
            "mode": mode,
        },
        "policy": {
            "name": name,
            "process_tokens": {
                "name": proc,
                "params": params,
            },
        },
        "rationale": "v14-B direct processing-only proposal bypassing old v10 process_tokens validator.",
    }


def propose_policy_with_llm(*args, **kwargs):
    import os as _os

    if _os.environ.get("EVO_V14B_PROCESSING_ONLY", "0").strip() == "1":
        from openevolve.v14b_processing_only import canonicalize_plan_to_policy, build_v14b_prompt

        iteration = _v14b_iteration_int_from_call(args, kwargs)
        mode = _v14b_mode_from_call(args, kwargs)

        plan = _v14b_direct_plan(iteration, mode)
        policy = canonicalize_plan_to_policy(plan)

        return PlannerResult(
            policy=policy,
            plan=plan,
            raw_response="v14b_direct_planner_override",
            prompt=build_v14b_prompt(iteration=iteration, mode=mode),
            error=None,
            downcompile_note="v14b_processing_only_policy",
            mode=mode,
        )

    if _ORIG_PROPOSE_POLICY_WITH_LLM_V14B is None:
        return PlannerResult(
            policy=None,
            plan=None,
            raw_response="",
            prompt="",
            error="original_propose_policy_with_llm_missing",
            downcompile_note=None,
            mode="exploration",
        )

    return _ORIG_PROPOSE_POLICY_WITH_LLM_V14B(*args, **kwargs)
