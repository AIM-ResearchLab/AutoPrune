"""Search Space v2 operator generator for Evo-CDPruner YAML policies.

Compared with the previous balanced-registry version, v2 makes three changes:

1. The generator is registry-driven: atom choices and budget choices are read
   from atom_registry.yaml rather than hard-coded only in process_parallel.py.
2. The search is organized by policy families: TopK, MMR, DPP, plus planned
   hybrid families exposed in summaries but not emitted until executor support
   exists.
3. High-value operators observed from smoke21 are prioritized early, especially
   fixed_keep_ratio variants, because the current logs show that ratio/budget
   changes are more likely to produce non-trivial improvements than pure
   monotonic score transforms.

The public entry point stays compatible with process_parallel.py:
    build_operator_candidates(parent_policy=None, registry_path=None)
returns List[Tuple[str, policy_dict]].
"""
from __future__ import annotations

import copy
import hashlib
import json
import os
from pathlib import Path
import yaml
from typing import Any, Dict, Iterable, List, Optional, Tuple

from openevolve.policy_grammar import (
    AtomRegistry,
    Policy,
    base_step,
    wrap_policy,
    budget_fixed_tokens,
    budget_ratio,
    deep_copy,
    dpp_policy,
    mmr_policy,
    policy_family,
    protection_anchor,
    protection_spatial,
    topk_policy,
    baseline_anchored_residual_policy,
    true_cdpruner_anchor_residual_policy,
)

Operator = Tuple[str, Policy]
REGISTRY_PATH = Path(__file__).with_name("atom_registry.yaml")


def _tag(x: Any) -> str:
    return str(x).replace(".", "p").replace("-", "m")


def _fingerprint(policy: Policy) -> str:
    return hashlib.sha256(json.dumps(policy, sort_keys=True).encode("utf-8")).hexdigest()[:16]


def _uniq(ops: Iterable[Operator]) -> List[Operator]:
    seen = set()
    out: List[Operator] = []
    for name, pol in ops:
        fp = _fingerprint(pol)
        if fp in seen:
            continue
        seen.add(fp)
        out.append((name, pol))
    return out




def _manual_policy(step_update: Dict[str, Any], name: str = "evolved_cdpruner_v3_2_operator") -> Policy:
    step = base_step()
    step.update(step_update)
    return wrap_policy(step, name=name)


def _score_atom(atom: str, **params: Any) -> Dict[str, Any]:
    return {"atom": atom, "params": params}


def _topk_multi_scorer_policy(scores: Dict[str, Dict[str, Any]], weights: List[float], norm: str = "minmax", ratio: float = 0.25, protection: Optional[List[Dict[str, Any]]] = None) -> Policy:
    return _manual_policy({
        "scorer": scores,
        "fusion": {"atom": "weighted_sum_score_fusion", "params": {"score_normalization": norm, "weights": weights}},
        "budget": budget_ratio(ratio, 16),
        "selector": {"atom": "topk_selector", "params": {"largest": True}},
        "action": {"atom": "hard_prune"},
        "protection": protection or [],
    })


def _pool_mmr_policy(ratio: float = 0.25, pool_multiplier: float = 2.0, lam: float = 0.65) -> Policy:
    return _manual_policy({
        "scorer": {
            "quality": _score_atom("instruction_guided_visual_relevance", sign="negative_mean", transform="minmax", power=1.0),
            "similarity": {"atom": "pairwise_token_similarity", "params": {"similarity_metric": "cosine", "similarity_transform": "identity"}},
        },
        "fusion": {"atom": "mmr_relevance_diversity_fusion", "params": {"lambda_relevance": lam}},
        "budget": budget_ratio(ratio, 16),
        "selector": {"atom": "topk_pool_mmr_selector", "params": {"pool_multiplier": pool_multiplier, "lambda_relevance": lam, "init_by": "top_relevance"}},
        "action": {"atom": "hard_prune"},
        "protection": [],
    })


def _pool_dpp_policy(ratio: float = 0.25, pool_multiplier: float = 2.0) -> Policy:
    return _manual_policy({
        "scorer": {
            "quality": _score_atom("instruction_guided_visual_relevance", sign="negative_mean", transform="minmax", power=1.0),
            "similarity": {"atom": "conditional_similarity_score", "params": {"similarity_metric": "cosine", "conditioning_mode": "none", "similarity_transform": "identity"}},
        },
        "fusion": {"atom": "quality_diversity_kernel", "params": {"quality_power": 1.0, "similarity_power": 1.0, "eps": 1e-6, "symmetrize": True}},
        "budget": budget_ratio(ratio, 16),
        "selector": {"atom": "topk_pool_dpp_selector", "params": {"pool_multiplier": pool_multiplier, "algorithm": "fast_map", "postprocess": "sort_by_position"}},
        "action": {"atom": "dpp_subset_prune"},
        "protection": [],
    })


def _get_step(policy: Optional[Policy]) -> Optional[Dict[str, Any]]:
    if not isinstance(policy, dict):
        return None
    pipe = policy.get("pipeline")
    if not isinstance(pipe, list) or not pipe or not isinstance(pipe[0], dict):
        return None
    return pipe[0]


def _parent_local_variants(parent_policy: Optional[Policy], registry: AtomRegistry) -> List[Operator]:
    """Local mutations around the sampled parent.

    This keeps exploitation, but v2 avoids spending too much budget on pure
    no-op transforms by putting budget/protection/selector-family changes first.
    """
    ops: List[Operator] = []
    step = _get_step(parent_policy)
    if step is None:
        return ops

    selector = step.get("selector", {}).get("atom")
    budget = step.get("budget", budget_fixed_tokens())
    protection = step.get("protection", []) or []

    try:
        if selector == "topk_selector":
            main = step.get("scorer", {}).get("main", {})
            params = main.get("params", {}) if isinstance(main, dict) else {}
            sign0 = params.get("sign", "negative_mean")
            transform0 = params.get("transform", "rank_norm")
            power0 = float(params.get("power", 1.0))

            # Budget is high-impact on smoke21; try this before score-only edits.
            for ratio in [0.18, 0.20, 0.22, 0.25, 0.30, 0.35]:
                ops.append((
                    f"parent_topk_budget_ratio_{_tag(ratio)}",
                    topk_policy(sign=sign0, transform="minmax", power=1.0, fusion_norm="minmax", budget=budget_ratio(ratio, 16), protection=protection),
                ))

            # Protection variants around current sign/transform.
            for prot_name, prot in [
                ("spatial4", [protection_spatial(4)]),
                ("spatial7", [protection_spatial(7)]),
                ("anchor8", [protection_anchor(8)]),
                ("anchor16", [protection_anchor(16)]),
            ]:
                ops.append((
                    f"parent_topk_protection_{prot_name}",
                    topk_policy(sign=sign0, transform=transform0, power=power0, fusion_norm=transform0, budget=budget, protection=prot),
                ))

            # Score/sign edits.  These may be useful but are often less diverse.
            for sign in ["negative_mean", "positive_mean", "max"]:
                ops.append((f"parent_topk_sign_{sign}", topk_policy(sign=sign, transform=transform0, power=power0, fusion_norm=transform0, budget=budget, protection=protection)))
            for transform in ["rank_norm", "minmax", "sigmoid", "softmax"]:
                ops.append((f"parent_topk_transform_{transform}", topk_policy(sign=sign0, transform=transform, power=1.0, fusion_norm=transform, budget=budget, protection=protection)))

            # Family jumps from a TopK parent.
            for lam in [0.45, 0.60, 0.75]:
                ops.append((f"parent_jump_mmr_lambda_{_tag(lam)}", mmr_policy(sign=sign0, transform=transform0, lambda_relevance=lam, budget=budget_fixed_tokens())))
            ops.append(("parent_jump_dpp_conditional", dpp_policy(sign=sign0, transform="minmax", sim_atom="conditional_similarity_score", budget=budget_fixed_tokens())))

        elif selector == "mmr_selector":
            sc = step.get("scorer", {})
            q = sc.get("quality", {}) if isinstance(sc, dict) else {}
            qp = q.get("params", {}) if isinstance(q, dict) else {}
            sign0 = qp.get("sign", "negative_mean")
            transform0 = qp.get("transform", "rank_norm")
            for lam in [0.35, 0.45, 0.55, 0.65, 0.75, 0.85]:
                ops.append((f"parent_mmr_lambda_{_tag(lam)}", mmr_policy(sign=sign0, transform=transform0, lambda_relevance=lam, budget=budget)))
            for ratio in [0.20, 0.25, 0.30]:
                ops.append((f"parent_mmr_ratio_{_tag(ratio)}", mmr_policy(sign=sign0, transform=transform0, lambda_relevance=0.65, budget=budget_ratio(ratio, 16))))
            ops.append(("parent_mmr_to_topk_ratio_0p2", topk_policy(sign="negative_mean", transform="minmax", fusion_norm="minmax", budget=budget_ratio(0.20, 16))))

        elif selector == "dpp_selector":
            sc = step.get("scorer", {})
            q = sc.get("quality", {}) if isinstance(sc, dict) else {}
            qp = q.get("params", {}) if isinstance(q, dict) else {}
            sign0 = qp.get("sign", "negative_mean")
            for qpwr, spwr in [(1.25, 1.0), (1.0, 1.25), (1.5, 0.75), (0.75, 1.5)]:
                ops.append((f"parent_dpp_qp_{_tag(qpwr)}_sp_{_tag(spwr)}", dpp_policy(sign=sign0, transform="minmax", quality_power=qpwr, similarity_power=spwr)))
            for ratio in [0.20, 0.25, 0.30]:
                ops.append((f"parent_dpp_ratio_{_tag(ratio)}", dpp_policy(sign=sign0, transform="minmax", budget=budget_ratio(ratio, 16))))
            ops.append(("parent_dpp_to_topk_ratio_0p2", topk_policy(sign="negative_mean", transform="minmax", fusion_norm="minmax", budget=budget_ratio(0.20, 16))))
    except Exception:
        return ops

    return _uniq(ops)


def _baseline_residual_ops(registry: AtomRegistry) -> List[Operator]:
    """v4.3 true-CDPruner-mask anchored residual fallback/enumerator.

    The LLM chooses residual branch structure; this enumerator systematically
    scans safe replacement operators around those structures.  It never emits
    old topk-ratio or full-DPP replacement policies.
    """
    ops: List[Operator] = []
    aux_families = [
        ("norm", [{"id": "aux1", "atom": "visual_token_norm_saliency", "params": {"transform": "minmax", "power": 1.0}}]),
        ("redundancy", [{"id": "aux1", "atom": "redundancy_density_penalty", "params": {"k_neighbors": 8, "metric": "cosine", "transform": "minmax"}}]),
        ("attention_norm", [{"id": "aux1", "atom": "attention_proxy_saliency", "params": {"proxy": "feature_norm", "transform": "minmax"}}]),
        ("spatial", [{"id": "aux1", "atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}}]),
        ("norm_redundancy", [
            {"id": "aux1", "atom": "visual_token_norm_saliency", "params": {"transform": "minmax", "power": 1.0}},
            {"id": "aux2", "atom": "redundancy_density_penalty", "params": {"k_neighbors": 8, "metric": "cosine", "transform": "minmax"}},
        ]),
        ("spatial_norm", [
            {"id": "aux1", "atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}},
            {"id": "aux2", "atom": "visual_token_norm_saliency", "params": {"transform": "minmax", "power": 1.0}},
        ]),
    ]
    operator_settings = [
        ("noop_strict", 0.03, 0.55, 0, 0.0625, 0.90, 0.10, 0.02),
        ("conservative", 0.05, 0.80, 0, 0.125, 0.85, 0.15, 0.01),
        ("moderate", 0.10, 1.00, 0, 0.25, 0.75, 0.25, 0.005),
        ("explore_guarded", 0.15, 1.20, 1, 0.25, 0.70, 0.30, 0.0),
    ]
    for fam_name, aux in aux_families:
        for op_name, aux_w, alpha, min_r, max_ratio, gb, gr, mg in operator_settings:
            ops.append((
                f"v4_3_{fam_name}_{op_name}",
                true_cdpruner_anchor_residual_policy(
                    aux_scorers=aux,
                    aux_total_weight=aux_w,
                    alpha=alpha,
                    min_residual=min_r,
                    max_residual_ratio=max_ratio,
                    gate_baseline_weight=gb,
                    gate_residual_weight=gr,
                    min_gain=mg,
                    no_op_if_no_positive_gain=True,
                ),
            ))
    return _uniq(ops)



# =========================
# v10 executable pipeline fallback operators
# =========================

def _v10_env_flag(name: str, default: str = "0") -> bool:
    return str(os.environ.get(name, default)).strip().lower() in {"1", "true", "yes", "y", "on"}


def _v10_load_seed_policy(parent_policy: Optional[Policy] = None) -> Optional[Policy]:
    if isinstance(parent_policy, dict) and isinstance(parent_policy.get("pipeline"), list):
        return copy.deepcopy(parent_policy)

    seed_paths = [
        Path("/data/lz/openevolve_pruner/CDPruner/openevolve/runs/v10_llm_driven_seed/seed_v9_5_anchor08_product_more_redundancy.yaml"),
        Path("openevolve/runs/v10_llm_driven_seed/seed_v9_5_anchor08_product_more_redundancy.yaml"),
    ]
    for sp in seed_paths:
        if sp.exists():
            return yaml.safe_load(sp.read_text())
    return None


def _v10_find_node(pipe: List[Dict[str, Any]], op: str, name: Optional[str] = None) -> Optional[Dict[str, Any]]:
    for node in pipe:
        if not isinstance(node, dict):
            continue
        if node.get("op") != op:
            continue
        if name is not None and node.get("name") != name:
            continue
        return node
    return None


def _v10_mutate_policy(
    base: Policy,
    name: str,
    weights: Dict[str, float],
    anchor_quota: int = 8,
    diversity_lambda: float = 0.18,
    pool_factor: float = 3.0,
    kernel: str = "pairwise_cosine_kernel",
) -> Policy:
    pol = copy.deepcopy(base)
    pol["policy_name"] = name
    pol["name"] = name
    pol["keep_tokens"] = 32

    pipe = pol.get("pipeline", [])

    fuse = _v10_find_node(pipe, "product_fuse_score", "weighted_product_fusion")
    if fuse is not None:
        fuse.setdefault("params", {})["weights"] = dict(weights)

    pool = _v10_find_node(pipe, "build_pool", "quality_pool_builder")
    if pool is not None:
        pool.setdefault("params", {})["pool_factor"] = float(pool_factor)

    ker = _v10_find_node(pipe, "compute_kernel")
    if ker is not None:
        ker["name"] = kernel
        if kernel in {"runtime_conditional_similarity_kernel", "cdpruner_conditional_similarity_kernel"}:
            ker.setdefault("inputs", {})["quality"] = "quality_score"
            ker.setdefault("params", {})["quality_power"] = 1.0
            ker.setdefault("params", {})["shift_similarity"] = True
        else:
            ker.pop("inputs", None)
            ker.pop("params", None)

    sel = _v10_find_node(pipe, "select", "runtime_reference_anchor_pool_dpp_selector")
    if sel is not None:
        sel.setdefault("params", {})["anchor_quota"] = int(anchor_quota)
        sel.setdefault("params", {})["diversity_lambda"] = float(diversity_lambda)
        sel.setdefault("params", {})["exclude_unanchored_reference"] = True
        sel.setdefault("params", {})["sort_selected"] = True

    return pol


def _v10_anchor_product_ops(parent_policy: Optional[Policy] = None) -> List[Operator]:
    base = _v10_load_seed_policy(parent_policy)
    if base is None:
        return []

    weight_sets = {
        "red030": {"semantic": 0.35, "attn": 0.10, "spatial": 0.15, "redundancy": 0.30, "contrast": 0.10},
        "red035": {"semantic": 0.32, "attn": 0.10, "spatial": 0.13, "redundancy": 0.35, "contrast": 0.10},
        "red040": {"semantic": 0.30, "attn": 0.08, "spatial": 0.12, "redundancy": 0.40, "contrast": 0.10},
        "semred": {"semantic": 0.40, "attn": 0.10, "spatial": 0.10, "redundancy": 0.30, "contrast": 0.10},
        "contrast": {"semantic": 0.32, "attn": 0.10, "spatial": 0.10, "redundancy": 0.28, "contrast": 0.20},
    }

    ops: List[Operator] = []

    for wname, weights in weight_sets.items():
        for anchor in [7, 8, 9]:
            for div in [0.12, 0.18, 0.24]:
                name = f"v10_fallback_{wname}_a{anchor}_d{str(div).replace('.', 'p')}"
                ops.append((
                    name,
                    _v10_mutate_policy(
                        base,
                        name=name,
                        weights=weights,
                        anchor_quota=anchor,
                        diversity_lambda=div,
                        pool_factor=3.0,
                        kernel="pairwise_cosine_kernel",
                    ),
                ))

    for wname in ["red030", "red035", "semred"]:
        weights = weight_sets[wname]
        name = f"v10_fallback_{wname}_condker_a8"
        ops.append((
            name,
            _v10_mutate_policy(
                base,
                name=name,
                weights=weights,
                anchor_quota=8,
                diversity_lambda=0.18,
                pool_factor=3.0,
                kernel="runtime_conditional_similarity_kernel",
            ),
        ))

    return _uniq(ops)


def build_operator_candidates(parent_policy: Optional[Policy] = None, registry_path: Optional[Path] = None) -> List[Operator]:
    if _v10_env_flag("EVO_V10_PIPELINE_PLANNER", "0"):
        return _v10_anchor_product_ops(parent_policy)

    registry = AtomRegistry(registry_path or REGISTRY_PATH)
    ops: List[Operator] = []

    # v4.1: fallback must stay inside the baseline-anchored residual search space.
    # This prevents duplicate LLM proposals from falling back to old full-replacement
    # TopK/DPP/MMR or ratio policies, which polluted v4 smoke runs.
    ops.extend(_baseline_residual_ops(registry))

    # Parent-specific exploitation is allowed only if it also emits v4 residual policies.
    # The old _parent_local_variants is deliberately not used here because it may emit
    # fixed_keep_ratio / full DPP / full TopK candidates.

    return _uniq(ops)


def build_search_space_report(parent_policy: Optional[Policy] = None, registry_path: Optional[Path] = None) -> Dict[str, Any]:
    registry = AtomRegistry(registry_path or REGISTRY_PATH)
    ops = build_operator_candidates(parent_policy, registry_path=registry_path)
    family_counts: Dict[str, int] = {}
    for _, pol in ops:
        family_counts[policy_family(pol)] = family_counts.get(policy_family(pol), 0) + 1
    return {
        "registry": registry.summary(),
        "num_executable_operators": len(ops),
        "operator_family_counts": family_counts,
        "first_30_operator_names": [name for name, _ in ops[:30]],
        "llm_planner_summary": registry.llm_planner_summary(max_atoms_per_family=8),
    }


if __name__ == "__main__":
    report = build_search_space_report()
    print(json.dumps(report, indent=2, ensure_ascii=False))

# ---------------------------------------------------------------------
# v14-B processing-only fallback override
# ---------------------------------------------------------------------
def _v14b_build_processing_fallback_candidates():
    import copy
    import itertools
    from openevolve.v14b_processing_only import (
        BASE_0021_PATH,
        PROCESS_INPUTS,
        base_selection_pipeline,
        load_yaml_policy,
    )

    base = load_yaml_policy(BASE_0021_PATH)
    base_pipe = base_selection_pipeline()
    ops = []

    specs = []

    for a, g, t in itertools.product(
        [0.004, 0.006, 0.008, 0.010, 0.012, 0.014, 0.016, 0.020],
        [0.55, 0.60, 0.65, 0.70, 0.75],
        [1, 2],
    ):
        specs.append(("semantic_gated_residual_merge", {
            "merge_alpha": a,
            "top_merge_neighbors": t,
            "temperature": 0.07,
            "semantic_gate_threshold": g,
            "norm_preserve": True,
        }))

    for a, t, temp in itertools.product(
        [0.004, 0.006, 0.010, 0.014, 0.020],
        [1, 2],
        [0.05, 0.07, 0.10],
    ):
        specs.append(("similarity_weighted_residual_merge", {
            "merge_alpha": a,
            "top_merge_neighbors": t,
            "temperature": temp,
            "quality_gate_threshold": 0.0,
            "norm_preserve": True,
        }))

    for a, t, r in itertools.product(
        [0.004, 0.008, 0.012, 0.016],
        [1, 2],
        [1.5, 2.0, 3.0],
    ):
        specs.append(("spatial_local_residual_merge", {
            "merge_alpha": a,
            "top_merge_neighbors": t,
            "temperature": 0.07,
            "spatial_radius": r,
            "norm_preserve": True,
        }))

    for b in [0.002, 0.004, 0.006, 0.010, 0.014, 0.020]:
        specs.append(("score_rescale_selected_features", {
            "rescale_beta": b,
            "center_score": True,
            "norm_preserve": True,
        }))

    for i, (proc, params) in enumerate(specs):
        pol = copy.deepcopy(base)
        name = f"v14b_fb_{i:04d}_{proc}"
        pol["policy_name"] = name
        pol["name"] = name
        pol["keep_tokens"] = 32
        pol["pipeline"] = copy.deepcopy(base_pipe) + [{
            "op": "process_tokens",
            "name": proc,
            "inputs": copy.deepcopy(PROCESS_INPUTS[proc]),
            "params": params,
            "output": "processed_features",
        }]
        ops.append((name, pol))

    return ops


try:
    _build_operator_candidates_original_v14b = build_operator_candidates
except NameError:
    _build_operator_candidates_original_v14b = None


def build_operator_candidates(parent_policy=None, registry_path=None):
    import os
    if os.environ.get("EVO_V14B_PROCESSING_ONLY", "0").strip() == "1":
        return _v14b_build_processing_fallback_candidates()
    if _build_operator_candidates_original_v14b is None:
        return []
    return _build_operator_candidates_original_v14b(parent_policy, registry_path=registry_path)
