"""
Internal OpenEvolve evaluator wrapper.

This file is part of the OpenEvolve framework layer.

Important:
- Do NOT put task-specific MNIST1D training logic here.
- Task-specific evaluator should be a separate file, e.g. mnist1d_evaluator.py.
- This class loads the task evaluator file passed from CLI and calls its evaluate(program_path).
"""

import asyncio
import importlib.util
import os
import shutil
import tempfile
import traceback
import uuid
from pathlib import Path
from typing import Any, Dict, Optional


class Evaluator:
    """
    OpenEvolve internal evaluator wrapper.

    The controller passes:
        Evaluator(config.evaluator, evaluation_file, llm_evaluator_ensemble, prompt_sampler, ...)

    `evaluation_file` should be a task evaluator script that defines:
        evaluate(program_path: str) -> EvaluationResult | dict

    The task evaluator is responsible for running the benchmark.
    This wrapper is responsible for:
    - writing candidate code to a temporary Python file;
    - calling the task evaluator;
    - normalizing returned metrics/artifacts;
    - exposing pending artifacts to the database.
    """

    def __init__(
        self,
        config: Any,
        evaluation_file: str,
        llm_ensemble: Any = None,
        prompt_sampler: Any = None,
        database: Any = None,
        suffix: str = ".py",
    ):
        self.config = config
        self.evaluation_file = os.path.abspath(evaluation_file)
        self.llm_ensemble = llm_ensemble
        self.prompt_sampler = prompt_sampler
        self.database = database
        self.suffix = suffix if suffix else ".py"

        self._pending_artifacts: Dict[str, Dict[str, Any]] = {}

        if not os.path.exists(self.evaluation_file):
            raise FileNotFoundError(f"Evaluation file not found: {self.evaluation_file}")

    def get_pending_artifacts(self, program_id: str) -> Optional[Dict[str, Any]]:
        """
        Return artifacts produced by the most recent evaluation of this program.
        The caller stores these artifacts in ProgramDatabase.
        """
        return self._pending_artifacts.pop(program_id, None)

    async def evaluate_program(self, program_code: str, program_id: Optional[str] = None) -> Dict[str, Any]:
        """
        Asynchronously evaluate candidate code and return metrics only.

        OpenEvolve expects this method to return a metrics dictionary.
        Artifacts are stored internally and retrieved via get_pending_artifacts(program_id).
        """
        if program_id is None:
            program_id = str(uuid.uuid4())

        timeout = getattr(self.config, "timeout", None)
        if timeout is None:
            timeout = 100000

        try:
            return await asyncio.wait_for(
                asyncio.to_thread(self._evaluate_program_sync, program_code, program_id),
                timeout=float(timeout),
            )
        except asyncio.TimeoutError:
            metrics = {
                "combined_score": -1e18,
                "ood_acc": -1e18,
                "error": f"evaluation timeout after {timeout} seconds",
            }
            self._pending_artifacts[program_id] = {
                "error": "timeout",
                "timeout": timeout,
            }
            return metrics
        except Exception as e:
            metrics = {
                "combined_score": -1e18,
                "ood_acc": -1e18,
                "error": str(e),
            }
            self._pending_artifacts[program_id] = {
                "error": str(e),
                "traceback": traceback.format_exc(),
            }
            return metrics

    def _evaluate_program_sync(self, program_code: str, program_id: str) -> Dict[str, Any]:
        tmp_dir = tempfile.mkdtemp(prefix=f"openevolve_eval_{program_id}_")
        program_path = os.path.join(tmp_dir, f"candidate{self.suffix}")

        try:
            with open(program_path, "w", encoding="utf-8") as f:
                f.write(program_code)

            eval_module = self._load_task_evaluator_module()
            if not hasattr(eval_module, "evaluate"):
                raise AttributeError(
                    f"Task evaluator must define evaluate(program_path). "
                    f"Missing in: {self.evaluation_file}"
                )

            result = eval_module.evaluate(program_path)
            metrics, artifacts = self._normalize_result(result)

            if not isinstance(metrics, dict):
                raise TypeError("Evaluator result metrics must be a dictionary")

            metrics = self._sanitize_metrics(metrics)
            artifacts = artifacts if isinstance(artifacts, dict) else {"artifacts": artifacts}
            artifacts.setdefault("candidate_program_path", program_path)
            artifacts.setdefault("task_evaluation_file", self.evaluation_file)

            self._pending_artifacts[program_id] = artifacts
            return metrics

        except Exception as e:
            self._pending_artifacts[program_id] = {
                "error": str(e),
                "traceback": traceback.format_exc(),
                "candidate_program_path": program_path,
                "task_evaluation_file": self.evaluation_file,
            }
            return {
                "combined_score": -1e18,
                "ood_acc": -1e18,
                "error": str(e),
            }

        finally:
            # The task evaluator may spawn subprocesses and should already have finished here.
            # Remove temporary code to avoid accumulating files.
            try:
                shutil.rmtree(tmp_dir, ignore_errors=True)
            except Exception:
                pass

    def _load_task_evaluator_module(self):
        """
        Load the task-specific evaluator file under a unique module name.

        Using a unique name prevents Python import cache conflicts across iterations.
        """
        module_name = f"_openevolve_task_eval_{uuid.uuid4().hex}"
        spec = importlib.util.spec_from_file_location(module_name, self.evaluation_file)
        if spec is None or spec.loader is None:
            raise ImportError(f"Could not load task evaluator from: {self.evaluation_file}")

        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    @staticmethod
    def _normalize_result(result: Any):
        """
        Convert different evaluator return styles into (metrics, artifacts).

        Supported:
        - object with .metrics and .artifacts
        - dict with {"metrics": ..., "artifacts": ...}
        - raw metrics dict
        """
        if hasattr(result, "metrics"):
            metrics = getattr(result, "metrics")
            artifacts = getattr(result, "artifacts", {})
            return metrics, artifacts

        if isinstance(result, dict):
            if "metrics" in result:
                return result.get("metrics", {}), result.get("artifacts", {})
            return result, {}

        raise TypeError(
            "Task evaluator must return EvaluationResult-like object or dict. "
            f"Got: {type(result)}"
        )

    @staticmethod
    def _sanitize_metrics(metrics: Dict[str, Any]) -> Dict[str, Any]:
        """
        Ensure metrics are JSON-friendly enough for logging/database use.
        """
        clean = {}
        for k, v in metrics.items():
            if isinstance(v, bool):
                clean[k] = v
            elif isinstance(v, int):
                clean[k] = int(v)
            elif isinstance(v, float):
                clean[k] = float(v)
            else:
                # Keep strings such as error messages; stringify other objects.
                clean[k] = v if isinstance(v, str) else str(v)

        if "combined_score" not in clean:
            numeric = [
                v for v in clean.values()
                if isinstance(v, (int, float)) and not isinstance(v, bool)
            ]
            clean["combined_score"] = float(sum(numeric) / len(numeric)) if numeric else -1e18

        return clean