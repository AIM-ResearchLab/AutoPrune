#!/usr/bin/env bash
set -euo pipefail

CDPRUNER_ROOT="/data/lz/openevolve_pruner/CDPruner"
DEFAULT_MERGE_POLICY="${CDPRUNER_ROOT}/openevolve/policies/v17_formal/v17_cdpruner_anchor_initial.yaml"

MERGE_POLICY="${1:-$DEFAULT_MERGE_POLICY}"
shift || true

if [ ! -f "$MERGE_POLICY" ]; then
  echo "ERROR: UniMerge policy not found: $MERGE_POLICY"
  exit 1
fi

if [ "$#" -eq 0 ]; then
  echo "Usage: $0 <merge_policy_yaml> <command...>"
  exit 1
fi

export PYTHONPATH="${CDPRUNER_ROOT}:${PYTHONPATH:-}"

export EVO_CDPRUNER_ENABLE=1
export EVO_CDPRUNER_V14_ENABLE=1
export EVO_TOKEN="${EVO_TOKEN:-32}"
export EVO_FORCE_FIXED_TOKENS="${EVO_FORCE_FIXED_TOKENS:-${EVO_TOKEN}}"

# Critical: use v16 initial / clean CDPruner path.
unset CDPRUNER_POLICY
unset EVO_POLICY_YAML_PATH
unset EVO_CANDIDATE_POLICY_PATH
unset EVO_POLICY_YAML
unset EVO_CANDIDATE_POLICY_YAML

# Universal merge DSL layer.
export EVO_UNIMERGE_ENABLE="${EVO_UNIMERGE_ENABLE:-1}"
export EVO_UNIMERGE_MODE="hybrid_v16_anchor"
export EVO_UNIMERGE_POLICY_PATH="$MERGE_POLICY"
export EVO_UNIMERGE_POLICY_YAML="$(cat "$MERGE_POLICY")"
export EVO_UNIMERGE_DEBUG="${EVO_UNIMERGE_DEBUG:-0}"
export EVO_UNIMERGE_OUTPUT_MODE="${EVO_UNIMERGE_OUTPUT_MODE:-inplace_full}"

if [ -n "${EVO_GPU:-}" ]; then
  export CUDA_VISIBLE_DEVICES="${EVO_GPU}"
fi

echo "=== v17 clean-CDPruner-anchored UniMerge ==="
echo "Anchor provider: clean_cdpruner_k32_no_yaml"
echo "Merge policy: $MERGE_POLICY"
echo "CDPRUNER_POLICY=${CDPRUNER_POLICY:-unset}"
echo "EVO_POLICY_YAML_PATH=${EVO_POLICY_YAML_PATH:-unset}"
echo "EVO_GPU=${EVO_GPU:-unset}"
echo "CUDA_VISIBLE_DEVICES=${CUDA_VISIBLE_DEVICES:-unset}"
echo "EVO_TOKEN=${EVO_TOKEN}"
echo "EVO_UNIMERGE_MODE=${EVO_UNIMERGE_MODE}"
echo "EVO_UNIMERGE_ENABLE=${EVO_UNIMERGE_ENABLE}"
echo "EVO_UNIMERGE_OUTPUT_MODE=${EVO_UNIMERGE_OUTPUT_MODE}"

exec "$@"
