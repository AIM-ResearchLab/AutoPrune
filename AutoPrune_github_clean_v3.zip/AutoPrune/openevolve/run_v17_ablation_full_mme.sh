#!/usr/bin/env bash
set -euo pipefail

cd /data/lz/openevolve_pruner/CDPruner

export PYTHONPATH="/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}"
export EVO_GPU="${EVO_GPU:-6}"
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0

RUN_ROOT="openevolve/runs/v17_ablation_full_mme"
mkdir -p "$RUN_ROOT"

POLICIES=(
  "openevolve/policies/v17_ablation/v17_anchor_only.yaml"
  "openevolve/policies/v17_ablation/v17_anchor_weighted_residual_s003.yaml"
  "openevolve/policies/v17_ablation/v17_anchor_weighted_residual_s005.yaml"
  "openevolve/policies/v17_ablation/v17_anchor_weighted_residual_s010.yaml"
)

for P in "${POLICIES[@]}"; do
  NAME="$(basename "$P" .yaml)"
  echo "===== Running $NAME ====="
  mkdir -p "$RUN_ROOT/$NAME"

  openevolve/run_with_v17_unimerge_env.sh \
    "$P" \
    bash scripts/v1_5/eval/mme.sh 32 "$NAME" \
    > "$RUN_ROOT/$NAME/mme_full.log" 2>&1

  grep -n "===========\|total score:\|score:" "$RUN_ROOT/$NAME/mme_full.log" \
    | tail -120 \
    | tee "$RUN_ROOT/$NAME/mme_full_score_summary.txt"

  echo "===== Finished $NAME ====="
done
