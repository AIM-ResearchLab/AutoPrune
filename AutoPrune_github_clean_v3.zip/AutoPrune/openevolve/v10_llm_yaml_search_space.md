# v14-B: LLM-Driven Post-Selection Token Processing Search

This is not a token-subset search.
This is not a new-base search.
This is not a selector search.

Seed:
- v14-A best policy: 0040_v14a_from_real0021_semmerge_a0p01_t1_g0p65
- full perception = 1404.9354
- full cognition  = 301.4286
- full raw        = 1706.3639
- overlap_with_reference_avg = 0.9375
- changed_tokens_avg = 2.0
- v14_feature_delta_norm_avg = 0.107058

Primary target:
- full raw_combined_score > 1706.3639

Secondary target:
- keep perception >= 1404.0 if possible
- keep cognition >= 301.4286 if possible
- keep balanced_score >= 1129.0 if possible

Hard constraints:
- keep_tokens must be 32
- keep the original 0021 selection pipeline unchanged
- keep native_teacher_mask_prior
- keep weighted_product_fusion weights unchanged unless explicitly necessary
- keep native_reference_residual_exchange_selector
- keep replace_quota = 2
- keep min_reference_keep = 30
- keep overlap_with_reference_avg = 0.9375
- keep changed_tokens_avg = 2.0
- only mutate the final process_tokens node

Allowed top-level schema:
policy_name: string
name: string
keep_tokens: 32
pipeline:
  - op: compute_score | product_fuse_score | compute_kernel | select | process_tokens
    name: string
    inputs: optional dict
    params: optional dict
    output: string

The first 9 nodes must remain the 0021 selection pipeline:
1. native_teacher_mask_prior -> reference_score
2. instruction_guided_visual_relevance -> semantic_score
3. attention_proxy_saliency -> attn_score
4. spatial_centrality_prior -> spatial_score
5. redundancy_density_penalty -> redundancy_score
6. local_contrast_saliency -> contrast_score
7. pairwise_cosine_kernel -> sim_kernel
8. weighted_product_fusion -> quality_score
9. native_reference_residual_exchange_selector -> selected

Only the final process_tokens node may be changed.

Allowed process_tokens modules:
- identity_token_processing
- score_rescale_selected_features
- similarity_weighted_residual_merge
- semantic_gated_residual_merge
- spatial_local_residual_merge

Recommended search focus:
- semantic_gated_residual_merge is currently best.
- Around best:
  - merge_alpha near 0.006 to 0.016
  - top_merge_neighbors = 1 is usually safest
  - semantic_gate_threshold near 0.60 to 0.70
  - temperature near 0.05 to 0.10
  - norm_preserve = true

Allowed parameter ranges:
merge_alpha:
- 0.002 to 0.030
top_merge_neighbors:
- 1, 2, 3
temperature:
- 0.04 to 0.12
semantic_gate_threshold:
- 0.50 to 0.80
quality_gate_threshold:
- 0.00 to 0.70
spatial_radius:
- 1.0 to 3.0
rescale_beta:
- 0.002 to 0.030
norm_preserve:
- true
center_score:
- true

Forbidden:
- changing keep_tokens
- changing selected-token count
- changing the first 9 pipeline nodes
- changing native_teacher_mask_prior
- changing native_reference_residual_exchange_selector
- changing replace_quota away from 2
- changing min_reference_keep away from 30
- using cdpruner_reference_mask_prior
- using margin_gated selectors
- using strict_margin selectors
- using runtime_reference_anchor_pool_dpp_selector
- using adaptive_reference_anchor_pool_dpp_selector
- using build_pool
- using policy_graph
- using residual_patch
- using any trainable module
- changing model weights
- changing LLaVA code
