from __future__ import annotations

import copy
import json
import os
from pathlib import Path
from typing import Any, Dict, List, Mapping, Optional, Tuple

import yaml


SEED_POLICY_PATH = Path(
    "openevolve/runs/v14_a_processing_grid/policies/0040_v14a_from_real0021_semmerge_a0p01_t1_g0p65.yaml"
)

BASE_0021_PATH = Path(
    "openevolve/runs/v12_native_reference_full_check/0021_v12_native_balanced_rq02.yaml"
)

ALLOWED_PROCESS_NAMES = {
    "identity_token_processing",
    "score_rescale_selected_features",
    "similarity_weighted_residual_merge",
    "semantic_gated_residual_merge",
    "spatial_local_residual_merge",
}

PROCESS_INPUTS = {
    "identity_token_processing": {
        "features": "image_features",
        "selected": "selected",
    },
    "score_rescale_selected_features": {
        "features": "image_features",
        "selected": "selected",
        "score": "quality_score",
    },
    "similarity_weighted_residual_merge": {
        "features": "image_features",
        "selected": "selected",
        "quality": "quality_score",
        "kernel": "sim_kernel",
    },
    "semantic_gated_residual_merge": {
        "features": "image_features",
        "selected": "selected",
        "quality": "quality_score",
        "semantic": "semantic_score",
        "kernel": "sim_kernel",
    },
    "spatial_local_residual_merge": {
        "features": "image_features",
        "selected": "selected",
        "quality": "quality_score",
        "kernel": "sim_kernel",
    },
}


def _clamp_float(x: Any, lo: float, hi: float, default: float) -> float:
    try:
        v = float(x)
    except Exception:
        v = float(default)
    return max(lo, min(hi, v))


def _clamp_int(x: Any, lo: int, hi: int, default: int) -> int:
    try:
        v = int(x)
    except Exception:
        v = int(default)
    return max(lo, min(hi, v))


def load_yaml_policy(path: Path) -> Dict[str, Any]:
    obj = yaml.safe_load(path.read_text())
    if not isinstance(obj, dict):
        raise ValueError(f"bad yaml policy: {path}")
    return obj


def base_selection_pipeline() -> List[Dict[str, Any]]:
    # Prefer the true 0021 base selection pipeline. It has no process_tokens.
    base = load_yaml_policy(BASE_0021_PATH)
    pipe = copy.deepcopy(base.get("pipeline", []))
    pipe = [n for n in pipe if isinstance(n, dict) and n.get("op") != "process_tokens"]
    if len(pipe) != 9:
        raise ValueError(f"expected 9 base selection nodes, got {len(pipe)}")
    return pipe


def seed_process_node() -> Dict[str, Any]:
    seed = load_yaml_policy(SEED_POLICY_PATH)
    for n in seed.get("pipeline", []):
        if isinstance(n, dict) and n.get("op") == "process_tokens":
            return copy.deepcopy(n)
    raise ValueError(f"seed policy has no process_tokens node: {SEED_POLICY_PATH}")


def sanitize_process_node(node: Mapping[str, Any], name_hint: str = "v14b_child") -> Dict[str, Any]:
    raw_name = str(node.get("name", "") or node.get("op", ""))
    if raw_name == "process_tokens":
        raw_name = str(node.get("processor", "") or node.get("module", ""))

    if raw_name not in ALLOWED_PROCESS_NAMES:
        # Default to the known best family.
        raw_name = "semantic_gated_residual_merge"

    params = dict(node.get("params", {}) or {})

    out_params: Dict[str, Any] = {"norm_preserve": True}

    if raw_name == "identity_token_processing":
        out_params = {}

    elif raw_name == "score_rescale_selected_features":
        out_params.update({
            "rescale_beta": _clamp_float(params.get("rescale_beta", 0.01), 0.001, 0.030, 0.01),
            "center_score": True,
            "norm_preserve": True,
        })

    elif raw_name == "similarity_weighted_residual_merge":
        out_params.update({
            "merge_alpha": _clamp_float(params.get("merge_alpha", 0.010), 0.001, 0.030, 0.010),
            "top_merge_neighbors": _clamp_int(params.get("top_merge_neighbors", 1), 1, 3, 1),
            "temperature": _clamp_float(params.get("temperature", 0.07), 0.04, 0.12, 0.07),
            "quality_gate_threshold": _clamp_float(params.get("quality_gate_threshold", 0.0), 0.0, 0.70, 0.0),
            "norm_preserve": True,
        })

    elif raw_name == "semantic_gated_residual_merge":
        out_params.update({
            "merge_alpha": _clamp_float(params.get("merge_alpha", 0.010), 0.001, 0.030, 0.010),
            "top_merge_neighbors": _clamp_int(params.get("top_merge_neighbors", 1), 1, 3, 1),
            "temperature": _clamp_float(params.get("temperature", 0.07), 0.04, 0.12, 0.07),
            "semantic_gate_threshold": _clamp_float(params.get("semantic_gate_threshold", 0.65), 0.50, 0.80, 0.65),
            "norm_preserve": True,
        })

    elif raw_name == "spatial_local_residual_merge":
        out_params.update({
            "merge_alpha": _clamp_float(params.get("merge_alpha", 0.010), 0.001, 0.030, 0.010),
            "top_merge_neighbors": _clamp_int(params.get("top_merge_neighbors", 1), 1, 3, 1),
            "temperature": _clamp_float(params.get("temperature", 0.07), 0.04, 0.12, 0.07),
            "spatial_radius": _clamp_float(params.get("spatial_radius", 2.0), 1.0, 3.0, 2.0),
            "norm_preserve": True,
        })

    return {
        "op": "process_tokens",
        "name": raw_name,
        "inputs": copy.deepcopy(PROCESS_INPUTS[raw_name]),
        "params": out_params,
        "output": "processed_features",
    }


def extract_process_node_from_plan(plan: Mapping[str, Any]) -> Dict[str, Any]:
    # Accept either full policy JSON or compact process-token JSON.
    policy = plan.get("policy", plan)
    if isinstance(policy, Mapping):
        pipe = policy.get("pipeline")
        if isinstance(pipe, list):
            for n in reversed(pipe):
                if not isinstance(n, Mapping):
                    continue
                if n.get("op") == "process_tokens" or str(n.get("name", "")) in ALLOWED_PROCESS_NAMES:
                    return sanitize_process_node(n, str(policy.get("name", "v14b_child")))

        # Compact format: {"process_tokens": {"name": ..., "params": ...}}
        pt = policy.get("process_tokens")
        if isinstance(pt, Mapping):
            return sanitize_process_node(pt, str(policy.get("name", "v14b_child")))

        # Compact format: {"processor": "...", "params": {...}}
        if "processor" in policy or "module" in policy:
            return sanitize_process_node(policy, str(policy.get("name", "v14b_child")))

    return seed_process_node()


def canonicalize_plan_to_policy(plan: Mapping[str, Any], name_prefix: str = "v14b_llm_child") -> Dict[str, Any]:
    policy_obj = plan.get("policy", plan)
    candidate_name = "v14b_llm_child"
    if isinstance(policy_obj, Mapping):
        candidate_name = str(policy_obj.get("name") or policy_obj.get("policy_name") or name_prefix)

    process_node = extract_process_node_from_plan(plan)

    policy = load_yaml_policy(BASE_0021_PATH)
    policy["policy_name"] = candidate_name
    policy["name"] = candidate_name
    policy["keep_tokens"] = 32
    policy["pipeline"] = base_selection_pipeline() + [process_node]
    return policy


def policy_to_program(policy: Mapping[str, Any]) -> str:
    yaml_text = yaml.safe_dump(dict(policy), sort_keys=False, allow_unicode=True)
    return f'''"""
Auto-generated v14-B processing-only policy.
Selection nodes are canonical 0021; only process_tokens is evolved.
"""

POLICY_YAML = r"""{yaml_text}"""

def get_policy_yaml():
    return POLICY_YAML
'''


def build_v14b_prompt(iteration: int = 0, mode: str = "exploration") -> str:
    if mode is None or str(mode).strip().lower() in {"", "none", "null"}:
        mode = "exploration"
    seed_yaml = SEED_POLICY_PATH.read_text()
    return f"""
Iteration: {iteration}
Planner mode: {mode}
Objective metric: raw_combined_score

You are in v14-B PROCESSING-ONLY OpenEvolve mode.

Current validated seed:
- policy = 0040_v14a_from_real0021_semmerge_a0p01_t1_g0p65
- full perception = 1404.9354
- full cognition  = 301.4286
- full raw        = 1706.3639
- overlap_with_reference_avg = 0.9375
- changed_tokens_avg = 2.0
- v14_feature_delta_norm_avg = 0.107058

Goal:
- Improve full raw_combined_score beyond 1706.3639.
- Preserve overlap=0.9375 and changed_tokens=2.0.
- Search only the final process_tokens node.

Hard rules:
- Do not change the first 9 selection nodes.
- Do not change keep_tokens.
- Do not change native_teacher_mask_prior.
- Do not change native_reference_residual_exchange_selector.
- Do not change replace_quota=2 or min_reference_keep=30.
- Do not use cdpruner_reference_mask_prior.
- Do not use build_pool, DPP selectors, policy_graph, residual_patch, or trainable modules.

Return JSON only. Preferred compact format:
{{
  "expected_effect": {{"perception": "increase", "cognition": "preserve", "risk": "low"}},
  "policy": {{
    "name": "v14b_semgate_a0p012_t1_g0p65_tau0p07",
    "process_tokens": {{
      "name": "semantic_gated_residual_merge",
      "params": {{
        "merge_alpha": 0.012,
        "top_merge_neighbors": 1,
        "temperature": 0.07,
        "semantic_gate_threshold": 0.65,
        "norm_preserve": true
      }}
    }}
  }},
  "rationale": "one short sentence"
}}

Allowed process_tokens names:
- score_rescale_selected_features
- similarity_weighted_residual_merge
- semantic_gated_residual_merge
- spatial_local_residual_merge

Parameter ranges:
- merge_alpha: 0.001 to 0.030
- top_merge_neighbors: 1, 2, 3
- temperature: 0.04 to 0.12
- semantic_gate_threshold: 0.50 to 0.80
- quality_gate_threshold: 0.00 to 0.70
- spatial_radius: 1.0 to 3.0
- rescale_beta: 0.001 to 0.030
- norm_preserve: true

Validated seed YAML:
```yaml
{seed_yaml}
""".strip()
