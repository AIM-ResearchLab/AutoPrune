#!/usr/bin/env bash
set -u

cd /data/lz/openevolve_pruner/CDPruner || exit 1

export PYTHONPATH="/data/lz/openevolve_pruner/CDPruner:${PYTHONPATH:-}"
export EVO_GPU=7
export CUDA_VISIBLE_DEVICES=7
export EVO_TOKEN=32
export EVO_FORCE_FIXED_TOKENS=32
export EVO_UNIMERGE_DEBUG=0
export EVO_UNIMERGE_OUTPUT_MODE=inplace_full

RUN_ROOT="openevolve/runs/v17_v1_initial_and_search_gpu7_seq"
mkdir -p "$RUN_ROOT"

INITIAL_POLICY="openevolve/policies/v17_formal/v17_cdpruner_anchor_initial.yaml"

SEARCH_POLICIES=(
  "openevolve/policies/v17_formal/candidates_exchange/v17_cdpruner_anchor_exchange_q2_a015.yaml"
  "openevolve/policies/v17_formal/candidates_exchange/v17_cdpruner_anchor_exchange_q4_a015.yaml"
  "openevolve/policies/v17_formal/candidates_exchange/v17_cdpruner_anchor_exchange_q8_a020.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0010.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0030.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0050.yaml"
  "openevolve/policies/v17_formal/candidates_nonanchor/v17_cdpruner_anchor_nonanchor_residual_s0100.yaml"
  "openevolve/policies/v17_formal/candidates/v17_cdpruner_anchor_residual_s001.yaml"
  "openevolve/policies/v17_formal/candidates/v17_cdpruner_anchor_residual_s003.yaml"
  "openevolve/policies/v17_formal/candidates/v17_cdpruner_anchor_residual_s005.yaml"
  "openevolve/policies/v17_formal/candidates/v17_cdpruner_anchor_residual_s010.yaml"
)

run_one() {
  local phase="$1"
  local policy="$2"
  local name
  name="$(basename "$policy" .yaml)"

  local out_dir="$RUN_ROOT/${phase}_${name}"
  mkdir -p "$out_dir"

  local exp="v17_v1_${phase}_${name}_g7_$(date +%Y%m%d_%H%M%S)"

  {
    echo "PHASE=$phase"
    echo "POLICY=$policy"
    echo "EXP=$exp"
    echo "GPU=7"
    echo "ANCHOR=v16_v1_clean_cdpruner_k32_reference_q0"
    echo "EXPECTED_INITIAL_PERCEPTION=1382.8248299319728"
    echo "START_TIME=$(date '+%F %T')"
  } > "$out_dir/status.txt"

  rm -f "playground/data/eval/MME/answers/${exp}.jsonl" 2>/dev/null || true
  rm -f "playground/data/eval/MME/answers/${exp}.txt" 2>/dev/null || true

  echo "===== RUN $phase $name on GPU 7 ====="

  openevolve/run_with_v17_v1_cdpruner_anchor_env.sh \
    "$policy" \
    bash scripts/v1_5/eval/mme.sh 32 "$exp" \
    > "$out_dir/mme_full.log" 2>&1

  local ret=$?

  echo "EXIT_CODE=$ret" >> "$out_dir/status.txt"
  echo "END_TIME=$(date '+%F %T')" >> "$out_dir/status.txt"

  grep -n "CDPRUNER_POLICY\|V16 anchor policy\|UniMergeHybridDelta\|UniMergeHybrid\|vtn=\|Traceback\|JSONDecodeError\|===========\|total score:\|score:" "$out_dir/mme_full.log" \
    | tail -260 \
    > "$out_dir/mme_full_score_summary.txt" || true

  if [ "$ret" -eq 0 ]; then
    echo "===== DONE_OK $phase $name ====="
  else
    echo "===== DONE_FAIL $phase $name, see $out_dir/mme_full.log ====="
  fi

  return 0
}

check_initial() {
  local dir="$RUN_ROOT/initial_$(basename "$INITIAL_POLICY" .yaml)"
  local log="$dir/mme_full.log"

  python - "$log" <<'PY'
import sys, re
from pathlib import Path

log = Path(sys.argv[1])
text = log.read_text(errors="ignore") if log.exists() else ""

totals = [float(x) for x in re.findall(r"total score:\s*([0-9.]+)", text)]
vtns = re.findall(r"vtn=(\d+)", text)

if len(totals) < 2:
    print("INITIAL_CHECK_FAIL no MME score found")
    raise SystemExit(2)

perception, cognition = totals[0], totals[1]
vtn = int(vtns[-1]) if vtns else -1

print(f"INITIAL_CHECK vtn={vtn} perception={perception:.6f} cognition={cognition:.6f}")

if vtn != 32:
    print("INITIAL_CHECK_FAIL vtn is not 32")
    raise SystemExit(3)

if perception < 1370:
    print("INITIAL_CHECK_FAIL perception below expected v16 v1 clean baseline")
    raise SystemExit(4)

print("INITIAL_CHECK_OK")
PY
}

echo "===== Stage 1: v17 initial from v16 v1/1382 baseline ====="
run_one "initial" "$INITIAL_POLICY"

if ! check_initial; then
  echo "Initial check failed. Stop search."
  exit 2
fi

echo "===== Stage 2: v17 search candidates ====="
echo "Number of search policies: ${#SEARCH_POLICIES[@]}"

for policy in "${SEARCH_POLICIES[@]}"; do
  if [ -f "$policy" ]; then
    run_one "search" "$policy"
  else
    echo "SKIP missing policy: $policy"
  fi
done

echo "All sequential GPU7 jobs finished."
