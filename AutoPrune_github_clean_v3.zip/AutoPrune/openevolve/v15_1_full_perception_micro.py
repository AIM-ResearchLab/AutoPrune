from __future__ import annotations

from typing import Any, Dict, Tuple

from openevolve.v15_full_perception_bandit import (
    _load_anchor_policy,
    _strip_program_fields,
    _ensure_process_node,
    _set_selector_safe,
    _set_process_semantic,
    _get_selector,
    _get_process,
    _get_fusion_weights,
    _policy_fingerprint,
    _policy_to_program,
    _feedback_path,
    ANCHOR_FULL_PERCEPTION,
    ANCHOR_FULL_RAW,
)


def build_v15_1_policy_and_program(
    iteration: int,
    parent: Any = None,
    inspirations: Any = None,
    config: Any = None,
) -> Tuple[Dict[str, Any], str, Dict[str, Any]]:
    """
    v15.1: full-MME perception anchor-local micro search.

    Design:
    - Always start from the known full-MME best anchor.
    - Apply exactly one tiny edit per candidate.
    - Avoid no-op, large module replacement, top_k=2/3, and large fusion shifts.
    """
    iteration = max(1, int(iteration))

    policy = _strip_program_fields(_load_anchor_policy())
    _ensure_process_node(policy)

    # Full-MME best anchor:
    # q=2, min_ref=30, div=0.08, ref_w=0.20, power=1.00,
    # semantic_gated_residual_merge, alpha=0.010, top_k=1, gate=0.65.
    _set_selector_safe(policy, q=2, min_ref=30, div=0.08, ref_w=0.20, power=1.00)
    _set_process_semantic(policy, alpha=0.010, top_k=1, gate=0.65, temp=0.07)

    weights = _get_fusion_weights(policy)
    weights.update({
        "semantic": 0.30,
        "attn": 0.10,
        "spatial": 0.10,
        "redundancy": 0.07,
        "contrast": 0.06,
    })

    plans = [
        ("selector_div", {"diversity_lambda": 0.06}),
        ("selector_div", {"diversity_lambda": 0.07}),
        ("selector_div", {"diversity_lambda": 0.09}),
        ("selector_div", {"diversity_lambda": 0.10}),
        ("selector_div", {"diversity_lambda": 0.11}),

        ("selector_refw", {"reference_keep_weight": 0.16}),
        ("selector_refw", {"reference_keep_weight": 0.18}),
        ("selector_refw", {"reference_keep_weight": 0.22}),
        ("selector_refw", {"reference_keep_weight": 0.24}),

        ("selector_power", {"candidate_quality_power": 0.90}),
        ("selector_power", {"candidate_quality_power": 0.95}),
        ("selector_power", {"candidate_quality_power": 1.05}),
        ("selector_power", {"candidate_quality_power": 1.10}),

        ("processing_alpha", {"merge_alpha": 0.008}),
        ("processing_alpha", {"merge_alpha": 0.009}),
        ("processing_alpha", {"merge_alpha": 0.011}),

        ("processing_gate", {"semantic_gate_threshold": 0.60}),
        ("processing_gate", {"semantic_gate_threshold": 0.62}),
        ("processing_gate", {"semantic_gate_threshold": 0.68}),
        ("processing_gate", {"semantic_gate_threshold": 0.70}),

        ("fusion_micro", {"semantic": 0.305, "attn": 0.095}),
        ("fusion_micro", {"semantic": 0.295, "attn": 0.105}),
        ("fusion_micro", {"spatial": 0.105, "redundancy": 0.065}),
        ("fusion_micro", {"spatial": 0.095, "contrast": 0.065}),

        # Limited selection structure exploration.
        ("selector_q", {"replace_quota": 1, "min_reference_keep": 31}),
        ("selector_q", {"replace_quota": 2, "min_reference_keep": 31}),
        ("selector_q", {"replace_quota": 3, "min_reference_keep": 29}),
    ]

    family, edit = plans[(iteration - 1) % len(plans)]

    sel = _get_selector(policy)
    proc = _get_process(policy)
    weights = _get_fusion_weights(policy)

    if family.startswith("selector"):
        if "replace_quota" in edit:
            _set_selector_safe(
                policy,
                q=edit.get("replace_quota", sel.get("replace_quota", 2)),
                min_ref=edit.get("min_reference_keep", sel.get("min_reference_keep", 30)),
                div=sel.get("diversity_lambda", 0.08),
                ref_w=sel.get("reference_keep_weight", 0.20),
                power=sel.get("candidate_quality_power", 1.00),
            )
        else:
            sel.update(edit)

    elif family.startswith("processing"):
        proc.setdefault("params", {}).update(edit)
        p = proc["params"]
        _set_process_semantic(
            policy,
            alpha=p.get("merge_alpha", 0.010),
            top_k=1,
            gate=p.get("semantic_gate_threshold", 0.65),
            temp=p.get("temperature", 0.07),
        )

    elif family == "fusion_micro":
        for k, v in edit.items():
            weights[k] = float(v)

    tag = "_".join(f"{k}{str(v).replace('.', 'p')}" for k, v in edit.items())
    name = f"v15_1_micro_i{iteration:04d}_{family}_{tag}"

    policy["policy_name"] = name
    policy["name"] = name
    policy["keep_tokens"] = 32
    policy.setdefault("meta", {})
    policy["meta"].update({
        "method": "v15_1_full_perception_micro_anchor_search",
        "iteration": iteration,
        "base_source": "anchor",
        "mutation_family": family,
        "mutation_detail": edit,
        "objective": "full_mme_perception",
        "anchor_full_perception": ANCHOR_FULL_PERCEPTION,
        "anchor_full_raw": ANCHOR_FULL_RAW,
    })

    policy["policy_fp"] = _policy_fingerprint(policy)
    program = _policy_to_program(policy)
    policy["__program_code__"] = program

    sel = _get_selector(policy)
    proc = _get_process(policy)
    weights = _get_fusion_weights(policy)

    meta = {
        "name": name,
        "policy_fp": policy["policy_fp"],
        "base_source": "anchor",
        "mutation_family": family,
        "mutation_detail": edit,
        "replace_quota": sel.get("replace_quota"),
        "min_reference_keep": sel.get("min_reference_keep"),
        "process_name": proc.get("name"),
        "process_params": proc.get("params"),
        "weights": dict(weights),
        "feedback_path": str(_feedback_path()),
    }
    return policy, program, meta
