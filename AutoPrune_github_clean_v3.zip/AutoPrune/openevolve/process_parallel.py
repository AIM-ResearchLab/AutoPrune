"""
Process-based parallel controller for Evo-CDPruner YAML policy search-space v3.

Design principle
----------------
This file intentionally does NOT ask the LLM to freely rewrite a YAML/Python file.
The previous route failed because YAML policies form a typed grammar, while the LLM
kept making monotonic no-op edits such as changing `power` under
TopK + rank_norm. In that regime, token order is unchanged, so TopK selects the
same visual tokens and the evaluator score does not move.

This v3 controller implements LLM-guided grammar-constrained evolution:

    parent POLICY_YAML
      -> parse + sanitize typed policy
      -> apply one operator-level structural mutation from a finite policy grammar
      -> canonicalize POLICY_YAML
      -> semantic fingerprint de-duplicates no-op variants
      -> evaluate with the existing task evaluator

The LLM is used as a JSON planner over compact YAML atom cards, slot grammar,
and concise good/bad examples. The compiler then enforces typed executable
policies. If the LLM is unavailable or proposes a duplicate/invalid policy, the
controller falls back to deterministic registry operators from v2.
"""

from __future__ import annotations

import ast
import asyncio
import hashlib
import json
import logging
import multiprocessing as mp
import os
import re
import time
import uuid
from concurrent.futures import Future, ProcessPoolExecutor
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Optional, Tuple

import yaml

try:
    from openevolve.operator_generator import build_operator_candidates
except Exception:
    build_operator_candidates = None

try:
    from openevolve.llm_policy_planner import propose_policy_with_llm
except Exception:
    propose_policy_with_llm = None

from openevolve.config import Config
from openevolve.database import Program, ProgramDatabase

logger = logging.getLogger(__name__)


@dataclass
class SerializableResult:
    child_program_dict: Optional[Dict[str, Any]] = None
    parent_id: Optional[str] = None
    iteration_time: float = 0.0
    prompt: Optional[Dict[str, str]] = None
    llm_response: Optional[str] = None
    artifacts: Optional[Dict[str, Any]] = None
    iteration: int = 0
    error: Optional[str] = None
    debug: Optional[Dict[str, Any]] = None


# ---------------------------------------------------------------------
# Worker initialization
# ---------------------------------------------------------------------


def _worker_init(config_dict: dict, evaluation_file: str) -> None:
    global _worker_config
    global _worker_evaluation_file
    global _worker_evaluator

    from openevolve.config import (
        Config,
        DatabaseConfig,
        EvaluatorConfig,
        LLMConfig,
        LLMModelConfig,
        PromptConfig,
    )

    models = [LLMModelConfig(**m) for m in config_dict["llm"]["models"]]
    evaluator_models = [LLMModelConfig(**m) for m in config_dict["llm"]["evaluator_models"]]

    llm_dict = config_dict["llm"].copy()
    llm_dict["models"] = models
    llm_dict["evaluator_models"] = evaluator_models
    llm_config = LLMConfig(**llm_dict)

    _worker_config = Config(
        llm=llm_config,
        prompt=PromptConfig(**config_dict["prompt"]),
        database=DatabaseConfig(**config_dict["database"]),
        evaluator=EvaluatorConfig(**config_dict["evaluator"]),
        **{
            k: v
            for k, v in config_dict.items()
            if k not in ["llm", "prompt", "database", "evaluator"]
        },
    )
    _worker_evaluation_file = evaluation_file
    _worker_evaluator = None


def _lazy_init_worker_components() -> None:
    global _worker_evaluator
    if _worker_evaluator is None:
        from openevolve.evaluator import Evaluator
        from openevolve.llm.ensemble import LLMEnsemble
        from openevolve.prompt.sampler import PromptSampler

        evaluator_llm = LLMEnsemble(_worker_config.llm.evaluator_models)
        evaluator_prompt = PromptSampler(_worker_config.prompt)
        evaluator_prompt.set_templates("evaluator_system_message")
        _worker_evaluator = Evaluator(
            _worker_config.evaluator,
            _worker_evaluation_file,
            evaluator_llm,
            evaluator_prompt,
            database=None,
        )


# ---------------------------------------------------------------------
# Generic utilities
# ---------------------------------------------------------------------


def _json_safe(obj: Any, max_str: int = 4000) -> Any:
    if obj is None or isinstance(obj, (bool, int, float, str)):
        if isinstance(obj, str) and len(obj) > max_str:
            return obj[:max_str] + f"...<truncated {len(obj) - max_str} chars>"
        return obj
    if isinstance(obj, dict):
        return {str(k): _json_safe(v, max_str=max_str) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [_json_safe(v, max_str=max_str) for v in list(obj)]
    try:
        return str(obj)
    except Exception:
        return f"<unserializable:{type(obj).__name__}>"


def _compact_json(obj: Any, max_len: int = 12000) -> str:
    try:
        s = json.dumps(_json_safe(obj), ensure_ascii=False, sort_keys=True)
    except Exception as e:
        s = json.dumps({"json_error": str(e), "repr": repr(obj)[:max_len]}, ensure_ascii=False)
    if len(s) > max_len:
        return s[:max_len] + f"...<truncated {len(s) - max_len} chars>"
    return s


def _code_hash(code: str) -> str:
    return hashlib.sha256((code or "").encode("utf-8", errors="ignore")).hexdigest()[:16]


def _safe_numeric(value: Any, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return float(default)


def _safe_program_metric(program: Program, name: str = "combined_score") -> float:
    try:
        metrics = program.metrics or {}
        if name in metrics:
            return float(metrics[name])
        from openevolve.utils.metrics_utils import safe_numeric_average
        return float(safe_numeric_average(metrics))
    except Exception:
        return 0.0


def _safe_metric_dict(metrics: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(metrics, dict):
        return {}
    out = {}
    for k, v in metrics.items():
        if isinstance(v, (int, float, bool, str)) or v is None:
            out[k] = v
        else:
            out[k] = str(v)
    return out


def _program_metrics_invalid(metrics: Optional[Dict[str, Any]]) -> bool:
    if not isinstance(metrics, dict):
        return True
    if metrics.get("valid") == 0 or metrics.get("valid") == 0.0:
        return True
    score = metrics.get("combined_score", metrics.get("score"))
    try:
        if score is None:
            return True
        if float(score) <= -1e17:
            return True
    except Exception:
        return True
    if "error" in metrics and metrics.get("error"):
        try:
            return float(score) <= 0.0
        except Exception:
            return True
    return False


def _program_brief(program: Program) -> Dict[str, Any]:
    return {
        "id": program.id,
        "parent_id": program.parent_id,
        "generation": program.generation,
        "iteration_found": program.iteration_found,
        "code_hash": _code_hash(program.code),
        "policy_fp": _policy_fingerprint_from_code(program.code),
        "metrics": _safe_metric_dict(program.metrics),
        "island": (program.metadata or {}).get("island"),
    }


def _artifact_summary(artifacts: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    if not isinstance(artifacts, dict):
        return {}
    summary = {"keys": sorted(list(artifacts.keys()))}
    for k in ["candidate_policy_path", "candidate_program_path", "stage", "reason", "error"]:
        if k in artifacts:
            summary[k] = artifacts[k]
    return summary


def _append_jsonl(path: str, record: Dict[str, Any]) -> None:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(_json_safe(record), ensure_ascii=False, sort_keys=True) + "\n")
    except Exception as e:
        logger.warning("Failed to append JSONL %s: %s", path, e)


# ---------------------------------------------------------------------
# Typed YAML policy grammar
# ---------------------------------------------------------------------


_ALLOWED_SCORERS = {
    "instruction_guided_visual_relevance",
    "visual_token_norm_saliency",
    "spatial_centrality_prior",
    "redundancy_density_penalty",
    "attention_proxy_saliency",
    "pairwise_token_similarity",
    "conditional_similarity_score",
}
_ALLOWED_FUSIONS = {"quality_diversity_kernel", "weighted_sum_score_fusion", "mmr_relevance_diversity_fusion", "baseline_residual_score_fusion"}
_ALLOWED_SELECTORS = {"dpp_selector", "topk_selector", "mmr_selector", "topk_pool_mmr_selector", "topk_pool_dpp_selector", "baseline_anchored_residual_selector", "cdpruner_mask_anchored_residual_selector"}
_ALLOWED_BUDGETS = {"fixed_keep_tokens", "fixed_keep_ratio"}
_ALLOWED_ACTIONS = {"dpp_subset_prune", "hard_prune"}
_ALLOWED_PROTECTIONS = {"spatial_coverage_preservation", "top_relevance_anchor_preservation", "special_token_preservation"}
_FORBIDDEN_POLICY_TEXT = {"kv_cache", "gradients", "llm_attention", "trainable", "model_path", "nn.Module", "Gumbel", "gumbel", "nn.Linear", "requires_grad"}


def _extract_policy_yaml_literal(code_or_yaml: str) -> Optional[str]:
    """Extract POLICY_YAML from Python candidate or accept raw YAML.

    Important: Python candidate contains target_host/pipeline inside the string,
    so we must try POLICY_YAML extraction first whenever the text looks like a
    Python wrapper.
    """
    text = (code_or_yaml or "").strip()
    if not text:
        return None
    fence = re.search(r"```(?:python|py|yaml|yml)?\s*(.*?)```", text, flags=re.S | re.I)
    if fence:
        text = fence.group(1).strip()

    looks_python = "POLICY_YAML" in text or "def get_policy_yaml" in text
    if looks_python:
        try:
            tree = ast.parse(text)
        except Exception:
            tree = None
        if tree is not None:
            for node in ast.walk(tree):
                if isinstance(node, ast.Assign):
                    for target in node.targets:
                        if isinstance(target, ast.Name) and target.id == "POLICY_YAML":
                            try:
                                value = ast.literal_eval(node.value)
                            except Exception:
                                value = None
                            if isinstance(value, str):
                                return value
                if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == "POLICY_YAML":
                    try:
                        value = ast.literal_eval(node.value)
                    except Exception:
                        value = None
                    if isinstance(value, str):
                        return value
        m = re.search(r"POLICY_YAML\s*=\s*r?([\"']{3})(.*?)\1", text, flags=re.S)
        if m:
            return m.group(2)
        return None

    if text.startswith("version:") or ("target_host:" in text and "pipeline:" in text):
        return text
    return None


def _as_float(x: Any, default: float) -> float:
    try:
        return float(x)
    except Exception:
        return float(default)


def _clamp_float(x: Any, lo: float, hi: float, default: float) -> float:
    return max(lo, min(hi, _as_float(x, default)))


def _clamp_int(x: Any, lo: int, hi: int, default: int) -> int:
    try:
        v = int(round(float(x)))
    except Exception:
        v = int(default)
    return max(lo, min(hi, v))


def _sanitize_relevance_params(params: Any) -> Dict[str, Any]:
    params = params if isinstance(params, dict) else {}
    sign = str(params.get("sign", "negative_mean"))
    if sign not in {"negative_mean", "positive_mean", "max"}:
        sign = "negative_mean"
    transform = str(params.get("transform", params.get("score_normalization", "rank_norm")))
    if transform not in {"minmax", "rank_norm", "softmax", "sigmoid", "none"}:
        transform = "rank_norm"
    return {"sign": sign, "transform": transform, "power": _clamp_float(params.get("power", 1.0), 0.25, 4.0, 1.0)}


def _sanitize_similarity_params(params: Any) -> Dict[str, Any]:
    params = params if isinstance(params, dict) else {}
    metric = str(params.get("similarity_metric", "cosine"))
    if metric not in {"cosine", "centered_cosine", "dot", "rbf", "l2_rbf"}:
        metric = "cosine"
    transform = str(params.get("similarity_transform", "identity"))
    if transform not in {"identity", "clamp_positive"}:
        transform = "identity"
    out = {"similarity_metric": metric, "similarity_transform": transform}
    if "conditioning_mode" in params:
        mode = str(params.get("conditioning_mode", "none"))
        if mode not in {"none", "multiplicative", "gated"}:
            mode = "none"
        out["conditioning_mode"] = mode
    if metric in {"rbf", "l2_rbf"}:
        out["tau"] = _clamp_float(params.get("tau", 1.0), 1e-4, 100.0, 1.0)
    return out


def _sanitize_fusion_params(atom: str, params: Any) -> Dict[str, Any]:
    params = params if isinstance(params, dict) else {}
    if atom == "quality_diversity_kernel":
        return {
            "quality_power": _clamp_float(params.get("quality_power", 1.0), 0.25, 4.0, 1.0),
            "similarity_power": _clamp_float(params.get("similarity_power", 1.0), 0.25, 4.0, 1.0),
            "eps": _clamp_float(params.get("eps", 1e-6), 1e-8, 1e-2, 1e-6),
            "symmetrize": bool(params.get("symmetrize", True)),
        }
    if atom == "weighted_sum_score_fusion":
        norm = str(params.get("score_normalization", "rank_norm"))
        if norm not in {"minmax", "rank_norm", "softmax", "sigmoid", "none"}:
            norm = "rank_norm"
        weights = params.get("weights", [1.0])
        if not isinstance(weights, list) or not weights:
            weights = [1.0]
        return {"score_normalization": norm, "weights": [_clamp_float(w, -5.0, 5.0, 1.0) for w in weights[:4]]}
    if atom == "mmr_relevance_diversity_fusion":
        return {"lambda_relevance": _clamp_float(params.get("lambda_relevance", 0.5), 0.0, 1.0, 0.5)}
    if atom == "baseline_residual_score_fusion":
        norm = str(params.get("score_normalization", "minmax"))
        if norm not in {"minmax", "rank_norm", "sigmoid", "none"}:
            norm = "minmax"
        return {
            "baseline_weight": _clamp_float(params.get("baseline_weight", 1.0), 0.0, 2.0, 1.0),
            "aux_total_weight": _clamp_float(params.get("aux_total_weight", 0.1), 0.0, 0.5, 0.1),
            "score_normalization": norm,
        }
    return {}


def _sanitize_budget(atom: str, params: Any) -> Dict[str, Any]:
    params = params if isinstance(params, dict) else {}
    if atom == "fixed_keep_tokens":
        keep = params.get("keep_tokens", "host_argument")
        if keep != "host_argument":
            keep = _clamp_int(keep, 1, 576, 64)
        return {"keep_tokens": keep}
    if atom == "fixed_keep_ratio":
        return {"keep_ratio": _clamp_float(params.get("keep_ratio", 0.5), 0.02, 1.0, 0.5), "min_keep_tokens": _clamp_int(params.get("min_keep_tokens", 8), 1, 128, 8)}
    return {"keep_tokens": "host_argument"}


def _sanitize_selector(atom: str, params: Any) -> Dict[str, Any]:
    params = params if isinstance(params, dict) else {}
    if atom == "topk_selector":
        return {"largest": bool(params.get("largest", True))}
    if atom == "dpp_selector":
        algorithm = str(params.get("algorithm", "fast_map"))
        if algorithm not in {"fast_map", "greedy_map", "exact_small_n"}:
            algorithm = "fast_map"
        post = str(params.get("postprocess", "sort_by_position"))
        if post not in {"sort_by_position", "sort_by_score", "none"}:
            post = "sort_by_position"
        return {"algorithm": algorithm, "postprocess": post}
    if atom == "mmr_selector":
        init_by = str(params.get("init_by", "top_relevance"))
        if init_by not in {"top_relevance", "center_token", "max_norm"}:
            init_by = "top_relevance"
        return {"init_by": init_by}
    if atom in {"baseline_anchored_residual_selector", "cdpruner_mask_anchored_residual_selector"}:
        scheduler = str(params.get("scheduler", "sqrt"))
        if scheduler not in {"sqrt", "ratio", "fixed"}:
            scheduler = "sqrt"
        true_anchor = atom == "cdpruner_mask_anchored_residual_selector" or bool(params.get("true_cdpruner_anchor", False))
        return {
            "true_cdpruner_anchor": bool(true_anchor),
            "scheduler": scheduler,
            "alpha": _clamp_float(params.get("alpha", 0.8 if true_anchor else 1.2), 0.1, 4.0, 0.8 if true_anchor else 1.2),
            "min_residual": _clamp_int(params.get("min_residual", 0 if true_anchor else 2), 0, 64, 0 if true_anchor else 2),
            "max_residual_ratio": _clamp_float(params.get("max_residual_ratio", 0.125 if true_anchor else 0.375), 0.0, 0.75, 0.125 if true_anchor else 0.375),
            "candidate_pool_multiplier": _clamp_float(params.get("candidate_pool_multiplier", 4.0), 1.0, 12.0, 4.0),
            "gate_baseline_weight": _clamp_float(params.get("gate_baseline_weight", 0.85 if true_anchor else 0.65), 0.0, 1.0, 0.85 if true_anchor else 0.65),
            "gate_residual_weight": _clamp_float(params.get("gate_residual_weight", 0.15 if true_anchor else 0.35), 0.0, 1.0, 0.15 if true_anchor else 0.35),
            "min_gain": _clamp_float(params.get("min_gain", 0.01 if true_anchor else 0.0), -0.5, 0.5, 0.01 if true_anchor else 0.0),
            "no_op_if_no_positive_gain": bool(params.get("no_op_if_no_positive_gain", True)),
        }
    return {}


def _sanitize_protection(item: Any) -> Optional[Dict[str, Any]]:
    if not isinstance(item, dict):
        return None
    atom = item.get("atom")
    if atom not in _ALLOWED_PROTECTIONS:
        return None
    params = item.get("params", {}) if isinstance(item.get("params", {}), dict) else {}
    if atom == "spatial_coverage_preservation":
        return {"atom": atom, "params": {"grid_size": _clamp_int(params.get("grid_size", 4), 1, 16, 4), "min_keep_per_cell": _clamp_int(params.get("min_keep_per_cell", 1), 0, 8, 1)}}
    if atom == "top_relevance_anchor_preservation":
        k = params.get("topk", params.get("anchor_count", 8))
        return {"atom": atom, "params": {"topk": _clamp_int(k, 1, 64, 8)}}
    return {"atom": atom, "params": {}}




# ---------------------------------------------------------------------
# v10 executable multi-step YAML pipeline support
# ---------------------------------------------------------------------

def _v10_env_flag(name: str, default: str = "0") -> bool:
    return str(os.environ.get(name, default)).strip().lower() in {"1", "true", "yes", "y", "on"}


_V10_SCORE_NAMES = {
    "cdpruner_reference_mask_prior",
    "native_teacher_mask_prior",
    "instruction_guided_visual_relevance",
    "attention_proxy_saliency",
    "spatial_centrality_prior",
    "redundancy_density_penalty",
    "local_contrast_saliency",
    "visual_token_norm_saliency",
}

_V10_FUSION_NAMES = {
    "weighted_product_fusion",
    "reference_confidence_weighted_product_fusion",
    "question_aware_weighted_product_fusion",
}

_V10_KERNEL_NAMES = {
    "pairwise_cosine_kernel",
    "runtime_conditional_similarity_kernel",
    "cdpruner_conditional_similarity_kernel",
}

_V10_POOL_NAMES = {
    "quality_pool_builder",
    "spatial_coverage_pool_builder",
    "top_quality_pool_builder",
}

_V10_SELECTOR_NAMES = {
    "runtime_reference_anchor_pool_dpp_selector",
    "adaptive_reference_anchor_pool_dpp_selector",
    "native_reference_residual_exchange_selector",
    "native_reference_margin_gated_exchange_selector",
    "native_reference_strict_margin_exchange_selector",
}


def _is_v10_pipeline_policy(policy: Any) -> bool:
    if not isinstance(policy, dict):
        return False
    pipe = policy.get("pipeline")
    if not isinstance(pipe, list) or not pipe:
        return False

    # v10 pipeline is a list of executable op nodes:
    # compute_score/product_fuse_score/compute_kernel/build_pool/select.
    if not all(isinstance(n, dict) and "op" in n and "name" in n for n in pipe):
        return False

    names = {str(n.get("name", "")) for n in pipe if isinstance(n, dict)}
    ops = {str(n.get("op", "")) for n in pipe if isinstance(n, dict)}

    return (
        "product_fuse_score" in ops
        or "build_pool" in ops
        or "select" in ops
        or "weighted_product_fusion" in names
        or "runtime_reference_anchor_pool_dpp_selector" in names
    )


def _v10_num(x: Any, default: float, lo: float, hi: float) -> float:
    try:
        v = float(x)
    except Exception:
        v = float(default)
    return max(lo, min(hi, v))


def _v10_int(x: Any, default: int, lo: int, hi: int) -> int:
    try:
        v = int(round(float(x)))
    except Exception:
        v = int(default)
    return max(lo, min(hi, v))


def _sanitize_v10_pipeline_policy(policy: Dict[str, Any]) -> Dict[str, Any]:
    pipe = policy.get("pipeline")
    if not isinstance(pipe, list) or not pipe:
        raise ValueError("v10 pipeline must be a non-empty list")

    out: Dict[str, Any] = {
        "policy_name": str(policy.get("policy_name") or policy.get("name") or "v10_llm_pipeline_policy"),
        "name": str(policy.get("name") or policy.get("policy_name") or "v10_llm_pipeline_policy"),
        "keep_tokens": 32,
        "pipeline": [],
    }

    has_reference = False
    has_quality = False
    has_kernel = False
    has_pool = False
    has_selector = False

    for idx, node in enumerate(pipe):
        if not isinstance(node, dict):
            raise ValueError(f"v10 node {idx} must be dict")

        op = str(node.get("op", ""))
        name = str(node.get("name", ""))

        new_node: Dict[str, Any] = {"op": op, "name": name}

        if isinstance(node.get("inputs"), dict):
            new_node["inputs"] = json.loads(json.dumps(node["inputs"], ensure_ascii=False))
        if isinstance(node.get("params"), dict):
            new_node["params"] = json.loads(json.dumps(node["params"], ensure_ascii=False))
        if "output" in node:
            new_node["output"] = str(node["output"])

        if op == "compute_score":
            if name not in _V10_SCORE_NAMES:
                raise ValueError(f"bad v10 compute_score: {name}")
            if name in {"cdpruner_reference_mask_prior", "native_teacher_mask_prior"}:
                has_reference = True
            new_node.setdefault("output", f"score_{idx}")

        elif op == "product_fuse_score":
            if name not in _V10_FUSION_NAMES:
                raise ValueError(f"bad v10 product_fuse_score: {name}")
            params = new_node.setdefault("params", {})
            weights = params.get("weights", {})
            if not isinstance(weights, dict) or not weights:
                weights = {
                    "semantic": 0.35,
                    "attn": 0.10,
                    "spatial": 0.15,
                    "redundancy": 0.30,
                    "contrast": 0.10,
                }
            fixed_weights = {}
            for k, v in weights.items():
                fixed_weights[str(k)] = _v10_num(v, 0.1, 0.0, 1.0)
            params["weights"] = fixed_weights
            new_node.setdefault("output", "quality_score")
            has_quality = True

        elif op == "compute_kernel":
            if name not in _V10_KERNEL_NAMES:
                raise ValueError(f"bad v10 compute_kernel: {name}")
            if name in {"runtime_conditional_similarity_kernel", "cdpruner_conditional_similarity_kernel"}:
                inputs = new_node.setdefault("inputs", {})
                inputs.setdefault("quality", "quality_score")
                params = new_node.setdefault("params", {})
                params["quality_power"] = _v10_num(params.get("quality_power", 1.0), 1.0, 0.5, 2.0)
                params["shift_similarity"] = bool(params.get("shift_similarity", True))
            new_node.setdefault("output", "sim_kernel")
            has_kernel = True

        elif op == "build_pool":
            if name not in _V10_POOL_NAMES:
                raise ValueError(f"bad v10 build_pool: {name}")
            inputs = new_node.setdefault("inputs", {})
            inputs.setdefault("quality", "quality_score")
            params = new_node.setdefault("params", {})
            params["pool_factor"] = _v10_num(params.get("pool_factor", 3.0), 3.0, 1.0, 6.0)
            new_node.setdefault("output", "pool")
            has_pool = True

        elif op == "select":
            if name not in _V10_SELECTOR_NAMES:
                raise ValueError(f"bad v10 select: {name}")
            inputs = new_node.setdefault("inputs", {})
            inputs.setdefault("pool", "pool")
            inputs.setdefault("quality", "quality_score")
            inputs.setdefault("kernel", "sim_kernel")
            inputs.setdefault("reference", "reference_score")
            params = new_node.setdefault("params", {})
            params["anchor_quota"] = _v10_int(params.get("anchor_quota", 8), 8, 6, 10)
            params["diversity_lambda"] = _v10_num(params.get("diversity_lambda", 0.18), 0.18, 0.08, 0.30)
            params["exclude_unanchored_reference"] = bool(params.get("exclude_unanchored_reference", True))
            params["sort_selected"] = bool(params.get("sort_selected", True))
            new_node.setdefault("output", "selected")
            has_selector = True

        else:
            raise ValueError(f"bad v10 op: {op}")

        out["pipeline"].append(new_node)

    if not has_reference:
        raise ValueError("v10 policy missing reference score")
    if not has_quality:
        raise ValueError("v10 policy missing product quality fusion")
    if not has_kernel:
        raise ValueError("v10 policy missing kernel")
    if not has_pool:
        raise ValueError("v10 policy missing pool builder")
    if not has_selector:
        raise ValueError("v10 policy missing runtime anchor selector")

    return out


def _sanitize_policy(policy: Any) -> Dict[str, Any]:
    if not isinstance(policy, dict):
        raise ValueError("policy must be a YAML mapping")

    # v10 mode: accept executable multi-step pipeline YAML directly.
    # Do not force it into the old single-step grammar.
    if _v10_env_flag("EVO_V10_PIPELINE_PLANNER", "0") and _is_v10_pipeline_policy(policy):
        return _sanitize_v10_pipeline_policy(policy)

    raw = json.dumps(policy, ensure_ascii=False)
    for forbidden in _FORBIDDEN_POLICY_TEXT:
        if forbidden in raw:
            raise ValueError(f"forbidden policy content: {forbidden}")

    if policy.get("target_host", "cdpruner_encode_images") != "cdpruner_encode_images":
        raise ValueError("target_host must be cdpruner_encode_images")
    if policy.get("target_domain", "mllm_visual_token_pruning") != "mllm_visual_token_pruning":
        raise ValueError("target_domain must be mllm_visual_token_pruning")

    pipeline = policy.get("pipeline")
    if not isinstance(pipeline, list) or len(pipeline) != 1:
        raise ValueError("pipeline must contain exactly one step")
    step = pipeline[0] if isinstance(pipeline[0], dict) else {}

    fusion_atom = step.get("fusion", {}).get("atom", "weighted_sum_score_fusion")
    selector_atom = step.get("selector", {}).get("atom", "topk_selector")
    budget_atom = step.get("budget", {}).get("atom", "fixed_keep_tokens")
    action_atom = step.get("action", {}).get("atom", "hard_prune")
    if fusion_atom not in _ALLOWED_FUSIONS:
        fusion_atom = "weighted_sum_score_fusion"
    if selector_atom not in _ALLOWED_SELECTORS:
        selector_atom = "topk_selector"
    if budget_atom not in _ALLOWED_BUDGETS:
        budget_atom = "fixed_keep_tokens"
    if action_atom not in _ALLOWED_ACTIONS:
        action_atom = "hard_prune"

    # Enforce executable template compatibility.
    if selector_atom in {"dpp_selector", "topk_pool_dpp_selector"}:
        fusion_atom = "quality_diversity_kernel"
        action_atom = "dpp_subset_prune"
    elif selector_atom in {"mmr_selector", "topk_pool_mmr_selector"}:
        fusion_atom = "mmr_relevance_diversity_fusion"
        action_atom = "hard_prune"
    elif selector_atom in {"baseline_anchored_residual_selector", "cdpruner_mask_anchored_residual_selector"}:
        fusion_atom = "baseline_residual_score_fusion"
        action_atom = "hard_prune"
        budget_atom = "fixed_keep_tokens"
    elif selector_atom == "topk_selector":
        action_atom = "hard_prune"
        if fusion_atom not in {"weighted_sum_score_fusion", "quality_diversity_kernel"}:
            fusion_atom = "weighted_sum_score_fusion"

    scorer = step.get("scorer", {})
    sanitized_scorer: Dict[str, Any] = {}
    if isinstance(scorer, dict) and "atom" in scorer:
        atom = scorer.get("atom")
        if atom == "instruction_guided_visual_relevance":
            sanitized_scorer["main"] = {"atom": atom, "params": _sanitize_relevance_params(scorer.get("params", {}))}
    elif isinstance(scorer, dict):
        for name, spec in scorer.items():
            if not isinstance(spec, dict):
                continue
            atom = spec.get("atom")
            if atom not in _ALLOWED_SCORERS:
                continue
            params = spec.get("params", {})
            if atom == "instruction_guided_visual_relevance":
                params = _sanitize_relevance_params(params)
            elif atom in {"pairwise_token_similarity", "conditional_similarity_score"}:
                params = _sanitize_similarity_params(params)
            else:
                params = params if isinstance(params, dict) else {}
            sanitized_scorer[str(name)] = {"atom": atom, "params": params}

    if selector_atom in {"baseline_anchored_residual_selector", "cdpruner_mask_anchored_residual_selector"}:
        baseline = sanitized_scorer.get("baseline") or sanitized_scorer.get("quality") or sanitized_scorer.get("main")
        if not baseline or baseline.get("atom") != "instruction_guided_visual_relevance":
            baseline = {"atom": "instruction_guided_visual_relevance", "params": _sanitize_relevance_params({"sign": "negative_mean", "transform": "minmax", "power": 1.0})}
        score_atoms = {"visual_token_norm_saliency", "spatial_centrality_prior", "redundancy_density_penalty", "attention_proxy_saliency", "instruction_guided_visual_relevance"}
        aux_items = []
        for k, v in sanitized_scorer.items():
            if k == "baseline":
                continue
            if v.get("atom") in score_atoms and not (v.get("atom") == "instruction_guided_visual_relevance" and k in {"quality", "main"}):
                aux_items.append((k, v))
        if not aux_items:
            aux_items = [("aux_spatial", {"atom": "spatial_centrality_prior", "params": {"center_bias": 1.0, "transform": "minmax"}})]
        sanitized_scorer = {"baseline": baseline}
        for i, (k, v) in enumerate(aux_items[:4]):
            kk = str(k) if str(k) != "baseline" else f"aux{i+1}"
            sanitized_scorer[kk] = v
    elif selector_atom == "topk_selector":
        # v3.2 allows one or more executable ScoreBN scorer atoms for TopK.
        score_items = {k: v for k, v in sanitized_scorer.items() if v.get("atom") in {
            "instruction_guided_visual_relevance", "visual_token_norm_saliency",
            "spatial_centrality_prior", "redundancy_density_penalty", "attention_proxy_saliency"
        }}
        if not score_items:
            score_items = {"main": {"atom": "instruction_guided_visual_relevance", "params": _sanitize_relevance_params({})}}
        sanitized_scorer = score_items
    elif selector_atom in {"dpp_selector", "topk_pool_dpp_selector"}:
        quality = sanitized_scorer.get("quality") or sanitized_scorer.get("main") or next((v for v in sanitized_scorer.values() if v.get("atom") not in {"pairwise_token_similarity", "conditional_similarity_score"}), None)
        if not quality or quality.get("atom") in {"pairwise_token_similarity", "conditional_similarity_score"}:
            quality = {"atom": "instruction_guided_visual_relevance", "params": _sanitize_relevance_params({"transform": "minmax"})}
        similarity = sanitized_scorer.get("similarity")
        if not similarity or similarity.get("atom") not in {"pairwise_token_similarity", "conditional_similarity_score"}:
            similarity = {"atom": "conditional_similarity_score", "params": _sanitize_similarity_params({"similarity_metric": "cosine", "conditioning_mode": "none"})}
        sanitized_scorer = {"quality": quality, "similarity": similarity}
    elif selector_atom in {"mmr_selector", "topk_pool_mmr_selector"}:
        quality = sanitized_scorer.get("quality") or sanitized_scorer.get("main") or next((v for v in sanitized_scorer.values() if v.get("atom") not in {"pairwise_token_similarity", "conditional_similarity_score"}), None)
        if not quality or quality.get("atom") in {"pairwise_token_similarity", "conditional_similarity_score"}:
            quality = {"atom": "instruction_guided_visual_relevance", "params": _sanitize_relevance_params({})}
        similarity = sanitized_scorer.get("similarity")
        if not similarity or similarity.get("atom") not in {"pairwise_token_similarity", "conditional_similarity_score"}:
            similarity = {"atom": "pairwise_token_similarity", "params": _sanitize_similarity_params({"similarity_metric": "cosine"})}
        sanitized_scorer = {"quality": quality, "similarity": similarity}

    protections = []
    for p in (step.get("protection", []) or []):
        pp = _sanitize_protection(p)
        if pp is not None:
            protections.append(pp)
        if len(protections) >= 2:
            break

    return {
        "version": str(policy.get("version", "0.5-light")),
        "policy_name": str(policy.get("policy_name", "evolved_cdpruner_policy")),
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "stage1_functional_search",
        "pipeline": [{
            "id": str(step.get("id", "visual_token_selection")),
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": sanitized_scorer,
            "fusion": {"atom": fusion_atom, "params": _sanitize_fusion_params(fusion_atom, step.get("fusion", {}).get("params", {}))},
            "budget": {"atom": budget_atom, "params": _sanitize_budget(budget_atom, step.get("budget", {}).get("params", {}))},
            "selector": {"atom": selector_atom, "params": _sanitize_selector(selector_atom, step.get("selector", {}).get("params", {}))},
            "action": {"atom": action_atom},
            "protection": protections,
        }],
    }


def _format_policy_program(policy: Dict[str, Any]) -> str:
    policy_yaml = yaml.safe_dump(policy, sort_keys=False, allow_unicode=True, width=120)
    return (
        '"""OpenEvolve candidate program for Evo-CDPruner YAML policy search.\n'
        'This file is generated by grammar-constrained policy evolution.\n'
        '"""\n\n'
        'POLICY_YAML = r"""\n'
        f"{policy_yaml}"
        '"""\n\n\n'
        'def get_policy_yaml() -> str:\n'
        '    return POLICY_YAML\n'
    )


def _parse_policy_from_code(code: str) -> Optional[Dict[str, Any]]:
    yml = _extract_policy_yaml_literal(code)
    if yml is None:
        return None
    try:
        return _sanitize_policy(yaml.safe_load(yml))
    except Exception:
        return None


def _canonicalize_policy_candidate(candidate_code: str) -> Tuple[Optional[str], Optional[Dict[str, Any]], str]:
    policy = _parse_policy_from_code(candidate_code)
    if policy is None:
        return None, None, "missing_or_invalid_POLICY_YAML"
    return _format_policy_program(policy), policy, "ok"


def _policy_semantic_fingerprint(policy: Optional[Dict[str, Any]]) -> str:
    """Fingerprint behavior, not formatting.

    In TopK + rank_norm, changing positive power is monotonic and does not change
    token ranking. We intentionally normalize that away so power-only mutations
    are treated as duplicates.
    """
    if not isinstance(policy, dict):
        return "invalid"
    p = json.loads(json.dumps(policy, sort_keys=True))
    try:
        step = p["pipeline"][0]
        selector = step.get("selector", {}).get("atom")
        fusion = step.get("fusion", {})
        scorer = step.get("scorer", {})
        if selector == "topk_selector":
            main = scorer.get("main", {})
            main_params = main.get("params", {})
            fusion_norm = fusion.get("params", {}).get("score_normalization")
            if main.get("atom") == "instruction_guided_visual_relevance" and main_params.get("transform") == "rank_norm" and fusion_norm == "rank_norm":
                main_params["power"] = "MONOTONIC_NOOP_UNDER_TOPK_RANKNORM"
    except Exception:
        pass
    return hashlib.sha256(json.dumps(p, sort_keys=True).encode("utf-8")).hexdigest()[:16]


def _policy_fingerprint_from_code(code: str) -> str:
    return _policy_semantic_fingerprint(_parse_policy_from_code(code))


# ---------------------------------------------------------------------
# Grammar mutation operators
# ---------------------------------------------------------------------


def _base_topk(transform: str = "rank_norm", sign: str = "negative_mean", power: float = 1.0, fusion_norm: Optional[str] = None) -> Dict[str, Any]:
    fusion_norm = fusion_norm or transform
    return _sanitize_policy({
        "version": "0.5-light",
        "policy_name": "evolved_cdpruner_policy",
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "stage1_functional_search",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": {"main": {"atom": "instruction_guided_visual_relevance", "params": {"sign": sign, "transform": transform, "power": power}}},
            "fusion": {"atom": "weighted_sum_score_fusion", "params": {"score_normalization": fusion_norm, "weights": [1.0]}},
            "budget": {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}},
            "selector": {"atom": "topk_selector", "params": {"largest": True}},
            "action": {"atom": "hard_prune"},
            "protection": [],
        }],
    })


def _base_mmr(lambda_relevance: float = 0.6, sim_atom: str = "pairwise_token_similarity", metric: str = "cosine", conditioning: str = "none") -> Dict[str, Any]:
    sim_params = {"similarity_metric": metric, "similarity_transform": "identity"}
    if sim_atom == "conditional_similarity_score":
        sim_params["conditioning_mode"] = conditioning
    return _sanitize_policy({
        "version": "0.5-light",
        "policy_name": "evolved_cdpruner_policy",
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "stage1_functional_search",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": {
                "quality": {"atom": "instruction_guided_visual_relevance", "params": {"sign": "negative_mean", "transform": "rank_norm", "power": 1.0}},
                "similarity": {"atom": sim_atom, "params": sim_params},
            },
            "fusion": {"atom": "mmr_relevance_diversity_fusion", "params": {"lambda_relevance": lambda_relevance}},
            "budget": {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}},
            "selector": {"atom": "mmr_selector", "params": {"init_by": "top_relevance"}},
            "action": {"atom": "hard_prune"},
            "protection": [],
        }],
    })


def _base_dpp(q_transform: str = "minmax", sim_atom: str = "conditional_similarity_score", metric: str = "cosine", conditioning: str = "none", q_power: float = 1.0, s_power: float = 1.0) -> Dict[str, Any]:
    sim_params = {"similarity_metric": metric, "similarity_transform": "identity"}
    if sim_atom == "conditional_similarity_score":
        sim_params["conditioning_mode"] = conditioning
    return _sanitize_policy({
        "version": "0.5-light",
        "policy_name": "evolved_cdpruner_policy",
        "target_host": "cdpruner_encode_images",
        "target_domain": "mllm_visual_token_pruning",
        "search_stage": "stage1_functional_search",
        "pipeline": [{
            "id": "visual_token_selection",
            "trigger": {"atom": "pre_llm_visual_reduction_trigger"},
            "target": {"atom": "image_patch_tokens"},
            "scorer": {
                "quality": {"atom": "instruction_guided_visual_relevance", "params": {"sign": "negative_mean", "transform": q_transform, "power": 1.0}},
                "similarity": {"atom": sim_atom, "params": sim_params},
            },
            "fusion": {"atom": "quality_diversity_kernel", "params": {"quality_power": q_power, "similarity_power": s_power, "eps": 1.0e-6, "symmetrize": True}},
            "budget": {"atom": "fixed_keep_tokens", "params": {"keep_tokens": "host_argument"}},
            "selector": {"atom": "dpp_selector", "params": {"algorithm": "fast_map", "postprocess": "sort_by_position"}},
            "action": {"atom": "dpp_subset_prune"},
            "protection": [],
        }],
    })


def _with_protection(policy: Dict[str, Any], protection: Dict[str, Any]) -> Dict[str, Any]:
    p = json.loads(json.dumps(policy))
    cur = p["pipeline"][0].get("protection", []) or []
    atoms = {x.get("atom") for x in cur if isinstance(x, dict)}
    if protection.get("atom") not in atoms:
        cur.append(protection)
    p["pipeline"][0]["protection"] = cur[:2]
    return _sanitize_policy(p)


def _with_budget_ratio(policy: Dict[str, Any], ratio: float, min_keep: int = 16) -> Dict[str, Any]:
    p = json.loads(json.dumps(policy))
    p["pipeline"][0]["budget"] = {"atom": "fixed_keep_ratio", "params": {"keep_ratio": ratio, "min_keep_tokens": min_keep}}
    return _sanitize_policy(p)


def _operator_library(parent_policy: Dict[str, Any]) -> List[Tuple[str, Dict[str, Any]]]:
    """Build typed mutation candidates from the atom registry/compiler.

    The broad candidate list is generated by openevolve.operator_generator from
    atom_registry.yaml and typed policy skeletons. This process controller remains
    the final sanitizer and semantic de-duplicator before expensive evaluation.
    """
    raw_ops: List[Tuple[str, Dict[str, Any]]] = []
    if build_operator_candidates is not None:
        try:
            raw_ops = build_operator_candidates(parent_policy)
        except Exception as e:
            logger.warning("operator_generator failed; falling back to minimal internal operators: %s", e)
            raw_ops = []
    if not raw_ops:
        spatial = {"atom": "spatial_coverage_preservation", "params": {"grid_size": 4, "min_keep_per_cell": 1}}
        anchor8 = {"atom": "top_relevance_anchor_preservation", "params": {"topk": 8}}
        raw_ops = [
            ("topk_sign_max", _base_topk(transform="rank_norm", sign="max")),
            ("topk_transform_minmax", _base_topk(transform="minmax", fusion_norm="minmax")),
            ("topk_transform_softmax", _base_topk(transform="softmax", fusion_norm="softmax")),
            ("topk_add_spatial", _with_protection(_base_topk(), spatial)),
            ("topk_add_anchor", _with_protection(_base_topk(), anchor8)),
            ("mmr_pairwise_lambda_0p6", _base_mmr(lambda_relevance=0.6)),
            ("dpp_default_minmax_conditional", _base_dpp(q_transform="minmax")),
        ]
    seen = set()
    unique: List[Tuple[str, Dict[str, Any]]] = []
    for name, pol in raw_ops:
        try:
            pol = _sanitize_policy(pol)
            fp = _policy_semantic_fingerprint(pol)
        except Exception as e:
            logger.debug("drop invalid generated operator %s: %s", name, e)
            continue
        if fp in seen:
            continue
        seen.add(fp)
        unique.append((name, pol))
    return unique

def _collect_existing_policy_fingerprints(programs: Dict[str, Program]) -> set:
    fps = set()
    for p in programs.values():
        fp = _policy_fingerprint_from_code(p.code)
        if fp != "invalid":
            fps.add(fp)
    return fps


def _choose_structural_child(
    parent: Program,
    programs: Dict[str, Program],
    iteration: int,
    inspirations: Optional[List[Program]] = None,
) -> Tuple[Optional[str], Optional[Dict[str, Any]], str, Dict[str, Any]]:
    """Choose a child policy.

    V4 first asks an LLM planner to choose a compact JSON plan from atom cards and
    examples. The plan is compiled into executable YAML and de-duplicated by
    semantic fingerprint. If the planner is disabled, unavailable, invalid, or
    duplicate, fall back to deterministic v2 registry operators.
    """
    inspirations = inspirations or []
    parent_policy = _parse_policy_from_code(parent.code) or _base_topk()
    existing = _collect_existing_policy_fingerprints(programs)

    debug: Dict[str, Any] = {
        "llm_planner_enabled": os.environ.get("EVO_V32_LLM_PLANNER", os.environ.get("EVO_V31_LLM_PLANNER", os.environ.get("EVO_V3_LLM_PLANNER", "1"))),
        "llm_attempt": None,
        "fallback": None,
    }

    # EVO_V16_CDPRUNER_SEED_FULL_PERCEPTION_BRANCH
    # v16: start from clean CDPruner baseline and search full-MME perception.
    if os.environ.get("EVO_V16_CDPRUNER_SEED_FULL_PERCEPTION", "0").strip() == "1":
        try:
            from openevolve.v16_cdpruner_seed_full_perception import build_v16_policy_and_program

            child_policy, child_code, meta = build_v16_policy_and_program(
                iteration=iteration,
                parent=parent,
                inspirations=inspirations,
                config=_worker_config,
            )

            op_name = "v16_cdpruner_seed:" + str(meta.get("name", child_policy.get("name", "policy")))

            debug["llm_attempt"] = {
                "error": None,
                "downcompile_note": "v16_cdpruner_seed_full_perception_policy",
                "raw_response": "v16_cdpruner_seed_inline_operator_selection_direct_branch",
                "policy_name": child_policy.get("name"),
                "policy_fp": child_policy.get("policy_fp"),
                "mutation_family": meta.get("mutation_family"),
                "mutation_detail": meta.get("mutation_detail"),
                "aux": meta.get("aux"),
                "feedback_path": meta.get("feedback_path"),
                "last_op": meta.get("last_op"),
                "last_name": meta.get("last_name"),
            }
            debug["fallback"] = None
            debug["ops"] = [op_name]

            return child_code, child_policy, op_name, debug

        except Exception as e:
            debug["llm_attempt"] = {"error": f"v16_cdpruner_seed_inline_direct_exception:{repr(e)}"}
            return None, None, "v16_cdpruner_seed_inline_direct_failed", {**debug, "ops": []}

    # EVO_V15_3_FULL_PERCEPTION_MARGIN_BRANCH
    # v15.3: full-MME perception-only margin-gated exchange search.
    if os.environ.get("EVO_V15_3_FULL_PERCEPTION_MARGIN", "0").strip() == "1":
        try:
            from openevolve.v15_3_full_perception_margin import build_v15_3_policy_and_program

            child_policy, child_code, meta = build_v15_3_policy_and_program(
                iteration=iteration,
                parent=parent,
                inspirations=inspirations,
                config=_worker_config,
            )

            op_name = "v15_3_margin:" + str(meta.get("name", child_policy.get("name", "policy")))

            debug["llm_attempt"] = {
                "error": None,
                "downcompile_note": "v15_3_full_perception_margin_policy",
                "raw_response": "v15_3_margin_inline_operator_selection_direct_branch",
                "policy_name": child_policy.get("name"),
                "policy_fp": child_policy.get("policy_fp"),
                "base_source": meta.get("base_source"),
                "mutation_family": meta.get("mutation_family"),
                "mutation_detail": meta.get("mutation_detail"),
                "selector_name": meta.get("selector_name"),
                "selector_params": meta.get("selector_params"),
                "process_name": meta.get("process_name"),
                "process_params": meta.get("process_params"),
                "weights": meta.get("weights"),
                "feedback_path": meta.get("feedback_path"),
                "last_op": child_policy.get("pipeline", [{}])[-1].get("op"),
                "last_name": child_policy.get("pipeline", [{}])[-1].get("name"),
            }
            debug["fallback"] = None
            debug["ops"] = [op_name]

            return child_code, child_policy, op_name, debug

        except Exception as e:
            debug["llm_attempt"] = {"error": f"v15_3_margin_inline_direct_exception:{repr(e)}"}
            return None, None, "v15_3_margin_inline_direct_failed", {**debug, "ops": []}

    # EVO_V15_2_FULL_PERCEPTION_TARGETED_BRANCH
    # v15.2: full-MME perception-only targeted selector-combination search.
    if os.environ.get("EVO_V15_2_FULL_PERCEPTION_TARGETED", "0").strip() == "1":
        try:
            from openevolve.v15_2_full_perception_targeted import build_v15_2_policy_and_program

            child_policy, child_code, meta = build_v15_2_policy_and_program(
                iteration=iteration,
                parent=parent,
                inspirations=inspirations,
                config=_worker_config,
            )

            op_name = "v15_2_perc:" + str(meta.get("name", child_policy.get("name", "policy")))

            debug["llm_attempt"] = {
                "error": None,
                "downcompile_note": "v15_2_full_perception_targeted_policy",
                "raw_response": "v15_2_perception_targeted_inline_operator_selection_direct_branch",
                "policy_name": child_policy.get("name"),
                "policy_fp": child_policy.get("policy_fp"),
                "base_source": meta.get("base_source"),
                "mutation_family": meta.get("mutation_family"),
                "mutation_detail": meta.get("mutation_detail"),
                "replace_quota": meta.get("replace_quota"),
                "min_reference_keep": meta.get("min_reference_keep"),
                "process_name": meta.get("process_name"),
                "process_params": meta.get("process_params"),
                "weights": meta.get("weights"),
                "feedback_path": meta.get("feedback_path"),
                "last_op": child_policy.get("pipeline", [{}])[-1].get("op"),
                "last_name": child_policy.get("pipeline", [{}])[-1].get("name"),
            }
            debug["fallback"] = None
            debug["ops"] = [op_name]

            return child_code, child_policy, op_name, debug

        except Exception as e:
            debug["llm_attempt"] = {"error": f"v15_2_perception_targeted_inline_direct_exception:{repr(e)}"}
            return None, None, "v15_2_perception_targeted_inline_direct_failed", {**debug, "ops": []}

    # EVO_V15_1_FULL_PERCEPTION_MICRO_BRANCH
    # v15.1: full-MME perception anchor-local micro search.
    if os.environ.get("EVO_V15_1_FULL_PERCEPTION_MICRO", "0").strip() == "1":
        try:
            from openevolve.v15_1_full_perception_micro import build_v15_1_policy_and_program

            child_policy, child_code, meta = build_v15_1_policy_and_program(
                iteration=iteration,
                parent=parent,
                inspirations=inspirations,
                config=_worker_config,
            )

            op_name = "v15_1_micro:" + str(meta.get("name", child_policy.get("name", "policy")))

            debug["llm_attempt"] = {
                "error": None,
                "downcompile_note": "v15_1_full_perception_micro_policy",
                "raw_response": "v15_1_micro_inline_operator_selection_direct_branch",
                "policy_name": child_policy.get("name"),
                "policy_fp": child_policy.get("policy_fp"),
                "base_source": meta.get("base_source"),
                "mutation_family": meta.get("mutation_family"),
                "mutation_detail": meta.get("mutation_detail"),
                "replace_quota": meta.get("replace_quota"),
                "min_reference_keep": meta.get("min_reference_keep"),
                "process_name": meta.get("process_name"),
                "process_params": meta.get("process_params"),
                "weights": meta.get("weights"),
                "feedback_path": meta.get("feedback_path"),
                "last_op": child_policy.get("pipeline", [{}])[-1].get("op"),
                "last_name": child_policy.get("pipeline", [{}])[-1].get("name"),
            }
            debug["fallback"] = None
            debug["ops"] = [op_name]

            return child_code, child_policy, op_name, debug

        except Exception as e:
            debug["llm_attempt"] = {"error": f"v15_1_micro_inline_direct_exception:{repr(e)}"}
            return None, None, "v15_1_micro_inline_direct_failed", {**debug, "ops": []}

    # EVO_V15_FULL_PERCEPTION_BANDIT_BRANCH
    # v15: full-MME perception-driven parent-conditioned local mutation
    # with module-bandit feedback.
    if os.environ.get("EVO_V15_FULL_PERCEPTION_BANDIT", "0").strip() == "1":
        try:
            from openevolve.v15_full_perception_bandit import build_v15_policy_and_program

            child_policy, child_code, meta = build_v15_policy_and_program(
                iteration=iteration,
                parent=parent,
                inspirations=inspirations,
                config=_worker_config,
            )

            op_name = "v15_fullperc:" + str(meta.get("name", child_policy.get("name", "policy")))

            debug["llm_attempt"] = {
                "error": None,
                "downcompile_note": "v15_full_perception_module_bandit_policy",
                "raw_response": "v15_full_perception_inline_operator_selection_direct_branch",
                "policy_name": child_policy.get("name"),
                "policy_fp": child_policy.get("policy_fp"),
                "base_source": meta.get("base_source"),
                "mutation_family": meta.get("mutation_family"),
                "mutation_detail": meta.get("mutation_detail"),
                "replace_quota": meta.get("replace_quota"),
                "min_reference_keep": meta.get("min_reference_keep"),
                "process_name": meta.get("process_name"),
                "process_params": meta.get("process_params"),
                "weights": meta.get("weights"),
                "feedback_path": meta.get("feedback_path"),
                "last_op": child_policy.get("pipeline", [{}])[-1].get("op"),
                "last_name": child_policy.get("pipeline", [{}])[-1].get("name"),
            }
            debug["fallback"] = None
            debug["ops"] = [op_name]

            # _choose_structural_child returns:
            #   child_code, child_policy, op_name, op_debug
            return child_code, child_policy, op_name, debug

        except Exception as e:
            debug["llm_attempt"] = {"error": f"v15_full_perception_inline_direct_exception:{repr(e)}"}
            return None, None, "v15_full_perception_inline_direct_failed", {**debug, "ops": []}

    # EVO_V14C_COUPLED_LOCAL_JOINT_BRANCH
    # v14-C++: jointly search token selection and post-selection token processing.
    # This bypasses the old v10 planner/downcompiler and emits executable POLICY_YAML.
    if os.environ.get("EVO_V14C_COUPLED_JOINT", "0").strip() == "1":
        try:
            from openevolve.v14c_coupled_joint import build_v14c_policy_and_program

            child_policy, child_code, meta = build_v14c_policy_and_program(
                iteration=iteration,
                parent=parent,
                inspirations=inspirations,
                config=_worker_config,
            )

            op_name = "v14c_coupled:" + str(meta.get("name", child_policy.get("name", "policy")))

            debug["llm_attempt"] = {
                "error": None,
                "downcompile_note": "v14c_coupled_local_joint_policy",
                "raw_response": "v14c_coupled_inline_operator_selection_direct_branch",
                "policy_name": child_policy.get("name"),
                "policy_fp": child_policy.get("policy_fp"),
                "replace_quota": meta.get("replace_quota"),
                "min_reference_keep": meta.get("min_reference_keep"),
                "process_name": meta.get("process_name"),
                "process_params": meta.get("process_params"),
                "weights": meta.get("weights"),
                "last_op": child_policy.get("pipeline", [{}])[-1].get("op"),
                "last_name": child_policy.get("pipeline", [{}])[-1].get("name"),
            }
            debug["fallback"] = None
            debug["ops"] = [op_name]

            # _choose_structural_child returns:
            #   child_code, child_policy, op_name, op_debug
            return child_code, child_policy, op_name, debug

        except Exception as e:
            debug["llm_attempt"] = {"error": f"v14c_coupled_inline_direct_exception:{repr(e)}"}
            return None, None, "v14c_coupled_inline_direct_failed", {**debug, "ops": []}

    # EVO_V14B_DIRECT_BRANCH_IN_OPERATOR_SELECTION
    # In v14-B processing-only mode, bypass the old v10 planner/downcompiler
    # at the actual grammar-operator-selection call site.  The old path rejects
    # process_tokens before a child policy can be evaluated.
    if os.environ.get("EVO_V14B_PROCESSING_ONLY", "0").strip() == "1":
        try:
            from openevolve.v14b_processing_only import canonicalize_plan_to_policy

            mode = "exploration"
            plan = _pp_v14b_direct_plan(iteration, mode)
            child_policy = canonicalize_plan_to_policy(plan)

            op_name = "v14b_direct:" + str(child_policy.get("name", plan.get("policy", {}).get("name", "policy")))

            import yaml as _v14b_yaml
            _v14b_policy_yaml = _v14b_yaml.safe_dump(child_policy, sort_keys=False, allow_unicode=True)
            _v14b_program_code = (
                '\"\"\"OpenEvolve candidate program for v14-B processing-only Evo-CDPruner.\n'
                'Generated by v14-B inline direct branch.\n'
                '\"\"\"\n\n'
                'POLICY_YAML = r\"\"\"\n'
                + _v14b_policy_yaml
                + '\n\"\"\"\n\n'
                'def get_policy_yaml():\n'
                '    return POLICY_YAML\n'
            )
            child_policy["__program_code__"] = _v14b_program_code

            debug["llm_attempt"] = {
                "error": None,
                "downcompile_note": "v14b_processing_only_policy",
                "raw_response": "v14b_inline_operator_selection_direct_branch",
                "policy_name": child_policy.get("name"),
                "last_op": child_policy.get("pipeline", [{}])[-1].get("op"),
                "last_name": child_policy.get("pipeline", [{}])[-1].get("name"),
            }
            debug["fallback"] = None
            debug["ops"] = [op_name]

            # _choose_structural_child returns:
            #   child_code, child_policy, op_name, op_debug
            # Therefore the executable Python source must be returned first.
            return _v14b_program_code, child_policy, op_name, debug

        except Exception as e:
            debug["llm_attempt"] = {"error": f"v14b_inline_direct_exception:{repr(e)}"}
            return None, None, "v14b_inline_direct_failed", {**debug, "ops": []}

    if propose_policy_with_llm is not None:
        try:
            plan_result = propose_policy_with_llm(_worker_config, parent, inspirations, iteration)
            llm_debug = {
                "error": plan_result.error,
                "plan": _json_safe(plan_result.plan, max_str=3000),
                "raw_response": _json_safe(plan_result.raw_response, max_str=3000),
                "prompt_preview": _json_safe(plan_result.prompt, max_str=4000),
                "downcompile_note": plan_result.downcompile_note,
            }
            debug["llm_attempt"] = llm_debug
            if plan_result.policy is not None:
                policy = _sanitize_policy(plan_result.policy)
                fp = _policy_semantic_fingerprint(policy)
                llm_debug["fingerprint"] = fp
                if fp not in existing:
                    return _format_policy_program(policy), policy, "llm_json_planner", debug
                llm_debug["duplicate"] = True
        except Exception as e:
            debug["llm_attempt"] = {"error": f"planner_exception:{e}"}
    else:
        debug["llm_attempt"] = {"error": "propose_policy_with_llm_import_failed"}

    ops = _operator_library(parent_policy)
    if not ops:
        return None, None, "no_available_operators", {**debug, "ops": []}
    start = iteration % len(ops)
    ordered = ops[start:] + ops[:start]

    fb = {"num_ops": len(ops), "start": start, "tried": []}
    debug["fallback"] = fb
    for name, policy in ordered:
        fp = _policy_semantic_fingerprint(policy)
        fb["tried"].append({"name": name, "fingerprint": fp})
        if fp in existing:
            continue
        return _format_policy_program(policy), policy, f"fallback:{name}", debug
    return None, None, "all_operator_candidates_duplicate", debug


# ---------------------------------------------------------------------
# Worker iteration
# ---------------------------------------------------------------------


def _run_iteration_worker(iteration: int, db_snapshot: Dict[str, Any], parent_id: str, inspiration_ids: List[str]) -> SerializableResult:
    debug: Dict[str, Any] = {
        "iteration": int(iteration),
        "worker_pid": os.getpid(),
        "events": [],
        "timestamps": {"worker_start_time": time.time()},
        "task": "evo_cdpruner_yaml_policy_search_space_v3_2_atom_first",
    }

    def add_event(name: str, **kwargs: Any) -> None:
        event = {"time": time.time(), "name": name}
        event.update(_json_safe(kwargs))
        debug.setdefault("events", []).append(event)

    try:
        _lazy_init_worker_components()
        add_event("worker_components_ready")

        programs = {pid: Program(**prog_dict) for pid, prog_dict in db_snapshot["programs"].items()}
        if parent_id not in programs:
            return SerializableResult(error=f"Parent id not found in snapshot: {parent_id}", iteration=iteration, debug=debug)

        parent = programs[parent_id]
        inspirations = [programs[pid] for pid in inspiration_ids if pid in programs]
        parent_meta = parent.metadata or {}
        default_island = db_snapshot.get("current_island", 0)
        num_islands = max(1, len(db_snapshot.get("islands", [])))
        try:
            parent_island = int(parent_meta.get("island", default_island))
            if parent_island < 0 or parent_island >= num_islands:
                parent_island = default_island
        except Exception:
            parent_island = default_island

        debug["snapshot"] = {"num_programs": len(programs), "num_islands": num_islands, "current_island": default_island}
        debug["parent"] = _program_brief(parent)
        debug["inspirations"] = [_program_brief(p) for p in inspirations[:10]]

        iteration_start = time.time()
        child_code, child_policy, op_name, op_debug = _choose_structural_child(parent, programs, iteration, inspirations)
        debug["proposal"] = {"operator": op_name, "operator_debug": op_debug, "policy": child_policy or {}}

        if not child_code or not child_policy:
            debug["failure_stage"] = "grammar_operator_selection"
            return SerializableResult(error=f"Failed to generate non-duplicate grammar policy: {op_name}", iteration=iteration, debug=debug)

        child_id = str(uuid.uuid4())
        debug["child_id"] = child_id
        logger.info(
            "Evaluating Evo-CDPruner search-space-v3 YAML child iteration=%s child_id=%s operator=%s parent=%s score=%.4f",
            iteration, child_id, op_name, parent.id, _safe_program_metric(parent, "combined_score"),
        )

        t_eval = time.time()
        child_metrics = asyncio.run(_worker_evaluator.evaluate_program(child_code, child_id))
        eval_time = time.time() - t_eval
        artifacts = _worker_evaluator.get_pending_artifacts(child_id) or {}

        metric_delta = {}
        try:
            for k, v in (child_metrics or {}).items():
                pv = parent.metrics.get(k) if isinstance(parent.metrics, dict) else None
                if isinstance(v, (int, float)) and isinstance(pv, (int, float)):
                    metric_delta[k] = float(v) - float(pv)
        except Exception:
            pass

        debug["evaluation"] = {
            "eval_time_sec": eval_time,
            "child_metrics": _safe_metric_dict(child_metrics),
            "parent_metrics": _safe_metric_dict(parent.metrics),
            "metric_delta": metric_delta,
            "artifact_summary": _artifact_summary(artifacts),
        }

        artifacts.setdefault("yaml_policy_balanced_registry_search_debug", _json_safe(debug, max_str=2500))
        child_program = Program(
            id=child_id,
            code=child_code,
            language=_worker_config.language,
            parent_id=parent.id,
            generation=parent.generation + 1,
            metrics=child_metrics,
            iteration_found=iteration,
            metadata={
                "changes": f"grammar_operator:{op_name}",
                "parent_metrics": parent.metrics,
                "island": parent_island,
                "operator": op_name,
                "parent_code_hash": _code_hash(parent.code),
                "child_code_hash": _code_hash(child_code),
                "child_policy_fingerprint": _policy_semantic_fingerprint(child_policy),
                "task": "evo_cdpruner_yaml_policy_search_space_v3_2_atom_first",
                "yaml_policy_balanced_registry_search_debug": _json_safe(debug, max_str=2500),
            },
        )

        iteration_time = time.time() - iteration_start
        debug["iteration_time_sec"] = iteration_time
        debug["timestamps"]["worker_end_time"] = time.time()
        add_event("worker_success", iteration_time_sec=iteration_time, child_id=child_id)

        prompt = {
            "system": "LLM-guided grammar-constrained Evo-CDPruner YAML policy search.",
            "user": f"Planner/operator {op_name} proposed a typed YAML policy for parent {parent.id}.",
        }

        return SerializableResult(
            child_program_dict=child_program.to_dict(),
            parent_id=parent.id,
            iteration_time=iteration_time,
            prompt=prompt,
            llm_response=json.dumps({"operator": op_name, "policy": child_policy, "proposal_debug": op_debug}, ensure_ascii=False),
            artifacts=artifacts,
            iteration=iteration,
            debug=_json_safe(debug, max_str=2500),
        )

    except Exception as e:
        logger.exception("Error in Evo-CDPruner grammar worker iteration %s", iteration)
        debug["failure_stage"] = "unhandled_exception"
        debug["exception"] = str(e)
        debug["timestamps"]["worker_end_time"] = time.time()
        return SerializableResult(error=str(e), iteration=iteration, debug=_json_safe(debug))


# ---------------------------------------------------------------------
# Process parallel controller
# ---------------------------------------------------------------------


class ProcessParallelController:
    """Process-based parallel evolution controller for typed Evo-CDPruner YAML policies."""

    def __init__(self, config: Config, evaluation_file: str, database: ProgramDatabase):
        self.config = config
        self.evaluation_file = evaluation_file
        self.database = database
        self.executor: Optional[ProcessPoolExecutor] = None
        self.shutdown_event = mp.Event()
        self.num_workers = config.evaluator.parallel_evaluations
        logger.info("Initialized Evo-CDPruner search-space-v4 baseline-anchored residual LLM-planner policy controller with %s workers", self.num_workers)

    def _serialize_config(self, config: Config) -> dict:
        return {
            "llm": {
                "models": [asdict(m) for m in config.llm.models],
                "evaluator_models": [asdict(m) for m in config.llm.evaluator_models],
                "api_base": config.llm.api_base,
                "api_key": config.llm.api_key,
                "temperature": config.llm.temperature,
                "top_p": config.llm.top_p,
                "max_tokens": config.llm.max_tokens,
                "timeout": config.llm.timeout,
                "retries": config.llm.retries,
                "retry_delay": config.llm.retry_delay,
            },
            "prompt": asdict(config.prompt),
            "database": asdict(config.database),
            "evaluator": asdict(config.evaluator),
            "max_iterations": config.max_iterations,
            "checkpoint_interval": config.checkpoint_interval,
            "log_level": config.log_level,
            "log_dir": config.log_dir,
            "random_seed": config.random_seed,
            "diff_based_evolution": config.diff_based_evolution,
            "max_code_length": config.max_code_length,
            "language": config.language,
        }

    def start(self) -> None:
        self.executor = ProcessPoolExecutor(max_workers=self.num_workers, initializer=_worker_init, initargs=(self._serialize_config(self.config), self.evaluation_file))
        logger.info("Started Evo-CDPruner search-space-v4 process pool with %s processes", self.num_workers)

    def stop(self) -> None:
        self.shutdown_event.set()
        if self.executor:
            self.executor.shutdown(wait=True)
            self.executor = None
        logger.info("Stopped Evo-CDPruner search-space-v4 process pool")

    def request_shutdown(self) -> None:
        logger.info("Graceful shutdown requested...")
        self.shutdown_event.set()

    def _create_database_snapshot(self) -> Dict[str, Any]:
        return {
            "programs": {pid: prog.to_dict() for pid, prog in self.database.programs.items()},
            "islands": [list(island) for island in self.database.islands],
            "current_island": self.database.current_island,
            "artifacts": {},
            "snapshot_time": time.time(),
        }

    async def run_evolution(self, start_iteration: int, max_iterations: int, target_score: Optional[float] = None, checkpoint_callback=None):
        if not self.executor:
            raise RuntimeError("Process pool not started")
        total_iterations = start_iteration + max_iterations
        logger.info("Starting Evo-CDPruner search-space-v4 policy evolution from iteration %s for %s iterations", start_iteration, max_iterations)

        pending_futures: Dict[int, Future] = {}
        batch_size = min(self.num_workers * 2, max_iterations)
        for i in range(start_iteration, min(start_iteration + batch_size, total_iterations)):
            future = self._submit_iteration(i)
            if future:
                pending_futures[i] = future
        next_iteration = start_iteration + batch_size
        completed_iterations = 0
        programs_per_island = max(1, max_iterations // (self.config.database.num_islands * 10))
        current_island_counter = 0

        while pending_futures and completed_iterations < max_iterations and not self.shutdown_event.is_set():
            completed_iteration = None
            for iteration, future in list(pending_futures.items()):
                if future.done():
                    completed_iteration = iteration
                    break
            if completed_iteration is None:
                await asyncio.sleep(0.01)
                continue

            future = pending_futures.pop(completed_iteration)
            try:
                result = future.result()
                if result.error:
                    logger.warning("Iteration %s error: %s", completed_iteration, result.error)
                    if result.debug:
                        logger.info("Evo-CDPruner grammar debug failed iteration %s: %s", completed_iteration, _compact_json(result.debug))
                elif result.child_program_dict:
                    child_program = Program(**result.child_program_dict)
                    if result.debug:
                        logger.info("Evo-CDPruner grammar debug iteration %s: %s", completed_iteration, _compact_json(result.debug))
                    if _program_metrics_invalid(child_program.metrics):
                        invalid_path = os.path.join(self.config.log_dir or ".", "invalid_candidates.jsonl")
                        _append_jsonl(invalid_path, {"iteration": completed_iteration, "program": child_program.to_dict(), "metrics": _safe_metric_dict(child_program.metrics), "debug": result.debug, "reason": "invalid_metrics"})
                        logger.warning("Iteration %s produced invalid child; quarantined. metrics=%s", completed_iteration, _safe_metric_dict(child_program.metrics))
                    else:
                        self.database.add(child_program, iteration=completed_iteration)
                        if result.artifacts:
                            self.database.store_artifacts(child_program.id, result.artifacts)
                        if result.prompt:
                            self.database.log_prompt("evo_cdpruner_grammar_operator", child_program.id, result.prompt, [result.llm_response] if result.llm_response else [])

                        if completed_iteration > start_iteration and current_island_counter >= programs_per_island:
                            self.database.next_island()
                            current_island_counter = 0
                        current_island_counter += 1
                        self.database.increment_island_generation()
                        if self.database.should_migrate():
                            logger.info("Performing migration at iteration %s", completed_iteration)
                            self.database.migrate_programs()
                            self.database.log_island_status()

                        logger.info("Iteration %s: Program %s (parent: %s) completed in %.2fs", completed_iteration, child_program.id, result.parent_id, result.iteration_time)
                        if child_program.metrics:
                            metrics_str = ", ".join([f"{k}={v:.4f}" if isinstance(v, (int, float)) else f"{k}={v}" for k, v in child_program.metrics.items()])
                            logger.info("Metrics: %s", metrics_str)
                        if self.database.best_program_id == child_program.id:
                            logger.info("🌟 New best solution found at iteration %s: %s", completed_iteration, child_program.id)
                        if completed_iteration > 0 and completed_iteration % self.config.checkpoint_interval == 0:
                            logger.info("Checkpoint interval reached at iteration %s", completed_iteration)
                            self.database.log_island_status()
                            if checkpoint_callback:
                                checkpoint_callback(completed_iteration)
                        if target_score is not None and child_program.metrics:
                            score = _safe_numeric(child_program.metrics.get("combined_score", child_program.metrics.get("score", 0.0)))
                            if score >= target_score:
                                logger.info("Target score %s reached at iteration %s", target_score, completed_iteration)
                                break
            except Exception as e:
                logger.error("Error processing result from iteration %s: %s", completed_iteration, e)

            completed_iterations += 1
            if next_iteration < total_iterations and not self.shutdown_event.is_set():
                future = self._submit_iteration(next_iteration)
                if future:
                    pending_futures[next_iteration] = future
                    next_iteration += 1

        if self.shutdown_event.is_set():
            for future in pending_futures.values():
                future.cancel()
        logger.info("Evo-CDPruner search-space-v4 policy evolution completed")
        return self.database.get_best_program()

    def _submit_iteration(self, iteration: int) -> Optional[Future]:
        try:
            parent, inspirations = self.database.sample()
            db_snapshot = self._create_database_snapshot()
            logger.info("Submitting Evo-CDPruner grammar iteration %s parent=%s parent_fp=%s inspirations=%s db_programs=%s", iteration, parent.id, _policy_fingerprint_from_code(parent.code), [insp.id for insp in inspirations], len(self.database.programs))
            return self.executor.submit(_run_iteration_worker, iteration, db_snapshot, parent.id, [insp.id for insp in inspirations])
        except Exception as e:
            logger.error("Error submitting iteration %s: %s", iteration, e)
            return None

# ---------------------------------------------------------------------
# v14-B direct process_parallel override
# ---------------------------------------------------------------------
# process_parallel imports/caches the planner entry.  The llm_policy_planner
# standalone test may pass while worker processes still call the old v10
# downcompiler.  In v14-B mode, replace the process_parallel-global
# propose_policy_with_llm directly.

def _pp_v14b_iteration_int_from_call(args, kwargs):
    for key in ["iteration", "iter_idx", "i"]:
        if key in kwargs:
            try:
                return int(kwargs[key])
            except Exception:
                pass
    for x in args:
        try:
            if isinstance(x, int):
                return int(x)
        except Exception:
            pass
    return 0


def _pp_v14b_mode_from_call(args, kwargs):
    mode = kwargs.get("mode", None)
    if mode is None or str(mode).strip().lower() in {"", "none", "null"}:
        mode = "exploration"
    return str(mode)


def _pp_v14b_direct_plan(iteration: int, mode: str):
    sem_alphas = [0.004, 0.006, 0.008, 0.010, 0.012, 0.014, 0.016, 0.020]
    sem_gates = [0.55, 0.60, 0.65, 0.70, 0.75]
    temps = [0.05, 0.07, 0.10]
    neigh = [1, 2, 3]

    specs = []

    for a in sem_alphas:
        for g in sem_gates:
            for t in [1, 2]:
                specs.append((
                    "semantic_gated_residual_merge",
                    {
                        "merge_alpha": a,
                        "top_merge_neighbors": t,
                        "temperature": 0.07,
                        "semantic_gate_threshold": g,
                        "norm_preserve": True,
                    },
                ))

    for a in sem_alphas:
        for t in neigh:
            for temp in temps:
                specs.append((
                    "similarity_weighted_residual_merge",
                    {
                        "merge_alpha": a,
                        "top_merge_neighbors": t,
                        "temperature": temp,
                        "quality_gate_threshold": 0.0,
                        "norm_preserve": True,
                    },
                ))

    for a in [0.004, 0.008, 0.012, 0.016, 0.020]:
        for t in [1, 2]:
            for r in [1.5, 2.0, 3.0]:
                specs.append((
                    "spatial_local_residual_merge",
                    {
                        "merge_alpha": a,
                        "top_merge_neighbors": t,
                        "temperature": 0.07,
                        "spatial_radius": r,
                        "norm_preserve": True,
                    },
                ))

    for b in [0.002, 0.004, 0.006, 0.008, 0.010, 0.014, 0.020]:
        specs.append((
            "score_rescale_selected_features",
            {
                "rescale_beta": b,
                "center_score": True,
                "norm_preserve": True,
            },
        ))

    idx = max(0, int(iteration) - 1) % len(specs)
    proc, params = specs[idx]

    name_bits = []
    for k, v in params.items():
        if isinstance(v, float):
            name_bits.append(f"{k[:3]}{str(v).replace('.', 'p')}")
        elif isinstance(v, int):
            name_bits.append(f"{k[:3]}{v}")

    name = f"v14b_pp_i{iteration:04d}_{proc}_" + "_".join(name_bits[:4])

    return {
        "expected_effect": {
            "perception": "increase",
            "cognition": "preserve",
            "risk": "low",
            "mode": mode,
        },
        "policy": {
            "name": name,
            "process_tokens": {
                "name": proc,
                "params": params,
            },
        },
        "rationale": "v14-B process_parallel direct proposal bypassing old v10 process_tokens validator.",
    }


def _pp_v14b_propose_policy_with_llm(*args, **kwargs):
    from types import SimpleNamespace
    from openevolve.v14b_processing_only import canonicalize_plan_to_policy, build_v14b_prompt

    iteration = _pp_v14b_iteration_int_from_call(args, kwargs)
    mode = _pp_v14b_mode_from_call(args, kwargs)

    plan = _pp_v14b_direct_plan(iteration, mode)
    policy = canonicalize_plan_to_policy(plan)

    return SimpleNamespace(
        policy=policy,
        plan=plan,
        raw_response="v14b_process_parallel_direct_override",
        prompt=build_v14b_prompt(iteration=iteration, mode=mode),
        error=None,
        downcompile_note="v14b_processing_only_policy",
        mode=mode,
    )


if os.environ.get("EVO_V14B_PROCESSING_ONLY", "0").strip() == "1":
    propose_policy_with_llm = _pp_v14b_propose_policy_with_llm
    logger.info("Installed v14-B process_parallel direct planner override")
