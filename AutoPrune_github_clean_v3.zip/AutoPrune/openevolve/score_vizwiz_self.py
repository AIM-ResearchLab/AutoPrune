from pathlib import Path
import json
import re
import string
from collections import Counter

ROOT = Path("/data/lz/openevolve_pruner/CDPruner")

GT_PATH = ROOT / "playground/data/eval/vizwiz/annotations/VQA_test.json"
PRED_PATH = ROOT / "playground/data/eval/vizwiz/answers_upload/llava_test/llava-v1.5-7b/vtn_32_v16_best_1405p1568_vizwiz_seed42.json"

ARTICLES = {"a", "an", "the"}

def normalize_answer(s):
    if s is None:
        return ""
    s = str(s).lower().strip()
    s = s.replace("\n", " ").replace("\t", " ")
    s = re.sub(r"\s+", " ", s)

    # normalize old labels
    if s in {"unsuitable", "unsuitable image", "can't answer", "cannot answer", "not answerable"}:
        s = "unanswerable"

    # remove punctuation
    trans = str.maketrans("", "", string.punctuation)
    s = s.translate(trans)

    words = [w for w in s.split() if w not in ARTICLES]
    return " ".join(words).strip()

def vqa_accuracy(pred, answers):
    pred = normalize_answer(pred)
    gt_answers = [normalize_answer(a.get("answer", "")) for a in answers]
    count = sum(1 for a in gt_answers if a == pred)
    return min(1.0, count / 3.0)

def main():
    if not GT_PATH.exists():
        raise FileNotFoundError(f"Missing GT annotation: {GT_PATH}")
    if not PRED_PATH.exists():
        raise FileNotFoundError(f"Missing prediction file: {PRED_PATH}")

    gt = json.load(open(GT_PATH, "r", encoding="utf-8"))
    pred = json.load(open(PRED_PATH, "r", encoding="utf-8"))

    # GT can be a list of dicts
    gt_by_image = {}
    for item in gt:
        image = item.get("image")
        if image:
            gt_by_image[image] = item

    pred_by_image = {}
    for item in pred:
        image = item.get("image")
        answer = item.get("answer", "")
        if image:
            pred_by_image[image] = answer

    scores = []
    missing = []
    answer_type_scores = {}

    for image, item in gt_by_image.items():
        if image not in pred_by_image:
            missing.append(image)
            continue

        score = vqa_accuracy(pred_by_image[image], item.get("answers", []))
        scores.append(score)

        answer_type = item.get("answer_type", "unknown")
        answer_type_scores.setdefault(answer_type, []).append(score)

    overall = 100.0 * sum(scores) / len(scores) if scores else 0.0

    print("GT:", GT_PATH)
    print("PRED:", PRED_PATH)
    print("GT items:", len(gt_by_image))
    print("Pred items:", len(pred_by_image))
    print("Matched:", len(scores))
    print("Missing:", len(missing))
    print(f"VizWiz VQA accuracy: {overall:.2f}")

    print("\nBy answer_type:")
    for k, vals in sorted(answer_type_scores.items()):
        acc = 100.0 * sum(vals) / len(vals)
        print(f"{k}: {acc:.2f}  n={len(vals)}")

    if missing:
        print("\nFirst missing examples:")
        for x in missing[:10]:
            print(x)

if __name__ == "__main__":
    main()
